import { queryRaw } from "./local_lib/dbhelper";
import { success, createSuccessBody } from "./local_lib/response-lib";
import axios from "axios";
import connectionpynk from "./local_lib/pynkconnection";

export async function getTest() {
  const query = `select * from test`;
  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ queryResult: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getProducts() {
  //ดึงข้อมูล Products จาก DB ของ PYNK
  const query = `select * from products `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ products: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getProductDetail(event) {
  //ดึงข้อมูล Product Detail จาก Zortout
  const { sku } = event.queryStringParameters;

  const apiPath = `https://open-api.zortout.com/v4/Product/GetProducts?searchsku=${sku}`;
  const apiHeaders = {
    headers: {
      storename: "saas@planforfit.com",
      apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
      apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ=",
    },
  };

  try {
    let result;

    await axios
      .get(apiPath, apiHeaders)
      .then((response) => {
        const data = response.data;
        const list = data.list;

        if (list.length > 0) {
          //เช็คว่ามีข้อมูลสินค้า
          // เลือก product ที่ sku ตรงแบบเป๊ะๆ - ต้องมีไม่งั้น api ของ zort จะดึงตัวที่ sku คล้ายๆกันมาด้วย
          const filter_list = list.filter((item) => item.sku === sku)[0];
          result = success(
            createSuccessBody({ message: "success", product: filter_list })
          );
        } else {
          // ไม่มีข้อมูลสินค้า
          result = success(createSuccessBody({ message: "fail" }));
        }
      })
      .catch((error) => {
        // จัดการข้อผิดพลาด
        console.error("Error:", error);
      });

    return result;
  } catch (error) {
    return error;
  }
}

export async function getPynkCoin(event) {
  const { email } = event.queryStringParameters;
  const query = `select pynk_coin from member where email = '${email}' `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ pynk_coin: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getPynkMemberPynkCoin(event) {
  const { email } = event.queryStringParameters;

  try {
    const sql = `select pynk_coin from member WHERE email = '${email}';`;

    // ใช้ Promise เพื่อรอผลลัพธ์จากการ query
    
    const result = await new Promise((resolve, reject) => {
      connectionpynk.query(sql, (error, results, fields) => {
        if (error) {
          console.error('Error select pynk memberinfo: ', error);
          reject(error);
        } else {
          console.log('select pynk memberinfo successfully');
          resolve(results);
        }
      });
      connectionpynk.end();
    });
    return success(createSuccessBody({ message: result }));
  } catch (error) {
    return error;
  }
}


