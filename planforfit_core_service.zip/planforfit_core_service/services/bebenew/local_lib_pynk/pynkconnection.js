const mysql = require('mysql');

// สร้าง connection object
const connectionpynk = mysql.createConnection({
    connectionLimit: 10,
    host: "db.planforfit.com",
    port: 3306,
    user: "admin",
    password: ",kpgvl8b;cv]ruFagva543",
    database: "pynk",
    multipleStatements: true,
    ssl: { rejectUnauthorized: false },
    timezone: "UTC+0",
    dateString: ["DATE", "DATETIME", "TIMESTAMP"],
});

// เชื่อมต่อกับ MySQL Database
connectionpynk.connect((err) => {
  if (err) {
    console.error('Error connecting to Pynk MySQL: ', err);
    return;
  }
  console.log('Connected to Pynk MySQL Database');
});

// export connection object เพื่อให้สามารถนำไปใช้ในไฟล์อื่น ๆ ได้
export default connectionpynk;
// module.exports = connection;