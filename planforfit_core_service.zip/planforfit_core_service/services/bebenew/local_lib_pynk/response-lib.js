export function success2(body) {
    return buildResponse2(200, body);
}

export function createSuccessBody2(results, data) {
    return {results, data};
}


export function createSuccessListBody2(generalAttributes, data) {
    return { ...generalAttributes, data };
}
  
  
export function failure2(body) {
    return buildResponse2(500, body);
}

export function createFailureBody2(error_code, error_message, data) {
    return {error_code, error_message, data};
}

function buildResponse2(statusCode, body) {
    return {
        statusCode: statusCode,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": true
        },
        body: JSON.stringify(body)
    };
}

export function htmlSuccess2(html) {
  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true,
      "Content-Type": "text/html; charset=utf-8"
    },
    body: html
  }
}
  