import AWS from "aws-sdk";
import { failure2, createFailureBody2 } from "./response-lib";

const setupAWS = () => {
  AWS.config.update({ 
      region: 'ap-southeast-1', 
      'accessKeyId': process.env.ACCESS_KEY_ID, 
      'secretAccessKey': process.env.SECRET_KEY 
  });
}

export const getUsers = async () => {
  let continueListing = true;
  let users = [];
  let PaginationToken = "";
  return new Promise(async (resolve, reject) => {
    try {
      while (continueListing) {
        const data = await gotSixtyUsers(PaginationToken);
        users = users.concat(data.Users);
        PaginationToken = data.PaginationToken;
        if ( data.Users.length < 60){
          continueListing = false;
        }
      }
      resolve({Users: users});
    } catch (error) {
      reject(error);
    }
  })
}

const gotSixtyUsers = (PaginationToken) => {
  return new Promise((resolve, reject) => {
      let params;
      if (PaginationToken === "") {
        params = {
          UserPoolId: process.env.USER_POOL_ID,
          Limit: 60
        }
      } else {
        params = {
          UserPoolId: process.env.USER_POOL_ID,
          Limit: 60,
          PaginationToken
        }
      }
      
      setupAWS();
      const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();
      cognitoServiceProvider.listUsers(params, function(error, data) {
          if (error) {
              const errorReturn = failure2(createFailureBody2(error.code , error.sqlMessage));
              reject(errorReturn);
          } else {
              resolve(data);
          }
      });
  });
}

export const getUsersFromGroup = async (GroupName) => {
  let continueListing = true;
  let users = [];
  let NextToken = "";
  return new Promise(async (resolve, reject) => {
    try {
      while (continueListing) {
        const data = await gotSixtyUsersFromGroup(NextToken, GroupName);
        users = users.concat(data.Users);
        NextToken = data.NextToken;
        if ( data.Users.length < 60){
          continueListing = false;
        }
      }
      resolve({Users: users});
    } catch (error) {
      reject(error);
    }
  })
}

const gotSixtyUsersFromGroup = (NextToken, GroupName) => {
  return new Promise((resolve, reject) => {
      let params;
      if (NextToken === "") {
        params = {
          GroupName,
          UserPoolId: process.env.USER_POOL_ID,
          Limit: 60
        }
      } else {
        params = {
          GroupName,
          UserPoolId: process.env.USER_POOL_ID,
          Limit: 60,
          NextToken
        }
      }
      
      setupAWS();
      const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();
      cognitoServiceProvider.listUsersInGroup(params, function(error, data) {
          if (error) {
              const errorReturn = failure2(createFailureBody2(error.code , error.sqlMessage));
              reject(errorReturn);
          } else {
              resolve(data);
          }
      });
  });
}

export const getUser = (Username) => {
    const params = {
        UserPoolId: process.env.USER_POOL_ID,
        Username
    }
    return new Promise((resolve, reject) => {
      setupAWS();
      const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();
      cognitoServiceProvider.adminGetUser(params, function(error, data) {
          if (error) {
              const errorReturn = failure2(createFailureBody2(error.code , error.message));
              reject(errorReturn);
          } else {
              resolve(data);
          }
      });
    });
}

export const updateUserAttributes = (Username, UserAttributes) => {
  return new Promise((resolve, reject) => {
    setupAWS();
    const params = {
      UserAttributes,
      Username,
      UserPoolId: process.env.USER_POOL_ID
    }
    const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();
    cognitoServiceProvider.adminUpdateUserAttributes(params, function(error, data) {
      if (error) {
          const errorReturn = failure2(createFailureBody2(error.code , error.message));
          reject(errorReturn);
      } else {
          resolve(data);
      }
    });
  });
}

export const addUserToGroup = (GroupName, Username) => {
  return new Promise((resolve, reject) => {
    setupAWS();
    const params = {
      GroupName,
      Username,
      UserPoolId: process.env.USER_POOL_ID
    }
    const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();
    cognitoServiceProvider.adminAddUserToGroup(params, function(error, data) {
      if (error) {
          const errorReturn = failure2(createFailureBody2(error.code , error.message));
          reject(errorReturn);
      } else {
          resolve(data);
      }
    });
  });
}

