export const get_resistance_program = () => {
  return {
    WT01: [
      {
        video_id: "00080",
        order: 1,
      },

      {
        video_id: "00039",
        order: 2,
      },
      {
        video_id: "00031",
        order: 3,
      },
      {
        video_id: "00002",
        order: 4,
      },
      {
        video_id: "00008",
        order: 5,
      },
      {
        video_id: "00006",
        order: 6,
      },
      {
        video_id: "00012",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT02: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00038",
        order: 2,
      },
      {
        video_id: "00031",
        order: 3,
      },
      {
        video_id: "00002",
        order: 4,
      },
      {
        video_id: "00011",
        order: 5,
      },
      {
        video_id: "00007",
        order: 6,
      },
      {
        video_id: "00016",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT03: [
      {
        video_id: "00080",
        order: 1,
      },
      {
        video_id: "00040",
        order: 2,
      },
      {
        video_id: "00034",
        order: 3,
      },
      {
        video_id: "00001",
        order: 4,
      },
      {
        video_id: "00010",
        order: 5,
      },
      {
        video_id: "00006",
        order: 6,
      },
      {
        video_id: "00015",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT04: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00039",
        order: 2,
      },
      {
        video_id: "00030",
        order: 3,
      },
      {
        video_id: "00003",
        order: 4,
      },
      {
        video_id: "00009",
        order: 5,
      },
      {
        video_id: "00007",
        order: 6,
      },
      {
        video_id: "00017",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT05: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00038",
        order: 2,
      },
      {
        video_id: "00029",
        order: 3,
      },
      {
        video_id: "00005",
        order: 4,
      },
      {
        video_id: "00011",
        order: 5,
      },
      {
        video_id: "00041",
        order: 6,
      },
      {
        video_id: "00017",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT06: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00040",
        order: 2,
      },
      {
        video_id: "00028",
        order: 3,
      },
      {
        video_id: "00003",
        order: 4,
      },
      {
        video_id: "00008",
        order: 5,
      },
      {
        video_id: "00041",
        order: 6,
      },
      {
        video_id: "00019",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT07: [
      {
        video_id: "00080",
        order: 1,
      },
      {
        video_id: "00038",
        order: 2,
      },
      {
        video_id: "00027",
        order: 3,
      },
      {
        video_id: "00004",
        order: 4,
      },
      {
        video_id: "00010",
        order: 5,
      },
      {
        video_id: "00043",
        order: 6,
      },
      {
        video_id: "00013",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT08: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00039",
        order: 2,
      },
      {
        video_id: "00032",
        order: 3,
      },
      {
        video_id: "00004",
        order: 4,
      },
      {
        video_id: "00009",
        order: 5,
      },
      {
        video_id: "00042",
        order: 6,
      },
      {
        video_id: "00015",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT09: [
      {
        video_id: "00080",
        order: 1,
      },
      {
        video_id: "00026",
        order: 2,
      },
      {
        video_id: "00022",
        order: 3,
      },
      {
        video_id: "00001",
        order: 4,
      },
      {
        video_id: "00008",
        order: 5,
      },
      {
        video_id: "00019",
        order: 6,
      },
      {
        video_id: "00015",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT10: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00024",
        order: 2,
      },
      {
        video_id: "00023",
        order: 3,
      },
      {
        video_id: "00005",
        order: 4,
      },
      {
        video_id: "00010",
        order: 5,
      },
      {
        video_id: "00014",
        order: 6,
      },
      {
        video_id: "00018",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT11: [
      {
        video_id: "00080",
        order: 1,
      },
      {
        video_id: "00025",
        order: 2,
      },
      {
        video_id: "00021",
        order: 3,
      },
      {
        video_id: "00001",
        order: 4,
      },
      {
        video_id: "00009",
        order: 5,
      },
      {
        video_id: "00020",
        order: 6,
      },
      {
        video_id: "00016",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT12: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00022",
        order: 2,
      },
      {
        video_id: "00021",
        order: 3,
      },
      {
        video_id: "00003",
        order: 4,
      },
      {
        video_id: "00011",
        order: 5,
      },
      {
        video_id: "00020",
        order: 6,
      },
      {
        video_id: "00016",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT13: [
      {
        video_id: "00080",
        order: 1,
      },
      {
        video_id: "00024",
        order: 2,
      },
      {
        video_id: "00037",
        order: 3,
      },
      {
        video_id: "00002",
        order: 4,
      },
      {
        video_id: "00008",
        order: 5,
      },
      {
        video_id: "00014",
        order: 6,
      },
      {
        video_id: "00017",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT14: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00025",
        order: 2,
      },
      {
        video_id: "00036",
        order: 3,
      },
      {
        video_id: "00003",
        order: 4,
      },
      {
        video_id: "00010",
        order: 5,
      },
      {
        video_id: "00013",
        order: 6,
      },
      {
        video_id: "00017",
        order: 7,
      },
      {
        video_id: "00082",
        order: 8,
      },
    ],
    WT15: [
      {
        video_id: "00080",
        order: 1,
      },
      {
        video_id: "00023",
        order: 2,
      },
      {
        video_id: "00035",
        order: 3,
      },
      {
        video_id: "00004",
        order: 4,
      },
      {
        video_id: "00011",
        order: 5,
      },
      {
        video_id: "00012",
        order: 6,
      },
      {
        video_id: "00016",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
    WT16: [
      {
        video_id: "00081",
        order: 1,
      },
      {
        video_id: "00026",
        order: 2,
      },
      {
        video_id: "00027",
        order: 3,
      },
      {
        video_id: "00004",
        order: 4,
      },
      {
        video_id: "00009",
        order: 5,
      },
      {
        video_id: "00013",
        order: 6,
      },
      {
        video_id: "00015",
        order: 7,
      },
      {
        video_id: "00083",
        order: 8,
      },
    ],
  };
};
