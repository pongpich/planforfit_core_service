import { query, queryRaw } from "./local_lib/dbhelper";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody,
} from "./local_lib/response-lib";
import { generateVideos, calculateWeekInProgram } from "./util/schedule";
var moment = require("moment-timezone");
moment.tz.setDefault("Asia/Bangkok");

export async function updatePlayTimeLastWeekSelected(event) {
  const {
    user_id,
    start_date,
    expire_date,
    day_number,
    video_number,
    play_time,
    duration,
    week_in_program,
  } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();

  const queryString = ` UPDATE exercise_activity 
                        SET activities = JSON_SET(activities,
                                                    '$[${day_number}][${video_number}].play_time', ${play_time},
                                                    '$[${day_number}][${video_number}].duration', ${duration}
                                          )
                        WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updatePlayTimeLastWeek(event) {
  const {
    user_id,
    start_date,
    expire_date,
    day_number,
    video_number,
    play_time,
    duration,
  } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) {
    //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }
  const lastweek = week - 1;

  const queryString = ` UPDATE exercise_activity 
                        SET activities = JSON_SET(activities,
                                                    '$[${day_number}][${video_number}].play_time', ${play_time},
                                                    '$[${day_number}][${video_number}].duration', ${duration}
                                          )
                        WHERE user_id = '${user_id}' AND week_in_program = ${lastweek};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updatePlayTime(event) {
  const {
    user_id,
    start_date,
    expire_date,
    day_number,
    video_number,
    play_time,
    duration,
  } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) {
    //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }
  const queryString = ` UPDATE exercise_activity 
                        SET activities = JSON_SET(activities,
                                                    '$[${day_number}][${video_number}].play_time', ${play_time},
                                                    '$[${day_number}][${video_number}].duration', ${duration}
                                          )
                        WHERE user_id = '${user_id}' AND week_in_program = ${week};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateVDO(event) {
  const {
    user_id,
    start_date,
    day_number,
    video_number,
    video_id,
    name,
    thumbnail = "",
    rep = 1,
    play_set = 1,
    rest_time = 0,
    duration,
    type = "",
    category,
    clip_gen,
  } = JSON.parse(event.body);
  const weekInProgram = calculateWeekInProgram(start_date);
  const queryString = `UPDATE exercise_activity 
              SET activities = JSON_SET(activities, 
                '$[${day_number}][${video_number}].video_id', '${video_id}',
                '$[${day_number}][${video_number}].name', '${name}',
                '$[${day_number}][${video_number}].thumbnail', '${thumbnail}',
                '$[${day_number}][${video_number}].rep', ${rep},
                '$[${day_number}][${video_number}].play_set', ${play_set},
                '$[${day_number}][${video_number}].rest_time', ${rest_time},
                '$[${day_number}][${video_number}].duration', ${duration},
                '$[${day_number}][${video_number}].type', '${type}',
                '$[${day_number}][${video_number}].category', '${category}',
                '$[${day_number}][${video_number}].clip_gen', '${clip_gen}'
              )
              WHERE user_id = '${user_id}' AND week_in_program = ${weekInProgram};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updatePlaylist(event) {
  const { user_id, start_date, day_number, playlist } = JSON.parse(event.body);

  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    const member = await queryRaw(selectMember);
    const expire_date = member[0].expire_date;
    var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();
    var expireDate = new Date(expire_date).getTime();
    var week;
    if (curr > expireDate) {
      //curr > expire_date คือ หมดอายุ
      week = calculateWeekInProgram(start_date, expire_date);
    } else {
      week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
    }

    const queryString = `UPDATE exercise_activity 
    SET activities = JSON_SET(activities, 
      '$[${day_number}]', CAST('${JSON.stringify(playlist)}' AS JSON)
    )
    WHERE user_id = '${user_id}' AND week_in_program = ${week};`;
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function createWeeklyStayfitProgram(event) {
  const { user_id, start_date, expire_date } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) {
    //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  try {
    const queryString = `
            INSERT INTO exercise_activity SET 
                user_id='${user_id}', week_in_program='${week}', 
                activities= ( 
                              SELECT video_template FROM register_log
                              WHERE user_id = '${user_id}' AND curdate() BETWEEN start_date AND expire_date
                              AND program_id like '%stay_fit%'
                            );
        `;
    let result;
    if (curr > expireDate) {
      //curr > expire_date คือ หมดอายุ
      result = result;
    } else {
      result = await query(queryString);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function createCustomWeekForUser(event) {
  const { user_id, weight, start_date, expire_date } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) {
    //curr > expire_date คือ หมดอายุ
    //เพิ่ม -1 หลัง calculateWeekInProgram เพื่อแก้ปัญหาระบบคำนวนเกินไป 1 week
    week = calculateWeekInProgram(start_date, expire_date) - 1;
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    const member = await queryRaw(selectMember);
    const low_impact =
      member[0].low_impact && member[0].low_impact === "yes" ? true : false;
    const program_level = member[0].program_level;
    const set_phase = member[0].set_phase; // Ex. none, 1, 2, 3, ...n
    const offset = member[0].offset;
    const exercise_type = member[0].exercise_type;

    //ถ้าเป็นผู้ใช้ทั่วไป
    let videosQuery = ` 
    SELECT * FROM vdo_detail;
    `;
    /* if (program_level === "bfr_lv1") {
      //ถ้าเป็นผู้ใช้ bfr_lv1
      videosQuery = `
      SELECT * FROM vdo_detail
      WHERE (category NOT IN ('Main Circuit', 'Sub circuit', 'Cardio', 'Warm Up', 'Cool Down'));
      `;
    }
    if (low_impact) {
      //ถ้าเป็นผู้ใช้ low_impact
      videosQuery = `
      SELECT * FROM vdo_detail
      WHERE (category NOT IN ('Main Circuit', 'Sub circuit', 'Cardio', 'Warm Up', 'Cool Down'));
      `;
    } */
    // test carrot

    if (exercise_type === "bodyweight") {
      //ถ้าเป็นผู้ใช้ bfr_lv1
      videosQuery = `
      SELECT * FROM vdo_detail
      WHERE video_id NOT IN ('00016', '00017', '00018');
      `;
    }
    if (exercise_type === "gym") {
      //ถ้าเป็นผู้ใช้ bfr_lv1
      videosQuery = `
      SELECT * FROM vdo_detail
      WHERE video_id NOT IN ('00012', '00013', '00014','00015','00019');
      `;
    }
    const videos = await queryRaw(videosQuery);
    const schedule = JSON.stringify(
      generateVideos(
        start_date,
        offset,
        weight,
        videos,
        curr > expireDate ? expire_date : null,
        [],
        program_level,
        set_phase,
        week,
        exercise_type
      )
    );
    const queryString = `
            INSERT INTO exercise_activity SET 
                user_id='${user_id}', week_in_program='${week}',
                activities='${schedule}', program_level='${
      !low_impact ? program_level : "lowimp_lv1"
    }';
        `;
    let result;
    if (curr > expireDate) {
      //curr > expire_date คือ หมดอายุ
      result = await query(queryString);
    } else {
      result = await query(queryString);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function getAllExerciseActivity(event) {
  const { user_id } = event.queryStringParameters;

  const selectAllExerciseActivity = `
   select * from exercise_activity 
   where user_id = '${user_id}'
  `;

  try {
    let result;

    const resultAllExerciseActivity = await queryRaw(selectAllExerciseActivity);

    result = success(
      createSuccessBody({ all_exercise_activity: resultAllExerciseActivity })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function videoListForUserLastWeek(event) {
  const { user_id, weight, start_date, expire_date } =
    event.queryStringParameters;
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;

  const selectMember = `
   select * from member
   where user_id = '${user_id}'
   `;

  if (curr > expireDate) {
    //curr > expire_date คือ หมดอายุ
    //เพิ่ม -1 หลัง calculateWeekInProgram เพื่อแก้ปัญหาระบบคำนวนเกินไป 1 week
    week = calculateWeekInProgram(start_date, expire_date) - 1;
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }
  const lastweek = week - 1;

  const queryString = `select week_in_program, activities from exercise_activity where user_id='${user_id}' 
                        AND week_in_program='${lastweek}'`;

  const selectExerciseActivity = `
    select * from exercise_activity 
    where user_id = '${user_id}'
  `;

  try {
    const member = await queryRaw(selectMember);
    const low_impact =
      member[0].low_impact && member[0].low_impact === "yes" ? true : false;
    const program_level = member[0].program_level;
    const set_phase = member[0].set_phase; // Ex. none, 1, 2, 3, ...n
    const offset = member[0].offset;
    const exercise_type = member[0].exercise_type;

    let queryResult = await query(queryString);
    let result;
    let bodyLength = JSON.parse(queryResult.body);

    //ถ้าเป็นผู้ใช้ทั่วไป
    let videosQuery = ` 
      SELECT * FROM vdo_detail;
      `;
    if (program_level === "bfr_lv1") {
      //ถ้าเป็นผู้ใช้ bfr_lv1
      videosQuery = `
        SELECT * FROM vdo_detail
        WHERE (tag LIKE '%low_impact, beginner%')
        OR (category NOT IN ('Main Circuit', 'Sub circuit', 'Cardio', 'Warm Up', 'Cool Down'));
        `;
    }
    if (low_impact) {
      //ถ้าเป็นผู้ใช้ low_impact
      videosQuery = `
      SELECT * FROM vdo_detail
      WHERE (tag LIKE '%low_impact%')
      OR (category NOT IN ('Main Circuit', 'Sub circuit', 'Cardio', 'Warm Up', 'Cool Down'));
      `;
    }
    const videos = await queryRaw(videosQuery);
    const schedule = JSON.stringify(
      generateVideos(
        start_date,
        offset,
        weight,
        videos,
        curr > expireDate ? expire_date : null,
        [],
        program_level,
        set_phase,
        lastweek,
        exercise_type
      )
    );
    const queryStringVideo = `
              INSERT INTO exercise_activity SET 
                  user_id='${user_id}', week_in_program='${lastweek}', 
                  activities='${schedule}', program_level='${
      !low_impact ? program_level : "lowimp_lv1"
    }';
          `;
    if (curr > expireDate) {
      //curr > expire_date คือ หมดอายุ
      //เช็คว่าถ้าเป็นผู้ใช้ที่หมดอายุแล้ว ให้เช็คว่ามี lastweek หรือยัง ถ้ายังไม่มีค่อย insert
      if (bodyLength.results.length <= 0) {
        await query(queryStringVideo);
      }
    } else {
      const resultExerciseActivity = await queryRaw(selectExerciseActivity);
      let availableWeek = []; //ใช้เก็บสัปดาห์ที่มีอยู่
      let lostWeek = []; //ใช้เก็บสัปดาห์ที่หายไป
      const mapExerciseActivityResult = resultExerciseActivity.map(
        (item, index) => {
          availableWeek.push(item.week_in_program);
        }
      );
      console.log("availableWeek :", availableWeek);
      for (let i = 1; i <= lastweek; i++) {
        if (availableWeek.includes(i)) {
          console.log(`${i} เป็นสมาชิกในอาร์เรย์`);
        } else {
          console.log(`${i} ไม่เป็นสมาชิกในอาร์เรย์`);
          if (i <= week) {
            lostWeek.push(i);
          }
        }
      }
      console.log("lostWeek :", lostWeek);
      let valuesString = "";

      const mapLostWeek = lostWeek.map((item, index) => {
        const itemWeek = item;
        const diffCurrWeek = week - itemWeek >= 0 ? week - itemWeek : 0; //เช็คป้องกัน week ปัจจุบันน้อยกว่าในระบบ แล้วอาจเกิดบัค

        //ต้องเพิ่มให้การ Schedule ย้อนหลังทำตามถูก phase ด้วย โดยใช้วิธีการ offset + (7 * diffCurrWeek)
        const itemSchedule = JSON.stringify(
          generateVideos(
            start_date,
            offset + 7 * diffCurrWeek,
            weight,
            videos,
            null,
            [],
            program_level,
            set_phase,
            lastweek,
            exercise_type
          )
        );
        if (index + 1 === lostWeek.length) {
          //เช็คว่าถ้าเป็นสมาชิกตัวสุดท้าย
          valuesString =
            valuesString +
            `( '${user_id}', ${itemWeek}, '${itemSchedule}', '${
              !low_impact ? program_level : "lowimp_lv1"
            }' )`;
        } else {
          valuesString =
            valuesString +
            `( '${user_id}', ${itemWeek}, '${itemSchedule}', '${
              !low_impact ? program_level : "lowimp_lv1"
            }' ),`;
        }
      });

      const insertExerciseActivitySQL = `
             insert into exercise_activity(user_id, week_in_program, activities, program_level) 
             values
             ${valuesString}
           `;

      if (lostWeek.length > 0) {
        await query(insertExerciseActivitySQL);
      }
    }

    result = queryResult;
    return result;
  } catch (error) {
    return error;
  }
}

export async function videoListForUser(event) {
  const { user_id, weight, start_date, expire_date, offset } =
    event.queryStringParameters;
  var currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;

  if (curr > expireDate) {
    //curr > expire_date คือ หมดอายุ
    //เพิ่ม -1 หลัง calculateWeekInProgram เพื่อแก้ปัญหาระบบคำนวนเกินไป 1 week
    week = calculateWeekInProgram(start_date, expire_date) - 1;
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  const queryString = `select week_in_program, activities from exercise_activity where user_id='${user_id}' 
                        AND week_in_program='${week}'`;
  try {
    let queryResult = await query(queryString);
    let result;
    let bodyLength = JSON.parse(queryResult.body);

    if (bodyLength.results.length <= 0) {
      result = success(createSuccessBody({ message: "no_video" }));
    } else {
      result = queryResult;
    }
    return result;
  } catch (error) {
    return error;
  }
}

async function randomBraveAndBurnVideo() {
  const selectRandomSQL = `
    select * from vdo_detail
    where category = 'Cardio' or category = 'Sub Circuit'
    `;

  const randomResult = await queryRaw(selectRandomSQL);

  // สุ่มตัวเลขระหว่าง 0 ถึง จำนวนวีดีโอทั้งหมด - 1
  const randomIndex = Math.floor(Math.random() * randomResult.length);

  // เลือกวีดีโอที่สุ่มได้
  const selectedVideo = randomResult[randomIndex];
  return selectedVideo;
}

export async function createBraveAndBurnChallenge(event) {
  const { user_id } = JSON.parse(event.body);

  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  let result;
  try {
    const member = await queryRaw(selectMember);
    const start_date = member[0].start_date;
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน

    const randomVideo = await randomBraveAndBurnVideo();

    const insertSQL = `
        insert into brave_and_burn_challenge
        set user_id = '${user_id}', week = ${week}, video = '${JSON.stringify(
      randomVideo
    )}'
    `;
    if (week <= 8) {
      await query(insertSQL);
      result = success(createSuccessBody({ message: "success" }));
    } else {
      result = success(createSuccessBody({ message: "fail" }));
    }
    return result;
  } catch (error) {
    result = success(createSuccessBody({ message: "fail" }));
    return result;
  }
}

export async function getBraveAndBurnChallenge(event) {
  const { user_id } = event.queryStringParameters;
  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  let result;
  try {
    const member = await queryRaw(selectMember);
    const start_date = member[0].start_date;
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน

    const selectSQL = `
    select * from brave_and_burn_challenge
    where  user_id = '${user_id}' and week = ${week}
    `;
    const queryResult = await queryRaw(selectSQL);
    console.log("queryResult :", queryResult);
    if (queryResult.length > 0) {
      result = success(
        createSuccessBody({
          message: "success",
          brave_and_burn_challenge: queryResult[0],
        })
      );
    } else {
      result = success(createSuccessBody({ message: "fail" }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateVideoStatusBraveAndBurn(event) {
  const { user_id } = JSON.parse(event.body);
  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  let result;
  try {
    const member = await queryRaw(selectMember);
    const start_date = member[0].start_date;
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน

    const updateSQL = `
    update brave_and_burn_challenge
    set video_status = 'success'
    where user_id = '${user_id}' and week = ${week}
    `;
    await query(updateSQL);
    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateFbShareStatusBraveAndBurn(event) {
  const { user_id } = JSON.parse(event.body);
  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  let result;
  try {
    const member = await queryRaw(selectMember);
    const start_date = member[0].start_date;
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน

    const updateSQL = `
    update brave_and_burn_challenge
    set facebook_share_status = 'success'
    where user_id = '${user_id}' and week = ${week}
    `;
    await query(updateSQL);
    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function randomVideo(event) {
  const { video_id, category, type, user_id } = event.queryStringParameters;
  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    const member = await queryRaw(selectMember);
    const low_impact =
      member[0] && member[0].low_impact && member[0].low_impact === "yes"
        ? true
        : false;
    const program_level = member[0] && member[0].program_level;
    console.log("program_level :", program_level);

    //กรณีผู้ใช้ทั่วไป - bfr_lv2 (standard) ไม่เอาคลิป low_impact เลย
    let query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND type='${type}' AND (tag not like '%low_impact%' OR tag IS NULL) `;

    //กรณีผู้ใช้ทั่วไป - bfr_lv1 (beginner) ไม่เอาคลิป low_impact เลย
    if (program_level === "bfr_lv1") {
      query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND type='${type}' AND (tag like '%beginner%') `;
    }

    if (low_impact) {
      //กรณีผู้ใช้ low_impact
      //ถ้าเป็นหมวดหมู่  'Main Circuit', 'Sub circuit', 'Cardio', 'warm up', 'cool down' คัดเอาแต่คลิป low_impact
      if (
        category.toLowerCase() === "main circuit" ||
        category.toLowerCase() === "sub circuit" ||
        category.toLowerCase() === "cardio" ||
        category.toLowerCase() === "warm up" ||
        category.toLowerCase() === "cool down"
      ) {
        query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND type='${type}'  AND (tag LIKE '%low_impact%')`;
      } else {
        //ถ้าเป็นหมวดหมู่ที่เหลือจากข้างต้น เอาอะไรก็ได้ เพราะไม่มี low_impact
        query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND type='${type}'`;
      }
    }
    const queryResult = await queryRaw(query);
    queryResult.sort(() => Math.random() - 0.5);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: "no_video" }));
    } else {
      result = success(createSuccessBody({ video: queryResult[0] }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectChangeVideo(event) {
  const { video_id, category, type, user_id, exr_position } =
    event.queryStringParameters;
  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    const member = await queryRaw(selectMember);
    const low_impact =
      member[0] && member[0].low_impact && member[0].low_impact === "yes"
        ? true
        : false;
    const program_level = member[0] && member[0].program_level;
    console.log("program_level :", program_level);

    let query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}'`;

    if (category === "Resistance") {
      query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND exr_position = ${exr_position} `;
    }

    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: "no_video" }));
    } else {
      result = success(createSuccessBody({ videos: queryResult }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function deleteProgramInWeek(event) {
  //Adminใช้ลบโปรแกรมออกกำลังกายในสัปดาห์นั้นของผู้ใช้ เพื่อให้ผู้ใช้ได้กรอกข้อมูลใหม่ เช่น กรณีกรอก นน. ผิด
  const { email } = JSON.parse(event.body);
  const selectStartDateSQL = ` SELECT start_date FROM member WHERE email='${email}';`;
  const selectStartDateResult = await queryRaw(selectStartDateSQL);
  const start_date = selectStartDateResult[0].start_date;

  const week = calculateWeekInProgram(start_date);

  const deleteProgramInWeekSQL = `  DELETE FROM exercise_activity 
                                    WHERE user_id=(SELECT user_id FROM member WHERE email='${email}') 
                                    AND week_in_program='${week}';`;

  const updateOtherAttributeSQL = ` UPDATE member
                                    SET other_attributes = NULL
                                    WHERE email = '${email}' ;`;

  try {
    await queryRaw(deleteProgramInWeekSQL);
    if (week === 1) {
      //ถ้าเป็นสัปดาห์แรก ให้Update OtherAttribute = NULL ด้วย
      await queryRaw(updateOtherAttributeSQL);
    }
  } catch (error) {
    return error;
  }
}

export async function selectProgramInWeek(event) {
  //Adminใช้ดูโปรแกรมออกกำลังกายในสัปดาห์นั้นของผู้ใช้
  const { email } = event.queryStringParameters;
  const selectStartDateSQL = ` SELECT start_date FROM member WHERE email='${email}';`;
  const selectStartDateResult = await queryRaw(selectStartDateSQL);
  const start_date = selectStartDateResult[0].start_date;

  const week = calculateWeekInProgram(start_date);

  const selectProgramInWeekSQL = `  SELECT * FROM exercise_activity 
                                    WHERE user_id=(SELECT user_id FROM member WHERE email='${email}') 
                                    AND week_in_program='${week}';`;
  try {
    let result;
    const selectProgramInWeekResult = await queryRaw(selectProgramInWeekSQL);
    const programInWeek = selectProgramInWeekResult[0];
    result = success(createSuccessBody({ programInWeek: programInWeek }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectMemberInfo(event) {
  //Admin ใช้ดูข้อมูลของผู้ใช้คนนั้นๆ
  const { email } = event.queryStringParameters;

  const selectMemberInfoSQL = ` SELECT * FROM member 
                                WHERE user_id=(SELECT user_id FROM member WHERE email='${email}');`;

  try {
    let result;
    const selectMemberInfoResult = await queryRaw(selectMemberInfoSQL);
    const memberInfo = selectMemberInfoResult[0];
    result = success(createSuccessBody({ memberInfo: memberInfo }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectBodyInfo(event) {
  //Admin ใช้ดูข้อมูล Body Info ในแต่ละ week ของผู้ใช้
  const { email } = event.queryStringParameters;

  const selectBodyInfoSQL = ` SELECT week_in_program, body_info FROM exercise_activity 
                              WHERE user_id=(SELECT user_id FROM member WHERE email='${email}');`;

  try {
    let result;
    const selectBodyInfoResult = await queryRaw(selectBodyInfoSQL);
    const bodyInfo = selectBodyInfoResult;
    result = success(createSuccessBody({ bodyInfo: bodyInfo }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function randomExerciseSnacksVideo(event) {
  const selectRandomSQL = `
  SELECT * FROM vdo_exercise_snack
  ORDER BY RAND()
  LIMIT 7;
`;
  const randomResult = await queryRaw(selectRandomSQL);
  return randomResult;
}

export async function createExerciseSnacksChallenge(event) {
  const { user_id } = JSON.parse(event.body);

  const selectMember = `
  select * from member
  where user_id = '${user_id}'
  `;

  let result;
  try {
    const member = await queryRaw(selectMember);
    const start_date = member[0].start_date;
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน

    const queryString = `select week from snack_activity where user_id='${user_id}'`;
    const weekResult = await queryRaw(queryString);

    let availableWeek = []; //ใช้เก็บสัปดาห์ที่มีอยู่
    let lostWeek = []; //ใช้เก็บสัปดาห์ที่หายไป
    const mapExerciseActivityResult = weekResult.map((item, index) => {
      availableWeek.push(item.week);
    });

    for (let i = 1; i <= week; i++) {
      if (availableWeek.includes(i)) {
        /*         console.log(`${i} เป็นสมาชิกในอาร์เรย์`); */
      } else {
        if (i <= week) {
          lostWeek.push(i);
        }
      }
    }

    if (week <= 8) {
      for (const weekValue of lostWeek) {
        const randomVideo = await randomExerciseSnacksVideo();
        const insertSQL = `
    insert into snack_activity
    set user_id = '${user_id}', video = '${JSON.stringify(randomVideo)}'
    `;
        const fullInsertSQL = `${insertSQL}, week = ${weekValue}`;
        await query(fullInsertSQL);
      }
      result = success(createSuccessBody({ message: "success" }));
    } else {
      result = success(createSuccessBody({ message: "fail" }));
    }
    return result;
  } catch (error) {
    result = success(createSuccessBody({ message: "fail" }));
    return result;
  }
}

export async function getExerciseSnacksChallenge(event) {
  const { user_id, week } = event.queryStringParameters;

  let result;
  try {
    const queryString = `select * from snack_activity where user_id='${user_id}' AND week='${week}'`;

    const exercise_snack = await queryRaw(queryString);
    console.log("user_id", user_id);
    console.log("exercise_snack", exercise_snack);

    result = success(createSuccessBody({ exerciseSnack: exercise_snack }));
  } catch (error) {
    result = success(createSuccessBody({ message: "fail" }));
  }
  return result;
}

export async function getExerciseSnacksChallengeAll(event) {
  const { user_id } = event.queryStringParameters;

  let result;
  try {
    const queryString = `select * from snack_activity where user_id='${user_id}'`;

    const exercise_snack = await queryRaw(queryString);
    console.log("user_id", user_id);
    console.log("exercise_snack", exercise_snack);

    result = success(
      createSuccessBody({ message: "success", exerciseSnack: exercise_snack })
    );
  } catch (error) {
    result = success(createSuccessBody({ message: "fail" }));
  }
  return result;
}

export async function getExerciseSnacksChallengeLog(event) {
  const { user_id, week } = event.queryStringParameters;

  let result;
  try {
    /* const queryString = `select * from member_event_log where user_id='${user_id}'`; */
    const queryString = `SELECT * FROM member_event_log WHERE user_id='${user_id}' AND log LIKE '%random exercise snacks%'`;

    const exercise_snack = await queryRaw(queryString);
    console.log("user_id", user_id);
    console.log("exercise_snack", exercise_snack);

    result = success(createSuccessBody({ exerciseSnack: exercise_snack }));
  } catch (error) {
    result = success(createSuccessBody({ message: "fail" }));
  }
  return result;
}

export async function updateVideoSnack(event) {
  const { data, id } = JSON.parse(event.body);

  let result;
  try {
    const updateSQL = `update snack_activity set video = '${JSON.stringify(
      data
    )}' where id = '${id}'`;
    await query(updateSQL);
    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getVideoSnack(event) {
  const { user_id, week } = event.queryStringParameters;

  /*  const queryStringActivity = `select * from snack_activity where user_id='${user_id}' AND week='${week}'`;
  const exercise_snack = await queryRaw(queryStringActivity);
  let video = exercise_snack && JSON.parse(exercise_snack[0].video);

  const videoIdsArray = video.map((item) => item.video_id); */

  try {
    /*  const queryString = `SELECT * FROM vdo_exercise_snack WHERE FIND_IN_SET(video_id, '${videoIdsArray.join(
      ","
    )}') = 0`; */
    const queryString = `SELECT * FROM vdo_exercise_snack`;
    const exercise_snack = await queryRaw(queryString);

    const result = success(
      createSuccessBody({ exerciseSnack: exercise_snack })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function createEventLogSnacks(event) {
  const { user_id, snacks_number, week } = JSON.parse(event.body);

  const selectMember = `
  select * from member_event_log
  where user_id = '${user_id}' AND  log_week = '${week}' AND count_snack ='${snacks_number}'
  `;
  const member = await queryRaw(selectMember);

  const score_snack =
    snacks_number == "4"
      ? "10.00"
      : snacks_number == "5"
      ? "2.00"
      : snacks_number == "6"
      ? "3.00"
      : snacks_number == "7" && "5.00";

  let result;
  try {
    const insertSQL = `
        insert into member_event_log
        set user_id = '${user_id}', log = 'random exercise snacks ${snacks_number}',log_value = '0', log_type ='individual',count_snack ='${snacks_number}',log_week ='${week}', score = '${score_snack}'
    `;
    if (member.length == 0) {
      await query(insertSQL);
      result = success(createSuccessBody({ message: "success" }));
    }

    return result;
  } catch (error) {
    result = success(createSuccessBody({ message: "fail 2" }));
    return result;
  }
}
