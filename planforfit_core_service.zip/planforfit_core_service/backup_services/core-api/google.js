import { success } from "./local_lib/response-lib";
const { google } = require('googleapis');

const auth = new google.auth.GoogleAuth({
  credentials: {
    "type": "service_account",
    "project_id": "root-rarity-356012",
    "private_key_id": "90659528d768d855b542d73005989944803204f1",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC4fdSnQ7oYvvh5\niu8sxgTeTn22zIccMcb6HyGAwu3upvGUnXd1ESsmqG9r0Ox0FU/jMra73SzvbEfe\nFLofZArdKbqvFbXSK5BQVJXrtRKM/pvBVorgQPc+t0yxT4wWqzPJYhCBvgdTFCYd\nWKa9MZOyMpmKVxhX7yhZUMOaXZt/Zypj9dKI73G6VljXgCrbjxiGnBSWOnRSWmd8\nRGNV7dfTmKIV4TJMQtFmH5OuAvZ2xrlZkE9WI4uFEfk8JYSR4mlFTQeHVKjKUZM4\nz0fE+Ns3Tw9dq0HIv2Ca3AOqgcm+HYAWGqzMv2SpBIWgHIyoyXhqUOXqinf11Pa4\nvNrr9YQxAgMBAAECggEAMC8pBaCCL6lc4v2e1u5G4jrUyZPka8AybCwKR4NhuhVe\n/gYcZ3Za80dFhn6z6uOQEFIz+J/c9xEsOfvm2oD592ZJLCY67Q/Uqq5U05FgrXNo\nAZhVQBmnmXktLhgNCfSf22Zh0kjrx8543+xB7CLRJNbjVAbIRFshiiY2WBA/pwe8\nd3zH5egbRrpZYMkkmltr8vulFajsKEuDWgyMoSuVPQ9XMN/lYu9pN/6miVQ6Q1xh\nMK0xuhgMQLO6Q2moryg61ttnf38EOEYxYh9drcP+/lrCpPuTNkkEvITOoPTdY18n\nEJtPb1LvDCzbunttDGIzh+39+IG8CCiP7nQEeULjIwKBgQDo3pNcWDdPsemd4n5t\nDydUJNSoxMS9aXG0vMu+goiBHXharR651DBfnmwB2DJWDRo5bqOLNyzSoyaOyBuf\nppD9xpbn0TMK4muPyTeiEXO0z9hQK4/0NLY5jz0b7wHYR/JEcQ0ok7bs7jlTwjqb\nq0JgwZM6GzWriMCnvG/gJ16KLwKBgQDK0RjqZ9klc/GjXIbW5SpI2BbxZWZ2NoPL\nDRDxBHq2cdtTloJ/mxC+nqA3OPyFpalZwXmiO6sXIEXXoeNwpsZEKn8E+n8ZHoUy\n4VEKmibNNt3wJOeHXyG7oORHJlzjTUj/PV6y5kRHrGCSk6UAWIpr5hGo7kmros0R\n+JHibB4fnwKBgFtzNTm5pxcUDmOjk/SuU8qWoDEa/QxJgY7x6a2KQ6M4+I/blspx\niwGyDEZ5KeNjR94wFefRJjgePEEsUrTSy/PtbkvhewMWQhl4cvGhmufyC8gII4NK\nxBk8qEn1BatzLbA1GW7K+7Z2I2tCRpPloK6wtmnGT8BqdwYoWWMU8uqfAoGADDVk\nA5A2wQtmq0fBkiP/VJ01XFiXP1xuuIVT1L5JSLw30KNJvbau3lqcGFbk1IKxXAbK\ndJqU5PJ7YcyL7VcMrkPEm58ckX2F1Rc9Ep9O4KGB4JfIHBz84deAhkvn4YLgdwTR\ns4Eq8QmOUqRylT+/LVmPDJUzeBJ3t7I3zeJmOc8CgYEAmk3VA7r3nu0HzKeo4bF6\nEGWkz9Gln8PE0mbl+8VbnLYu+UL+ipxra6SKIVDJLaS+CAr+/D7fVTmhFRoaHLaa\n2TvyIORVvJgfogOcNP+yGgZgii0C2KopzPXqgRcTKIzmrVXy40jdnoEmQwKyJvzS\nqkIOn77REZFrMAhlbeo6qNA=\n-----END PRIVATE KEY-----\n",
    "client_email": "akkewacheiei@root-rarity-356012.iam.gserviceaccount.com",
    "client_id": "109718169437483981766",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/akkewacheiei%40root-rarity-356012.iam.gserviceaccount.com"
  },
  scopes: "https://www.googleapis.com/auth/spreadsheets",
});

export async function appendRow(event) { //ต้องปรับสิทธิ์ใน gg sheet เป็น anyone - editor
  const {
    spreadsheetId,
    data
  } = JSON.parse(event.body);

  const auth = new google.auth.GoogleAuth({
    credentials: {
      "type": "service_account",
      "project_id": "root-rarity-356012",
      "private_key_id": "90659528d768d855b542d73005989944803204f1",
      "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC4fdSnQ7oYvvh5\niu8sxgTeTn22zIccMcb6HyGAwu3upvGUnXd1ESsmqG9r0Ox0FU/jMra73SzvbEfe\nFLofZArdKbqvFbXSK5BQVJXrtRKM/pvBVorgQPc+t0yxT4wWqzPJYhCBvgdTFCYd\nWKa9MZOyMpmKVxhX7yhZUMOaXZt/Zypj9dKI73G6VljXgCrbjxiGnBSWOnRSWmd8\nRGNV7dfTmKIV4TJMQtFmH5OuAvZ2xrlZkE9WI4uFEfk8JYSR4mlFTQeHVKjKUZM4\nz0fE+Ns3Tw9dq0HIv2Ca3AOqgcm+HYAWGqzMv2SpBIWgHIyoyXhqUOXqinf11Pa4\nvNrr9YQxAgMBAAECggEAMC8pBaCCL6lc4v2e1u5G4jrUyZPka8AybCwKR4NhuhVe\n/gYcZ3Za80dFhn6z6uOQEFIz+J/c9xEsOfvm2oD592ZJLCY67Q/Uqq5U05FgrXNo\nAZhVQBmnmXktLhgNCfSf22Zh0kjrx8543+xB7CLRJNbjVAbIRFshiiY2WBA/pwe8\nd3zH5egbRrpZYMkkmltr8vulFajsKEuDWgyMoSuVPQ9XMN/lYu9pN/6miVQ6Q1xh\nMK0xuhgMQLO6Q2moryg61ttnf38EOEYxYh9drcP+/lrCpPuTNkkEvITOoPTdY18n\nEJtPb1LvDCzbunttDGIzh+39+IG8CCiP7nQEeULjIwKBgQDo3pNcWDdPsemd4n5t\nDydUJNSoxMS9aXG0vMu+goiBHXharR651DBfnmwB2DJWDRo5bqOLNyzSoyaOyBuf\nppD9xpbn0TMK4muPyTeiEXO0z9hQK4/0NLY5jz0b7wHYR/JEcQ0ok7bs7jlTwjqb\nq0JgwZM6GzWriMCnvG/gJ16KLwKBgQDK0RjqZ9klc/GjXIbW5SpI2BbxZWZ2NoPL\nDRDxBHq2cdtTloJ/mxC+nqA3OPyFpalZwXmiO6sXIEXXoeNwpsZEKn8E+n8ZHoUy\n4VEKmibNNt3wJOeHXyG7oORHJlzjTUj/PV6y5kRHrGCSk6UAWIpr5hGo7kmros0R\n+JHibB4fnwKBgFtzNTm5pxcUDmOjk/SuU8qWoDEa/QxJgY7x6a2KQ6M4+I/blspx\niwGyDEZ5KeNjR94wFefRJjgePEEsUrTSy/PtbkvhewMWQhl4cvGhmufyC8gII4NK\nxBk8qEn1BatzLbA1GW7K+7Z2I2tCRpPloK6wtmnGT8BqdwYoWWMU8uqfAoGADDVk\nA5A2wQtmq0fBkiP/VJ01XFiXP1xuuIVT1L5JSLw30KNJvbau3lqcGFbk1IKxXAbK\ndJqU5PJ7YcyL7VcMrkPEm58ckX2F1Rc9Ep9O4KGB4JfIHBz84deAhkvn4YLgdwTR\ns4Eq8QmOUqRylT+/LVmPDJUzeBJ3t7I3zeJmOc8CgYEAmk3VA7r3nu0HzKeo4bF6\nEGWkz9Gln8PE0mbl+8VbnLYu+UL+ipxra6SKIVDJLaS+CAr+/D7fVTmhFRoaHLaa\n2TvyIORVvJgfogOcNP+yGgZgii0C2KopzPXqgRcTKIzmrVXy40jdnoEmQwKyJvzS\nqkIOn77REZFrMAhlbeo6qNA=\n-----END PRIVATE KEY-----\n",
      "client_email": "akkewacheiei@root-rarity-356012.iam.gserviceaccount.com",
      "client_id": "109718169437483981766",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/akkewacheiei%40root-rarity-356012.iam.gserviceaccount.com"
    },
    scopes: "https://www.googleapis.com/auth/spreadsheets",
  });
  const googleSheets = google.sheets({ version: "v4" });
  try {

    await googleSheets.spreadsheets.values.append({
      auth,
      spreadsheetId,
      range: "A2:Z",
      valueInputOption: "USER_ENTERED",
      resource: {
        values: [data]
      }
    }).then((repose) => {
      console.log('gsheet append!!');
    });
    return success(true);
  } catch (error) {
    return error;
  }
};

export async function gsheetAppendRow(spreadsheetId, data) {
  return new Promise(async (resolve, reject) => {
    const auth = new google.auth.GoogleAuth({
      credentials: {
        "type": "service_account",
        "project_id": "root-rarity-356012",
        "private_key_id": "90659528d768d855b542d73005989944803204f1",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC4fdSnQ7oYvvh5\niu8sxgTeTn22zIccMcb6HyGAwu3upvGUnXd1ESsmqG9r0Ox0FU/jMra73SzvbEfe\nFLofZArdKbqvFbXSK5BQVJXrtRKM/pvBVorgQPc+t0yxT4wWqzPJYhCBvgdTFCYd\nWKa9MZOyMpmKVxhX7yhZUMOaXZt/Zypj9dKI73G6VljXgCrbjxiGnBSWOnRSWmd8\nRGNV7dfTmKIV4TJMQtFmH5OuAvZ2xrlZkE9WI4uFEfk8JYSR4mlFTQeHVKjKUZM4\nz0fE+Ns3Tw9dq0HIv2Ca3AOqgcm+HYAWGqzMv2SpBIWgHIyoyXhqUOXqinf11Pa4\nvNrr9YQxAgMBAAECggEAMC8pBaCCL6lc4v2e1u5G4jrUyZPka8AybCwKR4NhuhVe\n/gYcZ3Za80dFhn6z6uOQEFIz+J/c9xEsOfvm2oD592ZJLCY67Q/Uqq5U05FgrXNo\nAZhVQBmnmXktLhgNCfSf22Zh0kjrx8543+xB7CLRJNbjVAbIRFshiiY2WBA/pwe8\nd3zH5egbRrpZYMkkmltr8vulFajsKEuDWgyMoSuVPQ9XMN/lYu9pN/6miVQ6Q1xh\nMK0xuhgMQLO6Q2moryg61ttnf38EOEYxYh9drcP+/lrCpPuTNkkEvITOoPTdY18n\nEJtPb1LvDCzbunttDGIzh+39+IG8CCiP7nQEeULjIwKBgQDo3pNcWDdPsemd4n5t\nDydUJNSoxMS9aXG0vMu+goiBHXharR651DBfnmwB2DJWDRo5bqOLNyzSoyaOyBuf\nppD9xpbn0TMK4muPyTeiEXO0z9hQK4/0NLY5jz0b7wHYR/JEcQ0ok7bs7jlTwjqb\nq0JgwZM6GzWriMCnvG/gJ16KLwKBgQDK0RjqZ9klc/GjXIbW5SpI2BbxZWZ2NoPL\nDRDxBHq2cdtTloJ/mxC+nqA3OPyFpalZwXmiO6sXIEXXoeNwpsZEKn8E+n8ZHoUy\n4VEKmibNNt3wJOeHXyG7oORHJlzjTUj/PV6y5kRHrGCSk6UAWIpr5hGo7kmros0R\n+JHibB4fnwKBgFtzNTm5pxcUDmOjk/SuU8qWoDEa/QxJgY7x6a2KQ6M4+I/blspx\niwGyDEZ5KeNjR94wFefRJjgePEEsUrTSy/PtbkvhewMWQhl4cvGhmufyC8gII4NK\nxBk8qEn1BatzLbA1GW7K+7Z2I2tCRpPloK6wtmnGT8BqdwYoWWMU8uqfAoGADDVk\nA5A2wQtmq0fBkiP/VJ01XFiXP1xuuIVT1L5JSLw30KNJvbau3lqcGFbk1IKxXAbK\ndJqU5PJ7YcyL7VcMrkPEm58ckX2F1Rc9Ep9O4KGB4JfIHBz84deAhkvn4YLgdwTR\ns4Eq8QmOUqRylT+/LVmPDJUzeBJ3t7I3zeJmOc8CgYEAmk3VA7r3nu0HzKeo4bF6\nEGWkz9Gln8PE0mbl+8VbnLYu+UL+ipxra6SKIVDJLaS+CAr+/D7fVTmhFRoaHLaa\n2TvyIORVvJgfogOcNP+yGgZgii0C2KopzPXqgRcTKIzmrVXy40jdnoEmQwKyJvzS\nqkIOn77REZFrMAhlbeo6qNA=\n-----END PRIVATE KEY-----\n",
        "client_email": "akkewacheiei@root-rarity-356012.iam.gserviceaccount.com",
        "client_id": "109718169437483981766",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/akkewacheiei%40root-rarity-356012.iam.gserviceaccount.com"
      },
      scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
    const googleSheets = google.sheets({ version: "v4" })
    try {

      const result = await googleSheets.spreadsheets.values.append({
        auth,
        spreadsheetId,
        range: "A2:Z",
        valueInputOption: "USER_ENTERED",
        resource: {
          values: [data]
        }
      });

      console.log('append!!');
      resolve(result.data);

    } catch (error) {
      reject(error);
    }
  })
}

export async function removeMatchingRows(criteriaData) {
  const spreadsheetId = process.env.spreadsheetId;
  const sheets = google.sheets({ version: "v4", auth })
  const result = await sheets.spreadsheets.values.get({
      spreadsheetId: spreadsheetId,
      range: 'A:A',
  });

  let ranges = [];
  var current = {
      dimension: "ROWS",
      startIndex: 0,
      endIndex: 0
  };
  for(var i = 0; i < result.data.values.length; i++) {
      if (result.data.values[i][0] == criteriaData) {
          if (current.endIndex === i - 1 || current.startIndex === 0) {
              if (current.startIndex === 0) {
                  current.startIndex = i;
              }
              current.endIndex = i + 1;
          } else {
              ranges.push(current);
              current = {
                  dimension: "ROWS",
                  startIndex: i,
                  endIndex: i + 1
              }
          }
      }
  }
  if (current.startIndex !== 0) {
      ranges.push(current);
  }
  let requests = ranges.map(range => {
      return {
          deleteDimension: {
              range: range
          }
      }
  }).reverse();

  await sheets.spreadsheets.batchUpdate({
      spreadsheetId: spreadsheetId,
      requestBody: {
          requests: requests
      }
  });
}
