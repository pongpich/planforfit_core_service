import { queryRaw } from "./local_lib/dbhelper";
import { success } from "./local_lib/response-lib";

exports.getPrice = async function (event) {
  const { program_id } = event.queryStringParameters;

  const queryString = `
      SELECT price
      FROM core_db.program
      WHERE program_id = '${program_id}';
    `;

  try {
    const result = await queryRaw(queryString);
    const returnBody = result && result.length > 0 ? result[0].price : 0;
    return success(returnBody);
  } catch (error) {
    return error;
  }
};

export async function getProfile(event) {
  const { email, call_count = 0 } = event.queryStringParameters;

  const queryString = `
    SELECT m.*, (
      SELECT count(*)
      FROM  core_db.health_profile hp join core_db.member m
        ON hp.user_id = m.user_id
      WHERE m.email = '${email}'
        AND hp.product_id = 'ccr') as ccr_count, 
        hp.base_info, hp.main_info, hp.start_date, hp.expire_date
    FROM core_db.member m LEFT outer JOIN core_db.health_profile hp
    ON m.user_id = hp.user_id 
        AND hp.product_id = 'ccr'
    WHERE email = '${email}';
  `;

  try {
    const result = await queryRaw(queryString);
    let returnBody = { call_count };
    if (result && result.length > 0) {
      returnBody = { ...result[0], address: JSON.parse(result[0].address), call_count };
    }
    return success(returnBody);
  } catch (error) {
    return error;
  }
}

export async function getCentralMember(event) {
  const { email } = event.queryStringParameters;

  const queryString = `
    SELECT * 
    FROM enterprise.member 
    WHERE email = '${email}';
  `;

  try {
    const result = await queryRaw(queryString);

    return success(result[0]);
  } catch (error) {
    return error;
  }
}

export async function centralSignin(event) {
  const { email, password } = event.queryStringParameters;

  const queryString = `
    SELECT * 
    FROM enterprise.employee 
    WHERE email = '${email}' AND staff_code = '${password}';
  `;

  try {
    const result = await queryRaw(queryString);

    return success(result[0]);
  } catch (error) {
    return error;
  }
}

export async function sales(event) {
  const { queryStringParameters } = event;
  let extended = "";
  if (queryStringParameters && queryStringParameters.get_all) {
    extended = "OR team_name IS NULL";
  }
  const queryString = `
    SELECT staff_code, email, first_name_th, last_name_th,
      first_name_en, last_name_en, nick_name, department_code,
      position, team_name 
    FROM enterprise.employee
    WHERE department_code='05'
    AND (team_name IS NOT NULL ${extended});
  `;

  try {
    const result = await queryRaw(queryString);

    return success(result);
  } catch (error) {
    return error;
  }
}

export async function haveOrder(event) {
  const { order_number } = event.queryStringParameters;

  const queryString = `
    SELECT EXISTS(SELECT * FROM enterprise.sale_order WHERE order_number='${order_number}') as have_order;
  `;

  try {
    const result = await queryRaw(queryString);

    return success(result[0].have_order);
  } catch (error) {
    return error;
  }
}

function onlyUnique(value, index, self) {
  return self.indexOf(value) === index;
}

export async function pendingOrders(event) {
  const queryString = `
    SELECT sod.order_detail_id, sod.sku, sod.name, sod.number, sod.price, sod.discount, so.*,
      em.email as entry_email, em.first_name_th as entry_first_name, em.last_name_th as entry_last_name, 
      em2.email as owner_email, em2.first_name_th as owner_first_name, em2.last_name_th as owner_last_name
    FROM enterprise.sale_order so LEFT OUTER JOIN enterprise.employee em
    ON so.entry_employee = em.staff_code LEFT OUTER JOIN enterprise.employee em2
    ON so.owner_employee = em2.staff_code JOIN enterprise.sale_order_detail sod
      ON so.order_number = sod.order_number
    WHERE so.payment_status = 'pending'
    ORDER BY so.order_number, sod.order_detail_id;
  `;

  try {
    const result = await queryRaw(queryString);

    const orderNumbers = result
                        .map(({ order_number }) => order_number)
                        .filter(onlyUnique);
    let formatResult = [];

    for (let index = 0; index < orderNumbers.length; index++) {
      const orderNo = orderNumbers[index];
      const orderArr = result.filter(order => order.order_number === orderNo);
      if (orderArr.length > 0) {
        const items = [];
        for (let innerI = 0; innerI < orderArr.length; innerI++) {
          const orderObj = orderArr[innerI];
          items.push({
            sku: orderObj.sku,
            number: orderObj.number,
            name: orderObj.name,
            price: orderObj.price,
            discount: orderObj.discount
          });
        }
        const formatOrder = {...orderArr[0], items};
        formatResult.push(formatOrder);
      }
    }

    return success(formatResult);
  } catch (error) {
    return error;
  }
}

export async function slips(event) {
  const queryString = `
    SELECT *
    FROM enterprise.bank_transaction;
  `;

  try {
    const result = await queryRaw(queryString);
    return success(result);
  } catch (error) {
    return error;
  }
}

exports.getSaleProductList = async function (event) {
  const { team_name = 'e-commerce' } = event.queryStringParameters;

  const queryString = `
    select sl.order_no, prd.id, prd.name, prd.description, prd.sku, prd.sellprice
    FROM enterprise.selected_list sl JOIN enterprise.product prd
      ON sl.product_id = prd.id
    WHERE sl.team_name = '${team_name}'
    ORDER BY sl.order_no;
  `;

  try {
    const result = await queryRaw(queryString);
    return success(result);
  } catch (error) {
    return error;
  }
};

exports.getAllProduct = async function (event) {
  const queryString = `
    select prd.id, prd.name, prd.sku, prd.sellprice
    FROM enterprise.product prd;
  `;

  try {
    const result = await queryRaw(queryString);
    return success(result);
  } catch (error) {
    return error;
  }
};

