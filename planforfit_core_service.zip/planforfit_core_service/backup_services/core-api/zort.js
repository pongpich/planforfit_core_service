import axios from 'axios';
import { eventarc } from 'googleapis/build/src/apis/eventarc';
import { success, createSuccessBody } from "./local_lib/response-lib";
import { removeMatchingRows } from "./google";
// Imports the Google Cloud client library
const { BigQuery } = require('@google-cloud/bigquery');

export async function getOrdersZort() {
  try {
    let result;
    var curr = (new Date()).toISOString().split('T')[0];
    //------------------------------------------- GETORDERS ที่สร้างหลังจาก 2022-10-31 --------------------------------------
    const apiPath = `https://api.zortout.com/api.aspx?method=GETORDERS&version=3&format=json&orderdateafter=${curr}` //&createdafter=2022-10-31 &orderdateafter=2022-10-31
    const apiHeaders = {
      headers: {
        storename: "saas@planforfit.com",
        apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
        apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ=",
        //numberlist: "221108HX8WE97J" //SO-202205076  BST-manual_13
      }
    }
    const response = await axios.get(apiPath, apiHeaders);  //GETORDERS
    //console.log("response :", response);
    const orders = response.data.list;
    console.log("orders numb :", orders.length);
    //console.log("orders[0] :", orders[0]);
    //const order = orders[0];
    const ordersFilter = orders.filter((order, index) => (index >= 0 && index < 800));
    console.log("ordersFilter numb :", ordersFilter.length);
    //console.log("ordersFilter :", ordersFilter);

    //------------------------------------------- insert ข้อมูลลง BigQuery ---------------------------------------------------
    const projectId = "innate-lacing-243313";
    const bigquery = new BigQuery({
      projectId: projectId,
      credentials: {
        "client_id": "764086051850-6qr4p6gpi6hn506pt8ejuq83di341hur.apps.googleusercontent.com",
        "client_secret": "d-FL95Q19q7MQmFpd7hHD0Ty",
        "refresh_token": "1//0gVWUC7Bjne5TCgYIARAAGBASNwF-L9IrOD36lL7gDgstLbeKIknearxVK0cQhbj6ZRElEAyk7ppByv0qI1M22NKAAblysSPTyNQ",
        "type": "authorized_user"
      },
    });
    var sqlQuery;
    sqlQuery = 'MERGE `zortout.get_orders` as c';
    sqlQuery = sqlQuery + `
    USING UNNEST([
      struct<
      order_id STRING ,
      customer_name STRING	,
      customer_email STRING	,
      customer_phone STRING	,
      customer_address STRING	,
      tax_id STRING	,
      affiliate_name STRING	,
      reference STRING	,
      sales_channel STRING,
      order_date DATETIME	,
      discount_fee STRING	,
      platform_income FLOAT64 ,
      delivery_fee FLOAT64 ,
      value_before_vat FLOAT64	,
      vat_fee FLOAT64	,
      delivery_date DATETIME	,
      tracking_no STRING	,
      delivery_channel STRING	,
      recipient_name STRING	,
      recipient_phone STRING	,
      delivery_address STRING	,
      post_id STRING	,
      province STRING	,
      district STRING	,
      sub_district STRING	,
      value FLOAT64	,
      note STRING	,
      order_status STRING	,
      payment_status STRING	,
      payment_channel STRING	,
      payment_amount FLOAT64	,
      payment_date DATETIME	,
      list JSON
      >
    `;
    console.log("sqlQuery 1:");
    sqlQuery = sqlQuery + ordersFilter.map(order => `
    ('${order.number}', 
    '${order.customername.split(/\r?\n/).join("").split("'").join('')}', 
    '${order.customeremail}', 
    '${order.customerphone}', 
    '${order.customeraddress.split(/\r?\n/).join("").split("'").join('')}', 
    '${order.customeridnumber.split(/\r?\n/).join("").split("'").join('')}', 
    '${order.agent ? order.agent.name ? order.agent.name : '' : ''}', 
    '${order.reference}', 
    '${order.saleschannel}', 
    (CAST('${order.orderdateString} 00:00:00' AS DateTime)), 
    '${order.discountamount}', 
    ${Math.floor(order.platformdiscount)}, 
    ${order.shippingdiscount}, 
    ${order.totalproductamount}, 
    ${order.vatamount}, 
    ${(order.shippingdateString) ? '(CAST(' + "'" + order.shippingdateString + " 00:00:00' AS DateTime))" : null}, 
    '${order.trackingno}', 
    '${order.shippingchannel}', 
    '${order.shippingname.split(/\r?\n/).join("").split("'").join('')}', 
    '${order.shippingphone}', 
    '${order.shippingaddress.split(/\r?\n/).join("").split("'").join('')}', 
    '${order.shippingpostcode}', 
    '${order.shippingprovince}', 
    '${order.shippingdistrict}', 
    '${order.shippingsubdistrict}', 
    ${order.amount}, 
    '${order.description.split(/\r?\n/).join("").split("'").join('')}', 
    '${order.status}', 
    '${order.paymentstatus}', 
    '${(order.payments.length > 0) ? order.payments[0].name : null}', 
    ${(order.payments.length > 0) ? order.payments[0].amount : null}, 
    ${(order.payments.length > 0) ? '(CAST(' + "'" + order.payments[0].paymentdatetimeString + ":00' AS DateTime))" : null}, 
    JSON '[${order.list.map(item =>
      `{"sku": "${item.sku}", "name": "${item.name.split("	").join("")}", "number": ${item.number},  "pricepernumber":${item.pricepernumber}, "discount": "${item.discount}", "totalprice": ${item.totalprice}}`
    )}]')
    `
    );
    console.log("sqlQuery 2:");
    sqlQuery = sqlQuery + ']) d';
    sqlQuery = sqlQuery + `
    ON c.order_id = d.order_id
    WHEN NOT MATCHED THEN
    INSERT (
      order_id ,
      customer_name ,
      customer_email ,
      customer_phone ,
      customer_address ,
      tax_id ,
      affiliate_name ,
      reference ,
      sales_channel,
      order_date ,
      discount_fee ,
      platform_income ,
      delivery_fee ,
      value_before_vat ,
      vat_fee ,
      delivery_date ,
      tracking_no ,
      delivery_channel ,
      recipient_name ,
      recipient_phone ,
      delivery_address ,
      post_id ,
      province ,
      district ,
      sub_district ,
      value ,
      note ,
      order_status ,
      payment_status ,
      payment_channel ,
      payment_amount ,
      payment_date ,
      list
    ) 
    VALUES (
      d.order_id ,
      d.customer_name ,
      d.customer_email ,
      d.customer_phone ,
      d.customer_address ,
      d.tax_id ,
      d.affiliate_name ,
      d.reference ,
      d.sales_channel,
      d.order_date ,
      d.discount_fee ,
      d.platform_income ,
      d.delivery_fee ,
      d.value_before_vat ,
      d.vat_fee ,
      d.delivery_date ,
      d.tracking_no ,
      d.delivery_channel ,
      d.recipient_name ,
      d.recipient_phone ,
      d.delivery_address ,
      d.post_id ,
      d.province ,
      d.district ,
      d.sub_district ,
      d.value ,
      d.note ,
      d.order_status ,
      d.payment_status ,
      d.payment_channel ,
      d.payment_amount ,
      d.payment_date ,
      d.list
    )
    WHEN MATCHED THEN
    UPDATE SET 
    c.customer_name = d.customer_name ,
    c.customer_email = d.customer_email ,
    c.customer_phone = d.customer_phone ,
    c.customer_address= d.customer_address ,
    c.tax_id = d.tax_id ,
    c.affiliate_name= d.affiliate_name ,
    c.reference = d.reference ,
    c.sales_channel= d.sales_channel,
    c.order_date = d.order_date ,
    c.discount_fee = d.discount_fee ,
    c.platform_income= d.platform_income ,
    c.delivery_fee = d.delivery_fee ,
    c.value_before_vat = d.value_before_vat ,
    c.vat_fee = d.vat_fee ,
    c.delivery_date = d.delivery_date ,
    c.tracking_no = d.tracking_no ,
    c.delivery_channel = d.delivery_channel ,
    c.recipient_name = d.recipient_name ,
    c.recipient_phone = d.recipient_phone ,
    c.delivery_address = d.delivery_address ,
    c.post_id = d.post_id ,
    c.province = d.province ,
    c.district = d.district ,
    c.sub_district = d.sub_district ,
    c.value = d.value ,
    c.note = d.note ,
    c.order_status  = d.order_status ,
    c.payment_status = d.payment_status ,
    c.payment_channel = d.payment_channel ,
    c.payment_amount = d.payment_amount ,
    c.payment_date = d.payment_date ,
    c.list = d.list;
    `;
    console.log("sqlQuery End:");
    const options = {
      query: sqlQuery,
      timeoutMs: 100000,
      useLegacySql: false,
    };
    const updateResult = await bigquery.query(options); //BigQuery - query

    result = success(createSuccessBody({ updateResult: updateResult, orders: orders }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function addOrder(event) {
  const order = JSON.parse(event.body);

  try {
    const result = await addOrderInZort(order);
    return success(createSuccessBody(result));
  } catch (error) {
    return error;
  }
}

export async function addGenericOrder(event) {
  const order = JSON.parse(event.body);

  try {
    const result = await addGenericZortOrder(order);
    return success(createSuccessBody("success"));
  } catch (error) {
    return error;
  }
}


export async function addOrderInZort(order) { //ใช้สำหรับให้แอดมินสร้างรายการ Zort กรณีชำระเงินเรียบร้อยแต่ไม่มีรายการใน Zort ตอนสมัครครั้งแรก

  const {
    amount,
    referenceNo,
    customerEmail,
    customerTelephone,
    customerName,
    program_id,
    payment_date,
    address,
    productName,
    price,
    discount
  } = order;
  return new Promise(async (resolve, reject) => {
    try {
      //----------------------------------สร้าง order ใน Zort--------------------------------------
      const apiPath = "https://api.zortout.com/api.aspx?method=ADDORDER&version=3&format=json";
      const apiHeaders = {
        headers: {
          storename: "saas@planforfit.com",
          apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
          apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ="
        }
      };

      const list = [{
        "sku": getSKU(program_id),
        "name": productName,
        "number": 1,
        "pricepernumber": parseFloat(price) + parseFloat(discount),
        "discount": discount,
        "totalprice": price
      }];
      const vatamount = `${(price * (7 / 107)).toFixed(2)}`;
      const order_id = `CCR-${referenceNo}`;
      const apiBody = {
        "number": order_id,
        "customername": customerName,
        "customeremail": customerEmail,
        "customerphone": customerTelephone,
        "customeraddress": address,
        "shippingchannel": "Flash express",
        "shippingname": customerName,
        "shippingemail": customerEmail,
        "shippingphone": customerTelephone,
        "shippingaddress": address,
        "saleschannel": "Sale CCR",
        "orderdate": payment_date,
        "paymentdate": payment_date,
        "amount": amount,
        "discount": discount,
        "paymentamount": amount,
        "shippingamount": 0,
        "vatamount": vatamount,
        "vattype": 3,
        "paymentmethod": "GBPay",
        "list": list,
        "customeridnumber": ""
      };
      const result = await axios.post(apiPath, apiBody, apiHeaders);  // เรียกใช้ api ของ zort
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });

}

export async function getZortProduct() { //ใช้สำหรับให้แอดมินสร้างรายการ Zort กรณีชำระเงินเรียบร้อยแต่ไม่มีรายการใน Zort ตอนสมัครครั้งแรก

  return new Promise(async (resolve, reject) => {
    try {
      //----------------------------------สร้าง order ใน Zort--------------------------------------
      const apiPath = "https://api.zortout.com/api.aspx?method=GETPRODUCTS&version=3&format=json";
      const apiHeaders = {
        headers: {
          storename: "saas@planforfit.com",
          apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
          apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ="
        }
      };

      const result = await axios.get(apiPath, apiHeaders);  // เรียกใช้ api ของ zort
      if(result.data.res.resCode == "200") {
        resolve(result.data.list);
      } else {
        reject(`${result.data.resCode}:${result.data.resDesc}, ${result.data.resDesc2}, ${result.data.resDesc3}`)
      }
    } catch (error) {
      reject(error);
    }
  });

}

export async function addGenericZortOrder(order) { //ใช้สำหรับให้แอดมินสร้างรายการ Zort กรณีชำระเงินเรียบร้อยแต่ไม่มีรายการใน Zort ตอนสมัครครั้งแรก

  const {
    order_number,
    email,
    phone,
    first_name,
    last_name,
    payment_date,
    address,
    shipping_channel,
    sale_channel,
    payment_type,
    items
  } = order;
  return new Promise(async (resolve, reject) => {
    try {
      //----------------------------------สร้าง order ใน Zort--------------------------------------
      const apiPath = "https://api.zortout.com/api.aspx?method=ADDORDER&version=3&format=json";
      const apiHeaders = {
        headers: {
          storename: "saas@planforfit.com",
          apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
          apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ="
        }
      };

      const list = [];
      let amount = 0.00;
      let totalDiscount = 0.00;

      for (let index = 0; index < items.length; index++) {
        const item = items[index];
        const {
          sku,
          name,
          number,
          price,
          discount
        } = item;
        amount += parseFloat(price);
        totalDiscount += parseFloat(discount);
        list.push({
          sku,
          name,
          number,
          pricepernumber: price,
          discount,
          totalprice: parseFloat(price) - parseFloat(discount)
        })
      }

      const inputAmount = parseFloat(amount-totalDiscount).toFixed(2);

      const vatamount = `${((amount-totalDiscount) * (7 / 107)).toFixed(2)}`;
      const apiBody = {
        number: order_number,
        customername: `${first_name} ${last_name}`,
        customeremail: email,
        customerphone: phone,
        customeraddress: address,
        shippingchannel: shipping_channel,
        shippingname: `${first_name} ${last_name}`,
        shippingemail: email,
        shippingphone: phone,
        shippingaddress: address,
        saleschannel: sale_channel,
        orderdate: payment_date,
        paymentdate: payment_date,
        amount: inputAmount,
        discount: "0.00",
        paymentamount: inputAmount,
        shippingamount: "0.00",
        vatamount: parseFloat(vatamount).toFixed(2),
        vattype: 3,
        paymentmethod: payment_type,
        list: list,
        customeridnumber: ""
      };
      const result = await axios.post(apiPath, apiBody, apiHeaders);  // เรียกใช้ api ของ zort
      if(result.data.resCode == "200") {
        resolve(result.data);
      } else {
        reject(`${result.data.resCode}:${result.data.resDesc}, ${result.data.resDesc2}, ${result.data.resDesc3}`)
      }
    } catch (error) {
      reject(error);
    }
  });

}

export async function updateOrder(event) { //ใช้สำหรับให้แอดมินสร้างรายการ Zort กรณีชำระเงินเรียบร้อยแต่ไม่มีรายการใน Zort ตอนสมัครครั้งแรก

  /*const data = JSON.parse(event.body);
  const {
    id,
    number,
    orderdate,
    orderdateString,
    customerid,
    customername,
    customeridnumber,
    customerphone,
    customeremail,
    customeraddress,
    customerbranchname,
    customerbranchno,
    shippingdate,
    shippingchannel,
    shippingamount,
    shippingvat,
    shippingname,
    shippingaddress,
    shippingphone,
    shippingemail,
    trackingno,
    saleschannel,
    description,
    reference,
    vattype,
    list,
    discount,
    vatamount,
    amount,
    paymentamount,
    paymentstatus,
    status,
    isCODe
  } = data;*/
  
  const datas = transformZortDatas(event.body);
  
  console.log("inside update Order", datas);
  return success("get data from updateorder zort");
}

export async function deleteOrder(event) { //ใช้สำหรับให้แอดมินสร้างรายการ Zort กรณีชำระเงินเรียบร้อยแต่ไม่มีรายการใน Zort ตอนสมัครครั้งแรก

  const { number } = transformZortDatas(event.body);
  
  console.log("inside delete Order", number);
  await removeMatchingRows(number);
  return success("get data from deleteorder zort");
}

function transformZortDatas(body, dataFieldName='datas') {
  const rawData = new URLSearchParams(decodeURIComponent(body));
  const datas = JSON.parse(rawData.get(dataFieldName));
  return datas;
}

function getSKU(program_id) {
  let sku = "";
  switch (program_id) {
    case "ccrnew":
      sku = "400220800002";
      break;
    case "ccr60d":
      sku = "400220201026";
      break;
    case "ccr2batch":
      sku = "400220800003";
      break;
    default:
      sku = "400220201026";
      break;
  }
  return sku;
}
