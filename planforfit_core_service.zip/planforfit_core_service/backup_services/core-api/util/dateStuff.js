export function formatThaiDate(date) {
  const rawDate = date || new Date();

  return `${rawDate.getDate()} ${getThaiMonth(rawDate.getMonth())} ${getThaiYear(rawDate.getFullYear())}`;
}

function getThaiMonth(month) {
  switch (month) {
    case 0:
      return "มกราคม";
    case 1:
      return "กุมภาพันธ์";
    case 2:
      return "มีนาคม";
    case 3:
      return "เมษายน";
    case 4:
      return "พฤษภาคม";
    case 5:
      return "มิถุนายน";
    case 6:
      return "กรกฎาคม";
    case 7:
      return "สิงหาคม";
    case 8:
      return "กันยายน";
    case 9:
      return "ดุลาคม";
    case 10:
      return "พฤศจิกายน";
    case 11:
      return "ธันวาคม";

  }
}

function getThaiYear(year) {
  let thaiYear = year;
  if (thaiYear < 2300) {
    thaiYear = thaiYear + 543;
  }
  return thaiYear;
}