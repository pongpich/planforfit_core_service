import { transaction, query } from "./local_lib/dbhelper";
import { addGenericZortOrder, getZortProduct } from "./zort";
import { gsheetAppendRow } from "./google";

export async function shuffleProductList(event) {
    const { team_name, product_list } = JSON.parse(event.body);

    const clearProductQuery = `
        DELETE FROM enterprise.selected_list WHERE team_name = '${team_name}';
    `

    let queryString = `
        INSERT INTO
                enterprise.selected_list(team_name, product_id, order_no)
        VALUES

    `;

    for (let index = 0; index < product_list.length; index++) {
        const product = product_list[index];
        const { id, order_no } = product;
        queryString += `('${team_name}', '${id}', ${order_no})`;
        queryString += index < product_list.length - 1 ? "," : ";";
    }

    try {
      const result = await transaction([clearProductQuery, queryString]);
      return result;
    } catch (error) {
      return error;
    }
  }

export async function orderManagement(event) {
  const order = JSON.parse(event.body);
  const {
    spreadsheetId,
    order_number,
    page,
    email,
    payment_status,
    phone,
    first_name,
    last_name,
    fb_link,
    address,
    payment_type,
    sending_bank,
    sending_account,
    receive_bank,
    receive_account,
    transref,
    slip_amount,
    slip_file,
    payment_date,
    payment_time,
    shipping_channel,
    sale_channel,
    entry_employee,
    owner_employee,
    entry_employee_name,
    owner_employee_name,
    remark,
    items
  } = order;

  const orderFieldsSetting = `
    payment_status='${payment_status}',
    payment_type='${payment_type}',
    sending_bank='${sending_bank}',
    sending_account='${sending_account}',
    receive_bank='${receive_bank}',
    receive_account='${receive_account}',
    transref='${transref}',
    slip_file='${slip_file}',
    slip_amount='${slip_amount}',
    order_date='${payment_date}',
    trans_date='${payment_date}',
    trans_time='${payment_time}',
    shipping_channel='${shipping_channel}',
    sale_channel='${sale_channel}',
    entry_employee='${entry_employee}',
    owner_employee='${owner_employee}',
    remark='${remark}',
    email='${email}',
    first_name='${first_name}',
    last_name='${last_name}',
    phone='${phone}',
    fb_link='${fb_link}',
    address='${address}',
    page='${page}'
  `;

  const orderSQL = `
    INSERT INTO enterprise.sale_order SET
      order_number='${order_number}',
      ${orderFieldsSetting}
    ON DUPLICATE KEY UPDATE   
      ${orderFieldsSetting};
  `;

  const delSODetailSQL = `
    DELETE FROM enterprise.sale_order_detail
    WHERE order_number='${order_number}';
  `;

  let soDetailSQL = `
    INSERT INTO enterprise.sale_order_detail 
      (order_number, sku, name, number, price, discount) 
    VALUES
  `;

  for (let index = 0; index < items.length; index++) {
    const item = items[index];
    const {
      sku,
      name,
      number,
      price,
      discount
    } = item;

    soDetailSQL = `
      ${soDetailSQL}
      ('${order_number}', '${sku}', '${name}', ${number}, ${price}, ${discount})${index === items.length-1 ? ";" : ","}
    `;
  }


  try {
    await transaction([orderSQL, delSODetailSQL, soDetailSQL]);
    if(payment_status === "approve") {
      await addGenericZortOrder(order);
      const prod_list = items.reduce((prev, curr) => prev + (prev === "" ? "" : ",") + curr.name, "");
      
      const net_price = items.reduce((prev, curr) => prev + curr.price, 0);
      console.log("inside if:", prod_list, net_price);

      const gData = [
            order_number,
            slip_file,
            transref,
            slip_amount,
            payment_date,
            payment_time,
            sending_bank,
            sending_account,
            receive_bank,
            receive_account,
            email,
            first_name,
            last_name,
            fb_link,
            phone,
            address,
            prod_list,
            net_price,
            entry_employee_name,
            owner_employee_name,
            remark
        ];
      const gResult = await gsheetAppendRow(spreadsheetId, gData);
      return success(createSuccessBody(gResult));
    }
    return success(createSuccessBody("success"));
  } catch (error) {
    return error;
  }
}

export async function updateAllZortProduct(event) {
  try {
    const zortProds = await getZortProduct();
    
    let productFieldsSetting = "";
    for (let index = 0; index < zortProds.length; index++) {
      const {
        id,
        name,
        description,
        sku,
        sellprice,
        purchaseprice,
        barcode,
        stock,
        availablestock,
        unittext,
        imagepath,
        categoryid,
        category
      } = zortProds[index];
      productFieldsSetting += `
        ("${id}","0","${name}","",
          "${sku}",${sellprice},${purchaseprice},"${barcode}","${stock}","${availablestock}",
          "${unittext}","${imagepath}","${categoryid}","${category}")
      `
      if (index === zortProds.length - 1) {
        productFieldsSetting += ';';
      } else {
        productFieldsSetting += ',';
      }
    }

    const delPrdSQL = 'DELETE FROM enterprise.product'

    let prodSQL = `
      INSERT INTO enterprise.product (id,producttype,name,description,
        sku,sellprice,purchaseprice,barcode,stock,availablestock,
        unittext,imagepath,categoryid,category)
      VALUES 
        ${productFieldsSetting}
    `;
    const result = await transaction([delPrdSQL, prodSQL]);
    return result;
  } catch (error) {
    return error
  }
}

export async function addEmployee(event) {
  const { 
    staff_code, 
    email,
    first_name_th,
    last_name_th,
    first_name_en,
    last_name_en,
    nick_name,
    department_code,
    position,
    team_name
  } = JSON.parse(event.body);

  const staffFieldsSetting = `
      email='${email}', 
      first_name_th='${first_name_th}', 
      last_name_th='${last_name_th}', 
      first_name_en='${first_name_en}', 
      last_name_en='${last_name_en}', 
      nick_name='${nick_name}', 
      department_code='${department_code}', 
      position='${position}', 
      team_name='${team_name}'
    `;

  let queryString = `
      INSERT INTO enterprise.employee SET
        staff_code='${staff_code}', 
        ${staffFieldsSetting}
      ON DUPLICATE KEY UPDATE   
        ${staffFieldsSetting};
    `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    console.log("error inside:", error);
    return error;
  }
}


export async function addBankTransaction(event) {
  const { 
    sending_bank, 
    sending_account,
    receive_bank,
    receive_account,
    transref,
    slip_file,
    amount,
    trans_date,
    trans_time
  } = JSON.parse(event.body);

  const transFieldsSetting = `
      sending_bank='${sending_bank}', 
      sending_account='${sending_account}', 
      receive_bank='${receive_bank}', 
      receive_account='${receive_account}', 
      transref='${transref}', 
      slip_file='${slip_file}', 
      amount=${amount}, 
      trans_date='${trans_date}', 
      trans_time='${trans_time}'
    `;

  let queryString = `
      INSERT INTO enterprise.bank_transaction SET
        ${transFieldsSetting};
    `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    console.log("error inside:", error);
    return error;
  }
}
