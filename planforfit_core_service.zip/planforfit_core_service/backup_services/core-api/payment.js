import { success, createSuccessBody } from "./local_lib/response-lib";
import { queryRaw, query, transaction as batchQuery } from "./local_lib/dbhelper";
import { sendHtmlMail } from "./local_lib/mail-helper";
import moment from "moment";
import { addOrderInZort } from "./zort";

export async function GBQRResponse(event) {
    const {
        amount,
        referenceNo,
        gbpReferenceNo,
        resultCode,
        date,
        detail,
        customerName,
        customerEmail,
        customerTelephone,
        customerAddress,
        merchantDefined1: program_id
    } = JSON.parse(event.body);
    console.log("inside gbqr:",
        amount,
        referenceNo,
        gbpReferenceNo,
        resultCode,
        date,
        detail,
        customerName,
        customerEmail,
        customerTelephone,
        customerAddress,
        program_id
    );

    if (resultCode.toString() !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));

    return success(createSuccessBody({ message: "success payment" }));
}

function getParams(body) {
    if (!body) return '01';

    const bodyParsed = body.split('&');
    console.log("inside getParams:", bodyParsed);
    let params = {};

    for (let i = 0; i < bodyParsed.length; i++) {
      const element = bodyParsed[i].split('=');
      params[element[0]] = element[1];
    }

    return params;
}

export async function thankyouRoute(event, context, callback) {
    const params = getParams(event.body);
    if (params.resultCode !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));
    const programId = params.referenceNo.split("SEC")[1];

    const queryString = `
        SELECT description, price
        FROM program
        WHERE program_id='${programId}';
      `;
    console.log("inside thankyouRoute:", params.referenceNo, programId, queryString);

    let description = "CCR";
    let price = "1";
    const start_date = getMondayStartDate();

    try {
        const result = await queryRaw(queryString);
        if (result && result.length > 0) {
            description = result[0].description || "CCR";
            price = result[0].price || 1;
        }
    } catch (error) {
        return error;
    }
    const response = {
        statusCode: 200,
        headers: {
            "content-type": "text/html; charset=UTF-8"
        },
        body: `<!DOCTYPE html>
      <html lang="en">

      <head>
        <title>CCR</title>
        <meta property="og:title" content="CCR Thank You" />
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="https://pot.planforfit.com/css/thankyou.css">
      </head>

      <body>
        <div class="w100">
          <img src="https://pot.planforfit.com/img/thank_you_main.jpg" alt="">
        </div>
        <p class="title">
          THANK YOU!
        </p>
        <div class="message_wrapper">
          <p class="message">ขอบคุณสำหรับความสนใจ<br class="mobile_break">โปรแกรมออกกำลังกายจาก <span class="planforfit">CCR</span> <br>
            ทีมงานได้รับคำสั่งซื้อและกำลังดำเนินการตรวจสอบ<br class="mobile_break">รายการคำสั่งซื้อของท่าน <br class="desktop_break">
            หากเรียบร้อยแล้ว<br class="mobile_break"> ท่านจะได้รับข้อมูลอัปเดตผ่านทางอีเมลโดยทันที<br>
          </p>
        </div>
        <div class="course_detail">
          <div class="left">
            <span>&nbsp;&nbsp;&nbsp;&nbsp;${description}</span>
          </div>
          <div class="right">
            <span>฿${new Intl.NumberFormat().format(price)}</span>
          </div>
        </div>
        <div class="download_wrapper">
          <p class="download_message">
            โดยโปรแกรมของคุณจะเริ่มในวันที่ ${start_date}
          </p>
        </div>
        <div class="button_wrapper">
          <a href="https://ccrdiet.co/app/main" class="btn">กลับไปหน้าแรก</a>
        </div>

      </body>

      </html>`
    };
    callback(null, response);
}

export async function sendPaymentResumeMail(event) {
    console.log("at first", event.body);
    const {
        email
    } = JSON.parse(event.body);
    try {
        const to = email;
        const from = 'contact@planforfit.com';
        const subject = "อีกนิดเดียวการลงทะเบียนเข้าร่วม CCR จะสำเร็จ!";
        await sendHtmlMail(to, from, subject, "", "https://sale.ccrdiet.co/checkout", "", "paymentResume");
        return success(createSuccessBody("Success!!"));
    } catch (error) {
        return error;
    }
}


export async function setQRStatus(event) {
    const {
        customerEmail: email,
        merchantDefined2: status
    } = JSON.parse(event.body);

    console.log("inside setQRStatus:", event.body);
    const queryString = `
      INSERT INTO qr_status VALUES ('${email}','${status}')
      ON DUPLICATE KEY UPDATE \`status\`='${status}';
    `;

    try {
        const result = await query(queryString);
        return result;
    } catch (error) {
        return error;
    }
}

export async function checkQRStatus(event) {
    const { email } = event.queryStringParameters;

    const queryString = `
      SELECT status
      FROM qr_status
      WHERE email = '${email}';
    `;

    try {
      const result = await query(queryString);
      return result;
    } catch (error) {
      return error;
    }
  }

  export async function subscription(event) {
    const data = JSON.parse(event.body);
    const {
        amount,
        resultCode,
        detail,
        customerEmail: email,
        customerTelephone: phone,
        customerAddress,
        merchantDefined1: program_id,
        merchantDefined2: status,
        merchantDefined3: user_id,
        merchantDefined4: period,
        merchantDefined5: fb_link
    } = data;
    if (resultCode.toString() !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));
    const { start_date, expire_date } = calculateCoursePeriod(period);
    const transaction = detail.split(",");
    const payment_date = transaction[3];
    const productName = transaction[0].trim();
    const price = transaction[1].trim();
    const discount = transaction[2].trim();
    console.log("inside subscription:", amount, resultCode, payment_date, detail, email, phone, customerAddress, program_id, status, user_id, period, fb_link, start_date, expire_date);

    const addressItems = customerAddress.split(",");
    let address = '{}';
    let addressForZort = "";
    if (customerAddress) {
      address = `{"address_line1": "${addressItems[0].trim()}", "address_line2": "${addressItems[1].trim()}", "tambol": "${addressItems[2].trim()}","city": "${addressItems[3].trim()}", "state": "${addressItems[4].trim()}","zip": "${addressItems[5].trim()}" }`;
      addressForZort = `${addressItems[0].trim()} ${addressItems[2].trim()} ${addressItems[3].trim()} ${addressItems[4].trim()} ${addressItems[5].trim()}`;
    }
    const qrStatusQuery = `
            INSERT INTO qr_status VALUES ('${email}','${status}')
            ON DUPLICATE KEY UPDATE \`status\`='${status}';
    `;

    const updateMemberQuery = `
            UPDATE member
            SET phone='${phone}',
            fb_link='${fb_link}',
            address='${(address)}'
            WHERE user_id='${user_id}';
    `;

    const subQuery = `
            INSERT INTO subscription SET
                user_id='${user_id}', program_id='${program_id}', payment_type='transfer',
                amount=${amount}, payment_date='${payment_date}', payment_status='approved',
                start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}'
            ON DUPLICATE KEY UPDATE
                payment_type='transfer', amount=${amount}, payment_date='${payment_date}',
                payment_status='approved',
                start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}';
        `;

    try {
        const healthProfileInsertStr = `
              INSERT INTO health_profile SET
                  user_id='${user_id}', product_id='ccr', base_info='{}', main_info='[]',
                  program_id='${program_id}', start_date='${start_date}', expire_date='${expire_date}'
              ON DUPLICATE KEY UPDATE
                  expire_date='${expire_date}';
            `;

        const invoiceQuery = getInvoiceStatement(user_id, payment_date, transaction);

        const result = await batchQuery([updateMemberQuery, qrStatusQuery, subQuery, healthProfileInsertStr, invoiceQuery]);
        const baseUrl = `https://ccrdiet.co`;
        const to =   email;
        const from = "contact@planforfit.com";
        const subject = "การลงทะเบียน และชำระเงินสำเร็จแล้ว!";
        const content = `การสั่งซื้อของคุณได้รับการดำเนินการโดยสมบูรณ์เรียบร้อยแล้ว หากคุณต้องการตรวจรับใบเสร็จ สามารถเข้าไปดูได้ที่
                         <a href="${baseUrl}/app/invoice" target="_blank" >ใบเสร็จรับเงิน</a><br/>
                         และคุณสามารถเข้าไปใช้งานระบบได้โดยคลิกปุ่มต่อไปนี้
                        `;
        const mainLink = `${baseUrl}/app/main`;
        const mainButtonLabel = "CCR";

        const order = {
          ...data,
          program_id,
          payment_date,
          address: addressForZort,
          productName,
          price,
          discount
        };

        await sendHtmlMail(to, from, subject, content, mainLink, mainButtonLabel);

        await addOrderInZort(order);

        return result;
    } catch (error) {
        return error;
    }
}

function getMondayStartDate() {
  const dateFormat = 'YYYY-MM-DD HH:mm';
  //if today is monday, system will use it. If not, system will use next monday
  return moment().day(1).isSame(moment(), 'day') ? moment().format(dateFormat) : moment().day(8).format(dateFormat);
}

function calculateCoursePeriod(period) {
  const dateFormat = 'YYYY-MM-DD HH:mm';
  const start_date = getMondayStartDate();
  const expire_date = moment().add(period, "days").format(dateFormat);

  return { start_date, expire_date };
}

function getInvoiceStatement(user_id, create_time, transaction) {
  const price = transaction[1].trim();
  const productName = transaction[0].trim();
  const vat_rate = 7;
  const invoiceDetailStatement = getInvoiceDetailState(productName, price);
  return (`
      select @newInvoiceNumber := CONCAT(
          YEAR(NOW()),
          IF(STRCMP(SUBSTRING(param_value, 1, 4), YEAR(NOW())) = 0,
              LPAD(CAST(SUBSTRING(param_value, 5, 6) as UNSIGNED) + 1, 6, '0'),
              LPAD('1', 6, '0')
          )
      ) as new_invoice_number
      from system_param
      where param_name = 'current_invoice';

      INSERT INTO invoice SET
      invoice_id = @newInvoiceNumber,
      transaction_date = '${create_time}',
      user_id = '${user_id}',
      total = ${price},
      vat_rate = ${vat_rate};

      ${invoiceDetailStatement}

      UPDATE system_param SET param_value = @newInvoiceNumber WHERE param_name = 'current_invoice';
  `
  );
}

function getInvoiceDetailState(productName, price, isTemp = false) {
  return `
          INSERT INTO invoice_detail${isTemp ? '_temp': ''} SET
          detail_order = 1,
          invoice_id = @newInvoiceNumber,
          item_name = '${productName}',
          quantity = 1,
          price = ${price};
      `;
}
