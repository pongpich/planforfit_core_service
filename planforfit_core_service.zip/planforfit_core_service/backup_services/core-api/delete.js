import { query } from "./local_lib/dbhelper";

export async function removeEmployee(event) {
  const { 
    staff_code
  } = JSON.parse(event.body);

  let queryString = `
      DELETE FROM enterprise.employee WHERE staff_code='${staff_code}';
    `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    console.log("error inside:", error);
    return error;
  }
}

