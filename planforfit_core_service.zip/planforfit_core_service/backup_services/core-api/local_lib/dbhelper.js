import db_pool from "./connection-lib";
import { success, failure, createSuccessBody, createFailureBody } from "./response-lib";

export const query = (queryText, data) => new Promise((resolve, reject) => {
  db_pool.getConnection((err, conn) => {
    if (err) {
      console.log("err :", err);
    }
    conn.query("SET SESSION group_concat_max_len = 1000000");
    conn.query(queryText, function (error, results, fields) {
      conn.destroy();
      let return_error;
      if (error) {
        console.log("inside query error detail:", error, queryText);
        switch (error.code) {
          case "ER_DUP_ENTRY":
            return_error = failure(createFailureBody(error.code, error.sqlMessage));
            break;
          default:
            return_error = failure(createFailureBody(error.code, error.sqlMessage));
        }
        reject(return_error);
      }
      resolve(success(createSuccessBody(results, fields)));
    });
  });
});

export const queryRaw = (queryText) => new Promise((resolve, reject) => {
  db_pool.getConnection((err, conn) => {
    if (err) {
      console.log("err :", err);
    }
    conn.query("SET SESSION group_concat_max_len = 1000000");
    conn.query(queryText, function (error, results, fields) {
      conn.destroy();
      let return_error;
      if (error) {
        console.log("inside queryRaw error detail:", error, queryText);
        switch (error.code) {
          case "ER_DUP_ENTRY":
            return_error = failure(createFailureBody(error.code, error.sqlMessage));
            break;
          default:
            return_error = failure(createFailureBody(error.code, error.sqlMessage));
        }
        reject(return_error);
      }
      resolve(results);
    });
  });
});

export const transaction = (queryArray, data) => new Promise((resolve, reject) => {
  db_pool.getConnection((err, conn) => {
    if (err) {
      reject(err);
    }
    conn.query("SET SESSION group_concat_max_len = 1000000");
    conn.beginTransaction(function (tran_err) {
      console.log("inside transaction begin transaction:");
      if (tran_err) {
        console.log("inside transaction show tran_error:", tran_err);
        conn.destroy();
        throw tran_err;
      }

      queryArray.forEach((item, index) => conn.query(item, function (error, results) {
        if (error) {
          console.log("inside transaction show each error:", error);
          return conn.rollback(function () {
            conn.destroy();
            reject(failure(createFailureBody(error.code, error.sqlMessage)));
          });
        }

        if (index === queryArray.length - 1) {
          conn.commit(function (commit_error) {
            console.log("inside transaction from commit error:", commit_error);
            if (commit_error) {
              return conn.rollback(function () {
                reject(failure(createFailureBody(commit_error.code, commit_error.sqlMessage)));
              });
            }
            conn.destroy();
            resolve(success(createSuccessBody(results)));
          });
        }
      })
      );


    });
  });
});
