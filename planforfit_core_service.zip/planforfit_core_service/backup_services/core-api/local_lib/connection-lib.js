import mysql from 'mysql';

const config = {
  connectionLimit: 10,
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_CORE,
  multipleStatements: true,
  ssl: { rejectUnauthorized: false },
  timezone: 'UTC+0',
  dateString: [
    'DATE',
    'DATETIME',
    'TIMESTAMP'
  ]
};

const db_pool = mysql.createPool(config);

export default db_pool;
