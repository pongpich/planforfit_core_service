import sgMail from "@sendgrid/mail";
//sgMail.setApiKey("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");
sgMail.setApiKey(
  "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"
); //api name 'sale_ccr'
//sgMail.setApiKey(process.env.NEW_SG_API);

export const sendBebeHtmlMail = async (to, from, subject, content, type) => {
  let html = {};
  switch (type) {
    case "subscription_stay_fit_01":
      html = bebeStayFitRegisterTemplate1(content);
      break;
    case "starter_stay_fit_01":
      html = bebeStayFitRegisterTemplate2(content);
      break;
    case "requestTaxInvoice":
      html = bebeStayFitRequestTaxInvoice(content);
      break;
    case "stay_fit_reset_passward":
      html = bebeStayFitResetPassword(content);
      break;
    case "subscription_30d":
      html = subscription30dTemplate(content);
      break;
    default:
      html = bebeStayFitRegisterTemplate1(content);
  }
  const msg = {
    to,
    from,
    subject,
    html,
  };
  console.log("before send mail:", msg);
  try {
    await sgMail.send(msg);
    console.log("sending to ", to, " success");
  } catch (error) {
    console.error(error);

    if (error.response) {
      console.error(error.response.body);
    }
  }
};

export const sendHtmlMail = async (
  to,
  from,
  subject,
  content,
  mainLink,
  mainButtonLabel,
  type = "simple"
) => {
  let html = {};
  switch (type) {
    case "simple":
      html = simpleTemplate(subject, content, mainLink, mainButtonLabel);
      break;
    case "tbpa_register":
      html = registerTemplate();
      break;
    case "paymentResume":
      html = paymentResume();
      break;
    default:
      html = simpleTemplate(subject, content, mainLink, mainButtonLabel);
  }
  const msg = {
    to,
    from,
    subject,
    html,
  };
  try {
    await sgMail.send(msg);
  } catch (error) {
    console.error(error);
  }
};

export const subscription30dTemplate = (orderdate) =>
  `
  <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <title>Bebe Stay Fit</title>

    <style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Kanit&family=Prompt:wght@200;600;700;900&display=swap');
      .colored {
        color: #000000;
      }
      .center {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .font {
        font-family: 'Prompt', sans-serif;
      }
    </style>
</head>

<body style="width: 90vw;">
      <div style=" width: 100%">
      <center>
      <div class='colored font'>

          <div style="width: 900px; height: 1220px; display: table-cell;text-align: center;vertical-align: middle;border: 1px solid #FFF; box-shadow: 1px 3px 5px 5px #c4c4c4; border-radius: 10px;">
              <div style="background-color: #FFF; font-family: 'Prompt', sans-serif;">
                  <div style="margin-top: 60px;">
                      <div>
                          <img src="https://fit.bebefitroutine.com/uploads/group198.png" style="padding-bottom: 20px">
                          <div>
                              <div style="border-bottom: 1px solid #707174; margin: 0px 40px 0px 40px;"></div>
                              <p style="font-size: 32px; font-weight: 600; color: #000000;"> ยินดีต้อนรับสมาชิกใหม่ของเรา</p>
                              <div style="border-bottom: 1px solid #707174;  margin: 0px 40px 0px 40px;"></div>
                          </div>
                      </div>
                      <div style="margin-top: 40px; font-size: 24px; line-height:100%;">
                          <p>ขอบคุณที่มาสมัครเข้าร่วมเป็นสมาชิก Bebe Stay Fit</p>
                          <p>ทางทีมงานได้รับข้อมูลการสมัครเรียบร้อยแล้ว</p>
                          <p>เราขอบคุณที่ท่านให้ความสนใจและเลือกเราเป็นส่วนหนึ่งสู่ความสำเร็จ </p>
                          <p>มาสร้างวินัย และมีความสุขกับการออกกำลังกายนะคะ </p>
                      </div>
                      <div style="width: 900px;">
                          <center>
                              <div style="width: 480px;padding: 25px;border: 1px solid; border-radius: 10px;">
                                <div style="margin-top: -20px; text-align: left;">
                                  <div style="line-height:60%;">
                                      <p style="font-size: 20px; color: #E25E96;" >วันที่ชำระ ${orderdate} </p>
                                      <p style="font-size: 26px; font-weight: 600;"> สมัครตามระยะเวลาของโปรแกรม</p>
                                      <p style="font-size: 20px; font-weight: 600;"> สิ่งที่จะได้รับ </p>
                                  </div>
                                  <div>
                                      <li>Exercise program</li>
                                      <li>Nutrition program</li>
                                      <li>Supplement program</li>
                                      <li>Fitto Plant Protein <span style="float: right;">3  กล่อง</span></li>
                                  </div>

                                  <div>
                                      <p  style="font-size: 26px; font-weight: 600;"> สรุป</p>
                                      <p style="font-size: 20px;"> ราคา (รวม Vat 7%) <span style="font-weight: 600; font-size: 26px; float: right;">1800 บาท / 1 เดือน</span></p>
                                  </div>
                              </div>
                            </div>
                          </center>
                      </>
                  </div>
                      <button style="width: 200px; height: 50px; margin-top: 30px; border-radius: 50px; border: 1px solid #E25E96; background-color: #E25E96; font-size: 20px; color: #FFF; font-family: 'Prompt', sans-serif;" type="button">
                        <a href="https://fit.bebefitroutine.com/#/welcome_new_nember" style="color: white; text-decoration: none;">
                        เริ่มต้นใช้งาน
                        </a>
                      </button>
                  <div style="font-family: 'Prompt', sans-serif; background-color: #F2F2F2; height: 100px; margin-top: 30px; line-height:70%; padding-top: 5px; padding-bottom: 5px;">
                      <p>หากคุณไม่ได้ทำการสั่งซื้อกรุณา</p>
                      <p>ติดต่อเราที่ contact@bebefitroutine.com โทร 028216146</p>
                  </div>
              </div>
          </div>
        </div>
      </center>
      </div>
  </body>
</html>
`;

export const bebeStayFitRegisterTemplate1 = (orderdate) =>
  `
  <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <title>Bebe Stay Fit</title>

    <style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Kanit&family=Prompt:wght@200;600;700;900&display=swap');
      .colored {
        color: #000000;
      }
      .center {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .font {
        font-family: 'Prompt', sans-serif;
      }
    </style>
</head>

<body style="width: 90vw;">
      <div style=" width: 100%">
      <center>
      <div class='colored font'>

          <div style="width: 900px; height: 1220px; display: table-cell;text-align: center;vertical-align: middle;border: 1px solid #FFF; box-shadow: 1px 3px 5px 5px #c4c4c4; border-radius: 10px;">
              <div style="background-color: #FFF; font-family: 'Prompt', sans-serif;">
                  <div style="margin-top: 60px;">
                      <div>
                          <img src="https://fit.bebefitroutine.com/uploads/group198.png" style="padding-bottom: 20px">
                          <div>
                              <div style="border-bottom: 1px solid #707174; margin: 0px 40px 0px 40px;"></div>
                              <p style="font-size: 32px; font-weight: 600; color: #000000;"> ยินดีต้อนรับสมาชิกใหม่ของเรา</p>
                              <div style="border-bottom: 1px solid #707174;  margin: 0px 40px 0px 40px;"></div>
                          </div>
                      </div>
                      <div style="margin-top: 40px; font-size: 24px; line-height:100%;">
                          <p>ขอบคุณที่มาสมัครเข้าร่วมเป็นสมาชิก Bebe Stay Fit</p>
                          <p>ทางทีมงานได้รับข้อมูลการสมัครเรียบร้อยแล้ว</p>
                          <p>เราขอบคุณที่ท่านให้ความสนใจและเลือกเราเป็นส่วนหนึ่งสู่ความสำเร็จ </p>
                          <p>มาสร้างวินัย และมีความสุขกับการออกกำลังกายนะคะ </p>
                      </div>
                      <div style="width: 900px;">
                          <center>
                              <div style="width: 480px;padding: 25px;border: 1px solid; border-radius: 10px;">
                                <div style="margin-top: -20px; text-align: left;">
                                  <div style="line-height:60%;">
                                      <p style="font-size: 20px; color: #E25E96;" >วันที่ชำระ ${orderdate} </p>
                                      <p style="font-size: 26px; font-weight: 600;"> สมัครตามระยะเวลาของโปรแกรม</p>
                                      <p style="font-size: 20px; font-weight: 600;"> สิ่งที่จะได้รับ </p>
                                  </div>
                                  <div>
                                      <li>Exercise program</li>
                                      <li>Nutrition program</li>
                                      <li>Supplement program</li>
                                      <li>Fitto Plant Protein <span style="float: right;">6  กล่อง</span></li>
                                  </div>

                                  <div style="line-height:60%;">
                                    <p style="font-size: 20px; font-weight: 600;"> ฟรีของแถม</p>
                                  </div>
                                  <div>
                                      <li>Shaker <span style="float: right;">1 ชิ้น</span></li>
                                      <li>Fitto Pre Workout - Green Lemonade <span style="float: right;">1 ซอง</span></li>
                                      <li>Fitto Drink - Arabica Latte <span style="float: right;">1 ซอง</span></li>
                                      <li>Fitto Colla C Unflavored <span style="float: right;">1 ซอง</span></li>
                                  </div>

                                  <div>
                                      <p  style="font-size: 26px; font-weight: 600;"> สรุป</p>
                                      <p style="font-size: 20px;"> ราคา (รวม Vat 7%) <span style="font-weight: 600; font-size: 26px; float: right;">3,750 บาท / 2 เดือน</span></p>
                                      <p style="text-align: right; line-height:60%; font-size: 15px;  margin-top: 20px;">*ราคาพิเศษสำหรับ 2 เดือนแรก เมื่อครบกำหนดจะชำระต่อเป็นรายเดือน</p>
                                      <p style="text-align: right; line-height:60%; font-size: 15px;  margin-top: 20px;">(เดือนละ 1,800 บาท) จนกว่าจะครบตามระยะที่โปรแกรมแนะนำ</p>
                                      <p style="text-align: right; line-height:60%; font-size: 15px;  margin-top: 20px;">**สามารถพักการชำระรายเดือนได้ทุกเวลาตามที่ต้องการ</p>
                                  </div>
                              </div>
                            </div>
                          </center>
                      </>
                  </div>
                      <button style="width: 200px; height: 50px; margin-top: 30px; border-radius: 50px; border: 1px solid #E25E96; background-color: #E25E96; font-size: 20px; color: #FFF; font-family: 'Prompt', sans-serif;" type="button">
                        <a href="https://fit.bebefitroutine.com/#/welcome_new_nember" style="color: white; text-decoration: none;">
                        เริ่มต้นใช้งาน
                        </a>
                      </button>
                  <div style="font-family: 'Prompt', sans-serif; background-color: #F2F2F2; height: 100px; margin-top: 30px; line-height:70%; padding-top: 5px; padding-bottom: 5px;">
                      <p>หากคุณไม่ได้ทำการสั่งซื้อกรุณา</p>
                      <p>ติดต่อเราที่ contact@bebefitroutine.com โทร 028216146</p>
                  </div>
              </div>
          </div>
        </div>
      </center>
      </div>
  </body>
</html>
`;

export const bebeStayFitRegisterTemplate2 = (orderdate) =>
  `
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <title>Bebe Stay Fit</title>

      <style type="text/css">
      @import url('https://fonts.googleapis.com/css2?family=Kanit&family=Prompt:wght@200;600;700;900&display=swap');
        .colored {
          color: #000000;
        }
        .center {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      body {
        font-family: 'Prompt', sans-serif;
      }
      </style>
  </head>

  <body style="width: 90vw;">
    <div style="width: 100%;">
      <center>
          <div class='colored'>
              <div style="width: 900px; height: 1220px; display: table-cell;text-align: center;vertical-align: middle;border: 1px solid #FFF; box-shadow: 1px 3px 5px 5px #c4c4c4; border-radius: 10px;">
                <div style="background-color: #FFF; font-family: 'Prompt', sans-serif;">
                    <div style="margin-top: 60px;">
                        <div>
                            <img src="https://fit.bebefitroutine.com/uploads/group198.png" style="padding-bottom: 20px">
                            <div>
                                <div style="border-bottom: 1px solid #707174; margin: 0px 40px 0px 40px;"></div>
                                <p style="font-size: 32px; font-weight: 600;"> ยินดีต้อนรับสมาชิกใหม่ของเรา</p>
                                <div style="border-bottom: 1px solid #707174;  margin: 0px 40px 0px 40px;"></div>
                            </div>
                        </div>
                        <div style="margin-top: 40px; font-size: 24px; line-height:100%;">
                            <p>ขอบคุณที่มาสมัครเข้าร่วมเป็นสมาชิก Bebe Stay Fit</p>
                            <p>ทางทีมงานได้รับข้อมูลการสมัครเรียบร้อยแล้ว</p>
                            <p>เราขอบคุณที่ท่านให้ความสนใจและเลือกเราเป็นส่วนหนึ่งสู่ความสำเร็จ </p>
                            <p>มาสร้างวินัย และมีความสุขกับการออกกำลังกายนะคะ </p>
                        </div>
                        <div style="width: 900px;">
                          <center>
                              <div style="width: 480px;padding: 25px;border: 1px solid; border-radius: 10px;">
                                <div style="margin-top: -20px; text-align: left;">
                                  <div style="line-height:60%;">
                                      <p style="font-size: 20px; color: #E25E96;">วันที่ชำระ ${orderdate}</p>
                                      <p style="font-size: 26px; font-weight: 600;"> สมัครตามระยะเวลาของโปรแกรม</p>
                                      <p style="font-size: 20px; font-weight: 600;"> สิ่งที่จะได้รับ </p>
                                  </div>
                                  <div>
                                      <li>Exercise program</li>
                                      <li>Nutrition program</li>
                                      <li>Supplement program</li>
                                      <li style=" display: flex;justify-content: space-between;">Fitto Plant Protein <span>6  กล่อง</span></li>
                                  </div>

                                  <div>
                                    <p  style="font-size: 26px; font-weight: 600;"> สรุป</p>
                                    <p style="font-size: 20px;"> ราคา (รวม Vat 7%) <span style="font-weight: 600; font-size: 26px; float: right;">3,990 บาท</span></p>
                                  </div>
                              </div>
                            </div>
                          </center>
                        </div>
                    </div>
                        <button style="width: 200px; height: 50px; margin-top: 30px; border-radius: 50px; border: 1px solid #E25E96; background-color: #E25E96; font-size: 20px; color: #FFF; font-family: 'Prompt', sans-serif;" type="button">
                          <a href="https://fit.bebefitroutine.com/#/welcome_new_nember" style="color: white; text-decoration: none">
                          เริ่มต้นใช้งาน
                          </a>
                        </button>
                    <div style="font-family: 'Prompt', sans-serif; background-color: #F2F2F2; height: 100px; margin-top: 30px; line-height:70%; padding-top: 5px; padding-bottom: 5px;">
                        <p>หากคุณไม่ได้ทำการสั่งซื้อ</p>
                        <p>ติดต่อเราที่ contact@bebefitroutine.com โทร 028216146</p>
                    </div>
                </div>
            </div>
          </div>
      </center>
    </div>
  </body>
</html>
`;
export const bebeStayFitRequestTaxInvoice = (content) =>
  `
<!DOCTYPE html>
  <html lang="en">

  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <title>Bebe Stay Fit</title>

      <style type="text/css">
      @import url('https://fonts.googleapis.com/css2?family=Kanit&family=Prompt:wght@200;600;700;900&display=swap');
        .colored {
          color: #000000;
        }
        .center {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      body {
        font-family: 'Prompt', sans-serif;
      }
      table {
        font-size: 15px;
        border-collapse: collapse;
        width: 100%;
        background-color: white;
      }
      td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
      }

      </style>
  </head>

  <body>
    <div style="width: 100%;">
      <center>
          <div class='colored'>
              <div style="width: 900px; padding-bottom: 20px; display: table-cell;text-align: center;vertical-align: middle;border: 1px solid #FFF; box-shadow: 1px 3px 5px 5px #c4c4c4; border-radius: 10px;">
                <div style="background-color: #FFF; font-family: 'Prompt', sans-serif;">
                    <div style="margin-top: 60px;">
                        <div style="line-height:100%;">
                        <img src="https://fit.bebefitroutine.com/uploads/group198.png" style="padding-bottom: 20px">
                            <div>
                                <div style="border-bottom: 1px solid #707174; margin: 0px 40px 0px 40px;"></div>
                                <p style="font-size: 32px; font-weight: 600;">ขอใบกำกับภาษี</p>
                                <div style="border-bottom: 1px solid #707174;  margin: 0px 40px 0px 40px;"></div>
                            </div>
                        </div>
                        <div style="text-align:left; padding-left: 100px;  mmargin-top: 40px; font-size: 24px; line-height:100%;">
                            <p>เรียนฝ่ายบัญชี</p>
                            <br>
                            <p>ผู้ใช้ <span style="font-weight: 600;">${content.email}</span></p>
                            <p>ต้องการขอรับใบกำกับภาษี</p>
                            <div style=" box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); width: 90%; background-color: #F2F2F2;">
                              <div style="padding: 2px 16px;">
                                <p>Order ID : <span style="font-weight: 600;"> ${content.order_id} </span></p>
                                <p>ชื่อผู้เสียภาษี : <span style="font-weight: 600;"> ${content.InvoiceTaxpayerName} </span></p>
                                <p>ชื่อสาขา (สำหรับนิติบุคคล) : <span style="font-weight: 600;"> ${content.InvoiceTaxpayerBranchName} </span></p>
                                <p>เลขประจำตัวผู้เสียภาษี : <span style="font-weight: 600;"> ${content.InvoiceTaxIdentificationNumber} </span></p>
                                <p>เบอร์โทรศัพท์ : <span style="font-weight: 600;"> ${content.InvoiceTelephone} </span></p>
                                <p>ที่อยู่ออกใบกำกับภาษี : <span style="font-weight: 600;"> ${content.taxInvoiceAddress} </span></p>
                                <p>ที่อยู่จัดส่งสินค้า : <span style="font-weight: 600;"> ${content.shippingaddress} </span></p>
                                <p><span style="font-weight: 600;">รายการสินค้า</span></p>
                                <table>
                                  <tr>
                                    <th>#</th>
                                    <th>รหัส</th>
                                    <th>ชื่อสินค้า</th>
                                    <th>จำนวน</th>
                                  </tr>
                                  ${content.list.map((item, index) =>
    `
                                      <tr>
                                       <td>${index + 1}</td>
                                       <td>${item.sku}</td>
                                       <td>${item.name}</td>
                                       <td>${item.number}</td>
                                      </tr>
                                      `
  )}
                                </table>
                                <p>มูลค่ารวมสุทธิ : <span style="font-weight: 600;"> ${parseFloat(content.amount).toLocaleString('en')} บาท</span></p>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div style="font-family: 'Prompt', sans-serif; background-color: #F2F2F2; height: 100px; margin-top: 30px; line-height:70%; padding-top: 5px; padding-bottom: 5px;">
                        <p>ติดต่อเราที่</p>
                        <p>contact@bebefitroutine.com</p>
                        <p>โทร 028216146</p>
                    </div>
                </div>
            </div>
          </div>
      </center>
    </div>
  </body>
  </html>
`;

export const bebeStayFitResetPassword = (email) =>
  `<!DOCTYPE html>
  <html lang="en">

  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <title>Bebe Stay Fit</title>

      <style type="text/css">
      @import url('https://fonts.googleapis.com/css2?family=Kanit&family=Prompt:wght@200;600;700;900&display=swap');
        .colored {
          color: #000000;
        }
        .center {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      body {
        font-family: 'Prompt', sans-serif;
      }
      </style>
  </head>

  <body>
    <div style="width: 100%;">
      <center>
          <div class='colored'>
              <div style="width: 900px; padding-bottom: 20px; display: table-cell;text-align: center;vertical-align: middle;border: 1px solid #FFF; box-shadow: 1px 3px 5px 5px #c4c4c4; border-radius: 10px;">
                <div style="background-color: #FFF; font-family: 'Prompt', sans-serif;  padding-left: 20px;padding-right: 20px; ">
                    <div style="margin-top: 60px;">
                        <div>
                        <img src="https://fit.bebefitroutine.com/uploads/group198.png" style="padding-bottom: 20px;padding-top: 40px;">
                            <div>
                                <div style="border-bottom: 1px solid #707174; margin: 0px 40px 0px 40px;"></div>
                                <p style="font-size: 32px; font-weight: 600;"> คำขอเปลี่ยนรหัสผ่านใหม่</p>
                                <div style="border-bottom: 1px solid #707174;  margin: 0px 40px 0px 40px;"></div>
                            </div>
                        </div>
                        <div style="text-align: center;
display: inline-block;">
                          <div style="text-align:left;   margin-top: 40px; font-size: 20px; ">
                            <p>เรียนคุณ   <span style="font-weight: 600;">${email}</span></p>
                            <p>เราได้รับคำขอในการเปลี่ยนรหัสผ่านใหม่</p>
                            <p>กรุณากดปุ่มด้านล่างเพื่อทำการตั้งรหัสผ่านใหม่</p>
                          </div>
                        </div>
                    </div>
                    <div>
                    <a href="https://fit.bebefitroutine.com/#/new_password?email=${email}" style="color: white;  text-decoration: none;">
                    <button style="cursor: pointer ;width: 200px; height: 50px; margin-top: 30px; border-radius: 50px; border: 1px solid #E25E96; background-color: #E25E96; font-size: 20px; color: #FFF; font-family: 'Prompt', sans-serif;" type="button">
                    เปลี่ยนรหัสผ่านใหม่
                    </button>
                     </a>
                    </div>

                    <div style="font-family: 'Prompt', sans-serif; font-size: 18px; background-color: #F2F2F2;  margin-top: 30px;  padding-top: 5px; padding-bottom: 5px;">
                    <p>ติดต่อเราที่</p>
                    <p>contact@bebefitroutine.com</p>
                    <p>โทร 028216146</p>
                    </div>
                </div>
            </div>
          </div>
      </center>
    </div>
  </body>
  </html>
`;

export const simpleTemplate = (
  subject,
  content,
  link,
  mainButtonLabel = "Go"
) =>
  `
        <div leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:auto !important;width:100% !important; font-family: Helvetica,Arial,sans-serif !important; margin-bottom: 40px;">
            <center>
                <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" style="max-width:600px; background-color:#ffffff;border:1px solid #e4e2e2;border-collapse:separate !important; border-radius:4px;border-spacing:0;color:#242128; margin:0;padding:40px;"
                    heigth="auto">
                    <tbody>
                        <tr>
                            <td colSpan="2" style="padding-top:10px;">
                                <h3 style="color:#303030; font-size:18px; line-height: 1.6; font-weight:500;">${subject}</h3>
                                <p style="color:#8f8f8f; font-size: 14px; padding-bottom: 20px; line-height: 1.4;">
                                    ${content}
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan="2">
                                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse;">
                                    <tbody>
                                        <tr>
                                            <td style="padding:15px 0px;" valign="top" align="center">
                                                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate !important;">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center" valign="middle" style="padding:13px;">
                                                                <a
                                                                    href="${link}"
                                                                    title="${mainButtonLabel}"
                                                                    target="_blank"
                                                                    style="font-size: 14px; line-height: 1.5; font-weight: 700; letter-spacing: 1px; padding: 15px 40px; text-align:center; text-decoration:none; color:#FFFFFF; border-radius: 50px; background-color:#922c88;"
                                                                >
                                                                    ${mainButtonLabel}
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="margin-top:30px; padding-bottom:20px;; margin-bottom: 40px;">
                    <tbody>
                        <tr>
                            <td align="center" valign="center">
                                <p style="font-size: 12px; text-decoration: none;line-height: 1; color:#909090; margin-top:0px; margin-bottom:5px; ">
                                    บริษัท ฟิต ทูเกทเธอร์ จำกัด (สำนักงานใหญ่) 11/17 ซอยร่วมฤดี แขวงลุมพินี เขตปทุมวัน กรุงเทพฯ 10330
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </center>
        </div>
    `;

export const registerTemplate = () =>
  `
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <meta name="format-detection" content="telephone=no" />
      <meta
        name="viewport"
        content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;"
      />
      <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

      <title>TBPA Registration</title>

      <style type="text/css">
        @import url('https://fonts.googleapis.com/css2?family=Prompt:ital,wght@1,400;1,700&display=swap');

        * {
          padding: 0;
          margin: 0;
          box-sizing: border-box;
        }
        body {
          font-family: 'Prompt', sans-serif;
          font-size: 18px;
        }
        img {
          width: 100%;
        }
        hr {
          border: 0;
          height: 1px;
          background: #979797;
        }
        hr.short {
          border: 0;
          height: 4px;
          background: #979797;
        }
        a {
          text-decoration: none;
          font-weight: bold;
          color: #003CFF;
        }
        a:hover {
          text-decoration: underline;
          color: #E85368
        }
        .content {
          height: 420px;
          background: #1E2836;
          padding: 40px 0;
          color: #fff;
        }
        .content h2 {
          text-align: center;
          margin-bottom: 20px;
        }
        .content .list {
          padding: 0 10%;
        }
        .content p {
          margin: 10px 0;
        }
        .topic {
          text-align: end;
          padding-top: 45px;
        }
        .topic img {
          width: 88%;
        }
        .topic .subheader {
          text-align: center;
          margin: 20px 0;
        }
        .topic p {
          text-align: start;
          padding: 0 30px 40px 40px;
        }
        .dark-bg {
          background: #D6D6D6;
        }
        .red-text {
          color: #D20D29;
          font-weight: bold;
        }
        .hr-wrapper {
          padding: 0 40px;
          text-align: center;
          margin-bottom: 40px;
        }

        .hr-short-wrapper {
          padding: 0 45%;
          text-align: center;
          margin-bottom: 40px;
        }

        .reward {
          margin: 0px 60px;
          padding: 20px 40px 0 40px;
        }
        .belt {
          background: #1E2836;
          padding: 10px 0;
          color: #fff;
        }
        .belt h2 {
          text-align: center;
          margin-bottom: 20px;
        }

        @media only screen and (min-width: 769px) {
          .page {
            width: 768px;
            margin: 0 auto;
          }
        }
      </style>
    </head>
    <body>
      <div
        class="page"
      >
        <div>
          <img
            src="https://cdn.planforfit.com/tbpa/header.jpg"
            alt="welcome to tbpa course"
          />
        </div>
        <div class="content">
          <h2>อีเมล์นี้มีรายละเอียดโปรแกรมมาแจ้งให้ทราบด้วยกัน 5 เรื่องคือ</h2>
          <div class="list">
            <p>01 ระยะเวลาการเริ่มโปรแกรม</p>
            <hr class="list">
            <p>02 วิธีการทำตามโปรแกรม</p>
            <hr>
            <p>03 ช่องทางการติดต่อสื่อสารกับทีมโค้ช</p>
            <hr>
            <p>04 สิ่งที่ต้องทำก่อนการเริ่มโปรแกรม</p>
            <hr>
            <p>05 กติการเงินรางวัล</p>
          </div>
        </div>
        <div class="topic">
          <img src="https://cdn.planforfit.com/tbpa/topic1.png" alt="topic 1">
          <p class="subheader">โปรแกรมนี้มีระยะเวลาการเข้าร่วม 45 วัน <strong>ตั้งแต่วันที่ 1 เมษายน - 15 พฤษภาคม 2563</strong></p>
        </div>
        <div class="topic dark-bg">
          <img src="https://cdn.planforfit.com/tbpa/topic2.png" alt="topic 2">
          <p class="subheader">สำหรับการทำตามโปรแกรมนี้ เราจะแบ่งเป็น 2 ส่วนคือ <strong>โภชนาการและการออกกำลังกาย</strong></p>
          <p><span class="red-text">1.โภชนาการ</span> เราเลือกใช้วิธีการแนะนำวิธีการกินแบบง่ายแต่ได้ผลด้วยวิธีการ Portion Control (กินแบบ 2:1:1
          ผัก 2 ส่วน แป้ง 1 ส่วน โปรตีน 1 ส่วน) ซีึ่งในแต่ละวันคุณสามารถเลือกทานเมนูอะไรก็ได้ตามสะดวก เมนูที่ทานต้องแบ่งเป็น Portion Control โดยคุณสามารถอ่านวิธีการทานอย่างละเอียดได้ที่
          <a href="https://tbpa.asia/login">https://tbpa.asia/login</a></p>
          <div class="hr-wrapper">
            <hr>
          </div>
          <p>
            <span class="red-text">2.การออกกำลังกาย</span> ในส่วนการออกกำลังกายตามโปรแกรม สามารถแบ่งย่อยได้ 2 ส่วนคือ Body Weight Training และการเบิร์นไขมัน
            <br>
            <strong>- Body Weight Training</strong> ให้ฝึก 3 วันต่อสัปดาห์ จะเป็นวันไหนเวลาไหนก็ได้ตามสะดวก เพื่อฝึกให้กล้ามเนื้อแข็งแรงและพัฒนาได้ดี
            <br>
            <strong>- การเบิร์นไขมัน</strong> เราได้มีการจัดคลิปวิดีโอประเภทเบิร์นไขมันให้ได้เลือกฝึกตามความชอบ
          </p>
          <p class="subheader"><strong>
            โดยสามารถแบ่งคลิปได้ 2 ประเภทคือ Circuit Training และ NEAT ในแต่ละสัปดาห์ เราจะกำหนดเป็นคะแนนให้ฝึก โดยจะเริ่มต้นที่ 15 คะแนนต่อสัปดาห์
            <br>
            (นับคะแนนจันทร์-อาทิตย์)
          </strong></p>
          <div class="hr-short-wrapper">
            <hr class="short">
          </div>
          <p class="subheader"><strong>
            คุณสามารถเลือกวีดีโอฝึกได้ตามความชอบเพื่อเก็บคะแนนในสัปดาห์นั้นให้ครบ และสามารถตรวจสอบวิธีการการออกกำลังกายอย่างละเอียดได้ที่
            <br>
            <a href="https://tbpa.asia/login">https://tbpa.asia/login</a>
          </strong></p>
        </div>
        <div class="topic">
          <img src="https://cdn.planforfit.com/tbpa/topic3.png" alt="topic 3">
          <p></p>
          <p>
            <strong><span class="red-text">- Facebook Group</span> ในการติดต่อสื่อสารตลอดระยะเวลาโปรแกรมนี้</strong>
            <br>
            เราจะสื่อสารพูดคุย ตามทุกข้อสงสัยทั้งการกิน และการออกกำลังกายรวมถึงกิจกรรมให้ร่วมสนุกตลอดโปรแกรมผ่าน Facebook Group หากคุณยังไม่ได้เข้าร่วมสามารถกดที่ลิงค์นี้เพื่อเข้ากลุ่ม
            <a href="https://www.facebook.com/sixpackonlinebyTBPA">https://www.facebook.com/sixpackonlinebyTBPA</a>
          </p>
          <p>
            <strong><span class="red-text">- การบันทึกผลการกินและดูโปรแกรมออกกำลังกาย</span></strong>
            สามารถเข้าดูได้ที่ <a href="https://tbpa.asia/login">https://tbpa.asia/login</a> รหัสการเข้าคืออีเมล์ และพาสเวิร์ดที่ตั้งไว้ตอนที่ลงทะเบียน
          </p>
        </div>
        <div class="topic dark-bg">
          <img src="https://cdn.planforfit.com/tbpa/topic4.png" alt="topic 4">
          <p></p>
          <p>
            สิ่งที่เราอยากให้คุณทำเพื่อเป็นการวัดผลความสำเร็จในการเข้าร่วมคือการบันทึกน้ำหนัก สัดส่วนปัจจุบัน และรูปถ่ายที่เห็นสัดส่วนชัดเจน ไม่ผ่านการตัดต่อใด ๆ ที่โพสต์
            <a href="https://www.facebook.com/groups/6packonlinebyTBPA/learning_content/">คลิก</a>
            เพื่อเก็บเป็นผลลัพธ์ก่อนเข้าร่วมกลุ่ม
          </p>
          <p>
            <strong>โดยเมื่อจบโปรแกรมจะมีการเก็บบันทึกผลหลังการเข้าร่วมอีกครั้งเพื่อวัดการเปลี่ยนแปลง</strong>
          </p>
        </div>
        <div class="topic">
          <img src="https://cdn.planforfit.com/tbpa/topic5.png" alt="topic 5">
          <p class="subheader">
            หลังจาการจบโปรแกรมนี้เราจะมีเงินรางวัลให้กับผู้ที่เปลี่ยนแปลงแบบที่ชัดดเจนที่สุดทั้งหมด 25 ท่าน โดยมีรายละเอียดแต่ละลำดับดังนี้
          </p>
          <div class="reward dark-bg">
            <p>อันดับที่ 1 <strong>เงินรางวัล 10,000 บาท</strong></p>
            <p>อันดับที่ 2 <strong>เงินรางวัล 8,000 บาท</strong></p>
            <p>อันดับที่ 3 <strong>เงินรางวัล 6,000 บาท</strong></p>
            <p>อันดับที่ 4 <strong>เงินรางวัล 4,000 บาท</strong></p>
            <p>อันดับที่ 5 <strong>เงินรางวัล 2,000 บาท</strong></p>
            <p>อันดับที่ 6-25 <strong>เงินรางวัล 1,000 บาท</strong></p>
          </div>
          <p></p>
          <p>และสำหรับเกณฑ์การตัดสินผู้มีสิทธิ์ได้รับเงินรางวัลมีดังต่อไปนี้</p>
          <p><span class="red-text"><strong>1. ส่งบันทึก</strong></span> ผลการกินอาหารทุกวัน ทุกมื้อ ผ่านระบบ <a href="https://tbpa.asia/login">https://tbpa.asia/login</a></p>
          <p><span class="red-text"><strong>2. เก็บคะแนน</strong></span> การเบิร์นไขมันครบทุกสัปดาห์</a></p>
          <p><span class="red-text"><strong>3. ส่งประเมิน</strong></span> รายสัปดาห์ผ่าน <a href="https://tbpa.asia/login">https://tbpa.asia/login</a> (ส่งได้ทุกวันเสาร์ - อาทิตย์)</p>
          <p><span class="red-text"><strong>4. มีการเปลี่ยน</strong></span> ทางน้ำหนัก หรือสัดส่วน หรือเห็น 6-pack ชัดเจนที่สุด เมื่อเปรียบเทียบการเปลี่ยนแปลงก่อนและหลังการเข้าโปรแกรมของผู้เข้าร่วมเอง</p>
        </div>
        <div class="belt">
          <h2>การตัดสินของคณะกรรมการ และทีมงานถือเป็นที่สิ้นสุด</h2>
        </div>
        <div class="topic">
          <p class="subheader">
            หากมีข้อสงสัยใด ๆ เพิ่มเติม สามารถติดตามรายละเอียด และสอบถามข้อมูลที่ Facebook Group ได้ตลอดระยะเวลาการร่วมโปรแกรม <a href="https://www.facebook.com/sixpackonlinebyTBPA">https://www.facebook.com/sixpackonlinebyTBPA</a>
          </p>
        </div>
      </div>
    </body>
  </html>

`;

export const paymentResume = () => `
<!DOCTYPE HTML
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
  <!--[if gte mso 9]>
<xml>
  <o:OfficeDocumentSettings>
    <o:AllowPNG/>
    <o:PixelsPerInch>96</o:PixelsPerInch>
  </o:OfficeDocumentSettings>
</xml>
<![endif]-->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="x-apple-disable-message-reformatting">
  <!--[if !mso]><!-->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!--<![endif]-->
  <title></title>

  <style type="text/css">
    table,
    td {
      color: #000000;
    }

    a {
      color: #0000ee;
      text-decoration: underline;
    }

    @media (max-width: 480px) {
      #u_content_image_1 .v-src-width {
        width: 229px !important;
      }

      #u_content_image_1 .v-src-max-width {
        max-width: 45% !important;
      }
    }

    @media only screen and (min-width: 670px) {
      .u-row {
        width: 650px !important;
      }

      .u-row .u-col {
        vertical-align: top;
      }

      .u-row .u-col-100 {
        width: 650px !important;
      }

    }

    @media (max-width: 670px) {
      .u-row-container {
        max-width: 100% !important;
        padding-left: 0px !important;
        padding-right: 0px !important;
      }

      .u-row .u-col {
        min-width: 320px !important;
        max-width: 100% !important;
        display: block !important;
      }

      .u-row {
        width: calc(100% - 40px) !important;
      }

      .u-col {
        width: 100% !important;
      }

      .u-col>div {
        margin: 0 auto;
      }
    }

    body {
      margin: 0;
      padding: 0;
    }

    table,
    tr,
    td {
      vertical-align: top;
      border-collapse: collapse;
    }

    p {
      margin: 0;
    }

    .ie-container table,
    .mso-container table {
      table-layout: fixed;
    }

    * {
      line-height: inherit;
    }

    a[x-apple-data-detectors='true'] {
      color: inherit !important;
      text-decoration: none !important;
    }
  </style>



</head>

<body class="clean-body u_body"
  style="margin: 0;padding: 0;-webkit-text-size-adjust: 100%;background-color: #f8fafb;color: #000000">
  <!--[if IE]><div class="ie-container"><![endif]-->
  <!--[if mso]><div class="mso-container"><![endif]-->
  <table
    style="border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;min-width: 320px;Margin: 0 auto;background-color: #f8fafb;width:100%"
    cellpadding="0" cellspacing="0">
    <tbody>
      <tr style="vertical-align: top">
        <td style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
          <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" style="background-color: #f8fafb;"><![endif]-->

          <div class="u-row-container" style="padding: 0px;background-color: transparent">
            <div class="u-row"
              style="Margin: 0 auto;min-width: 320px;max-width: 650px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #ffffff;">
              <div style="border-collapse: collapse;display: table;width: 100%;background-color: transparent;">
                <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:650px;"><tr style="background-color: #ffffff;"><![endif]-->

                <!--[if (mso)|(IE)]><td align="center" width="650" style="background-color: #040485;width: 650px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;" valign="top"><![endif]-->
                <div class="u-col u-col-100"
                  style="max-width: 320px;min-width: 650px;display: table-cell;vertical-align: top;">
                  <div style="background-color: #040485;width: 100% !important;">
                    <!--[if (!mso)&(!IE)]><!-->
                    <div
                      style="padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">
                      <!--<![endif]-->

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:30px 10px 0px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <div
                                style="color: #ffffff; line-height: 140%; text-align: center; word-wrap: break-word;">
                                <p style="font-size: 14px; line-height: 140%;"><span
                                    style="font-family: helvetica, sans-serif; font-size: 24px; line-height: 33.6px;">อีกนิดเดียวการลงทะเบียนเข้าร่วม</span>
                                </p>
                              </div>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:5px 10px 30px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <div
                                style="color: #ffffff; line-height: 120%; text-align: center; word-wrap: break-word;">
                                <p style="font-size: 14px; line-height: 120%;"><span
                                    style="font-size: 26px; line-height: 31.2px;"><strong><span
                                        style="font-family: helvetica, sans-serif; line-height: 31.2px; font-size: 26px;">CCR จะสำเร็จ !</span></strong></span></p>
                              </div>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <!--[if (!mso)&(!IE)]><!-->
                    </div>
                    <!--<![endif]-->
                  </div>
                </div>
                <!--[if (mso)|(IE)]></td><![endif]-->
                <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
              </div>
            </div>
          </div>



          <div class="u-row-container" style="padding: 0px;background-color: transparent">
            <div class="u-row"
              style="Margin: 0 auto;min-width: 320px;max-width: 650px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: transparent;">
              <div style="border-collapse: collapse;display: table;width: 100%;background-color: transparent;">
                <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:650px;"><tr style="background-color: transparent;"><![endif]-->

                <!--[if (mso)|(IE)]><td align="center" width="650" style="width: 650px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;" valign="top"><![endif]-->
                <div class="u-col u-col-100"
                  style="max-width: 320px;min-width: 650px;display: table-cell;vertical-align: top;">
                  <div style="width: 100% !important;">
                    <!--[if (!mso)&(!IE)]><!-->
                    <div
                      style="padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">
                      <!--<![endif]-->

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:0px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                <tr>
                                  <td style="padding-right: 0px;padding-left: 0px;" align="center">

                                    <img align="center" border="0"
                                      src="https://pot.planforfit.com/img/register/main_uncomplete.png" alt="Hero Image"
                                      title="Hero Image"
                                      style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: inline-block !important;border: none;height: auto;float: none;width: 100%;max-width: 650px;"
                                      width="650" class="v-src-width v-src-max-width" />

                                  </td>
                                </tr>
                              </table>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <!--[if (!mso)&(!IE)]><!-->
                    </div>
                    <!--<![endif]-->
                  </div>
                </div>
                <!--[if (mso)|(IE)]></td><![endif]-->
                <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
              </div>
            </div>
          </div>



          <div class="u-row-container" style="padding: 0px;background-color: transparent">
            <div class="u-row"
              style="Margin: 0 auto;min-width: 320px;max-width: 650px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #ffffff;">
              <div style="border-collapse: collapse;display: table;width: 100%;background-color: transparent;">
                <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:650px;"><tr style="background-color: #ffffff;"><![endif]-->

                <!--[if (mso)|(IE)]><td align="center" width="650" style="background-color: #ffffff;width: 650px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;" valign="top"><![endif]-->
                <div class="u-col u-col-100"
                  style="max-width: 320px;min-width: 650px;display: table-cell;vertical-align: top;">
                  <div style="background-color: #ffffff;width: 100% !important;">
                    <!--[if (!mso)&(!IE)]><!-->
                    <div
                      style="padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">
                      <!--<![endif]-->

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:17px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <div
                                style="color: #000000; line-height: 140%; text-align: center; word-wrap: break-word;">
                                <p style="font-size: 14px; line-height: 140%;">&nbsp;</p>
                                <p style="font-size: 14px; line-height: 140%;"><span
                                    style="font-family: helvetica, sans-serif; font-size: 18px; line-height: 25.2px;">เหลืออีกเพียง
                                    1 ขั้นตอนเท่านั้นสำหรับการลงทะเบียนเข้าร่วมเทรนออนไลน์ CCR
                                    กรุณาคลิกที่นี่เพื่อทำรายการต่อ</span></p>
                              </div>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:8px 10px 16px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <div align="center">
                                <!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;font-family:arial,helvetica,sans-serif;"><tr><td style="font-family:arial,helvetica,sans-serif;" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="https://pot.planforfit.com/login.html" style="height:50px; v-text-anchor:middle; width:214px;" arcsize="0%" stroke="f" fillcolor="#040485"><w:anchorlock/><center style="color:#FFFFFF;font-family:arial,helvetica,sans-serif;"><![endif]-->
                                <a href="https://sale.ccrdiet.co/checkout" target="_blank"
                                  style="box-sizing: border-box;display: inline-block;font-family:arial,helvetica,sans-serif;text-decoration: none;-webkit-text-size-adjust: none;text-align: center;color: #FFFFFF; background-color: #040485; border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px; width:34%; max-width:100%; overflow-wrap: break-word; word-break: break-word; word-wrap:break-word; mso-border-alt: none;">
                                  <span style="display:block;padding:15px 30px 16px;line-height:120%;"><span
                                      style="font-size: 16px; line-height: 19.2px; font-family: helvetica, sans-serif;">คลิก</span></span>
                                </a>
                                <!--[if mso]></center></v:roundrect></td></tr></table><![endif]-->
                              </div>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <!--[if (!mso)&(!IE)]><!-->
                    </div>
                    <!--<![endif]-->
                  </div>
                </div>
                <!--[if (mso)|(IE)]></td><![endif]-->
                <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
              </div>
            </div>
          </div>



          <div class="u-row-container" style="padding: 0px;background-color: transparent">
            <div class="u-row"
              style="Margin: 0 auto;min-width: 320px;max-width: 650px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #ffffff;">
              <div style="border-collapse: collapse;display: table;width: 100%;background-color: transparent;">
                <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:650px;"><tr style="background-color: #ffffff;"><![endif]-->

                <!--[if (mso)|(IE)]><td align="center" width="650" style="background-color: #ffffff;width: 650px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;" valign="top"><![endif]-->
                <div class="u-col u-col-100"
                  style="max-width: 320px;min-width: 650px;display: table-cell;vertical-align: top;">
                  <div style="background-color: #ffffff;width: 100% !important;">
                    <!--[if (!mso)&(!IE)]><!-->
                    <div
                      style="padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">
                      <!--<![endif]-->

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:10px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <table height="0px" align="center" border="0" cellpadding="0" cellspacing="0" width="93%"
                                style="border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;border-top: 1px solid #BBBBBB;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%">
                                <tbody>
                                  <tr style="vertical-align: top">
                                    <td
                                      style="word-break: break-word;border-collapse: collapse !important;vertical-align: top;font-size: 0px;line-height: 0px;mso-line-height-rule: exactly;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%">
                                      <span>&#160;</span>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                        cellspacing="0" width="100%" border="0">
                        <tbody>
                          <tr>
                            <td
                              style="overflow-wrap:break-word;word-break:break-word;padding:10px 10px 27px;font-family:arial,helvetica,sans-serif;"
                              align="left">

                              <div
                                style="color: #000000; line-height: 190%; text-align: center; word-wrap: break-word;">
                                <p style="font-size: 14px; line-height: 190%;"><span
                                    style="font-family: helvetica, sans-serif; font-size: 16px; line-height: 30.4px;">หากพบปัญหาหรือต้องการ</span>
                                </p>
                                <p style="font-size: 14px; line-height: 190%;"><span
                                    style="font-family: helvetica, sans-serif; font-size: 16px; line-height: 30.4px;">ติดต่อสอบถามเพิ่มเติมคลิก
                                    : <a target="_blank" href="https://m.me/planforfit">m.me/planforfit</a> </span></p>
                              </div>

                            </td>
                          </tr>
                        </tbody>
                      </table>

                      <!--[if (!mso)&(!IE)]><!-->
                    </div>
                    <!--<![endif]-->
                  </div>
                </div>
                <!--[if (mso)|(IE)]></td><![endif]-->
                <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
              </div>
            </div>
          </div>


          <!--[if (mso)|(IE)]></td></tr></table><![endif]-->
        </td>
      </tr>
    </tbody>
  </table>
  <!--[if mso]></div><![endif]-->
  <!--[if IE]></div><![endif]-->
</body>

</html>`;
