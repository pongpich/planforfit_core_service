import axios from "axios";

import { calculateTDEE } from "./lib/tdee";
import { query, transaction } from "../../lib/dbhelper";
import { genActivitiesInsertState } from "../../lib/someSQLs";
import { success, createSuccessListBody } from "../../lib/response-lib";

export async function insertActivities(event) {
  const data = JSON.parse(event.body);
  const { user_id, product_id } = data;
  try {
    const queryString = genActivitiesInsertState(user_id, product_id);
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function insertExerciseVideo(event) {
  const apiUrl = "https://vimeo.com/api/v2/video/";
  const data = JSON.parse(event.body);
  const { ids, category, level, score } = data;
  let level_color = "info";
  if (level.toUpperCase() === "ADVANCE") {
    level_color = "danger";
  } else if (level.toUpperCase() === "INTERMEDIATE") {
    level_color = "warning";
  }
  try {
    let promises = [];
    for (let i = 0; i < ids.length; i++) {
      promises.push(axios.get(`${apiUrl}${ids[i]}.json`));
    }
    //const apiResult = await axios.get(`${apiUrl}${id}.json`);
    const apiResults = await axios.all(promises);
    const queryStrings = apiResults.map(apiResult => {
      const {
        id,
        title,
        description,
        url,
        thumbnail_large,
        duration
      } = apiResult.data[0];
      const thumbnail =
        thumbnail_large.substring(0, thumbnail_large.lastIndexOf("_")) +
        "_270.jpg";

      return `
                        INSERT INTO exercise_video SET 
                            id = ${id}, title = '${title}',
                            description = '${description}', url = '${url}',
                            thumbnail = '${thumbnail}', duration = ${duration},
                            category = '${category}', level = '${level}',
                            level_color = '${level_color}', score = ${score}
                        ON DUPLICATE KEY UPDATE
                            title = '${title}',
                            description = '${description}', url = '${url}',
                            thumbnail = '${thumbnail}', duration = ${duration},
                            category = '${category}', level = '${level}',
                            level_color = '${level_color}', score = ${score};
                    `;
    });

    const result = await transaction(queryStrings);
    return result;
  } catch (error) {
    return error;
  }
}

export async function addVideo(event) {
  axios.defaults.headers.common[
    "Authorization"
  ] = `Bearer ${process.env.VIMEO_API_KEY}`;
  const data = JSON.parse(event.body);
  const { id, category, level, score } = data;
  const apiUrl = `https://api.vimeo.com/videos/${id}`;

  let level_color = "info";
  if (level.toUpperCase() === "ADVANCE") {
    level_color = "danger";
  } else if (level.toUpperCase() === "INTERMEDIATE") {
    level_color = "warning";
  }
  try {
    let duration = 0;
    let thumbnail_name = "default";
    let apiResult = {};
    while (duration === 0 || thumbnail_name === "default") {
      apiResult = await axios.get(apiUrl);
      duration = apiResult.data.duration;
      const link = apiResult.data.pictures.sizes[0].link;
      thumbnail_name = link.substring(
        link.lastIndexOf("/") + 1,
        link.lastIndexOf("_")
      );
      if (duration === 0 || thumbnail_name === "default") await sleep(4000);
    }
    const { name, description, link, pictures } = apiResult.data;
    const thumbnail_link = pictures.sizes[0].link;
    const thumbnail =
      thumbnail_link.substring(0, thumbnail_link.lastIndexOf("_")) + "_270.jpg";

    const queryString = `
                    INSERT INTO exercise_video SET 
                        id = ${id}, title = "${name}",
                        description = "${description}", url = "${link}",
                        thumbnail = "${thumbnail}", duration = ${duration},
                        category = "${category}", level = "${level}",
                        level_color = "${level_color}", score = ${score}
                    ON DUPLICATE KEY UPDATE
                        title = "${name}",
                        description = "${description}", url = "${link}",
                        thumbnail = "${thumbnail}", duration = ${duration},
                        category = "${category}", level = "${level}",
                        level_color = "${level_color}", score = ${score};
                `;
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export function getTrainingSuite(workout_day) {
  let training_suite = 'suite3day';
  if(workout_day <= 3) {
    training_suite = 'suite3day';
  } else if (workout_day === 4) {
    training_suite = 'suite4day';
  } else {
    training_suite = 'suite5day';
  }

  return training_suite;
}

export async function createHealthProfile(event) {
  const data = JSON.parse(event.body);
  const {
    user_id,
    product_id,
    program_id,
    workout_day
  } = data;
  const training_suite = getTrainingSuite(workout_day);
  try {
    const healthProfile = calculateTDEE(data);
    const queryString = `CALL ccrAddFirstProgram(
      '${user_id}', 
      '${product_id}',
      '${program_id}',
      '${training_suite}',
      '${JSON.stringify(healthProfile)}'
    );`
    console.log("inside createHealthProfile:", queryString);
    await query(queryString);
    
    return success(createSuccessListBody(healthProfile));
  } catch (error) {
    console.log("inside createHealthProfile error:", error);
    return error;
  }
}

export async function resetCCRHealthProfile(event) {
  const data = JSON.parse(event.body);
  const {
    user_id,
    program_id,
    workout_day
  } = data;
  const training_suite = getTrainingSuite(workout_day);
  try {
    const healthProfile = calculateTDEE(data);
    const queryString = `CALL resetCCRProfile(
      '${user_id}', 
      '${program_id}',
      '${training_suite}',
      '${JSON.stringify(healthProfile)}'
    );`
    console.log("inside resetCCRHealthProfile:", queryString);
    await query(queryString);
    
    return success(createSuccessListBody(healthProfile));
  } catch (error) {
    console.log("inside createHealthProfile error:", error);
    return error;
  }
}

function sleep(ms) {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
}
