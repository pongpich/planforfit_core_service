import { query, transaction } from "../../lib/dbhelper";
import axios from "axios";
import request from "request";

import { success, failure, createSuccessListBody, createFailureBody } from "../../lib/response-lib";
import { getTrainingSuite } from "./create";
import { reCalculateMainInfo } from "./lib/tdee";

export async function updateActivity(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, program_id, week_in_program, activities } = data;
    const activitiesString = JSON.stringify(activities);
    const actString = program_id.includes('ccr') 
                        ? `JSON_SET('${activitiesString}',
                            '$.weekly_plan.completeness', ccrIsHomeworkCompleteDetail('${activitiesString}', user_id)
                          )`
                        : `'${activitiesString}'`;
    const activityQuery = `
            UPDATE daily_activity SET
            activities = ${actString}
            WHERE user_id = '${user_id}'
                AND program_id = '${program_id}'
                AND week_in_program = ${week_in_program};
        `
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateActivity:", error);
    return error;
  }
}

export async function updateDailyActivity(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, program_id, week_in_program, daily_activities } = data;
    const dailyActString = JSON.stringify(daily_activities);
    const activityQuery = `
            UPDATE daily_activity SET
            activities = JSON_SET(activities, 
              "$.daily_activities", CAST('${dailyActString}' as JSON))
            WHERE user_id = '${user_id}'
                AND program_id = '${program_id}'
                AND week_in_program = ${week_in_program};
        `
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateDailyActivity:", error);
    return error;
  }
}

export async function updateWeeklyNote(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, program_id, week_in_program, note } = data;
    const activityQuery = `
            UPDATE daily_activity SET
            note = '${note}'
            WHERE user_id = '${user_id}'
                AND program_id = '${program_id}'
                AND week_in_program = ${week_in_program};
        `
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateWeeklyNote:", error);
    return error;
  }
}

export async function updateBaseInfo(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, product_id, raw_data } = data;
    const activityQuery = `
            UPDATE health_profile SET base_info = 
              JSON_SET(
                base_info,
                ${createUpdateSTMFromObject(raw_data)}
              )
            WHERE user_id = '${user_id}'
                AND product_id = '${product_id}';
        `;
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateDailyActivity:", error);
    return error;
  }
}

export async function updateCoachToCoach(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, product_id, coach_id, coach_name, message, datetime } = data;
    const activityQuery = `
            UPDATE health_profile SET c_to_c = 
              JSON_ARRAY_APPEND(
                COALESCE(c_to_c, '[]'),
                '$',
                JSON_OBJECT("coach_id", "${coach_id}","coach_name","${coach_name}","message","${message}","datetime","${datetime}")
              )
            WHERE user_id = '${user_id}'
                AND product_id = '${product_id}';
        `;
    console.log("update c to c:", activityQuery);
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateDailyActivity:", error);
    return error;
  }
}

export async function updateGoal(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, week_in_program, goal } = data;
    const activityQuery = `CALL ccrChangeGoal('${user_id}', ${week_in_program}, '${goal}')`;
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateGoal:", error);
    return error;
  }
}

export async function updateMode(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, week_in_program } = data;
    const activityQuery = `CALL ccrChangeMode('${user_id}', ${week_in_program})`;
    const result = await query(activityQuery);
    return result;
  } catch (error) {
    console.log("error inside updateMode:", error);
    return error;
  }
}

function createUpdateSTMFromObject(arr) {
  const ret_stm = arr.reduce((accumulator, elem, index) => {
                    return accumulator + `"$.${elem.name}", ${elem.value} ${index < arr.length - 1 ? ", " : " "}
                    `;
                  }, "");
  return ret_stm;
}

export async function updateCCRWorkoutAmount(event) {
  try {
    const data = JSON.parse(event.body);
    const { user_id, amount } = data;
    const hpUpdateQry = `
        update health_profile
        SET base_info = JSON_SET(base_info, '$.workout_day', ${amount})
        where user_id = '${user_id}'
          and product_id = 'ccr';
      `;
    const trainingSuite = getTrainingSuite(amount);
    const suiteUpdateQry = `
        UPDATE suite_for_user
        SET suite_code = '${trainingSuite}'
        where user_id = '${user_id}'
          and product_id = 'ccr';
      `;
    
    const result = await transaction([hpUpdateQry, suiteUpdateQry]);
    return result;
  } catch (error) {
    console.log("error inside updateWorkoutAmount:", error);
    return error;
  }
}

export async function confirmCertName(event) {
  const data  = JSON.parse(event.body);
  const { user_id, name, product_id } = data;

  const confirmQuery = `
      UPDATE health_profile 
      SET base_info = JSON_SET(base_info, '$.certificates.name', '${name}', '$.certificates.confirmed', 1)
      WHERE user_id = '${user_id}'
      AND product_id = '${product_id}'
  `;

  try {
    const results = await query(confirmQuery);
    return results;
} catch (error) {
  console.log("error inside confirmCertName:", error);
    return error;
}
}


export async function updateVideo(event) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${process.env.VIMEO_API_KEY}`;
    const data = JSON.parse(event.body);
    const { id, title, description, category, level, score } = data;
    const apiUrl = `https://api.vimeo.com/videos/${id}`;

    let level_color = 'info';
    if(level.toUpperCase() === 'ADVANCE') {
        level_color = 'danger'
    } else if (level.toUpperCase() === 'INTERMEDIATE') {
        level_color = 'warning'
    }
    try {         
        const queryString =  `
                    UPDATE exercise_video SET 
                        title = "${title}", description = "${description}", 
                        category = "${category}", level = "${level}",
                        level_color = "${level_color}", score = ${score}
                    WHERE id = ${id};
                `;
        let result = {};
        const deleteResult = await axios.all([
            axios.patch(apiUrl, {
                description,
                name: title
            }),
            query(queryString)
        ]);
        result = deleteResult.find(elem => elem.hasOwnProperty('statusCode'));
        return result;
    } catch (error) {
      console.log("error inside updateVideo:", error);
      return error;
    }
}

export async function updateVideoThumbnail(event) {
  const { video_id, thumbnail_id } = JSON.parse(event.body);
  const url = `https://api.vimeo.com/videos/${video_id}/pictures/${thumbnail_id}`;
  console.log(url);
  const options = { 
    method: 'PATCH',
    url,
    headers: 
      { 
        'cache-control': 'no-cache',
        Connection: 'keep-alive',
        'Accept-Encoding': 'gzip, deflate',
        Host: 'api.vimeo.com',
        Accept: 'application/vnd.vimeo.*+json;version=3.4',
        'Content-type': 'application/json',
        Authorization: `Bearer ${process.env.VIMEO_API_KEY}` 
      },
    body: '{ \n\t"active": true \n}'
  };

  try {
    const result = await requestForActive(options);
    if (result) {
      const thumbnailUrl = `https://i.vimeocdn.com/video/${thumbnail_id}_270.jpg`;
      const queryString =  `
                  UPDATE exercise_video SET 
                      thumbnail = "${thumbnailUrl}"
                  WHERE id = ${video_id};
              `;
      await query(queryString);
      return success(createSuccessListBody({thumbnailUrl}))
    }
  } catch (error) {
    console.log("error inside updateVideoThumbnail:", error);
    return error;
  }
}

const requestForActive = (options) => new Promise((resolve, reject) => {
  request(options, (error, response) => {
    if (error) {
      console.log("error of thumbnail update:", error);
      reject(failure(createFailureBody(error.code, error.message)));
    }

    resolve(success(createSuccessListBody(response)));
  });
})

export async function updateCCRHomework(event) {
  const { 
    act_id, 
    weekly_plan: {
      note,
      coach_id, 
      coach_name,
      plan: {
        food: {
          fat,
          protein,
          carbohydrate
        },
        cardio,
        nutrients_week,
        auto_plans
      }
    },
    change_mode = false,
    goal
  } = JSON.parse(event.body);

  const oldActivitiesStatement = ` 
		'$.weekly_plan.status', 'complete',
		'$.weekly_plan.next_week_coach_id', '${coach_id}',
		'$.weekly_plan.next_week_coach_name', '${coach_name}'`

  const updateOldHWQuery = `
    UPDATE daily_activity SET
      activities = JSON_SET(activities, ${oldActivitiesStatement}),
      next_week_note = '${note}'
    where act_id = ${act_id};
  `;

  const auto_plans_string = JSON.stringify(auto_plans);

  const newActivitiesStatement = ` 
		'$.weekly_plan.status', 'init',
		'$.weekly_plan.coach_id', '${coach_id}',
		'$.weekly_plan.coach_name', '${coach_name}',
    '$.weekly_plan.plan.food.fat', ${fat},
    '$.weekly_plan.plan.food.protein', ${protein},
    '$.weekly_plan.plan.food.carbohydrate', ${carbohydrate},
    '$.weekly_plan.plan.cardio', ${cardio},
    '$.weekly_plan.plan.nutrients_week', ${nutrients_week},
    '$.weekly_plan.plan.auto_plans', CAST(@auto_plans AS JSON)
  `; 
  let updateNewHWQuery = `
    SELECT @user_id := user_id, @program_id := program_id, @new_week := week_in_program+1
    FROM daily_activity
    WHERE act_id = ${act_id};
    
    SET @auto_plans = '${auto_plans_string}';
    UPDATE daily_activity SET
      activities = JSON_SET(activities, ${newActivitiesStatement}),
      note = '${note}'
    WHERE user_id=@user_id AND program_id=@program_id AND week_in_program=@new_week;
  `;

  if (change_mode) {
    if (goal === "diet") {
      const nutrient = {
        fat,
        protein,
        carb: carbohydrate
      }
      const newMainInfo = JSON.stringify(reCalculateMainInfo(nutrient, nutrients_week + 1));
      updateNewHWQuery += `
          UPDATE health_profile
          SET main_info = '${newMainInfo}',
            base_info = JSON_SET(base_info, '$.mode', 'auto')
          WHERE product_id = 'ccr'
            AND user_id = @user_id
        `
    } else {
      updateNewHWQuery += "CALL ccrChangeMode(@user_id, @new_week);"
      if (goal !== "same") {
        updateNewHWQuery += ` UPDATE health_profile
                              SET base_info = JSON_SET(base_info,
                                    '$.goal', '${goal}'
                                  )
                              WHERE user_id = @user_id
                                AND product_id = 'ccr';
                            `
      }
    }
  }
  console.log("inside updateCCRHomework:", updateNewHWQuery);
  
  try {
    const result = await transaction([updateOldHWQuery, updateNewHWQuery]);

    return result;
  } catch (error) {
    console.log("when update ccr homework, the reason of error:", error);
    return error;
  }
}

