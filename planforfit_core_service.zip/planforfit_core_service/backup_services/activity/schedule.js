import { transaction, queryRaw } from "../../lib/dbhelper";
import { genActivitiesInsertState } from "../../lib/someSQLs";
import { getUsers } from "../../lib/cognito-lib";

export async function addActivities() {
    try {
      const cognitoUsers = await getUsers();
      const batchQuery = cognitoUsers.Users.map(genActivitiesInsertQuery);
      const result = await transaction(batchQuery);
      return result;
    } catch (error) {
      console.log("the reason of error in addActivities:", error);
      return error;
    }
}

const genActivitiesInsertQuery = (user) => {
  return genActivitiesInsertState(user.Username, 'bemoove')
};

export async function addCCRActivities() {
  try {
    const getActiveUsersQuery = `
    select distinct m.user_id
    FROM member m JOIN health_profile hp
      ON m.user_id = hp.user_id
    WHERE hp.base_info->>'$' != "{}"
    AND hp.main_info->>'$' != "[]"
    AND hp.expire_date >= now()
    AND hp.product_id = 'ccr';
    `;
    const users = await queryRaw(getActiveUsersQuery);
    const rawQuery = users.map(user => `CALL ccrAdjustProgram('${user.user_id}');`);
    const batchQuery = rawQuery.join(" ");
    const result = await queryRaw(batchQuery);
    return result;
  } catch (error) {
    console.log("the reason of error in addCCRActivities:", error);
    return error;    
  }
}


