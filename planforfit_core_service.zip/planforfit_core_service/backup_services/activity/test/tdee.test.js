import {
  calculateTDEE,
  calculateBulkSpecial,
  calculateBulkHighTDEE,
  calculateBulkLowTDEE,
  calculateProtein,
  calculateฺฺBulkFat,
  calculateฺฺFat,
  calculateCarb,
  calculateBulkCarb,
  findDietTDEEPercentage,
  reCalculateTDEE,
  reCalculateMainInfo
} from "../lib/tdee";

describe("calculateProtein Test", () => {
  it("should return twice a weight", () => {
    const result = calculateProtein(78);
    expect(result).toBe(156);
  });
  it("when minus should return zero", () => {
    const result = calculateProtein(-78);
    expect(result).toBe(0);
  });
});

describe("calculateBulkFat Test", () => {
  it("should return with 0.25 * xxx / 9", () => {
    const result = calculateฺฺBulkFat(2517);
    expect(result).toBe(70);
  });
  it("when minus should return zero", () => {
    const result = calculateฺฺBulkFat(-2517);
    expect(result).toBe(0);
  });
});

describe("calculateFat Test", () => {
  it("should return with 0.3 * xxx / 9", () => {
    const result = calculateฺฺFat(2517);
    expect(result).toBe(84);
  });
  it("when minus should return zero", () => {
    const result = calculateฺฺFat(-2517);
    expect(result).toBe(0);
  });
});

describe("calculateCarb Test", () => {
  it("should return with TDEE - (4*protein) - (9*fat)", () => {
    const result = calculateCarb(2517, 120, 70);
    expect(result).toBe(352);
  });
  it("should return with TDEE - (4*protein) - (9*fat)#2", () => {
    const result = calculateCarb(2340, 120, 70);
    expect(result).toBe(308);
  });
  it("should return with TDEE - (4*protein) - (9*fat)#3", () => {
    const result = calculateCarb(1510, 120, 70);
    expect(result).toBe(100);
  });
  it("when carb less than 100 should return 100", () => {
    const result = calculateCarb(-2517, 120, 70);
    expect(result).toBe(100);
  });
});

describe("calculateBulkCarb Test", () => {
  it("should return with TDEE - (4*protein) - (9*fat)", () => {
    const result = calculateBulkCarb(2517, 120, 70);
    expect(result).toBe(352);
  });
  it("should return with TDEE - (4*protein) - (9*fat)#2", () => {
    const result = calculateBulkCarb(2340, 120, 70);
    expect(result).toBe(308);
  });
  it("should return with TDEE - (4*protein) - (9*fat)#3", () => {
    const result = calculateBulkCarb(1510, 120, 70);
    expect(result).toBe(100);
  });
  it("when carb less than 0 should return 0", () => {
    const result = calculateBulkCarb(-2517, 120, 70);
    expect(result).toBe(0);
  });
});

describe('calculateBulkLowTdee Test', () => {
  it('should return with TDEE * 0.6', () => {
    const result = calculateBulkLowTDEE(2517);
    expect(result).toBe(1510);
  });
  it('should return with TDEE * 0.6#2', () => {
    const result = calculateBulkLowTDEE(2255);
    expect(result).toBe(1353);
  });
});

describe('calculateBulkHighTdee Test', () => {
  it('should return with TDEE * 0.85 + 200', () => {
    const result = calculateBulkHighTDEE(2517);
    expect(result).toBe(2339);
  });
  it('should return with TDEE * 0.85 + 200#2', () => {
    const result = calculateBulkHighTDEE(2255);
    expect(result).toBe(2117);
  });
});

describe('calculateBulkSpecial Test', () => {
  it('should return correct bulk high', () => {
    const result = calculateBulkSpecial(2517, 120, "high");
    const expectResult = {
      name: "bulk_high",
      tdee: 2339,
      protein: 120,
      fat: 70,
      carb: 307,
      cardio: 150
    }
    expect(result).toEqual(expectResult);
  });
  it('should return correct bulk high#2', () => {
    const result = calculateBulkSpecial(2255, 120, "high");
    const expectResult = {
      name: "bulk_high",
      tdee: 2117,
      protein: 120,
      fat: 63,
      carb: 268,
      cardio: 150
    }
    expect(result).toEqual(expectResult);
  });
  it('should return correct bulk low', () => {
    const result = calculateBulkSpecial(2517, 120, "low");
    const expectResult = {
      name: "bulk_low",
      tdee: 1510,
      protein: 120,
      fat: 56,
      carb: 132,
      cardio: 150
    }
    expect(result).toEqual(expectResult);
  });
  it('should return correct bulk low#2', () => {
    const result = calculateBulkSpecial(2255, 120, "low");
    const expectResult = {
      name: "bulk_low",
      tdee: 1353,
      protein: 120,
      fat: 50,
      carb: 106,
      cardio: 150
    }
    expect(result).toEqual(expectResult);
  });
});

describe('calculateTDEE test', () => {
  it('should return correct answer for male w: 60, h:188, age:30, active and workout 3 days', () => {
    const weight = 60;
    const height = 188;
    const age = 30;
    const gender = "male";
    const work_active_level = "active";
    const workout_day = 3;
    const goal = "diet";
    const result = calculateTDEE({
      weight,
      height,
      age,
      gender,
      work_active_level,
      workout_day,
      goal
    });
    const expectResult = {
      base_info: {
        weight,
        height,
        age,
        gender,
        work_active_level,
        workout_day,
        low_carb_first_day: 0,
        low_carb_second_day: 3,
        goal: "diet",
        mode: "auto"
      },
      main_info: [
        {
          name: "100%",
          tdee: 2517,
          cardio: 150,
          protein: 120,
          fat: 84,
          carb: 320,
        },
        {
          name: "80%",
          tdee: 2014,
          cardio: 150,
          protein: 120,
          fat: 67,
          carb: 233,
        },
        {
          name: "70%",
          tdee: 1762,
          cardio: 150,
          protein: 120,
          fat: 59,
          carb: 188,
        },
        {
          name: "60%",
          tdee: 1510,
          cardio: 150,
          protein: 120,
          fat: 50,
          carb: 145,
        },
        {
          name: "50%",
          tdee: 1259,
          cardio: 150,
          protein: 120,
          fat: 42,
          carb: 100,
        },
        { 
          name: "40%",
          tdee: 1007,
          cardio: 150,
          protein: 120,
          fat: 34,
          carb: 100,
        },
        {
          name: "30%",
          tdee: 755,
          cardio: 150,
          protein: 120,
          fat: 25,
          carb: 100,
        },
        {
          name: "20%",
          tdee: 503,
          cardio: 150,
          protein: 120,
          fat: 17,
          carb: 100,
        },
        {
          name: "10%",
          tdee: 252,
          cardio: 150,
          protein: 120,
          fat: 8,
          carb: 100,
        },
        {
          name: "bulk_high",
          tdee: 2340,
          cardio: 150,
          protein: 120,
          fat: 70,
          carb: 308,
        },
        {
          name: "bulk_low",
          tdee: 1510,
          cardio: 150,
          protein: 120,
          fat: 56,
          carb: 132,
        },
      ],
    };
    expect(result).toEqual(expectResult);
  });
  it('should return correct answer for female w: 60, h:188, age:30, active and workout 3 days', () => {
    const weight = 60;
    const height = 188;
    const age = 30;
    const gender = "female";
    const work_active_level = "active";
    const workout_day = 3;
    const goal = "diet";
    const result = calculateTDEE({
      weight,
      height,
      age,
      gender,
      work_active_level,
      workout_day,
      goal
    });
    const expectResult = {
      base_info: {
        weight,
        height,
        age,
        gender,
        work_active_level,
        workout_day,
        low_carb_first_day: 0,
        low_carb_second_day: 3,
        goal: "diet",
        mode: "auto"
      },
      main_info: [
        {
          name: "100%",
          tdee: 2255,
          cardio: 150,
          protein: 120,
          fat: 75,
          carb: 275,
        },
        {
          name: "80%",
          tdee: 1804,
          cardio: 150,
          protein: 120,
          fat: 60,
          carb: 196,
        },
        {
          name: "70%",
          tdee: 1579,
          cardio: 150,
          protein: 120,
          fat: 53,
          carb: 156,
        },
        {
          name: "60%",
          tdee: 1353,
          cardio: 150,
          protein: 120,
          fat: 45,
          carb: 117,
        },
        {
          name: "50%",
          tdee: 1128,
          cardio: 150,
          protein: 120,
          fat: 38,
          carb: 100,
        },
        { 
          name: "40%",
          tdee: 902,
          cardio: 150,
          protein: 120,
          fat: 30,
          carb: 100,
        },
        {
          name: "30%",
          tdee: 677,
          cardio: 150,
          protein: 120,
          fat: 23,
          carb: 100,
        },
        {
          name: "20%",
          tdee: 451,
          cardio: 150,
          protein: 120,
          fat: 15,
          carb: 100,
        },
        {
          name: "10%",
          tdee: 226,
          cardio: 150,
          protein: 120,
          fat: 8,
          carb: 100,
        },
        {
          name: "bulk_high",
          tdee: 2117,
          cardio: 150,
          protein: 120,
          fat: 63,
          carb: 268,
        },
        {
          name: "bulk_low",
          tdee: 1353,
          cardio: 150,
          protein: 120,
          fat: 50,
          carb: 106,
        },
      ],
    };
    expect(result).toEqual(expectResult);
  });
});

describe('findDietTDEEPercentage test', () => {
  it('should return 1 when nutrient week is modable by 4', () => {
    const result = findDietTDEEPercentage(12);
    expect(result).toEqual(1);
  });
  it('should return 0.8 when nutrient week is less than 4', () => {
    const result = findDietTDEEPercentage(3);
    expect(result).toEqual(0.8);
  });
  it('should return 0.7 when nutrient week is less than 8 but more than 4', () => {
    const result = findDietTDEEPercentage(7);
    expect(result).toEqual(0.7);
  });
  it('should return 0.6 when nutrient week is less than 12 but more than 8', () => {
    const result = findDietTDEEPercentage(11);
    expect(result).toEqual(0.6);
  });
  it('should return 0.7 when nutrient week is less than 16 but more than 12', () => {
    const result = findDietTDEEPercentage(14);
    expect(result).toEqual(0.7);
  });
  it('should return 0.6 when nutrient week is less than 20 but more than 16', () => {
    const result = findDietTDEEPercentage(17);
    expect(result).toEqual(0.6);
  });
  it('should return 0.5 when nutrient week is less than 24 but more than 20', () => {
    const result = findDietTDEEPercentage(22);
    expect(result).toEqual(0.5);
  });
});

describe('reCalculateTDEE test', () => {
  it('should return 2518 when p: 120, f:70, c:352 with nutrient week 12', () => {
    const nutrient = {
      protein: 120,
      fat: 70,
      carb: 352
    }
    const result = reCalculateTDEE(nutrient, 12);
    expect(result).toEqual(2518);
  });
});

describe('reCalculateMainInfo test', () => {
  it('should return 2518 main info set when supply with p: 120, f:70, c:352 with nutrient week 12', () => {
    const nutrient = {
      protein: 120,
      fat: 70,
      carb: 352
    }
    const expectResult = [
      {
        name: "100%",
        tdee: 2518,
        cardio: 150,
        protein: 120,
        fat: 84,
        carb: 321,
      },
      {
        name: "80%",
        tdee: 2014,
        cardio: 150,
        protein: 120,
        fat: 67,
        carb: 233,
      },
      {
        name: "70%",
        tdee: 1763,
        cardio: 150,
        protein: 120,
        fat: 59,
        carb: 188,
      },
      {
        name: "60%",
        tdee: 1511,
        cardio: 150,
        protein: 120,
        fat: 50,
        carb: 145,
      },
      {
        name: "50%",
        tdee: 1259,
        cardio: 150,
        protein: 120,
        fat: 42,
        carb: 100,
      },
      { 
        name: "40%",
        tdee: 1007,
        cardio: 150,
        protein: 120,
        fat: 34,
        carb: 100,
      },
      {
        name: "30%",
        tdee: 755,
        cardio: 150,
        protein: 120,
        fat: 25,
        carb: 100,
      },
      {
        name: "20%",
        tdee: 504,
        cardio: 150,
        protein: 120,
        fat: 17,
        carb: 100,
      },
      {
        name: "10%",
        tdee: 252,
        cardio: 150,
        protein: 120,
        fat: 8,
        carb: 100,
      },
      {
        name: "bulk_high",
        tdee: 2340,
        cardio: 150,
        protein: 120,
        fat: 70,
        carb: 308,
      },
      {
        name: "bulk_low",
        tdee: 1511,
        cardio: 150,
        protein: 120,
        fat: 56,
        carb: 132,
      },
    ];
    const result = reCalculateMainInfo(nutrient, 12);
    expect(result).toEqual(expectResult);
  });
  it('should return 2519 main info set when supply with p: 120, f:59, c:188 with nutrient week 6', () => {
    const nutrient = {
      protein: 120,
      fat: 59,
      carb: 188
    }
    const expectResult = [
      {
        name: "100%",
        tdee: 2519,
        cardio: 150,
        protein: 120,
        fat: 84,
        carb: 321,
      },
      {
        name: "80%",
        tdee: 2015,
        cardio: 150,
        protein: 120,
        fat: 67,
        carb: 233,
      },
      {
        name: "70%",
        tdee: 1763,
        cardio: 150,
        protein: 120,
        fat: 59,
        carb: 188,
      },
      {
        name: "60%",
        tdee: 1511,
        cardio: 150,
        protein: 120,
        fat: 50,
        carb: 145,
      },
      {
        name: "50%",
        tdee: 1259,
        cardio: 150,
        protein: 120,
        fat: 42,
        carb: 100,
      },
      { 
        name: "40%",
        tdee: 1007,
        cardio: 150,
        protein: 120,
        fat: 34,
        carb: 100,
      },
      {
        name: "30%",
        tdee: 756,
        cardio: 150,
        protein: 120,
        fat: 25,
        carb: 100,
      },
      {
        name: "20%",
        tdee: 504,
        cardio: 150,
        protein: 120,
        fat: 17,
        carb: 100,
      },
      {
        name: "10%",
        tdee: 252,
        cardio: 150,
        protein: 120,
        fat: 8,
        carb: 100,
      },
      {
        name: "bulk_high",
        tdee: 2341,
        cardio: 150,
        protein: 120,
        fat: 70,
        carb: 308,
      },
      {
        name: "bulk_low",
        tdee: 1511,
        cardio: 150,
        protein: 120,
        fat: 56,
        carb: 132,
      },
    ];
    const result = reCalculateMainInfo(nutrient, 6);
    expect(result).toEqual(expectResult);
  });
});