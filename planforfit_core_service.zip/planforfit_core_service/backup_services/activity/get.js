import { transaction, query, queryRaw } from "../../lib/dbhelper";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody,
  createSuccessListBody,
} from "../../lib/response-lib";
import { genActivitiesInsertState, genCCRActivitiesInsertState, genTBPAActivitiesInsertState } from "../../lib/someSQLs";

export async function personalHistory(event) {
  const { user_id, product_id } = event.queryStringParameters;

  try {
    const getHistoryActivitiesQuery = `
      SELECT act.week_in_program, act.activities
      FROM daily_activity act JOIN program pg
        ON act.program_id = pg.program_id
      WHERE act.user_id = '${user_id}'
        AND act.activities->>"$.weekly_progress" IS NOT NULL
        AND pg.product_id = '${product_id}'
      ORDER BY act.week_in_program DESC
      LIMIT 50;
    `

    const getProfileQuery = `
      SELECT base_info, COALESCE(c_to_c, '[]') as c_to_c, expire_date
      FROM health_profile 
      WHERE user_id = '${user_id}' and product_id = '${product_id}';
    `;

    const historyResult = await queryRaw(getHistoryActivitiesQuery);
    const history = historyResult.map(item => (
                                        { ...item, activities: JSON.parse(item.activities)}
                                      ));
    const profileResult = await queryRaw(getProfileQuery);
    const profile = (profileResult && profileResult.length > 0) 
                      ? {
                          base_info: JSON.parse(profileResult[0].base_info),
                          c_to_c: JSON.parse(profileResult[0].c_to_c),
                          expire_date: profileResult[0].expire_date
                        }
                      : {
                          base_info: "",
                          c_to_c: []
                        };
    const results = {profile, history};
    return success(createSuccessBody(results));
  } catch (error) {
    console.log("inside get personalHistory service:", error);
    return failure(createFailureBody(error.code, error.sqlMessage));
  }
}

export async function currentInfo(event) {
    const data = JSON.parse(event.body);
    const { user_id, product_id } = data;
    const activityQuery = genActivitiesState(user_id, product_id);
    
    try{
      const result = await query(activityQuery);
      return result;
    } catch (error) {
      return error;
    }
}

export async function addAndGetActivity(event) {
  const data = JSON.parse(event.body);
  const { user_id, product_id } = data;
  let updateActQuery;
  switch (product_id) {
    case 'bemoove':
      updateActQuery = genActivitiesInsertState(user_id, product_id);
      break;
    case 'ccr':
      updateActQuery = genCCRActivitiesInsertState(user_id);
      break;
    case 'tbpa':
      updateActQuery = genTBPAActivitiesInsertState(user_id);
      break;
    default:
      updateActQuery = genActivitiesInsertState(user_id, product_id);
      break;
  }
  const getActQuery = genActivitiesState(user_id, product_id);

  try {
    const result = await transaction([updateActQuery, getActQuery]);
    return result;
  } catch (error) {
    return error;
  }
}

export async function videos(event) {
    const videosQuery = `
        SELECT *
        FROM exercise_video;
    `;

    try {
        const queryResult = await queryRaw(videosQuery, { status: true });
        const returnAttributes = { status: true };
        return success(createSuccessListBody(returnAttributes, queryResult));
    } catch (error) {
        return error;
    }
}

export async function videosPaging(event) {
    const { 
        pageSize=8, currentPage=1, orderBy="title", 
        level="('elementary', 'intermediate', 'advance')", 
        minDuration=0, maxDuration=18000, 
        minScore=0, maxScore=10 }  = event.queryStringParameters
    const offset = pageSize * (currentPage-1);

    const videosQuery = `
        SELECT -100 as id, 'general info' as title, '' as url, '' as thumbnail, '' as category, 
            '' as level, '' as level_color, '' as description, 
            COUNT(id) as duration, COUNT(id)/${pageSize} as score 
        FROM exercise_video
        UNION
        (SELECT id, title, url, thumbnail, category,  
            level, level_color, description, duration, score
        FROM exercise_video
        WHERE level IN ${level}
            AND duration BETWEEN ${minDuration} AND ${maxDuration}
            AND score BETWEEN ${minScore} AND ${maxScore}
        ORDER BY ${orderBy}
        LIMIT ${offset}, ${pageSize});
    `;

    try {
        const generalAttributes = {
            status: true,
            pageSize,
            currentPage,
        };
        const results = await queryRaw(videosQuery);

        const { duration: totalItem, score } = results.find((element) => element.id === -100);
        const returnAttributes = { ...generalAttributes, totalItem, totalPage: Math.ceil(score) };
        const returnResult = results.filter((element) => element.id !== -100);
        return success(createSuccessListBody(returnAttributes, returnResult));
    } catch (error) {
        return error;
    }
}

export async function getCert(event) {
    const { user_id, product_id }  = event.queryStringParameters;

    const certQuery = `
      SELECT base_info->>'$.certificates' as certificate
      FROM health_profile
      WHERE user_id = '${user_id}'
        AND product_id = '${product_id}';    
    `;

    try {
      const results = await query(certQuery);
      return results;
    } catch (error) {
      console.log("error inside getCert:", error);
      return error;
    }
}

export async function getWeeklyProgress(event) {
  const { user_id } = event.queryStringParameters;

  const progressQuery = `
        SELECT * 
        FROM (
          SELECT week_in_program, activities->>"$.weekly_progress" weekly_progress
          FROM daily_activity 
          WHERE user_id = '${user_id}' 
            AND activities->>"$.weekly_progress" IS NOT NULL
          ORDER BY week_in_program desc
          LIMIT 8
        ) as progress
        ORDER BY week_in_program;
  `;


  try {
    const results = await query(progressQuery);
    return results;
  } catch (error) {
    console.log("error inside getCert:", error);
    return error;
  }
}

export async function getWorkoutProgram(event) {
  const { program_code } = event.queryStringParameters;

  const programQuery = `
                select tp.day, ts.order, tf.name, ts.rep, ts.set, ts.rest, tf.resource, tp.program_code, ts.set_code, tf.form_code
                from training_program tp JOIN training_set ts
                  on tp.set_code = ts.set_code JOIN training_form tf
                  ON ts.main_form = tf.form_code
                where tp.program_code = '${program_code}'
                order by tp.day, ts.order;
            `;


  try {
    const results = await query(programQuery);
    return results;
  } catch (error) {
    console.log("error inside getWorkoutProgram:", error);
    return error;
  }
}

const genActivitiesState = (user_id, product_id) => 
    `
    SELECT act.user_id, act.program_id, act.week_in_program, act.activities, act.note,
        hp.product_id, hp.start_date as program_start_date, hp.expire_date as program_expire_date
    FROM daily_activity act JOIN health_profile hp
        ON act.program_id = hp.program_id
        AND act.user_id = hp.user_id
    WHERE act.user_id = '${user_id}'
        AND DATEDIFF(hp.expire_date, NOW()) >= 0
        AND act.week_in_program = calcWeekInProgram(hp.start_date)
        AND hp.product_id = '${product_id}';
    `;

