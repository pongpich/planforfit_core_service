import { query } from "../../lib/dbhelper";
import axios from "axios";

export function removeActivity(event) {
    const data = JSON.parse(event.body);
    const { user_id, program_id, week_in_program } = data;
    const activityQuery = `
        DELETE FROM daily_activity
        WHERE user_id = '${user_id}'
            AND program_id = '${program_id}'
            AND week_in_program = ${week_in_program};
    `
    
    return query(activityQuery);
}


export async function deleteVideo(event) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${process.env.VIMEO_API_KEY}`;
    const data = JSON.parse(event.body);
    const { id, deleteEntirely } = data;
    const apiUrl = `https://api.vimeo.com/videos/${id}`;

    try {
        const queryString =  `DELETE FROM exercise_video WHERE id = ${id};`;
        let result = {};
        if (deleteEntirely) {
            const deleteResult = await axios.all([
                axios.delete(apiUrl),
                query(queryString)
            ]);
            result = deleteResult.find(elem => elem.hasOwnProperty('statusCode'));
        } else {
            result = query(queryString);
        }
        return result;
    } catch (error) {
        return error;
    }
}

