import bcrypt from 'bcrypt';
import md5 from 'md5';
import { query, queryRaw } from "./local_lib/dbhelper";
import { uuidv4 } from "./local_lib/Utils";
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");
import axios from 'axios';
import { encode as btoa } from 'base-64';

export async function login(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;

  try {
    const queryResult = await queryRaw(query);

    let result;
    if (queryResult.length <= 0) {
      //อีเมลที่ผู้ใช้กรอกไม่มีอยู่ในระบบ
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      //อีเมลที่ผู้ใช้กรอกมีอยู่จริงในระบบ
      const user = queryResult[0];
      console.log("user :", user);
      console.log("real password  :", user.password);
      const hash = md5(password);
      console.log("hash  :", hash);
      const isMatch = (hash === user.password);
      result = (isMatch) ?
        success(createSuccessBody({ message: 'success', user: user }))
        :
        success(createSuccessBody({ message: 'fail' }));
    }
    return result
  } catch (error) {
    return error;
  }
}

export async function login_admin(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;

  try {
    const queryResult = await queryRaw(query);

    let result;
    if (queryResult.length <= 0) {
      //อีเมลที่ผู้ใช้กรอกไม่มีอยู่ในระบบ
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      //อีเมลที่ผู้ใช้กรอกมีอยู่จริงในระบบ
      const user = queryResult[0];
      console.log("user :", user);
      console.log("real password  :", user.password);
      const hash = md5(password);
      console.log("hash  :", hash);
      const isMatch = ((hash === user.password)&&(user.auth === 'admin'));
      // const isAuth = (user.auth === 'admin');

      result = (isMatch) ?
        success(createSuccessBody({ message: 'success', user: user }))
        :
        success(createSuccessBody({ message: 'fail' }));
    }
    return result
  } catch (error) {
    return error;
  }
}

export async function deleteAccount(event) {
  const { user_id } = event.queryStringParameters;
  const querySQL = `
  delete from member where user_id = '${user_id}'
  `;
  try {
    let result;
    await query(querySQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}
