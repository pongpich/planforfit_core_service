import moment from "moment";

export function calculatePoints(max_point, stars, trophies, badges, quiz_completion, assessment_kit_completion) {
  const max_stars = 24;
  const max_trophies = 8;
  const max_badges = 5;
  const max_quiz_completion = 6;
  const max_assessment_kit_completion = 7;

  stars = stars * ((max_point * 0.3) / max_stars); // 30% | max_point
  trophies = trophies * ((max_point * 0.1) / max_trophies); // 10% | max_point
  badges = badges * ((max_point * 0.2) / max_badges); // 20% | max_point
  quiz_completion = quiz_completion * ((max_point * 0.2) / max_quiz_completion); // 20% | max_point
  assessment_kit_completion = assessment_kit_completion * ((max_point * 0.2) / max_assessment_kit_completion); // 20% | max_point

  const point = stars + trophies + badges + quiz_completion + assessment_kit_completion;

  return point;
}
