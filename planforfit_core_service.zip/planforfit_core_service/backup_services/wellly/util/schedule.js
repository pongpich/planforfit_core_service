import { query, queryRaw } from "../local_lib/dbhelper";
//import moment from 'moment';

var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

export const generateExerciseMission = (week, health_type) => {
  let user_group;
  //C1,C2,C3,C4 กลุ่มที่มีอาการเบาหวาน
  if (health_type === 'C1' || health_type === 'C2' || health_type === 'C3' || health_type === 'C4') {
    user_group = 'b'; //กลุ่มที่มีอาการเบาหวาน
  } else {
    user_group = 'a'; //กลุ่มที่ไม่มีอาการเบาหวาน
  }

  let mission_id;
  if (week === 1) { mission_id = '1ab' };
  if (week === 2) { mission_id = '2ab' };
  if (week === 3) { mission_id = '1cd' };
  if (week === 4) {
    if (user_group === 'a') { mission_id = '2c_1' };
    if (user_group === 'b') { mission_id = '2c_2' };
  }
  if (week === 5) {
    if (user_group === 'a') { mission_id = '3c_1' };
    if (user_group === 'b') { mission_id = '3c_2' };
  }
  if (week === 6) {
    if (user_group === 'a') { mission_id = '4c_1' };
    if (user_group === 'b') { mission_id = '4c_2' };
  }
  if (week === 7) {
    if (user_group === 'a') { mission_id = '5c_1' };
    if (user_group === 'b') { mission_id = '5c_2' };
  }
  if (week === 8) { 
    if (user_group === 'a') { mission_id = '6c_1' };
    if (user_group === 'b') { mission_id = '6c_2' };
  }
  if (week >= 9) { //ตั้งแต่ week ที่ 9 ขึ้นไป
    mission_id = 'continuous'
  }

  return mission_id;
}

export const generateNutritionMission = (week, health_type) => {
  let user_group;
  if (health_type === 'A1' || health_type === 'A2') {
    user_group = 'a'; //กลุ่มปกติ
  }
  if (
    health_type === 'B1' || health_type === 'B2' || health_type === 'B3' || health_type === 'B4' ||
    health_type === 'C1' || health_type === 'C2' || health_type === 'C3' || health_type === 'C4'
  ) {
    user_group = 'b'; //กลุ่มก่อนเบาหวาน + เบาหวาน
  }
  if (health_type === 'D1' || health_type === 'D2') {
    user_group = 'c'; //กลุ่มความดัน ไม่มีเบาหวาน
  }

  let mission_id;
  if (week === 1) { mission_id = 'gn1' };
  if (week === 2) { mission_id = 'gn2' };
  if (week === 3) { mission_id = 'gn3' };
  if (week === 4) { mission_id = 'gn4' };
  if (week === 5) { mission_id = 'gn5' };
  if (week === 6) { mission_id = 'gn6' };
  if (week === 7) {
    if (user_group === 'a') { mission_id = 'sna1' };
    if (user_group === 'b') { mission_id = 'snb1' };
    if (user_group === 'c') { mission_id = 'snc1' };
  }
  if (week === 8) {
    if (user_group === 'a') { mission_id = 'sna2' }
    if (user_group === 'b') { mission_id = 'snb2' };
    if (user_group === 'c') { mission_id = 'snc2' };
  }
  return mission_id;
}

export const calculateWeekInProgram = (startDate, endDate) => {
  let startDateMoment = moment(startDate).startOf('isoWeek');
  let endDateMoment = endDate ? moment(endDate) : moment();
  return endDateMoment.diff(startDateMoment, 'week') + 1
}