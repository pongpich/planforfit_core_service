import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
import { uuidv4 } from "./local_lib/Utils";
import md5 from 'md5';

export async function updateDisplayName(event) {
    const { user_id, display_name } = JSON.parse(event.body);
    const updateDisplayNameSQL = `
    update member
    set display_name = '${display_name}'
    where user_id = '${user_id}';
    `;
    try {
        let result;
        await query(updateDisplayNameSQL);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function updatePersonalData(event) {
    const { user_id, personal_data } = JSON.parse(event.body);
    const updatePersonalDataSQL = `
    update member
    set personal_data = '${JSON.stringify(personal_data)}'
    where user_id = '${user_id}';
    `;
    try {
        let result;
        await query(updatePersonalDataSQL);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function updateHealthData(event) {
    const { user_id, health_data, health_type } = JSON.parse(event.body);
    const updateHealthDataSQL = `
    update member
    set health_data = '${JSON.stringify(health_data)}', health_type = '${health_type}'
    where user_id = '${user_id}';
    `;
    try {
        let result;
        await query(updateHealthDataSQL);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function updateQuizActivities(event) {
    const { user_id, week_in_program, quiz_activities, quiz_activities_number } = JSON.parse(event.body);
    console.log("quiz_activities_number :", quiz_activities_number);
    //เช็คว่า quiz_activities_number ถ้าเป็น null เซ็ตใน db เป็น NULL
    let updateQuizActivitiesSQL
    if (quiz_activities_number) {
        updateQuizActivitiesSQL = `
        update nutrition_activity
            set quiz_activities = '${JSON.stringify(quiz_activities)}' ,quiz_activities_number = '${quiz_activities_number}'
            where user_id = '${user_id}' and week_in_program = ${week_in_program}
        `;
    } else {
        updateQuizActivitiesSQL = `
        update nutrition_activity
            set quiz_activities = '${JSON.stringify(quiz_activities)}' ,quiz_activities_number = NULL
            where user_id = '${user_id}' and week_in_program = ${week_in_program}
        `;
    }

    console.log("updateQuizActivitiesSQL :", updateQuizActivitiesSQL);
    try {
        let result;
        await query(updateQuizActivitiesSQL);
        result = success(createSuccessBody({ message: 'success' }));
        console.log("result :", result);
        return result;
    } catch (error) {
        return error;
    }
}


export async function updateAssessmentKitActivties(event) {
    const { user_id, week_in_program, assessment_kit_activties, assessment_kit_number } = JSON.parse(event.body);
    const updateQuizActivitiesSQL = `
    update nutrition_activity
        set assessment_kit_activties = '${JSON.stringify(assessment_kit_activties)}',assessment_kit_number = '${assessment_kit_number}'
        where user_id = '${user_id}' and week_in_program = ${week_in_program}
    `;
    console.log("updateQuizActivitiesSQL :", updateQuizActivitiesSQL);
    try {
        let result;
        await query(updateQuizActivitiesSQL);
        result = success(createSuccessBody({ message: 'success' }));
        console.log("result :", result);
        return result;
    } catch (error) {
        return error;
    }
}
export async function updatPopupSatry(event) {
    const { user_id, week_in_program, popup_stary } = JSON.parse(event.body);
    const updateQuizActivitiesSQL = `
    update exercise_activity
        set popup_stary = '${popup_stary}'
        where user_id = '${user_id}' and week_in_program = ${week_in_program}
    `;
    console.log("updateQuizActivitiesSQL :", updateQuizActivitiesSQL);
    try {
        let result;
        await query(updateQuizActivitiesSQL);
        result = success(createSuccessBody({ message: 'success' }));
        console.log("result :", result);
        return result;
    } catch (error) {
        return error;
    }
}

export async function updateReadExerciserActivity(event) {
    const { user_id, week_in_program, read_article } = JSON.parse(event.body);
    const updateQuizActivitiesSQL = `
    update exercise_activity
        set read_article = '${read_article}'
        where user_id = '${user_id}' and week_in_program = ${week_in_program}
    `;
    console.log("updateQuizActivitiesSQL :", updateQuizActivitiesSQL);
    try {
        let result;
        await query(updateQuizActivitiesSQL);
        result = success(createSuccessBody({ message: 'success' }));
        console.log("result :", result);
        return result;
    } catch (error) {
        return error;
    }
}

async function updateMemberActivityLog(user_id, activity, intensity, type, duration, note) {

    const selectCheckSQL = `
    SELECT COUNT(*) as count  FROM member_activity_log WHERE user_id = '${user_id}' AND ABS(TIMESTAMPDIFF(SECOND,created_at,NOW())) < 10;
    `;

    const updateLogSQL = `
    INSERT INTO member_activity_log 
    SET user_id = '${user_id}', activity = '${activity}', intensity = '${intensity}', type = '${type}', duration = '${duration}', note = '${note}';
    `;

    try {
        const selectCheckResult = await queryRaw(selectCheckSQL);
        if (selectCheckResult[0].count === 0) {
            await query(updateLogSQL);
        };

        return true;
    } catch (error) {
        return false;
    }
}

async function checkStatusMission(user_id, week_in_program) { //เพิ่มดาว ถ้วย badge ไปด้วย
    const selectExeActSQL = `
    select ea.mission_id, ea.mission_activities, ea.status_mission_activities, em.activities_level from exercise_activity as ea
    join exercise_mission as em on ea.mission_id = em.id
    where ea.user_id = '${user_id}' and ea.week_in_program = ${week_in_program}
    `;

    const selectBadgeSQL = `
    select badge from member
    where user_id = '${user_id}'
    `;

    try {
        const queryResult = await queryRaw(selectExeActSQL);
        const mission_activities = JSON.parse(queryResult[0].mission_activities);
        const mission_id = queryResult[0].mission_id;
        const activities_level = JSON.parse(queryResult[0].activities_level);

        const query2Result = await queryRaw(selectBadgeSQL);
        let badge = query2Result[0].badge ? JSON.parse(query2Result[0].badge) : [];

        //เพิ่มการเช็ค status
        //โดย status ประกอบไปด้วย 1.completed(ทำเสร็จ) 2.in_progress(กำลังดำเนินการ) 3.not_yet_started(ยังไม่เริ่มทำ)
        const numb_mission = mission_activities.length;
        let numb_completed_mission = 0;
        let score = 0;
        let new_badge = [];
        mission_activities.map(item => {
            //นับจำนวน mission ที่ completed
            if (item.number_completed >= item.number) {
                numb_completed_mission += 1;
            }
            //นับคะแนนที่ได้รับ
            score += item.number_completed * item.score;

            if ((item.id === "core_balance") && (item.number_completed >= 1)) {
                //ถือว่าได้รับ badge - core_balance
                new_badge.push("core_balance");
            }
            if ((item.id === "core_balance_plyo") && (item.number_completed >= 1)) {
                //ถือว่าได้รับ badge - core_balance_plyo
                new_badge.push("core_balance");
                new_badge.push("core_balance_plyo");
            }
            if ((item.id === "flexibility") && (item.number_completed >= 1)) {
                //ถือว่าได้รับ badge - flexibility
                new_badge.push("flexibility");
            }
            if ((item.id === "resistance") && (item.number_completed >= 1)) {
                //ถือว่าได้รับ badge - resistance
                new_badge.push("resistance");
            }
            if ((item.id === "cardio") && (item.number_completed >= 1)) {
                //ถือว่าได้รับ badge - cardio
                new_badge.push("cardio");
            }

        })

        //นำ new_badge เช็คกับ badge แล้วนำสมาชิกที่ยังไม่มีใน badge เพิ่มเข้าไป
        new_badge.map(item => {
            if (badge.includes(item)) { // item เป็นสมาชิกของ array
                //not to do
            } else {
                badge.push(item)
            }
        });

        //นำคะแนนที่ได้รับ เช็คเกณว่าผู้ใช้ได้กี่ดาว
        let star = 0;
        activities_level.map(item => {
            if ((score >= item.pts_length_min) && (score <= item.pts_length_max)) {
                star = item.star_numb
            }
        })

        let status = "in_progress";
        if (numb_completed_mission === numb_mission) {
            status = "completed";
        }

        let queryString;
        queryString = ` UPDATE exercise_activity 
            SET status_mission_activities = '${status}', star = ${star}
            WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};`;
        //ถ้า completed จะได้รับ trophy
        if (status === "completed") {
            queryString = ` UPDATE exercise_activity 
                SET status_mission_activities = '${status}', star = ${star} , trophy = 1
                WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};`;
        }
        await query(queryString);

        if (new_badge.length >= 1) {  //เช็คว่าถ้าได้รับ badge ให้ไปอัพเดท badge
            const updateBadgeSQL = `
            update member
            set badge = '${JSON.stringify(badge)}'
            where user_id = '${user_id}'         
            `;
            await query(updateBadgeSQL);
        }

        return true;
    } catch (error) {
        return false;
    }
}

export async function updateNumberCompleted(event) { // ใช้ update number_completed ของ mission_acticities
    const { user_id, activity_id, week_in_program, activity, intensity, type, duration, note } = JSON.parse(event.body);

    const selectExeActSQL = `
    select * from exercise_activity
    where user_id = '${user_id}' and week_in_program = ${week_in_program}
    `;

    try {
        let result;
        const queryResult = await queryRaw(selectExeActSQL);
        const mission_activities = JSON.parse(queryResult[0].mission_activities);

        //กรองเพื่อ update ตาม activity_id ที่ได้รับมา
        let ma_filter = ma_filter = mission_activities.filter(item => item.id === activity_id);

        //เช็คว่า activity_id ที่ได้รับมาจากการบันทึก cardio ไหม ?
        if (activity_id === "cardio") {
            const cardioMission = mission_activities.filter(item => item.id === "cardio");
            if (cardioMission.length > 0) { //มี mission cardio
                const numbCompleted = cardioMission[0].number_completed; //จำนวนที่ทำสำเร็จ
                const numbOfWeek = cardioMission[0].number; //จำนวนที่ต้องทำใน Week นั้น
                //เช็คว่าทำภารกิจ Cardio ใน Week นั้นครบหรือยัง
                if (numbCompleted >= numbOfWeek) {
                    //ถ้าทำครบแล้ว ให้เพิ่มจำนวนไปยังตามความเข้มข้นต่างๆแทน
                    ma_filter = mission_activities.filter(item => item.id === intensity);
                }
            }
        }

        if ((activity_id === 'light_intensity') || (activity_id === 'moderate_intensity') || (activity_id === 'vigorous_intensity') || (activity_id === 'cardio')) {
            await updateMemberActivityLog(user_id, activity, intensity, type, duration, note);
        }

        const queryString = ` UPDATE exercise_activity 
        SET mission_activities = JSON_SET(mission_activities,
                                    '$[${ma_filter[0].index - 1}].number_completed', ${ma_filter[0].number_completed + 1}
                          )
        WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};`;
        await query(queryString);

        //ทำการเช็ค status และ update status ให้
        await checkStatusMission(user_id, week_in_program);

        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function editActivityListAddOn(event) { //ใช้แก้ไขรายการกิจกรรม
    const { user_id, activity_id, activity_name, intensity } = JSON.parse(event.body);
    const selectSQL = `
    select * from activity_list_for_user
    where user_id = '${user_id}'
    `;
    try {
        let result;

        const selectResult = await queryRaw(selectSQL);
        let old_activity_list_addon = JSON.parse(selectResult[0].activity_list_addon);

        //แก้ไขสมาชิกตาม activity_id ที่ได้รับมากำหนด activity_name และ intensity ตามนั้น กำหนดไปในตัวแปร new_activity_list_addon
        let found = old_activity_list_addon.find(obj => obj.id === activity_id);
        found.activity = activity_name;
        found.intensity = intensity;

        const new_activity_list_addon = [...old_activity_list_addon];
        const updateActivityListAddOn = `
        update activity_list_for_user
            set activity_list_addon = '${JSON.stringify(new_activity_list_addon)}'
            where user_id = '${user_id}'
        `;
        await query(updateActivityListAddOn);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function addActivityListAddOn(event) { //ใช้เพิ่มรายการกิจกรรมใหม่ๆ
    const { user_id, activity_name, intensity } = JSON.parse(event.body);
    const selectSQL = `
    select * from activity_list_for_user
    where user_id = '${user_id}'
    `;
    try {
        let result;

        const selectResult = await queryRaw(selectSQL);

        if (selectResult.length === 0) {
            const insertDataSQL = `
                        insert into activity_list_for_user set user_id = '${user_id}', activity_list_addon = '[]'
                        `;
            await query(insertDataSQL);
        }
        const old_activity_list_addon = selectResult[0] ? JSON.parse(selectResult[0].activity_list_addon) : [];
        const id = `addon_${uuidv4()}`;
        const activity = {
            "id": id,
            "type": "addon",
            "activity": activity_name,
            "intensity": intensity
        };
        const new_activity_list_addon = [...old_activity_list_addon, activity];
        const updateActivityListAddOn = `
        update activity_list_for_user
            set activity_list_addon = '${JSON.stringify(new_activity_list_addon)}'
            where user_id = '${user_id}'
        `;
        await query(updateActivityListAddOn);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function deleteActivityListAddOn(event) { //ใช้ลบรายการกิจกรรมใหม่ๆ
    const { user_id, activity_id } = JSON.parse(event.body);
    const selectSQL = `
    select * from activity_list_for_user
    where user_id = '${user_id}'
    `;
    try {
        let result;

        const selectResult = await queryRaw(selectSQL);
        const old_activity_list_addon = JSON.parse(selectResult[0].activity_list_addon);

        //ทำการนำ id ที่รับมาออกจากสมาชิกและกำหนดไปใน new_activity_list_addon
        const new_activity_list_addon = old_activity_list_addon.filter(item => item.id !== activity_id);

        const updateActivityListAddOn = `
        update activity_list_for_user
            set activity_list_addon = '${JSON.stringify(new_activity_list_addon)}'
            where user_id = '${user_id}'
        `;
        await query(updateActivityListAddOn);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function updatePassword(event) {
    const { user_id, password } = JSON.parse(event.body);
    console.log("user_id, password", user_id, password);
    const updatePasswordSQL = `
    update member
    set password = '${md5(password)}'
    where user_id = '${user_id}'
          `;

    const pass = md5(password);
    try {

        let result;
        await query(updatePasswordSQL);
        result = success(createSuccessBody({ message: 'success', password: pass }));
        return result;

    } catch (error) {

        return error;
    }


}


export async function checkUpdateBadgeWin(event) { //ใช้สำหรับเช็คว่าผู้ใช้ได้สำเร็จ exercise mission ครบ 8อัน ให้ทำการ update Badge - Win
    const { user_id } = JSON.parse(event.body);

    const queryString = `
    select COUNT(status_mission_activities) as count from exercise_activity 
    where  status_mission_activities = 'completed' and user_id = '${user_id}'
    `;

    const selectBadgeSQL = `
    select badge from member
    where user_id = '${user_id}'
    `;

    try {
        let result;
        const queryResult = await queryRaw(queryString);
        const numbMissionCompleted = queryResult[0].count;
        const query2Result = await queryRaw(selectBadgeSQL);
        let badge = query2Result[0].badge ? JSON.parse(query2Result[0].badge) : [];

        if (numbMissionCompleted >= 8) {
            badge.push("eight_mission_completed")
            const updateBadgeSQL = `
            update member
            set badge = '${JSON.stringify(badge)}'
            where user_id = '${user_id}'         
            `;
            await query(updateBadgeSQL);
        }

        return result;
    } catch (error) {
        return error;
    }
}

//ใช้อัพเดท status การสอนใช้แอพ
export async function update_teach_user_home(event) {
    const { user_id, status } = JSON.parse(event.body);
    const updateString = `
                        update member
                        set teach_user_home = '${status}'
                        where user_id = '${user_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}
export async function update_teach_user_nutrition(event) {
    const { user_id, status } = JSON.parse(event.body);
    const updateString = `
                        update member
                        set teach_user_nutrition = '${status}'
                        where user_id = '${user_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}
export async function update_teach_user_article_template(event) {
    const { user_id, status } = JSON.parse(event.body);
    const updateString = `
                        update member
                        set teach_user_article_template = '${status}'
                        where user_id = '${user_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}
export async function update_teach_user_exercise(event) {
    const { user_id, status } = JSON.parse(event.body);
    const updateString = `
                        update member
                        set teach_user_exercise = '${status}'
                        where user_id = '${user_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}
export async function update_teach_user_ex_article_template(event) {
    const { user_id, status } = JSON.parse(event.body);
    const updateString = `
                        update member
                        set teach_user_ex_article_template = '${status}'
                        where user_id = '${user_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}
export async function update_teach_user_exercise_program(event) {
    const { user_id, status } = JSON.parse(event.body);
    const updateString = `
                        update member
                        set teach_user_exercise_program = '${status}'
                        where user_id = '${user_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function update_walk_step(event) {
    const { user_id, event_id, walk_step } = JSON.parse(event.body);
    const updateString = `
                        update event_activity_list_for_user
                        set walk_step = '${walk_step}'
                        where user_id = '${user_id}' and event_id = '${event_id}'
                        `;
    try {
        let result;
        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function update_distance(event) {
    const { user_id, event_id, distance, distance_goal } = JSON.parse(event.body);
    const selectDistance = `
                        select * from event_activity_list_for_user
                        where user_id = '${user_id}' and event_id = '${event_id}'
                        `;


    try {
        let result;

        const distanceResult = await queryRaw(selectDistance);
        const old_distance = distanceResult[0].distance;
        let new_distance = old_distance + distance;
        if (new_distance > distance_goal) {
            new_distance = distance_goal;
        }

        const updateString = `
        update event_activity_list_for_user
        set distance = '${new_distance}'
        where user_id = '${user_id}' and event_id = '${event_id}'
        `;

        await query(updateString);
        result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}