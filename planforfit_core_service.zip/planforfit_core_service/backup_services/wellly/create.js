import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody,
} from "./local_lib/response-lib";
import {
  calculateWeekInProgram,
  generateNutritionMission,
  generateExerciseMission,
} from "./util/schedule";
import { uuidv4 } from "./local_lib/Utils";
import md5 from "md5";

export async function insertNutritionActivity(event) {
  const { user_id } = JSON.parse(event.body);

  const selectMemberSQL = `
    select * from member where user_id = '${user_id}'
    `;

  try {
    let result;

    const selectMemberResult = await queryRaw(selectMemberSQL);
    const start_date = selectMemberResult[0].start_date;
    const health_type = selectMemberResult[0].health_type;

    //นำ start_date มาคำนวน week
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน

    //ก่อนจะ insert เช็คว่าสัปดาห์ก่อนหน้านี้มีอันไหนยังขาดบ้าง และทำการ insert ที่เดียวครบๆ
    const selectNutritionActivity = `select * from nutrition_activity where user_id = '${user_id}'`;
    const nutritionActivityResult = await queryRaw(selectNutritionActivity);

    let availableWeek = []; //ใช้เก็บสัปดาห์ที่มีอยู่
    let lostWeek = []; //ใช้เก็บสัปดาห์ที่หายไป
    const mapNutritionActivityResult = nutritionActivityResult.map(
      (item, index) => {
        availableWeek.push(item.week_in_program);
      }
    );
    console.log("availableWeek :", availableWeek);

    for (let i = 1; i <= 8; i++) {
      if (availableWeek.includes(i)) {
        console.log(`${i} เป็นสมาชิกในอาร์เรย์`);
      } else {
        console.log(`${i} ไม่เป็นสมาชิกในอาร์เรย์`);
        if (i <= week) {
          lostWeek.push(i);
        }
      }
    }
    console.log("lostWeek :", lostWeek);
    let valuesString = "";
    const mapLostWeek = lostWeek.map((item, index) => {
      const itemWeek = item;
      //นำ week และ health_type มาเช็ค mission_id ที่ได้รับ
      const itemMissionId = generateNutritionMission(itemWeek, health_type);
      if (index + 1 === lostWeek.length) {
        //เช็คว่าถ้าเป็นสมาชิกตัวสุดท้าย
        valuesString =
          valuesString + `('${user_id}', ${itemWeek}, '${itemMissionId}')`;
      } else {
        valuesString =
          valuesString + `('${user_id}', ${itemWeek}, '${itemMissionId}'),`;
      }
    });

    const insertNutritionActivitySQL = `
             insert into nutrition_activity(user_id, week_in_program, mission_id) 
             values
             ${valuesString}
         `;
    //ถ้ามี week ไหนหายไป ค่อย insert ให้ผู้ใช้
    if (lostWeek.length > 0) {
      await query(insertNutritionActivitySQL);
    }
    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function insertExerciseActivity(event) {
  const { user_id } = JSON.parse(event.body);

  const selectMemberSQL = `
    select * from member where user_id = '${user_id}'
    `;

  try {
    let result;

    const selectMemberResult = await queryRaw(selectMemberSQL);
    const start_date = selectMemberResult[0].start_date;
    const health_type = selectMemberResult[0].health_type;

    //นำ start_date มาคำนวน week
    const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน
    //นำ week และ health_type มาเช็ค mission_id ที่ได้รับ
    const mission_id = generateExerciseMission(week, health_type);

    //ก่อนจะ insert เช็คว่าสัปดาห์ก่อนหน้านี้มีอันไหนยังขาดบ้าง และทำการ insert ที่เดียวครบๆ
    const selectExerciseActivity = `select * from exercise_activity where user_id = '${user_id}'`;
    const exerciseActivityResult = await queryRaw(selectExerciseActivity);

    let availableWeek = []; //ใช้เก็บสัปดาห์ที่มีอยู่
    let lostWeek = []; //ใช้เก็บสัปดาห์ที่หายไป
    const mapExerciseActivityResult = exerciseActivityResult.map(
      (item, index) => {
        availableWeek.push(item.week_in_program);
      }
    );
    console.log("availableWeek :", availableWeek);

    for (let i = 1; i <= week; i++) {
      if (availableWeek.includes(i)) {
        console.log(`${i} เป็นสมาชิกในอาร์เรย์`);
      } else {
        console.log(`${i} ไม่เป็นสมาชิกในอาร์เรย์`);
        if (i <= week) {
          lostWeek.push(i);
        }
      }
    }
    console.log("lostWeek :", lostWeek);

    const selecExercise_missionSQL = `select * from exercise_mission`;
    const selectExercise_mission = await queryRaw(selecExercise_missionSQL);

    let valuesString = "";
    const mapLostWeek = lostWeek.map((item, index) => {
      const itemWeek = item;
      //นำ week และ health_type มาเช็ค mission_id ที่ได้รับ
      const itemMissionId = generateExerciseMission(itemWeek, health_type);

      // ใส่ mission_activities
      const foundObject = selectExercise_mission.find(
        (obj) => obj.id === itemMissionId
      );
      const exercise_mission = JSON.parse(foundObject.mission);
      // วนลูปเพื่อเพิ่ม attribute number_completed เข้าไป
      exercise_mission.forEach((item) => {
        item.number_completed = 0;
      });
      const ex_mission = JSON.stringify(exercise_mission);
      if (index + 1 === lostWeek.length) {
        //เช็คว่าถ้าเป็นสมาชิกตัวสุดท้าย
        valuesString =
          valuesString +
          `('${user_id}', ${itemWeek}, '${itemMissionId}', '${ex_mission}')`;
      } else {
        valuesString =
          valuesString +
          `('${user_id}', ${itemWeek}, '${itemMissionId}', '${ex_mission}'),`;
      }
    });

    const inserExerciseActivitySQL = `
                      insert into exercise_activity(user_id, week_in_program, mission_id, mission_activities) 
                      values
                      ${valuesString}
                  `;

    //ถ้ามี week ไหนหายไป ค่อย insert ให้ผู้ใช้
    if (lostWeek.length > 0) {
      await query(inserExerciseActivitySQL);
    }

    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function register(event) {
  const { email, password } = JSON.parse(event.body);
  const hash = md5(password);

  try {
    let result;

    result = success(createSuccessBody({ message: "success" }));
    const insertMemberSQL = `
        INSERT INTO member set 
        user_id = '${uuidv4()}', email = '${email}', password = '${hash}'
        `;
    await query(insertMemberSQL); //ปิดการทำงานการสมัครสมาชิก

    return result;
  } catch (error) {
    return error;
  }
}
export async function insertNutritionKnowledgeActivity(event) {
  const { user_id, knowledge, score, assess_knowledge } = JSON.parse(
    event.body
  );
  const insertNutritionActivitySQL = `
             INSERT INTO nutrition_knowledge_activity set
              user_id = '${user_id}', knowledge = '${JSON.stringify(
    knowledge
  )}', score = '${JSON.stringify(score)}', assess_knowledge = '${JSON.stringify(
    assess_knowledge
  )}';
          `;

  try {
    const checkUserNutritionKnowledgeActivitySQL = `
        select * from nutrition_knowledge_activity
        where user_id = '${user_id}'
        `;
    const checkUserNutritionKnowledgeActivityResult = await queryRaw(
      checkUserNutritionKnowledgeActivitySQL
    );
    if (!checkUserNutritionKnowledgeActivityResult[0]) {
      let result;
      await query(insertNutritionActivitySQL);
      result = success(createSuccessBody({ message: "success" }));
      return result;
    }
  } catch (error) {
    return error;
  }
}

export async function create_event_activity(event) {
  const {
    eventName,
    imageHead,
    eventDetail,
    startDate,
    endDate,
    startDateShow,
    endDateShow,
    criteria_distance,
    distance,
    criteria_walk_step,
    walk_step,
    rewards,
    creator,
  } = JSON.parse(event.body);

  const eventActivity = `
  INSERT INTO event_activity SET
    event_name = '${eventName}',
    cover_Image = '${imageHead}',
    event_detail = '${eventDetail}',
    start_date = '${startDate}',
    end_date = '${endDate}',
    start_date_show = '${startDateShow}',
    end_date_show = '${endDateShow}',
    criteria_distance = '${criteria_distance}',
    distance = '${distance}',
    criteria_walk_step = '${criteria_walk_step}',
    walk_step = '${walk_step}',
    reward = '${JSON.stringify(rewards)}',
    creator= '${creator}';
`;
  try {
    let result;
    await query(eventActivity);
    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function register_event_activity(event) {
  const { id, user_id, walk_step, distance } = JSON.parse(event.body);

  const eventActivity = `
  INSERT INTO event_activity_list_for_user SET
  user_id = '${user_id}',
  event_id = '${id}',
  walk_step = '${walk_step}',
  distance = '${distance}'
`;

  const check_event_activityUserSQL = `
  SELECT * FROM event_activity_list_for_user
  WHERE user_id = '${user_id}' AND event_id = '${id}';
`;
  try {
    const result = await queryRaw(check_event_activityUserSQL);
    if (result && result.length === 0) {
      let result;
      await query(eventActivity);
      result = success(createSuccessBody({ message: "success" }));
      return result;
    }
  } catch (error) {
    return error;
  }
}
