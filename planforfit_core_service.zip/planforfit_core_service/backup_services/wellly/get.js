import bcrypt from "bcrypt";
import md5 from "md5";
import { query, queryRaw } from "./local_lib/dbhelper";
import { uuidv4 } from "./local_lib/Utils";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody,
} from "./local_lib/response-lib";
import { calculateWeekInProgram } from "./util/schedule";
import { calculatePoints } from "./util/calculate";
var moment = require("moment-timezone");
moment.tz.setDefault("Asia/Bangkok");
import axios from "axios";
import { encode as btoa } from "base-64";

export async function checkEmailExisted(event) {
  const { email } = event.queryStringParameters;
  try {
    let result;

    const checkEmailExistedSQL = `
    select * from member
    where email = '${email}'
    `;
    const checkEmailExistedResult = await queryRaw(checkEmailExistedSQL);

    if (checkEmailExistedResult[0]) {
      result = success(createSuccessBody({ message: "email_existed" }));
    } else {
      result = success(createSuccessBody({ message: "success" }));
    }

    return result;
  } catch (error) {
    return error;
  }
}

export async function getProfanity() {
  const query = `select * from profanity`;
  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ profanities: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getNutritionMission(event) {
  const { mission_id } = event.queryStringParameters;
  const query = `select * from nutrition_mission where id = '${mission_id}' `;
  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ nutrition_mission: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getNutritionActivity(event) {
  const { user_id } = event.queryStringParameters;
  const query = ` 
  select na.act_id, na.user_id, na.week_in_program, na.mission_id, nm.heading, nm.heading_eng, nm.short_content, nm.short_content_eng, na.quiz_activities, na.quiz_activities_number,na.assessment_kit_activties,na.assessment_kit_number from nutrition_activity as na
  join nutrition_mission as nm on nm.id = na.mission_id 
  where user_id = '${user_id}' ORDER BY nm.week_in_program DESC
  `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ nutrition_activity: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getNutritionActivityIdMission(event) {
  const { user_id, mission_id } = event.queryStringParameters;
  const query = `
  select na.act_id, na.user_id, nm.id,na.week_in_program, na.mission_id, nm.heading, nm.short_content, na.quiz_activities, na.quiz_activities_number,nm.assessment_kit,na.assessment_kit_activties,na.assessment_kit_number,nm.assessment_results from nutrition_activity as na
  join nutrition_mission as nm on nm.id = na.mission_id
  where user_id = '${user_id}' AND  mission_id = '${mission_id}' 
  `;

  try {
    let result;
    const queryResult = await queryRaw(query); //
    result = success(
      createSuccessBody({ nutrition_activity_id_mission: queryResult })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getExerciserActivity(event) {
  //ใช้ดึงภารกิจทั้งหมดที่ผู้ใช้คนนั้นได้รับ
  const { user_id } = event.queryStringParameters;
  const query = ` 
  select ea.act_id, ea.user_id, ea.week_in_program, ea.mission_id,  ea.read_article, em.heading, em.heading_eng, em.short_content,  em.short_content_eng,
  ea.mission_activities, em.activities_level, ea.status_mission_activities, ea.quiz_activities_number,ea.popup_stary from exercise_activity as ea
  join exercise_mission as em on em.id = ea.mission_id 
  where user_id = '${user_id}' ORDER BY ea.week_in_program DESC
  `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ exerciser_activity: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getExerciserActivitySelected(event) {
  //ใช้ดึงรายละเอียดภารกิจอันที่ผู้ใช้กดเลือกเข้าไปดู
  const { user_id, week_in_program } = event.queryStringParameters;

  const query = `
  select ea.act_id, ea.user_id, em.id, ea.week_in_program, ea.mission_id, em.heading, em.short_content, ea.mission_activities from exercise_activity as ea
  join exercise_mission as em on em.id = ea.mission_id
  where user_id = '${user_id}' AND  ea.week_in_program = ${week_in_program}
  `;
  //test เอาขึ้น git
  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(
      createSuccessBody({ nutrition_activity_id_mission: queryResult })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getActivityList(event) {
  const { user_id } = event.queryStringParameters;
  const query = `
  select id, activity, activity_eng, intensity, type, tag from activity_list
  `;

  const query2 = `
  select * from activity_list_for_user
  where user_id = '${user_id}'
  `;

  try {
    let result;
    const activity_list_default = await queryRaw(query);
    //queryResult รายการ default ทั้งหมด
    const queryResult2 = await queryRaw(query2);
    const activity_list_addon = queryResult2[0]
      ? JSON.parse(queryResult2[0].activity_list_addon)
      : [];
    const activity_list_all = activity_list_default.concat(activity_list_addon);
    let grouped = activity_list_all.reduce(function (result, current) {
      if (!result[current.intensity]) {
        result[current.intensity] = [];
      }
      result[current.intensity].push(current);
      return result;
    }, {});

    result = success(createSuccessBody({ activity_list: grouped }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getMemberActivityLogInWeek(event) {
  const { user_id } = event.queryStringParameters;
  const query = `
  select * from member_activity_log
  where user_id = '${user_id}' and created_at between 
  DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)
  AND
  DATE_ADD(DATE_ADD(CURDATE(), INTERVAL (6-WEEKDAY(CURDATE())) DAY), INTERVAL 1439 minute)
  order by created_at desc
  `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(
      createSuccessBody({ member_activity_log_in_week: queryResult })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getAllTrainingSet(event) {
  const { user_id, week_in_program } = event.queryStringParameters;

  const selectTrainingSetSQL = `
  select * from exercise_activity
  where user_id = '${user_id}' and week_in_program = ${week_in_program}
  `;

  try {
    let result;
    const selectallTrainingSetResult = await queryRaw(selectTrainingSetSQL);
    const mission_activities = JSON.parse(
      selectallTrainingSetResult[0].mission_activities
    );
    //เข้าไป mission_activities เข้าไปกรองหมวดหมู่ที่มึกท่าฝึกออกมา
    const mission_activities_filter = mission_activities.filter(
      (item) =>
        item.id === "core_balance" ||
        item.id === "core_balance_plyo" ||
        item.id === "resistance" ||
        item.id === "flexibility"
    );
    result = success(
      createSuccessBody({ allTrainingSet: mission_activities_filter })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getTrainingSet(event) {
  const { set_code } = event.queryStringParameters;

  const selectTrainingSetSQL = `
  select ts.set_code, ts.order, ts.main_form, ts.alt_form, tf.name, tf.img_url_m,  tf.img_url_f, tf.thumbnail_m, tf.thumbnail_f, ts.set, ts.rep,ts.rep_eng, ts.tempo,ts.tempo_eng, ts.rest ,ts.rest_eng from training_set as ts 
  join training_form as tf 
  on ts.main_form =  tf.form_code or ts.alt_form =  tf.form_code
  where ts.set_code = '${set_code}'
  `;

  try {
    let result;
    let selectTrainingSetResult = await queryRaw(selectTrainingSetSQL);

    const groupBy = (data, key) => {
      return data.reduce((result, currentValue) => {
        (result[currentValue[key]] = result[currentValue[key]] || []).push(
          currentValue
        );
        return result;
      }, {});
    };

    const groupedData = groupBy(selectTrainingSetResult, "order");
    console.log("groupedData :", groupedData);
    const count = Object.keys(groupedData).length;
    result = success(
      createSuccessBody({ trainingSet: groupedData, numb_form: count })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getMonthActivityLog(event) {
  const { user_id, year, month } = event.queryStringParameters;
  const queryString = `
  select * from member_activity_log
  where user_id = '${user_id}' and year(created_at) = ${year} and month(created_at) = ${month}
  `;
  try {
    let result;
    let activityLog = await queryRaw(queryString);
    result = success(createSuccessBody({ activityLog: activityLog }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getEventActivity() {
  //ดึงข้อมูล Event_activity จาก DB ของ Welly

  const query = `select * from event_activity `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ eventActivity: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

async function groupByActLog(log) {
  const groupBy = (data, key) => {
    return data.reduce((result, currentValue) => {
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      );
      return result;
    }, {});
  };
  let sumAll = {
    lightDuration: 0,
    moderateDuration: 0,
    virgorousDuration: 0,
  };

  if (log.length > 0) {
    let logGroupBy = groupBy(log, "intensity");
    const logLightDuration = logGroupBy.light_intensity
      ? logGroupBy.light_intensity.map((item) => {
          let num = parseInt(item.duration);
          return (num = isNaN(num) ? 0 : num);
        })
      : [0];
    const logModerateDuration = logGroupBy.moderate_intensity
      ? logGroupBy.moderate_intensity.map((item) => {
          let num = parseInt(item.duration);
          return (num = isNaN(num) ? 0 : num);
        })
      : [0];
    const logVirgorousDuration = logGroupBy.vigorous_intensity
      ? logGroupBy.vigorous_intensity.map((item) => {
          let num = parseInt(item.duration);
          return (num = isNaN(num) ? 0 : num);
        })
      : [0];
    const sumLogLightDuration = logLightDuration.reduce(
      (accumulator, currentValue) => accumulator + currentValue,
      0
    );
    const sumLogModerateDuration = logModerateDuration.reduce(
      (accumulator, currentValue) => accumulator + currentValue,
      0
    );
    const sumLogVirgorousDuration = logVirgorousDuration.reduce(
      (accumulator, currentValue) => accumulator + currentValue,
      0
    );
    //แปลงนาทีเป็นชั่วโมง และ fixed ทศนิยม 1 ตำแหน่งด้วย
    sumAll = {
      lightDuration: parseFloat((sumLogLightDuration / 60).toFixed(1)),
      moderateDuration: parseFloat((sumLogModerateDuration / 60).toFixed(1)),
      virgorousDuration: parseFloat((sumLogVirgorousDuration / 60).toFixed(1)),
    };
  }

  return sumAll;
}

export async function getYearActivityLogGraph(event) {
  const { user_id, year } = event.queryStringParameters;
  const queryString = `
  select * from member_activity_log
  where user_id = '${user_id}' and year(created_at) = ${year}
  `;
  try {
    let result;
    let activityLog = await queryRaw(queryString);
    let month1Log = [];
    let month2Log = [];
    let month3Log = [];
    let month4Log = [];
    let month5Log = [];
    let month6Log = [];
    let month7Log = [];
    let month8Log = [];
    let month9Log = [];
    let month10Log = [];
    let month11Log = [];
    let month12Log = [];
    activityLog.map((item) => {
      const date = new Date(item.created_at);
      const month = date.getMonth() + 1;
      if (month === 1) {
        month1Log.push(item);
      }
      if (month === 2) {
        month2Log.push(item);
      }
      if (month === 3) {
        month3Log.push(item);
      }
      if (month === 4) {
        month4Log.push(item);
      }
      if (month === 5) {
        month5Log.push(item);
      }
      if (month === 6) {
        month6Log.push(item);
      }
      if (month === 7) {
        month7Log.push(item);
      }
      if (month === 8) {
        month8Log.push(item);
      }
      if (month === 9) {
        month9Log.push(item);
      }
      if (month === 10) {
        month10Log.push(item);
      }
      if (month === 11) {
        month11Log.push(item);
      }
      if (month === 12) {
        month12Log.push(item);
      }
    });
    const yearLog = [
      [await groupByActLog(month1Log)],
      [await groupByActLog(month2Log)],
      [await groupByActLog(month3Log)],
      [await groupByActLog(month4Log)],
      [await groupByActLog(month5Log)],
      [await groupByActLog(month6Log)],
      [await groupByActLog(month7Log)],
      [await groupByActLog(month8Log)],
      [await groupByActLog(month9Log)],
      [await groupByActLog(month10Log)],
      [await groupByActLog(month11Log)],
      [await groupByActLog(month12Log)],
    ];
    result = success(createSuccessBody({ yearLog: yearLog }));
    return result;
  } catch (error) {
    return error;
  }
}

function getWeekOfMonth(date) {
  const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
  const firstWeekDay = monthStart.getDay();
  const adjustedDate = date.getDate() + firstWeekDay - 1;
  return Math.floor(adjustedDate / 7) + 1;
}

export async function getMonthActivityLogGraph(event) {
  const { user_id, month } = event.queryStringParameters;
  const currDate = new Date();
  const currYear = currDate.getFullYear();
  const queryString = `
  select * from member_activity_log
  where user_id = '${user_id}' and month(created_at) = ${month} and year(created_at) = ${currYear}
  `;
  try {
    let result;
    let activityLog = await queryRaw(queryString);
    // console.log("activityLog :", activityLog);
    let week1Log = [];
    let week2Log = [];
    let week3Log = [];
    let week4Log = [];
    let week5Log = [];

    //ทำตัวแยกว่า data อันนั้นๆอยู่ week ไหน
    activityLog.map((item) => {
      const date = new Date(item.created_at);
      const weekOfMonth = getWeekOfMonth(item.created_at);
      if (weekOfMonth === 1) {
        week1Log.push(item);
      }
      if (weekOfMonth === 2) {
        week2Log.push(item);
      }
      if (weekOfMonth === 3) {
        week3Log.push(item);
      }
      if (weekOfMonth === 4) {
        week4Log.push(item);
      }
      if (weekOfMonth === 5) {
        week5Log.push(item);
      }
    });
    const monthLog = [
      [await groupByActLog(week1Log)],
      [await groupByActLog(week2Log)],
      [await groupByActLog(week3Log)],
      [await groupByActLog(week4Log)],
      [await groupByActLog(week5Log)],
    ];

    result = success(createSuccessBody({ monthLog: monthLog }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getWeekActivityLogGraph(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `
  select * from member_activity_log
  where user_id = '${user_id}' and week(created_at) = week(CURDATE())
  `;
  const queryStringLastWeek = `
  select * from member_activity_log
  where user_id = '${user_id}' and week(created_at) = week(CURDATE()) - 1
  `;
  try {
    let result;
    let activityLog = await queryRaw(queryString);
    let activityLogLastWeek = await queryRaw(queryStringLastWeek);
    const weekLog = [
      [await groupByActLog(activityLogLastWeek)],
      [await groupByActLog(activityLog)],
    ];
    result = success(createSuccessBody({ weekLog: weekLog }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getNutritionKnowledge() {
  const queryString = `select * from nutrition_knowledge`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({ get_nutrition_knowledge: queryResult })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function getNutritionKnowledgeActivity(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select * from nutrition_knowledge_activity  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({ get_nutrition_knowledge_activity: queryResult })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getBadge(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select badge from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(createSuccessBody({ get_badge: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

//เช็คการสอนใช้แอพ
export async function get_teach_user_home(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select teach_user_home from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({ teach_user_home: queryResult[0].teach_user_home })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function get_teach_user_nutrition(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select teach_user_nutrition from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({
        teach_user_nutrition: queryResult[0].teach_user_nutrition,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function get_teach_user_article_template(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select teach_user_article_template from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({
        teach_user_article_template: queryResult[0].teach_user_article_template,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function get_teach_user_exercise(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select teach_user_exercise from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({
        teach_user_exercise: queryResult[0].teach_user_exercise,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function get_teach_user_ex_article_template(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select teach_user_ex_article_template from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({
        teach_user_ex_article_template:
          queryResult[0].teach_user_ex_article_template,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function get_teach_user_exercise_program(event) {
  const { user_id } = event.queryStringParameters;
  const queryString = `select teach_user_exercise_program from member  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);
    result = success(
      createSuccessBody({
        teach_user_exercise_program: queryResult[0].teach_user_exercise_program,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}
export async function get_point(event) {
  const { max_point, email } = event.queryStringParameters;
  //ดึงข้อมูล stars, trophies, badges, quiz_completion, assessment_kit_completion ของผู้ใช้
  const selectStarsAndTrophies = `
    select sum(star) as star , sum(trophy) as trophy from exercise_activity
    where user_id in (select user_id from member where email = '${email}')
  `;
  const selectBadge = `
    select badge from member
    where user_id in (select user_id from member where email = '${email}')
  `;
  const selectQuizAndAssessmentKit = `
    select quiz_activities_number, assessment_kit_number from nutrition_activity
    where user_id in (select user_id from member where email = '${email}')
  `;
  try {
    let result;

    const resultStarsAndTrophies = await queryRaw(selectStarsAndTrophies);
    const stars = resultStarsAndTrophies[0].star
      ? resultStarsAndTrophies[0].star
      : 0;
    const trophies = resultStarsAndTrophies[0].trophy
      ? resultStarsAndTrophies[0].trophy
      : 0;

    const resultBadge = await queryRaw(selectBadge);
    const badges = resultBadge[0].badge
      ? JSON.parse(resultBadge[0].badge).length
      : 0;

    const resultQuizAndAssessmentKit = await queryRaw(
      selectQuizAndAssessmentKit
    );

    //เข้าไปสมาชิกแต่ละตัวของ resultQuizAndAssessmentKit และนับจำนวน Complete ของ Quiz กับ AssessmentKit
    let numbCompQuiz = 0;
    let numbCompAssessmentKit = 0;
    for (let i = 0; i < resultQuizAndAssessmentKit.length; i++) {
      if (resultQuizAndAssessmentKit[i].quiz_activities_number) {
        numbCompQuiz = numbCompQuiz + 1;
      }

      if (resultQuizAndAssessmentKit[i].assessment_kit_number) {
        numbCompAssessmentKit = numbCompAssessmentKit + 1;
      }
    }

    const quiz_completion = numbCompQuiz;
    const assessment_kit_completion = numbCompAssessmentKit;
    const point = calculatePoints(
      max_point,
      stars,
      trophies,
      badges,
      quiz_completion,
      assessment_kit_completion
    );

    result = success(createSuccessBody({ point: point }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function get_event_user(event) {
  const { user_id } = event.queryStringParameters;

  const queryString = `select * from event_activity_list_for_user  where user_id = '${user_id}'`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);

    result = success(
      createSuccessBody({
        event_user: queryResult,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function get_activity_users(event) {
  const { id } = event.queryStringParameters;

  const queryString = `SELECT event_activity_list_for_user.id,
  event_activity_list_for_user.user_id,
  event_activity_list_for_user.event_id,
  event_activity_list_for_user.walk_step,
  event_activity_list_for_user.distance,
  event_activity.distance as event_distance,
  event_activity.walk_step as event_walk_step,
  event_activity.status,
  event_activity.event_name,
  event_activity.start_date,
  event_activity.end_date,
  event_activity.start_date_show,
  event_activity.end_date_show,
  event_activity.reward,
  member.display_name,
  member.email
  FROM wellly_db.event_activity_list_for_user
  LEFT JOIN wellly_db.event_activity
  ON event_activity_list_for_user.event_id = event_activity.id
  LEFT JOIN wellly_db.member
  ON event_activity_list_for_user.user_id = member.user_id
  where event_activity_list_for_user.event_id = '${id}'
  ORDER BY
  CASE WHEN criteria_distance = 'true' AND criteria_walk_step = 'true' THEN event_activity_list_for_user.walk_step END DESC,
  CASE WHEN criteria_distance = 'false' AND criteria_walk_step = 'true' THEN event_activity_list_for_user.walk_step END DESC,
  CASE WHEN criteria_distance = 'true' AND criteria_walk_step = 'false' THEN event_activity_list_for_user.distance END DESC`;
  try {
    let result;
    const queryResult = await queryRaw(queryString);

    result = success(
      createSuccessBody({
        event_user: queryResult,
      })
    );
    return result;
  } catch (error) {
    return error;
  }
}
