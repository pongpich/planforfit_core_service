import { google } from 'googleapis';

const google_client_id = `437818993892-bktohqnk6qtcq8hhh8tjodtiu58lkbq7.apps.googleusercontent.com`;
const google_client_secret = `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`;
const google_redirect_url = `https://api.planforfit.com/wellly/handleGoogleRedirect`;
const google_scope = `https://www.googleapis.com/auth/fitness.activity.read`;

export async function getUrlGoogleAuth() {
  const oAuth2Client = new google.auth.OAuth2(
    google_client_id,
    google_client_secret,
    google_redirect_url
  );

  const url = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: google_scope,
    prompt: 'consent',
  });
  console.log("url :", url);

  return {
    statusCode: 200,
    body: JSON.stringify({ url }),
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',

    },
  };

}

export async function handleGoogleRedirect(event) {
  const { code } = event.queryStringParameters;

  const oAuth2Client = new google.auth.OAuth2(
    google_client_id,
    google_client_secret,
    google_redirect_url
  );

  return new Promise((resolve, reject) => {
    oAuth2Client.getToken(code, (err, tokens) => {
      if (err) {
        console.error("Error getting tokens:", err);
        reject("Error getting tokens");
      } else {
        const accessToken = tokens.access_token;
        const refreshToken = tokens.refresh_token;

        const redirectUrl = `https://wellly.planforfit.com/#/detailTimer?accessToken=${accessToken}&refreshToken=${refreshToken}`;  //สำหรับ prod
        //const redirectUrl = `http://localhost:3000/#/detailTimer?accessToken=${accessToken}&refreshToken=${refreshToken}`;  //สำหรับ local

        resolve({
          statusCode: 302,
          headers: {
            Location: redirectUrl,
            'Access-Control-Allow-Origin': '*',
          },
        });
      }
    });
  });
};



export async function getValidToken(event) {
  try {
    const requestBody = JSON.parse(event.body);

    const response = await fetch("https://www.googleapis.com/oauth2/v4/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        client_id: google_client_id,
        client_secret: google_client_secret,
        refresh_token: requestBody.refreshToken,
        grant_type: "refresh_token",
      }),
    });

    const data = await response.json();
    console.log("Server 74 | data", data.access_token);

    return {
      statusCode: 200,
      body: JSON.stringify({
        accessToken: data.access_token,
      }),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
    };
  }
};