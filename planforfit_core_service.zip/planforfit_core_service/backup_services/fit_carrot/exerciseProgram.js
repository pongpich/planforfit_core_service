import { query, queryRaw } from "./local_lib/dbhelper";
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";

export async function getUserProgram(event) {
  const { email } = event.queryStringParameters;
  const query = ` select start_date, expire_date, program_id from member
                  where email = '${email}'`;

  try {
    const queryResult = await queryRaw(query);
    let result;

    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_program' }));
    } else { 
      const userProgram = queryResult;
      console.log("userProgram :", userProgram);
      result = success(createSuccessBody({ message: 'success', userProgram: userProgram }))
    }
    return result
  } catch (error) {
    return error;
  }
}

export async function selectProgram(event) {
  const { program_id } = event.queryStringParameters;
  const query = `select * from program where program_id='${program_id}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;

    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_program' }));
    } else {
      const program = queryResult[0];
      result = success(createSuccessBody({ message: 'success', program: program }))
    }
    return result
  } catch (error) {
    return error;
  }
}
export async function getAllProgram(event) {
  const query = `select * from program`;
  try {
    const queryResult = await queryRaw(query);
    let result;

    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_program' }));
    } else {
      const allProgram = queryResult;
      console.log("allProgram :", allProgram);
      result = success(createSuccessBody({ message: 'success', allProgram: allProgram }))
    }
    return result
  } catch (error) {
    return error;
  }
}