import { sha256 } from "js-sha256";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody
} from "./local_lib/response-lib";
import { queryRaw } from "./local_lib/dbhelper";
import { calculateWeekInProgram } from './util/schedule';
//import moment from 'moment';
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

export async function check4WeeksPrompt(event) {
  const { user_id } = event.queryStringParameters;

  const selectMemberInfo = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    let result;
    let statusCheck4WeeksPrompt = false;

    const memberInfo = await queryRaw(selectMemberInfo);
    const start_date = memberInfo[0].start_date;
    const program_level = memberInfo[0].program_level;
    const week = calculateWeekInProgram(start_date);
    const batch = Math.ceil(week / 8);
    console.log("week :", week);
    console.log("batch :", batch);
    const selectProgramPromptLog = `
    select * from program_prompt_log
    where user_id = '${user_id}' and batch = ${batch} and log = '4 weeks prompt';
    `;
    const programPromptLog = await queryRaw(selectProgramPromptLog);
    console.log("programPromptLog :", programPromptLog.length);

    if ((programPromptLog.length === 0) && (program_level === 'bfr_lv1.5') && ((week % 8 === 2) || (week % 8 === 3) || (week % 8 === 4))) { // %8 === 2,3,4 จะมีโอกาสเป็นช่วงที่เพิ่งเล่น bfr_lv1.5 แล้วเปลี่ยนใจอยากอัพ level

      if (batch > 1) { //เช็ค batch ที่แล้ว ว่าเป็น low imp ไหม ถ้าเป็น statusCheck4WeeksPrompt = true
        const last_batch = batch - 1;
        const start_week = ((last_batch - 1) * 8) + 1;
        const end_week = start_week + 7;
        const selectExerciseHistory = `
          select week_in_program, program_level from exercise_activity
          where user_id = '${user_id}' and week_in_program >= ${start_week} and  week_in_program <= ${end_week}
        `;
        const exerciseHistory = await queryRaw(selectExerciseHistory);
        //วน loop เข้าไปใน exerciseHistory เช็คว่าเป็น low imp ไหม
        var lowimp = false;
        for (var i = 0; i < exerciseHistory.length; i++) {
          if (exerciseHistory[i].program_level.includes("lowimp")) {
            lowimp = true;
          }
        }
        if (lowimp) {
          statusCheck4WeeksPrompt = true;
        }
      } else {
        statusCheck4WeeksPrompt = true;
      }
    }

    result = success(createSuccessBody({ statusCheck4WeeksPrompt: statusCheck4WeeksPrompt }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkRenewPrompt(event) {
  const { user_id } = event.queryStringParameters;

  const selectMemberInfo = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    let result;
    let statusCheckRenewPrompt = false;

    const memberInfo = await queryRaw(selectMemberInfo);
    const start_date = memberInfo[0].start_date;
    const program_level = memberInfo[0].program_level;
    const week = calculateWeekInProgram(start_date);
    const batch = Math.ceil(week / 8);
    console.log("week :", week);
    console.log("batch :", batch);

    const selectCurrBatch = `
    select *  from exercise_activity
    where user_id = '${user_id}' and week_in_program >= ${(batch * 8) - 7} and  week_in_program <= ${batch * 8};
    `;
    const currBatch = await queryRaw(selectCurrBatch);
    console.log("currBatch :", currBatch.length);

    const selectProgramPromptLog = `
    select * from program_prompt_log
    where user_id = '${user_id}' and batch = ${batch} and log = 'renew prompt';
    `;
    const programPromptLog = await queryRaw(selectProgramPromptLog);
    console.log("programPromptLog :", programPromptLog.length);

    if ((programPromptLog.length === 0) && (program_level === 'bfr_lv1') && (currBatch.length === 0)) { // currBatch.length === 0 คือ Batch ปัจจุบันยังไม่มี exercise_activity

      if (batch > 1) { //เช็ค batch ที่แล้ว ว่าเป็น low imp ไหม ถ้าเป็น statusCheckRenewPrompt = true
        const last_batch = batch - 1;
        const start_week = ((last_batch - 1) * 8) + 1;
        const end_week = start_week + 7;
        const selectExerciseHistory = `
          select week_in_program, program_level from exercise_activity
          where user_id = '${user_id}' and week_in_program >= ${start_week} and  week_in_program <= ${end_week}
        `;
        const exerciseHistory = await queryRaw(selectExerciseHistory);
        //วน loop เข้าไปใน exerciseHistory เช็คว่าเป็น low imp ไหม
        var lowimp = false;
        for (var i = 0; i < exerciseHistory.length; i++) {
          if (exerciseHistory[i].program_level.includes("lowimp")) {
            lowimp = true;
          }
        }
        if (!lowimp) {
          statusCheckRenewPrompt = true;
        }
      }
    }

    result = success(createSuccessBody({ statusCheckRenewPrompt: statusCheckRenewPrompt }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getMemberInfo(event) {
  const { user_id } = event.queryStringParameters;
  const query = `select * from member where user_id='${user_id}'`;
  try {
    const queryResult = await queryRaw(query);
    const member_info = queryResult[0];
    let result;
    result = success(createSuccessBody({ member_info: member_info }));
    return result
  } catch (error) {
    return error;
  }
}

export async function checkDisplayName(event) {
  const { display_name } = event.queryStringParameters;
  const selectDisplayNameSQL = `select * from member where display_name='${display_name}'`;
  try {
    let result;
    const selectDisplayNameResult = await queryRaw(selectDisplayNameSQL);
    if (selectDisplayNameResult.length <= 0) {
      result = success(createSuccessBody({ message: 'new' }));
    } else {
      result = success(createSuccessBody({ message: 'exist' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function getAchievementLog(event) {
  const { user_id } = event.queryStringParameters;

  const selectAchievementLog = `
                            select * from achievement_log
                            where user_id = '${user_id}'; `
  try {
    let result;
    const selectAchievementLogResult = await queryRaw(selectAchievementLog);
    const achievementLog = selectAchievementLogResult;
    result = success(createSuccessBody({ message: 'success', achievementLog: achievementLog }))
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}

export async function getFriendsRank(event) {
  const { user_id } = event.queryStringParameters;
  const friendListSQL = `
  select friend_list from member
  where user_id = '${user_id}'
`;

  const challengePeriodSQL = `SELECT start_date, expire_date
  FROM challenge_event
  ORDER BY start_date DESC
  LIMIT 1;` ;

  try {
    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const start_date_challenge = moment(challengePeriodResult[0].start_date).format('YYYYMMDD');
    const expire_date_challenge = moment(challengePeriodResult[0].expire_date).format('YYYYMMDD'); //วันหมดอายุ ของ Season ล่าสุด
    const friendListResult = await queryRaw(friendListSQL);

    if (friendListResult[0].friend_list && JSON.parse(friendListResult[0].friend_list).length > 0) { //ถ้าเป็น null หรือ []เปล่าๆ แสดงว่ายังไม่มีเพื่อน
      const friends = JSON.parse(friendListResult[0].friend_list);
      const numberOfFriends = friends.length;
      var stringFriendList = '';
      for (var i = 0; i < numberOfFriends; i++) {
        if (i < (numberOfFriends - 1)) {
          stringFriendList = stringFriendList + `member.user_id = '${friends[i]}' OR `
        } else {
          stringFriendList = stringFriendList + `member.user_id = '${friends[i]}' OR member.user_id = '${user_id}'`
        }
      }

      const selectFriendListSQL = ` select m.user_id, m.email, m.first_name, m.last_name, m.facebook, m.display_name, coalesce(calcScore.total_score, 0) as total_score, challenge_activity.start_rank, challenge_activity.end_rank, challenge_activity.created_at
                                    from (
                                          select user_id, sum(score) as total_score
                                          from member_event_log
                                          where created_at BETWEEN '${start_date_challenge}' AND '${expire_date_challenge}'
                                          group by user_id
                                          ) as calcScore RIGHT JOIN (
                                          select * from member
                                    where ${stringFriendList}
                                          ) as m
                                    ON m.user_id = calcScore.user_id
                                    JOIN (
                                      select * from challenge_activity
                                      WHERE user_id IN (
                                        select user_id from member 
                                    where ${stringFriendList}
                                      )
                                      order by challenge_activity.created_at DESC LIMIT ${numberOfFriends + 1}
                                    ) as challenge_activity
                                    ON m.user_id = challenge_activity.user_id 
                                    ORDER BY calcScore.total_score DESC, challenge_activity.created_at DESC;`

      const friend_list = await queryRaw(selectFriendListSQL);
      result = success(createSuccessBody({ message: "success", friend_list: friend_list }));
    } else {
      result = success(createSuccessBody({ message: "friendless" }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function getTeamInvite(event) {
  const { user_id } = event.queryStringParameters;

  const selectTeamInviteSQL = `
                                select * from team_invite
                                join member on team_invite.sender_id = member.user_id
                                where receiver_id = '${user_id}' and status = 'default'
                                `

  try {
    let result;
    const selectTeamInviteResult = await queryRaw(selectTeamInviteSQL);
    if (selectTeamInviteResult.length > 0) { // เช็คว่ามีคำเชิญร่วมทีมไหม
      result = success(createSuccessBody({ message: 'success', team_invite: selectTeamInviteResult }))
    } else {
      result = success(createSuccessBody({ message: 'no_team_invite' }))
    }
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}

export async function getMaxFriends(event) {
  const { user_id } = event.queryStringParameters;

  const selectMaxFriensSQL = `
                            select max_friends from member
                            where user_id = '${user_id}'; `
  try {
    let result;
    const selectMaxFriensResult = await queryRaw(selectMaxFriensSQL);
    const max_friends = selectMaxFriensResult[0].max_friends;
    result = success(createSuccessBody({ message: 'success', max_friends: max_friends }))
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}

export async function getFriendRequest(event) {
  const { user_id } = event.queryStringParameters;

  const selectFriendRequstSQL = `
                                select * from friend_request
                                join member on friend_request.sender_id = member.user_id
                                where receiver_id = '${user_id}' and status = 'default'
                                `

  try {
    let result;
    const selectFriendRequstResult = await queryRaw(selectFriendRequstSQL);
    if (selectFriendRequstResult.length > 0) { // เช็คว่ามีคำขอเป็นเพื่อนไหม
      result = success(createSuccessBody({ message: 'success', friend_request: selectFriendRequstResult }))
    } else {
      result = success(createSuccessBody({ message: 'no_friend_request' }))
    }
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}

export async function getFriendList(event) {
  const { user_id } = event.queryStringParameters;
  const friendListSQL = `
  select friend_list from member
  where user_id = '${user_id}'
`;

  const challengePeriodSQL = `SELECT start_date, expire_date
  FROM challenge_event
  ORDER BY start_date DESC
  LIMIT 1;` ;

  try {
    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const start_date_challenge = moment(challengePeriodResult[0].start_date).format('YYYYMMDD');
    const expire_date_challenge = moment(challengePeriodResult[0].expire_date).format('YYYYMMDD'); //วันหมดอายุ ของ Season ล่าสุด
    const friendListResult = await queryRaw(friendListSQL);

    if (friendListResult[0].friend_list && JSON.parse(friendListResult[0].friend_list).length > 0) { //ถ้าเป็น null หรือ []เปล่าๆ แสดงว่ายังไม่มีเพื่อน
      const friends = JSON.parse(friendListResult[0].friend_list);
      const numberOfFriends = friends.length;
      var stringFriendList = '';
      for (var i = 0; i < numberOfFriends; i++) {
        if (i < (numberOfFriends - 1)) {
          stringFriendList = stringFriendList + `member.user_id = '${friends[i]}' OR `
        } else {
          stringFriendList = stringFriendList + `member.user_id = '${friends[i]}'`
        }
      }

      const selectFriendListSQL = ` select m.user_id, m.email, m.first_name, m.last_name, m.facebook, m.display_name, coalesce(calcScore.total_score, 0) as total_score, challenge_activity.start_rank, challenge_activity.end_rank, challenge_activity.created_at
                                    from (
                                          select user_id, sum(score) as total_score
                                          from member_event_log
                                          where created_at BETWEEN '${start_date_challenge}' AND '${expire_date_challenge}'
                                          group by user_id
                                          ) as calcScore RIGHT JOIN (
                                          select * from member
                                    where ${stringFriendList}
                                          ) as m
                                    ON m.user_id = calcScore.user_id
                                    JOIN (
                                      select * from challenge_activity
                                      WHERE user_id IN (
                                        select user_id from member 
                                    where ${stringFriendList}
                                      )
                                      order by challenge_activity.created_at DESC LIMIT ${numberOfFriends}
                                    ) as challenge_activity
                                    ON m.user_id = challenge_activity.user_id 
                                    ORDER BY calcScore.total_score DESC, challenge_activity.created_at DESC;`

      const friend_list = await queryRaw(selectFriendListSQL);
      console.log("start_date_challenge :", start_date_challenge);
      console.log("expire_date_challenge :", expire_date_challenge);
      console.log("stringFriendList :", stringFriendList);
      console.log("numberOfFriends :", numberOfFriends);
      result = success(createSuccessBody({ message: "success", friend_list: friend_list }));
    } else {
      result = success(createSuccessBody({ message: "friendless" }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function getBestClipInSeason() {
  /*   const {clip_quality} = event.queryStringParameters; */
  const getBestClipInSeasonSQL = `SELECT * FROM  bi_clip_count WHERE clip_quality = 'best';`;

  try {
    let result;
    const getBesClipInSeasonResult = await queryRaw(getBestClipInSeasonSQL);
    result = success(createSuccessBody({ bestClipInSeason: getBesClipInSeasonResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getWorstClipInSeason() {
  /*   const {clip_quality} = event.queryStringParameters; */
  const getWorstClipInSeasonSQL = `SELECT * FROM  bi_clip_count WHERE clip_quality = 'worst';`;

  try {
    let result;
    const getWorstClipInSeasonResult = await queryRaw(getWorstClipInSeasonSQL);
    result = success(createSuccessBody({ worstClipInSeason: getWorstClipInSeasonResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getChallengeEvent() {
  const challengeEventSQL = `SELECT event_name FROM challenge_event;`;

  try {
    let result;
    const challengeEventResult = await queryRaw(challengeEventSQL);
    result = success(createSuccessBody({ challengeEvent: challengeEventResult }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getDateOfJoiningChallenge(event) {
  const { user_id } = event.queryStringParameters;
  const challengeEventSQL = `SELECT event_name FROM challenge_event;`;

  try {
    let result;
    let dateOfJoiningChallengeEachSeason = [];
    const challengeEventResult = await queryRaw(challengeEventSQL);
    //วนลูปเพื่อไล่แต่ละ season ทั้งหมดภายในระบบ
    for (var j = 0; j < challengeEventResult.length; j++) {
      const event_name = challengeEventResult[j].event_name;
      let dateOfJoiningChallengeEachSeasonJson = {};
      // [ { event_name: season1, date: "2021-05-01"}, {event_name: season2, date: "2021-05-01"} ]
      dateOfJoiningChallengeEachSeasonJson.event_name = event_name;
      dateOfJoiningChallengeEachSeason.push(dateOfJoiningChallengeEachSeasonJson);

      const challengePeriodSQL = `SELECT start_date, expire_date
                                FROM challenge_event
                                WHERE event_name = '${event_name}';`;
      const challengePeriodResult = await queryRaw(challengePeriodSQL);
      const challengeStart = challengePeriodResult[0].start_date;
      const challengeEnd = challengePeriodResult[0].expire_date;
      const start_date = moment(challengeStart).format('YYYY-MM-DD');
      const expire_date = moment(challengeEnd).format('YYYY-MM-DD');

      //เช็คว่า season นั้นๆ ผู้ใช้คนนี้ได้เข้าร่วมหรือไม่ โดยการดูว่ามี member_event_log ไหม
      const memberInSeasonSQL = `SELECT DISTINCT member_event_log.user_id, member.email, member.phone, member.first_name, member.last_name FROM member_event_log JOIN member 
                                ON member_event_log.user_id=member.user_id
                                WHERE member_event_log.user_id = '${user_id}' AND member_event_log.created_at BETWEEN '${start_date}' AND '${expire_date}';`;
      const memberInSeasonResult = await queryRaw(memberInSeasonSQL);

      if (memberInSeasonResult.length > 0) {
        //กรณี season นั้นผู้ใช้มีการเข้าร่วม ให้ทำการเช็คว่าเริ่มเล่นชาเลนจ์วันไหนเป็นวันแรก โดยดูจาก created_at
        const dateOfJoiningChallengeSQL = ` SELECT user_id, created_at FROM member_event_log
                                            WHERE user_id = '${user_id}' AND created_at BETWEEN '${start_date}' AND '${expire_date}'
                                            ORDER BY created_at LIMIT 1;`;
        const dateOfJoiningChallengeResult = await queryRaw(dateOfJoiningChallengeSQL);
        dateOfJoiningChallengeEachSeasonJson.created_at = dateOfJoiningChallengeResult[0].created_at;
      } else {
        dateOfJoiningChallengeEachSeasonJson.created_at = "-";
      }
    }
    result = success(createSuccessBody({ dateOfJoiningChallengeEachSeason: dateOfJoiningChallengeEachSeason }));
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}


export async function getMembersEachWeekInSeason() {
  const challengeEventSQL = `SELECT event_name FROM challenge_event;`;

  try {
    let result;
    var percentOfMembersEachWeek = [];
    const challengeEventResult = await queryRaw(challengeEventSQL);
    //วนลูปเพื่อไล่แต่ละ season ทั้งหมดภายในระบบ
    for (var j = 0; j < challengeEventResult.length; j++) {
      const event_name = challengeEventResult[j].event_name;
      percentOfMembersEachWeek.push([])

      const challengePeriodSQL = `SELECT start_date, expire_date
                                FROM challenge_event
                                WHERE event_name = '${event_name}';`;
      const challengePeriodResult = await queryRaw(challengePeriodSQL);
      const challengeStart = challengePeriodResult[0].start_date;
      const challengeEnd = challengePeriodResult[0].expire_date;
      const start_date = moment(challengeStart).format('YYYY-MM-DD');
      const expire_date = moment(challengeEnd).format('YYYY-MM-DD');

      const userInSeasonSQL = ` SELECT DISTINCT user_id FROM member_event_log
                                WHERE created_at BETWEEN '${start_date}' AND '${expire_date}';`;
      const userInSeasonResult = await queryRaw(userInSeasonSQL);
      // จำนวนคนที่เล่น Gamification ใน season 
      const numberOfMembersInSeason = userInSeasonResult.length;

      const numberOfdaysInSeason = Math.abs(moment(challengeStart).diff(moment(challengeEnd), 'days')) + 1;
      //คำนวนจำนวน week ของ season (เนื่องจากบาง season มีจำนวนวันไม่เท่ากัน)
      const numberOfweeksInSeason = numberOfdaysInSeason / 7;

      //วนลูปเพื่อไล่แต่ละ week ภายใน season
      for (var i = 0; i < numberOfweeksInSeason; i++) {
        const week_start_date = moment(challengeStart).add(0 + (i * 7), 'days').format('YYYY-MM-DD');
        const week_end_date = moment(challengeStart).add(7 + (i * 7), 'days').format('YYYY-MM-DD');

        //จำนวนผู้ใช้ที่ active ใน week นั้นๆ ดูจากคนที่มี log_type = 'individual' 
        const userInWeekSQL = `  SELECT DISTINCT user_id FROM member_event_log
                                 WHERE log_type = 'individual' 
                                 AND created_at BETWEEN '${week_start_date}' AND '${week_end_date}';`;
        const userInWeekResult = await queryRaw(userInWeekSQL);
        const numberOfMembersInWeek = userInWeekResult.length;
        const percentOfMembersInWeek = (numberOfMembersInWeek / numberOfMembersInSeason * 100).toFixed(2);
        percentOfMembersEachWeek[j].push(percentOfMembersInWeek)
      }
    }
    //ตย.ข้อมูล percentOfMembersEachWeek[A][B] - [A] คือ index ของ Season, [B] คือ index ของ Week 
    result = success(createSuccessBody({ percentOfMembersEachWeek: percentOfMembersEachWeek }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getGamification(event) { //ใช้สำหรับ dashboard
  const { season } = event.queryStringParameters;

  const challengePeriodSQL = `SELECT start_date, expire_date
                              FROM challenge_event
                              WHERE event_name = '${season}';`;

  try {
    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const challengeStart = challengePeriodResult[0].start_date;
    const challengeEnd = challengePeriodResult[0].expire_date;
    const start_date = moment(challengeStart).format('YYYY-MM-DD');
    const expire_date = moment(challengeEnd).format('YYYY-MM-DD');

    const userInSeasonSQL = `  SELECT DISTINCT user_id FROM member_event_log
                            WHERE created_at BETWEEN '${start_date}' AND '${expire_date}';`;
    const userInSeasonResult = await queryRaw(userInSeasonSQL);
    const numberOfMembersInSeason = userInSeasonResult.length; // จำนวนคนที่เล่น Gamification ใน season 


    const numberOfMembersActiveMoreThan1WeekSQL = ` 
                              SELECT user_id, log, log_type FROM member_event_log 
                              WHERE log_type = 'individual' AND log = 'weight' AND created_at BETWEEN '${start_date}' AND '${expire_date}' 
                              GROUP BY user_id HAVING count(user_id) > 2`;
    const numberOfMembersActiveMoreThan1WeekResult = await queryRaw(numberOfMembersActiveMoreThan1WeekSQL);
    const numberOfMembersActiveMoreThan1Week = numberOfMembersActiveMoreThan1WeekResult.length; // จำนวนคนที่เล่น Gamification มากกว่า 1 week ใน season นั้นๆ

    // ใช้ expire_date_00_00_00 เพื่อเช็คว่าภายในวันสุดท้ายของ season มี user จำนวนกี่คน
    let challengeEnd_00_00_00 = challengeEnd;
    challengeEnd_00_00_00.setHours(challengeEnd_00_00_00.getHours() - 23);
    const expire_date_00_00_00 = moment(challengeEnd_00_00_00).format('YYYY-MM-DD');
    const userInEndSeasonSQL = `  SELECT DISTINCT user_id FROM member_event_log
                               WHERE created_at BETWEEN '${expire_date_00_00_00}' AND '${expire_date}';`;
    const userInEndSeasonResult = await queryRaw(userInEndSeasonSQL);
    const numberOfMembersInEndSeason = userInEndSeasonResult.length; // จำนวนคนที่เล่น Gamification จนจบ season 

    // allUserInSeasonSQL คือ นับทั้งสมาชิกที่ เข้าร่วม และ ไม่เข้าร่วม Gamification
    const allUserInSeasonSQL = `  SELECT DISTINCT exercise_activity.user_id, member.fb_group FROM exercise_activity
                                JOIN member ON exercise_activity.user_id = member.user_id
                                WHERE exercise_activity.created_at BETWEEN '${start_date}' AND '${expire_date}'
                                AND fb_group != 404`;
    const allUserInSeasonResult = await queryRaw(allUserInSeasonSQL);
    const allUserInSeason = allUserInSeasonResult.length;
    const numberOfMembersNotInGamification = allUserInSeason - numberOfMembersInSeason; // จำนวนคนที่ไม่เข้าร่วม  Gamification

    let startDateMoment = moment(start_date).startOf('isoWeek');
    let endDateMoment = moment(expire_date).startOf('isoWeek');
    const numberOfWeeksInSeason = endDateMoment.diff(startDateMoment, 'week'); // จำนวน week ใน season
    //------------------------------------- percentCompleteOfWeight -------------------------------------
    const weightSQL = ` SELECT * FROM member_event_log
     WHERE created_at BETWEEN '${start_date}' AND '${expire_date}'
     AND log = 'weight' AND score = 10 ;`;
    const weightResult = await queryRaw(weightSQL);
    const numberOfWeightResult = weightResult.length;
    // weight AND score = 10 (ชั่งน้ำหนักครบ 2 ครั้ง) สามารถเกิดได้สูงสุดอาทิตย์ละ 1 ครั้ง ต่อผู้ใช้ 1 คน
    const maximumOfWeightResult = numberOfWeeksInSeason * numberOfMembersInSeason;
    const percentCompleteOfWeightResult = numberOfWeightResult / maximumOfWeightResult * 100;

    //------------------------------------- percentCompleteOfExerciseComplete -------------------------------------
    const exerciseCompleteSQL = ` SELECT * FROM member_event_log
        WHERE created_at BETWEEN '${start_date}' AND '${expire_date}'
        AND log = 'exercise complete';`;
    const exerciseCompleteResult = await queryRaw(exerciseCompleteSQL);
    const numberOfExerciseComplete = exerciseCompleteResult.length;
    // exercise complete (ออกกำลังกายครบ 4 วันต่ออาทิตย์) สามารถเกิดได้สูงสุดอาทิตย์ละ 1 ครั้ง ต่อผู้ใช้ 1 คน
    const maximumOfExerciseComplete = numberOfWeeksInSeason * numberOfMembersInSeason;
    const percentCompleteOfExerciseComplete = numberOfExerciseComplete / maximumOfExerciseComplete * 100;

    //------------------------------------- percentCompleteOfWeightBonus -------------------------------------
    const weightBonusSQL = ` SELECT * FROM member_event_log
      WHERE created_at BETWEEN '${start_date}' AND '${expire_date}'
      AND log = 'weight bonus';`;
    const weightBonusResult = await queryRaw(weightBonusSQL);
    const numberOfWeightBonusResult = weightBonusResult.length;
    // weight bonus (ภายในวันนั้นมีสมาชิกในทีมชั่งน้ำหนัก) สามารถเกิดได้สูงสุดอาทิตย์ละ 7 ครั้ง ต่อผู้ใช้ 1 คน
    const maximumOfWeightBonusResult = (numberOfWeeksInSeason * 7) * numberOfMembersInSeason;
    const percentCompleteOfWeightBonusResult = numberOfWeightBonusResult / maximumOfWeightBonusResult * 100;

    //------------------------------------- percentCompleteOfWeightTeamComplete -------------------------------------
    const weightTeamCompleteSQL = ` SELECT * FROM member_event_log
                                    WHERE created_at BETWEEN '${start_date}' AND '${expire_date}'
                                    AND log = 'weight team complete';`;
    const weightTeamCompleteResult = await queryRaw(weightTeamCompleteSQL);
    const numberOfWeightTeamComplete = weightTeamCompleteResult.length;
    // weight team complete (สมาชิกชั่งนน.ครบ 2 ครั้ง) สามารถเกิดได้สูงสุดอาทิตย์ละ 1 ครั้ง ต่อผู้ใช้ 1 คน
    const maximumOfWeightTeamComplete = numberOfWeeksInSeason * numberOfMembersInSeason;
    const percentCompleteOfWeightTeamComplete = numberOfWeightTeamComplete / maximumOfWeightTeamComplete * 100;

    //------------------------------------- percentCompleteOfreducedWeight -------------------------------------
    const reducedWeightSQL = ` SELECT * FROM member_event_log
      WHERE created_at BETWEEN '${start_date}' AND '${expire_date}'
      AND log = 'reduced weight';`;
    const reducedWeightResult = await queryRaw(reducedWeightSQL);
    const numberOfReducedWeight = reducedWeightResult.length;
    // reduced weight (น้ำหนักลดลงจากสัปดาห์ที่แล้ว) สามารถเกิดได้สูงสุดอาทิตย์ละ 1 ครั้ง (ยกเว้นอาทิตย์แรก) ต่อผู้ใช้ 1 คน
    const maximumOfReducedWeight = (numberOfWeeksInSeason - 1) * numberOfMembersInSeason;
    const percentCompleteOfReducedWeight = numberOfReducedWeight / maximumOfReducedWeight * 100;



    result = success(createSuccessBody({
      percentCompleteOfWeightResult: percentCompleteOfWeightResult.toFixed(2),
      percentCompleteOfExerciseComplete: percentCompleteOfExerciseComplete.toFixed(2),
      percentCompleteOfWeightBonusResult: percentCompleteOfWeightBonusResult.toFixed(2),
      percentCompleteOfWeightTeamComplete: percentCompleteOfWeightTeamComplete.toFixed(2),
      percentCompleteOfReducedWeight: percentCompleteOfReducedWeight.toFixed(2),
      numberOfMembersInSeason: numberOfMembersInSeason,
      numberOfMembersActiveMoreThan1Week: numberOfMembersActiveMoreThan1Week,
      numberOfMembersInEndSeason: numberOfMembersInEndSeason,
      numberOfMembersNotInGamification: numberOfMembersNotInGamification
    }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getMemberInSeason(event) {
  const { season } = event.queryStringParameters;

  const challengePeriodSQL = `SELECT start_date, expire_date
                              FROM challenge_event
                              WHERE event_name = '${season}';`;

  try {

    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const challengeStart = challengePeriodResult[0].start_date;
    const challengeEnd = challengePeriodResult[0].expire_date;
    const start_date = moment(challengeStart).format('YYYY-MM-DD');
    const expire_date = moment(challengeEnd).format('YYYY-MM-DD');

    const memberInSeasonSQL = `SELECT DISTINCT member_event_log.user_id, member.email, member.phone, member.first_name, member.last_name FROM member_event_log JOIN member 
                                ON member_event_log.user_id=member.user_id
                                WHERE member_event_log.created_at BETWEEN '${start_date}' AND '${expire_date}';`;
    const memberInSeasonResult = await queryRaw(memberInSeasonSQL);
    const memberOfInSeasonResult = memberInSeasonResult; // จำนวนคน number ใน season 


    result = success(createSuccessBody({
      memberOfInSeasonResult,
    }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectMemberEventLog(event) { //Admin ใช้ดูข้อมูล member_event_log
  const { email } = event.queryStringParameters;

  const selectMemberEventLogSQL = ` SELECT * FROM member_event_log
                                    WHERE user_id=(SELECT user_id FROM member WHERE email='${email}')
                                    AND created_at 
                                      BETWEEN 
                                        (SELECT start_date FROM challenge_event ORDER BY start_date DESC LIMIT 1) 
                                          AND 
                                        (SELECT expire_date FROM challenge_event ORDER BY start_date DESC LIMIT 1)
                                    ORDER BY created_at DESC;`;

  try {
    let result;
    const selectMemberEventLogResult = await queryRaw(selectMemberEventLogSQL);
    const memberEventLog = selectMemberEventLogResult;
    result = success(createSuccessBody({ memberEventLog: memberEventLog }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getChallengePeriod() {
  const challengePeriodSQL = `SELECT start_date, expire_date
  FROM challenge_event
  ORDER BY start_date DESC
  LIMIT 1;` ;

  try {
    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();
    var expireDate = new Date(challengePeriodResult[0].expire_date).getTime(); //วันหมดอายุ ของ Season ล่าสุด
    var startDate = new Date(challengePeriodResult[0].start_date).getTime(); //วันเริ่มต้น ของ Season ล่าสุด

    let challengePeriod = true;
    if ((curr > expireDate) || (curr < startDate)) {
      challengePeriod = false;
    }
    result = success(createSuccessBody({ challengePeriod: challengePeriod }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getLeaderboard() {
  const challengePeriodSQL = `SELECT start_date, expire_date
  FROM challenge_event
  ORDER BY start_date DESC
  LIMIT 1;` ;

  try {
    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const start_date = moment(challengePeriodResult[0].start_date).format('YYYYMMDD');
    const expire_date = moment(challengePeriodResult[0].expire_date).format('YYYYMMDD');
    const teamRankSQL = `
                                select Sum(mlog.score) totalScoreOfTeam, cgrp.group_id, cgrp.group_name, cgrp.fb_group
                                from member m JOIN
                                        (
                                          select *
                                          from member_event_log
                                          where created_at BETWEEN '${start_date}' AND '${expire_date}'
                                        ) as mlog
                                    ON m.user_id = mlog.user_id JOIN challenge_group cgrp
                                    ON m.group_id = cgrp.group_id
                                GROUP BY cgrp.group_id
                                ORDER BY SUM(mlog.score) DESC;`;
    const individualRankSQL = `
                              SET @row_number = 0;
                              select (@row_number:=@row_number + 1) AS rank, m.user_id, m.email, m.first_name, m.last_name, m.facebook, m.display_name, m.start_date, m.expire_date, calcScore.total_score
                              from (
                                select user_id, sum(score) as total_score
                                from member_event_log
                                where created_at BETWEEN '${start_date}' AND '${expire_date}'
                                group by user_id
                                  ) as calcScore JOIN member m
                                  ON m.user_id = calcScore.user_id
                              order by total_score desc;`;
    const teamRankResult = await queryRaw(teamRankSQL);
    const individualRankResult = await queryRaw(individualRankSQL);
    const teamRank = teamRankResult;
    const individualRank = individualRankResult[1];
    result = success(createSuccessBody({ teamRank: teamRank, individualRank: individualRank }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getScoreOfTeam(event) {
  const { group_id } = event.queryStringParameters;

  const challengePeriodSQL = `SELECT start_date, expire_date
  FROM challenge_event
  ORDER BY start_date DESC
  LIMIT 1;` ;

  try {
    let result;
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const start_date = moment(challengePeriodResult[0].start_date).format('YYYYMMDD');
    const expire_date = moment(challengePeriodResult[0].expire_date).format('YYYYMMDD');
    const totalScoreOfTeamSQL = `
                                select sum(mlog.score) totalScoreOfTeam, cgrp.group_id, cgrp.group_name
                                from member m JOIN
                                        (
                                          select *
                                          from member_event_log
                                          where created_at BETWEEN '${start_date}' AND '${expire_date}'
                                        ) as mlog
                                      ON m.user_id = mlog.user_id JOIN challenge_group cgrp
                                      ON m.group_id = cgrp.group_id
                                GROUP BY cgrp.group_id
                                having cgrp.group_id = '${group_id}';`;
    const totalScoreOfTeamResult = await queryRaw(totalScoreOfTeamSQL);
    const totalScoreOfTeam = totalScoreOfTeamResult[0].totalScoreOfTeam;
    result = success(createSuccessBody({ totalScoreOfTeam: totalScoreOfTeam }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getGroupName(event) {
  const { group_id } = event.queryStringParameters;

  const getGroupNameSQL = ` SELECT group_name FROM challenge_group
                            WHERE group_id = '${group_id}'`;

  try {
    let result;
    const getGroupNameResult = await queryRaw(getGroupNameSQL);
    const group_name = getGroupNameResult[0].group_name;
    result = success(createSuccessBody({ group_name: group_name }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getMembersAndRank(event) {
  const { group_id, start_date } = event.queryStringParameters;
  const numberOfMembersSQL = `
                              select count(*) as count
                                    from member
                                    where group_id = '${group_id}'
                            `;

  const challengePeriodSQL = `SELECT start_date, expire_date
                              FROM challenge_event
                              ORDER BY start_date DESC
                              LIMIT 1;` ;

  try {
    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const start_date_challenge = moment(challengePeriodResult[0].start_date).format('YYYYMMDD');
    const expire_date_challenge = moment(challengePeriodResult[0].expire_date).format('YYYYMMDD'); //วันหมดอายุ ของ Season ล่าสุด
    const numberOfMembersResult = await queryRaw(numberOfMembersSQL);
    const numberOfMembers = numberOfMembersResult[0].count; //จำนวนสมาชิกของทีม

    var curr = new Date().getTime();
    var expireDate = new Date(challengePeriodResult[0].expire_date).getTime();
    var week;
    if (curr > expireDate) { //curr > expireDate คือเกินระยะเวลาของ Season ล่าสุดแล้ว
      week = calculateWeekInProgram(start_date, challengePeriodResult[0].expire_date); //ถ้าเกินระยะเวลา Season ล่าสุดแล้ว ให้โชว์ Week สุดท้ายของ Season นั้น
    } else {
      week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน
    }

    const getMembersAndRankSQL = `
                                    select m.user_id, m.email, m.first_name, m.last_name, m.facebook, m.display_name, calcScore.total_score, challenge_activity.start_rank, challenge_activity.end_rank
                                    from (
                                          select user_id, sum(score) as total_score
                                          from member_event_log
                                          where created_at BETWEEN '${start_date_challenge}' AND '${expire_date_challenge}'
                                          group by user_id
                                          ) as calcScore JOIN member m 
                                    ON m.user_id = calcScore.user_id
                                    JOIN challenge_activity ON m.user_id = challenge_activity.user_id      
                                    WHERE m.group_id='${group_id}' AND challenge_activity.week_in_program='${week}'
                                    ORDER BY calcScore.total_score DESC, challenge_activity.created_at DESC
                                    LIMIT ${numberOfMembers};
                                  `;
    const getMembersAndRankResult = await queryRaw(getMembersAndRankSQL);
    const getMembersSQL = `
                            select m.user_id, m.email, m.first_name, m.last_name
                            from member m 
                            JOIN challenge_activity ON m.user_id = challenge_activity.user_id      
                            WHERE m.group_id='${group_id}';
                          `
    const getMembersResult = await queryRaw(getMembersSQL);
    let result;
    const members = getMembersAndRankResult;
    const membersCheck = getMembersResult;
    // members.length < numberOfMembers คือ มีสมาชิกบางคนที่ไม่มีข้อมูลใน member_event_log
    if (members.length < numberOfMembers) {
      let checkItem;
      membersCheck.map((item, index) => {
        checkItem = members.filter(item2 => item2.user_id === item.user_id);
        // เช็คว่า item ตัวนั้นไม่เป็นสมาชิกใน members
        if (checkItem.length === 0) {
          // ทำการกำหนด total_score และ start_rank ให้
          item["total_score"] = 0;
          item["start_rank"] = 'newbie';
          item["end_rank"] = '';
          // push เพิ่มเข้าไปเป็นสมาชิกใน members
          members.push(item);
        }
      })
    }
    result = success(createSuccessBody({ members: members }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getGroupID(event) {
  const { user_id } = event.queryStringParameters;
  const query = `select group_id from member where user_id='${user_id}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    const group_id = queryResult[0].group_id;
    result = success(createSuccessBody({ group_id: group_id }));
    return result;
  } catch (error) {
    return error;
  }
}

//ใช้เช็คว่า มีทีมที่ยังไม่เต็มไหม (ถ้ามี - ทำการสุ่มทีมให้) (ถ้าไม่มี - อนุญาติให้สร้างทีม) Ver.ไม่มี fb_group
/* export async function getNumberOfTeamNotFull() {
  const numberOfTeamNotFullSQL = `
    SELECT count(*) AS count FROM challenge_group 
    WHERE (SELECT count(*) AS count FROM member WHERE group_id = challenge_group.group_id)<10;`;
  try {
    let result;
    const numberOfTeamNotFullResult = await queryRaw(numberOfTeamNotFullSQL);
    const numberOfTeamNotFull = numberOfTeamNotFullResult[0].count; //จำนวนทีมที่สมาชิกไม่เต็ม
    result = success(createSuccessBody({ numberOfTeamNotFull: numberOfTeamNotFull }));
    return result;
  } catch (error) {
    return error;
  }
} */

//ใช้เช็คว่า มีทีมที่ยังไม่เต็มไหม (ถ้ามี - ทำการสุ่มทีมให้) (ถ้าไม่มี - อนุญาติให้สร้างทีม) Ver.มี fb_group
export async function getNumberOfTeamNotFull(event) {
  const {
    fb_group
  } = event.queryStringParameters;

  const numberOfTeamNotFullSQL = `
    SELECT count(*) AS count FROM challenge_group 
    WHERE fb_group = '${fb_group}'
    AND
    (SELECT count(*) AS count FROM member WHERE group_id = challenge_group.group_id)<10;`;
  try {
    let result;
    const numberOfTeamNotFullResult = await queryRaw(numberOfTeamNotFullSQL);
    const numberOfTeamNotFull = numberOfTeamNotFullResult[0].count; //จำนวนทีมที่สมาชิกไม่เต็ม
    result = success(createSuccessBody({ numberOfTeamNotFull: numberOfTeamNotFull }));
    return result;
  } catch (error) {
    return error;
  }
}

//ใช้เช็ค จำนวนการชั่งน้ำหนักในวันนั้น และจำนวนการชั่งน้ำหนักในสัปดาห์นั้น
//ถ้าวันนั้นยังไม่ชั่ง และในสัปดาห์ชั่งยังไม่ครบ 2ครั้ง จะมีการเกิด dailyWeighChallenge ทาง Frontend
export async function getDailyWeighChallenge(event) {
  const {
    user_id
  } = event.queryStringParameters;

  const dailyIndividualWeightCountSQL = ` select count(*) as count
                                          from member_event_log
                                          where user_id = '${user_id}'
                                            AND log = 'weight'
                                            ANd log_type = 'individual'
                                            AND DATE(created_at) = CURDATE();`;

  const weeklyIndividualWeightCountSQL = ` select count(*) as count
                                          from member_event_log
                                          where user_id = '${user_id}'
                                            AND log = 'weight'
                                            ANd log_type = 'individual'
                                            AND created_at BETWEEN 
                                            DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) 
                                                AND 
                                            DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute);`; // getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const challengePeriodSQL = `SELECT start_date, expire_date
                              FROM challenge_event
                              ORDER BY start_date DESC
                              LIMIT 1;` ;

  const userPeriodSQL = ` SELECT start_date, expire_date FROM member 
                          WHERE user_id = '${user_id}';`;

  try {
    let result;
    const dailyIndividualWeightCountResult = await queryRaw(dailyIndividualWeightCountSQL);
    const weeklyIndividualWeightCountResult = await queryRaw(weeklyIndividualWeightCountSQL);
    const dailyIndividualWeightCount = dailyIndividualWeightCountResult[0].count;
    const weeklyIndividualWeightCount = weeklyIndividualWeightCountResult[0].count;

    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    const userPeriodResult = await queryRaw(userPeriodSQL);
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();
    var expireDate_challenge = new Date(challengePeriodResult[0].expire_date).getTime(); //วันหมดอายุ ของ Season ล่าสุด
    var startDate_challenge = new Date(challengePeriodResult[0].start_date).getTime(); //วันเริ่มต้น ของ Season ล่าสุด
    var expireDate_user = new Date(userPeriodResult[0].expire_date).getTime();

    let dailyWeighChallenge = true;
    if ((dailyIndividualWeightCount > 0) || (curr > expireDate_challenge) || (curr < startDate_challenge) || (curr > expireDate_user)) {
      dailyWeighChallenge = false;
    }
    result = success(createSuccessBody({ dailyWeighChallenge: dailyWeighChallenge }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getDailyTeamWeightBonus(event) {
  const {
    user_id
  } = event.queryStringParameters;

  const logWeightBonusTeamCount_MondaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                    DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) 
                                                    AND
                                                    DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute);`; // getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const logWeightBonusTeamCount_TuesdaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                    DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 1 DAY)
                                                    AND
                                                    DATE_ADD(DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute), INTERVAL 1 DAY);`;// getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const logWeightBonusTeamCount_WednesdaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                    DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) , INTERVAL 2 DAY)
                                                    AND
                                                    DATE_ADD(DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute), INTERVAL 2 DAY);`;// getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const logWeightBonusTeamCount_ThursdaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                    DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) , INTERVAL 3 DAY)
                                                    AND
                                                    DATE_ADD(DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute), INTERVAL 3 DAY);`;// getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const logWeightBonusTeamCount_FridaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                    DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) , INTERVAL 4 DAY)
                                                    AND
                                                    DATE_ADD(DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute), INTERVAL 4 DAY);`;// getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const logWeightBonusTeamCount_SaturdaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                    DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) , INTERVAL 5 DAY)
                                                    AND
                                                    DATE_ADD(DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute), INTERVAL 5 DAY);`;// getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  const logWeightBonusTeamCount_SundaySQL = ` select count(*) as count
                                              from member_event_log
                                              where user_id IN (
                                                    select user_id from member
                                                    where group_id = (select group_id from member where user_id='${user_id}')
                                                  )
                                                  AND log = 'weight bonus'
                                                  AND log_type = 'team'
                                                  AND DATE(created_at) BETWEEN
                                                  DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) , INTERVAL 6 DAY)
                                                  AND
                                                  DATE_ADD(DATE_ADD(DATE_ADD((CURDATE()), INTERVAL (6-WEEKDAY((CURDATE()))) DAY), INTERVAL 1439 minute), INTERVAL 6 DAY);`;// getMondayOfTheWeek(CURDATE()), getSundayOfTheWeek(CURDATE())

  try {
    let result;
    const logWeightBonusTeamCount_MondayResult = await queryRaw(logWeightBonusTeamCount_MondaySQL);
    const logWeightBonusTeamCount_TuesdayResult = await queryRaw(logWeightBonusTeamCount_TuesdaySQL);
    const logWeightBonusTeamCount_WednesdayResult = await queryRaw(logWeightBonusTeamCount_WednesdaySQL);
    const logWeightBonusTeamCount_ThursdayResult = await queryRaw(logWeightBonusTeamCount_ThursdaySQL);
    const logWeightBonusTeamCount_FridayResult = await queryRaw(logWeightBonusTeamCount_FridaySQL);
    const logWeightBonusTeamCount_SaturdayResult = await queryRaw(logWeightBonusTeamCount_SaturdaySQL);
    const logWeightBonusTeamCount_SundayResult = await queryRaw(logWeightBonusTeamCount_SundaySQL);
    const logWeightBonusTeamCount_Monday = logWeightBonusTeamCount_MondayResult[0].count;
    const logWeightBonusTeamCount_Tuesday = logWeightBonusTeamCount_TuesdayResult[0].count;
    const logWeightBonusTeamCount_Wednesday = logWeightBonusTeamCount_WednesdayResult[0].count;
    const logWeightBonusTeamCount_Thursday = logWeightBonusTeamCount_ThursdayResult[0].count;
    const logWeightBonusTeamCount_Friday = logWeightBonusTeamCount_FridayResult[0].count;
    const logWeightBonusTeamCount_Saturday = logWeightBonusTeamCount_SaturdayResult[0].count;
    const logWeightBonusTeamCount_Sunday = logWeightBonusTeamCount_SundayResult[0].count;
    var dailyTeamWeightBonusCount = 0;
    if (logWeightBonusTeamCount_Monday > 0) { dailyTeamWeightBonusCount += 1 };
    if (logWeightBonusTeamCount_Tuesday > 0) { dailyTeamWeightBonusCount += 1 };
    if (logWeightBonusTeamCount_Wednesday > 0) { dailyTeamWeightBonusCount += 1 };
    if (logWeightBonusTeamCount_Thursday > 0) { dailyTeamWeightBonusCount += 1 };
    if (logWeightBonusTeamCount_Friday > 0) { dailyTeamWeightBonusCount += 1 };
    if (logWeightBonusTeamCount_Saturday > 0) { dailyTeamWeightBonusCount += 1 };
    if (logWeightBonusTeamCount_Sunday > 0) { dailyTeamWeightBonusCount += 1 };
    result = success(createSuccessBody({ dailyTeamWeightBonusCount: dailyTeamWeightBonusCount }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getLogWeightTeam(event) {
  const {
    group_id
  } = event.queryStringParameters;

  const weeklyIndividualWeightCountSQL = `
                                          select count(*) as count
                                          from member_event_log
                                          where user_id IN (
                                                select user_id from member
                                                where group_id = '${group_id}'
                                              )
                                            AND log = 'weight'
                                            ANd log_type = 'individual'
                                            AND created_at BETWEEN 
                                                getMondayOfTheWeek(CURDATE())
                                                AND 
                                                getSundayOfTheWeek(CURDATE());
                                          `;

  const numberOfMembersSQL = `
                              select count(*) as count
                                    from member
                                    where group_id = '${group_id}'
                            `;

  try {
    const weeklyIndividualWeightCountResult = await queryRaw(weeklyIndividualWeightCountSQL);
    const numberOfMembersResult = await queryRaw(numberOfMembersSQL);
    let result;
    const logWeightTeamCount = weeklyIndividualWeightCountResult[0].count; //จำนวนweightของทีม
    const numberOfMembers = numberOfMembersResult[0].count; //จำนวนสมาชิกของทีม
    result = success(createSuccessBody({ logWeightTeamCount: logWeightTeamCount, numberOfMembers: numberOfMembers }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getIsReducedWeight(event) {
  const {
    user_id
  } = event.queryStringParameters;

  const weightInWeekSQL = ` SELECT log_value FROM member_event_log
                            WHERE user_id = '${user_id}'
                              AND log = 'weight'
                              ANd log_type = 'individual'
                              AND created_at BETWEEN 
                                  getMondayOfTheWeek(CURDATE())
                                  AND 
                                  getSundayOfTheWeek(CURDATE());
                          `;

  const weightInLastweekSQL = ` SELECT log_value FROM member_event_log
                                WHERE user_id = '${user_id}'
                                  AND log = 'weight'
                                  ANd log_type = 'individual'
                                  AND created_at BETWEEN 
                                      date_sub(getMondayOfTheWeek(CURDATE()), INTERVAL 7 DAY)
                                      AND 
                                      date_sub(getSundayOfTheWeek(CURDATE()), INTERVAL 7 DAY);
                              `;
  try {
    let result;
    let isReducedWeight = false;
    const weightInWeekResult = await queryRaw(weightInWeekSQL);
    const weightInLastweekResult = await queryRaw(weightInLastweekSQL);
    if (weightInWeekResult.length !== 0 && weightInLastweekResult.length !== 0) {
      var weightInWeek = weightInWeekResult;
      var weightInLastweek = weightInLastweekResult;
      var sumWeightInWeek = 0;
      var sumWeightInLastweek = 0;
      for (var k = 0; k < weightInWeek.length; k++) {
        sumWeightInWeek += Number(weightInWeek[k].log_value);
      }
      for (var l = 0; l < weightInLastweek.length; l++) {
        sumWeightInLastweek += Number(weightInLastweek[l].log_value);
      }
      var avgWeightInWeek = sumWeightInWeek / weightInWeek.length;
      var avgWeightInLastweek = sumWeightInLastweek / weightInLastweek.length;
      if (avgWeightInWeek < avgWeightInLastweek) { //คนที่avgWeight ต่ำกว่า weekที่แล้ว จะได้รับ 10คะแนน
        isReducedWeight = true;
      }
    }
    result = success(createSuccessBody({ isReducedWeight: isReducedWeight }));
    return result;
  } catch (error) {
    return error;
  }
}

//เช็ค log รอบเอวลดลง
export async function getIsReducedWaist(event) {
  const {
    user_id
  } = event.queryStringParameters;

  const waistInWeekSQL = ` SELECT log_value FROM member_event_log
                            WHERE user_id = '${user_id}'
                              AND log = 'reduced waist'
                              ANd log_type = 'individual'
                              AND created_at BETWEEN 
                                  getMondayOfTheWeek(CURDATE())
                                  AND 
                                  getSundayOfTheWeek(CURDATE());
                          `;

  try {
    let result;

    const waistInWeekResult = await queryRaw(waistInWeekSQL);
    const numbLog = waistInWeekResult.length;

    result = success(createSuccessBody({ waistInWeekResult: numbLog }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getLogWeight(event) {
  const {
    user_id
  } = event.queryStringParameters;
  const queryString = ` select count(*) as count
                        from member_event_log
                        where user_id = '${user_id}'
                          AND log = 'weight'
                            ANd log_type = 'individual'
                            AND created_at BETWEEN 
                              getMondayOfTheWeek(CURDATE())
                              AND 
                              getSundayOfTheWeek(CURDATE());`;
  try {
    const queryResult = await queryRaw(queryString);
    let result;
    const logWeightCount = queryResult[0].count;
    result = success(createSuccessBody({ logWeightCount: logWeightCount }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getRank(event) {
  const {
    user_id,
    start_date
  } = event.queryStringParameters;
  const week = calculateWeekInProgram(start_date);
  const queryString = ` SELECT start_rank, created_at  FROM challenge_activity
                        WHERE user_id = '${user_id}' AND week_in_program = '${week}'
                        ORDER BY created_at DESC LIMIT 1;`;

  const challengePeriodSQL = `SELECT start_date, expire_date
                              FROM challenge_event
                              ORDER BY start_date DESC
                              LIMIT 1;` ;
  const challengeActivityInWeekCountSQL = ` SELECT count(*) AS count FROM challenge_activity
                                            WHERE user_id = '${user_id}' AND week_in_program = '${week}';`;
  const createChallengeActivitySQL = `  INSERT INTO challenge_activity
                                        SET user_id = '${user_id}', week_in_program = '${week}', 
                                            start_rank = 'newbie' ; `;
  try {
    let result;

    const challengePeriodResult = await queryRaw(challengePeriodSQL);
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();
    var expireDate_challenge = new Date(challengePeriodResult[0].expire_date).getTime(); //วันหมดอายุ ของ Season ล่าสุด
    var startDate_challenge = new Date(challengePeriodResult[0].start_date).getTime(); //วันเริ่มต้น ของ Season ล่าสุด
    const challengeActivityInWeekCountResult = await queryRaw(challengeActivityInWeekCountSQL);
    const challengeActivityInWeekCount = challengeActivityInWeekCountResult[0].count; //จำนวน challengeActivity ของ week นั้น
    if ((curr >= startDate_challenge) && (curr < expireDate_challenge) && (challengeActivityInWeekCount === 0)) { //เช็คว่าอยู่ในระยะเวลาชาเลนจ์ และ weekนั้นไม่มีchallengeActivity 
      //ทำการกำหนด Rank เป็น Newbie
      await queryRaw(createChallengeActivitySQL);
    }

    const queryResult = await queryRaw(queryString);
    const start_rank = queryResult[0].start_rank;
    result = success(createSuccessBody({ start_rank: start_rank }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getTreepayHash(event) {
  const {
    pay_type,
    order_no,
    trade_mony,
    user_id
  } = event.queryStringParameters;
  const site_cd = process.env.MID;
  const secure_key = process.env.TREEPAY_SECURE_KEY;
  const hash_string = `${pay_type}${order_no}${trade_mony}${site_cd}${secure_key}${user_id}`;
  const hash_data = sha256(hash_string);
  const returnData = {
    site_cd,
    hash_data
  }
  return success(createSuccessBody(returnData));
}

export async function getExpireDate(event) {
  const { email } = event.queryStringParameters;
  const query = `select expire_date from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    const expire_date = queryResult[0].expire_date;
    result = success(createSuccessBody({ expire_date: expire_date }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getInvoices(event) {
  try {
    const { user_id } = event.queryStringParameters;
    const queryString = `
        SELECT i.invoice_id, i.transaction_date, i.total, i.vat_rate, 
            d.detail_order, d.item_name, d.quantity, d.price
        FROM invoice_detail d JOIN invoice i 
            ON d.invoice_id = i.invoice_id 
        WHERE i.user_id = '${user_id}'
        ORDER BY i.invoice_id DESC;
        `;
    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const invoices = [];
    const map = new Map();
    for (const result of results) {
      if (!map.has(result.invoice_id)) {
        map.set(result.invoice_id, true);
        const master = {
          invoice_id: result.invoice_id,
          transaction_date: result.transaction_date,
          total: result.total,
          vat_rate: result.vat_rate
        };
        const details = results.reduce((acc, curr) => {
          if (curr.invoice_id === result.invoice_id) {
            acc.push({
              detail_order: curr.detail_order,
              item_name: curr.item_name,
              quantity: curr.quantity,
              price: curr.price
            });
          }
          return acc;
        }, []);
        invoices.push({ master, details });
      }
    }
    return success(createSuccessBody(invoices));
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function getAllSubscriptions(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const queryString = `
        SELECT CONCAT(sub.user_id, '||', sub.program_id) as sub_id, sub.user_id, sub.program_id,
          sub.payment_type, sub.amount, sub.payment_date, sub.payment_status, pg.batch_no,
          m.email, CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
          m.phone, m.fb_link as facebookLink, m.address
        FROM subscription sub JOIN program pg 
          ON sub.program_id = pg.program_id JOIN member m
          ON sub.user_id = m.user_id
        WHERE pg.product_id = '${product_id}';
        `;

    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const approves = [];
    const pendings = [];
    const rejects = [];
    for (const result of results) {
      const {
        address_line1 = "",
        address_line2 = "",
        tambol = "",
        city = "",
        state = "",
        zip = ""
      } = JSON.parse(result.address) || {};
      const address = [
        `${address_line1}`,
        `${address_line2}`,
        `${tambol} ${city}`,
        `${state} ${zip}`
      ];

      const subData = {
        ...result,
        facebookLink: unescape(result.facebookLink),
        address
      };

      if (result.payment_status === "pending") {
        pendings.push(subData);
      } else if (result.payment_status === "rejected") {
        rejects.push(subData);
      } else {
        approves.push(subData);
      }
    }
    const subscriptions = { pendings, approves, rejects };
    return success(createSuccessBody(subscriptions));
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function getAllUnsubscriptions(event) {
  try {
    const queryString = `
      SELECT user_id, email, CONCAT(COALESCE(first_name, ''), ' ', COALESCE(last_name,'')) as name , phone,
              fb_link as facebookLink, address, created_at as register_date
      FROM member 
      WHERE NOT EXISTS (	SELECT * FROM subscription 
              WHERE subscription.user_id = member.user_id);
    `;
    const results = await queryRaw(queryString); if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const subscriptions = [];
    for (const result of results) {
      const {
        address_line1 = "",
        address_line2 = "",
        tambol = "",
        city = "",
        state = "",
        zip = ""
      } = JSON.parse(result.address) || {};
      const address = [
        `${address_line1}`,
        `${address_line2}`,
        `${tambol} ${city}`,
        `${state} ${zip}`
      ];

      const subData = {
        ...result,
        facebookLink: unescape(result.facebookLink),
        address
      };

      subscriptions.push(subData);
    }
    return success(createSuccessBody(subscriptions));
  } catch (error) {
    return error;
  }
}

export async function getAllProgram(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const queryString = `
        SELECT *
        FROM program
        WHERE product_id = '${product_id}';
        `;

    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const batches = [];
    const subscriptions = [];
    for (const result of results) {
      if (result.period) {
        subscriptions.push(result);
      } else {
        batches.push(result);
      }
    }
    const result = { batches, subscriptions };
    return success(createSuccessBody(result));
  } catch (error) {
    console.log(error);
    return error;
  }
}

function getResultCode(body) {
  if (!body) return '01';

  const bodyParsed = body.split('&');
  const resultArray = bodyParsed.filter(elem => elem.toLowerCase().includes('resultcode'));

  if (resultArray.length > 0) {
    const resultCode = resultArray[0].split('=')[1];
    return resultCode;
  } else {
    return '01';
  }
}

export async function thankyouRoute(event, context, callback) {
  console.log("inside thankyouRoute:", event);
  const resultCode = getResultCode(event.body);
  if (resultCode !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));


  const response = {
    statusCode: 200,
    headers: {
      "content-type": "text/html; charset=UTF-8"
    },
    body: `
    <!DOCTYPE html>
    <html lang="en">
        
        <head>
          <title>Bebe Stay Fit</title>
        </head>
        
        <body>
          <div>
          </div>
          <script>
            window.location = "https://fit.bebefitroutine.com/#/welcome_new_nember"
          </script>
        </body>
    </html>
    `
  };
  callback(null, response);
}


export async function getFriendRequestSent(event) { //ดึงข้อมูลคำขอเป็นเพื่อนที่ฉันเป็นผู้ส่ง และ status = 'default'
  const { user_id } = event.queryStringParameters;

  const selectFriendRequstSQL = `
                                select * from friend_request
                                join member on friend_request.sender_id = member.user_id
                                where sender_id = '${user_id}' and status = 'default'
                                `

  try {
    let result;
    const selectFriendRequstResult = await queryRaw(selectFriendRequstSQL);
    if (selectFriendRequstResult.length > 0) { // เช็คว่ามีคำขอเป็นเพื่อนไหม
      result = success(createSuccessBody({ message: 'success', friend_request: selectFriendRequstResult }))
    } else {
      result = success(createSuccessBody({ message: 'no_friend_request' }))
    }
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}

export async function getTeamInviteSent(event) { //ดึงข้อมูลคำชวนเข้าทีมที่ฉันเป็นผู้ส่ง และ status = 'default'
  const { user_id } = event.queryStringParameters;

  const selectTeamInviteSQL = `
                                  select * from team_invite
                                  join member on team_invite.sender_id = member.user_id
                                  where sender_id = '${user_id}' and status = 'default'
                                `

  try {
    let result;
    const selectTeamInviteResult = await queryRaw(selectTeamInviteSQL);
    if (selectTeamInviteResult.length > 0) { // เช็คว่ามีคำชวนเข้าทีมไหม
      result = success(createSuccessBody({ message: 'success', team_invite: selectTeamInviteResult }))
    } else {
      result = success(createSuccessBody({ message: 'no_team_invite' }))
    }
    console.log("result :", result);
    return result;
  } catch (error) {
    return error;
  }
}

export async function getAllMemberPlatfrom(event) {
  const { fb_group } = event.queryStringParameters;
  const query = `
  select mb.user_id, mb.email, mb.display_name, coalesce(ca.start_rank, 'newbie') as rank, mb.group_id from member mb
  left join challenge_activity ca on mb.user_id = ca.user_id and ca.week_in_program  = CalcWeekInProgram(mb.start_date)
  where fb_group = ${fb_group}
  order by mb.display_name desc;
  `;
  try {
    const queryResult = await queryRaw(query);
    let result;
    result = success(createSuccessBody({ allMemberStayFit: queryResult }));
    return result
  } catch (error) {
    return error;
  }
}

export async function getAllMembers(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const queryString = `
            SELECT m.user_id, m.email, CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
              m.phone, m.fb_link, p.product_id
            FROM member m JOIN subscription s 
              ON m.user_id = s.user_id JOIN program p 
              ON s.program_id = p.program_id
            WHERE p.product_id = '${product_id}';
        `;

    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    return success(createSuccessBody(results));
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function checkQuestionnaireLog(event) {
  const { user_id, log } = event.queryStringParameters;
  const selectSQL = `
    select * from questionnaire_log 
    where user_id = '${user_id}' and log = '${log}'
  `;
  try {
    let result;
    const queryResult = await queryRaw(selectSQL);
    if (queryResult.length > 0) {
      result = 'done';
    } else {
      result = 'not';
    }
    result = success(createSuccessBody({ message: result }));
    return result
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function checkNewsLog(event) {
  const { user_id, log } = event.queryStringParameters;
  const selectSQL = `
    select * from news_log 
    where user_id = '${user_id}' and log = '${log}'
  `;
  try {
    let result;
    const queryResult = await queryRaw(selectSQL);
    if (queryResult.length > 0) {
      result = 'done';
    } else {
      result = 'not';
    }
    result = success(createSuccessBody({ message: result }));
    return result
  } catch (error) {
    console.log(error);
    return error;
  }
}