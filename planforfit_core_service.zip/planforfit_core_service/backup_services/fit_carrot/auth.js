import bcrypt from 'bcrypt';
import md5 from 'md5';
import { query, queryRaw } from "./local_lib/dbhelper";
import { uuidv4 } from "./local_lib/Utils";
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
import { sendBebeHtmlMail } from "./local_lib/mail-helper";
import { getUrlVars } from "./local_lib/Utils";
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");
import axios from 'axios';


export async function login(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      const user = queryResult[0];
      /* const hash = md5(password);
      const isMatch = (hash === user.password);
      result = isMatch
        ? success(createSuccessBody({ message: 'success', user: user }))
        : success(createSuccessBody({ message: 'fail' })); */
      result = success(createSuccessBody({ message: 'success', user: user }))
    }
    console.log("email :", email);
    console.log("result :", result);
    return result
  } catch (error) {
    return error;
  }
}

export async function loginStayfit(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      const user = queryResult[0];
      const hash = md5(password);
      console.log("hash :", hash);
      console.log("user.password :", user.password);

      const isMatch = (hash === user.password) ? true : false;
      console.log("isMatch:", isMatch);
      const completedRegister = (user.expire_date) ? true : false; //ถ้าสมัครไม่จบขั้นตอนจ่ายเงิน expire_date จะเป็น null
      const isStayFitMember = (user.program_id) ? true : false; //ถ้าเป็นสมาชิกของ Stay Fit จะต้องมีระบุ program_id
      result = (isMatch && completedRegister && isStayFitMember) ?
        success(createSuccessBody({ message: 'success', user: user }))
        :
        success(createSuccessBody({ message: 'fail' }));
    }
    console.log("email :", email);
    console.log("result :", result);
    return result
  } catch (error) {
    return error;
  }
}

export async function loginTest(event) {
  const { email } = event.queryStringParameters;
  const query = `select email from member where email='${email}'`;
  const query2 = `select password from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    const queryResult2 = await queryRaw(query2);
    console.log("queryResult loginTest: ", queryResult)
    console.log("queryResult loginTest2: ", queryResult2)
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else if (queryResult2[0].password !== null) {
      result = success(createSuccessBody({ message: 'have_user_have_password' }));
    } else if (queryResult2[0].password == null) {
      result = success(createSuccessBody({ message: 'have_user_no_password' }));
    }
    return result
  } catch (error) {
    return error;
  }
}

export async function checkUser(event) {
  const { email } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'new' }));
    } else {
      result = success(createSuccessBody({ message: 'exist' }));
    }
    return result
  } catch (error) {
    return error;
  }
}

export async function setQRStatus(event) {
  const {
    customerEmail: email,
    status
  } = JSON.parse(event.body);

  console.log("inside setQRStatus:", event.body);
  const queryString = `
    INSERT INTO qr_status VALUES ('${email}','${status}') 
    ON DUPLICATE KEY UPDATE \`status\`='${status}';
  `

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkQRStatus(event) {
  const { email } = event.queryStringParameters;

  const queryString = `
    SELECT status 
    FROM qr_status
    WHERE email = '${email}';
  `

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function testPostService(event) {
  const customerEmail = "akkewach.yodsomboon@gmail.com"
  const customerTelephone = "0840045946"
  const customerName = "Akkewach Yodsomboon"
  const queryString = `
  INSERT INTO member SET 
  user_id='${uuidv4()}',
  email='${customerEmail}', phone='${customerTelephone}'
`;

  try {
    await queryRaw(queryString);
    console.log("after queryRaw!");
    const to = customerEmail;
    const from = 'contact@planforfit.com';
    const subject = `การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว! ${customerEmail} ${customerTelephone}`;
    await sendBebeHtmlMail(to, from, subject, customerName, "bebe_stay_fit_register");
    console.log("after sendBebeHtmlMail!");
  } catch (error) {
    return error;
  }
}

function convertRawBodyToData(body) {
  const splitLine = body.split('\r\n')[0];
  let dataSet = body.split(splitLine);
  dataSet = dataSet.filter(x => x != '' && x != '\r\n' && x != '--\r\n')
  dataSet = dataSet.map(x => x.split('\r\n'))
  dataSet = dataSet.map(x => x.filter(x => x != ''))
  dataSet = dataSet.map(x => [x[0].split('name=')[1].replace('"', '').replace('"', ''), x[x.length - 1]]);
  const data = {};
  for (let i = 0; i < dataSet.length; i++) {
    const key = dataSet[i][0]
    const value = dataSet[i][1]
    data[key] = value
  }
  return data
}

export async function recurringResponse(event) {
  const {
    amount,
    recurringNo,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    paymentType,
    cardType,
    issuerBank,
    date,
    amountPerMonth,
    cardNo,
    customerName,
    customerEmail,
    customerTelephone,
    merchantDefined1: program_id,
    merchantDefined2: products_list,
    merchantDefined3: delivery_address,
    merchantDefined4: receipt_address,
  } = convertRawBodyToData(event.body);
  console.log("inside recurringResponse:",
    amount,
    recurringNo,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    paymentType,
    cardType,
    issuerBank,
    date,
    amountPerMonth,
    cardNo,
    customerName,
    customerEmail,
    customerTelephone,
    program_id,
    products_list,
    delivery_address,
    receipt_address
  )
  console.log("before if");
  if (resultCode.toString() !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));
  console.log("after if");

  const queryPeriodProgram = ` SELECT period FROM program
  WHERE program_id = '${program_id}';`;

  const queryUserId = ` SELECT user_id FROM member
  WHERE member.email = '${customerEmail}';`;

  try {
    //const contentType = event.headers['content-type'] || event.headers['Content-Type'];
    console.log("raw event data:", event);
    //const data = await parseMultipartFormData(event.body, contentType);
    //console.log("converted data:", data);

    const resultUserId = await queryRaw(queryUserId);
    var user_id = resultUserId[0].user_id;
    const resultPeriodProgram = await queryRaw(queryPeriodProgram);
    console.log("afer run  queryRaw!");
    var period = resultPeriodProgram[0].period;
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    const startDate = `${moment(currTimeZone).format('YYYY-MM-DD')} 00:00:00`
    var expireDate;
    expireDate = new Date(currTimeZone);
    expireDate.setDate(expireDate.getDate() + period);
    expireDate = `${moment(expireDate).format('YYYY-MM-DD')} 23:59:59`

    const queryString = `
            UPDATE member INNER JOIN program
              ON program.program_id = '${program_id}'
            SET member.start_date = '${startDate}', member.expire_date = '${expireDate}',
                member.program_id = '${program_id}'
            WHERE member.email = '${customerEmail}';
    `;
    await queryRaw(queryString);


    const queryString2 = `
    INSERT INTO register_log SET
    user_id = '${user_id}', program_id = '${program_id}', amount = '${amount}', referenceNo = '${referenceNo}', gbpReferenceNo = '${gbpReferenceNo}',
    start_date= '${startDate}', expire_date = '${expireDate}', round = 1
    ;
  `;
    await query(queryString2);

    const queryString3 = `
                  UPDATE subscription_products
                  SET status_payment = 'success'
                  WHERE user_id = '${user_id}';
  `;
    await query(queryString3);

    //----------------------------------สร้าง order ใน Zort--------------------------------------
    const apiPath = "https://api.zortout.com/api.aspx?method=ADDORDER&version=3&format=json"
    const apiHeaders = {
      headers: {
        storename: "saas@planforfit.com",
        apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
        apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ="
      }
    }
    const queryProducts = ` SELECT * FROM subscription_products
    WHERE user_id = '${user_id}';`;
    const resultProducts = await queryRaw(queryProducts);
    const delivery_address = JSON.parse(resultProducts[0].delivery_address);
    const shippingaddress = `
    ${delivery_address.address} ${delivery_address.subdistrict} ${delivery_address.district} ${delivery_address.province} ${delivery_address.zipcode}
    `
    const orderdate = `${moment(currTimeZone).format('YYYY-MM-DD')}`;
    const products_list = JSON.parse(resultProducts[0].products_list);
    var products_list_array = [];
    products_list_array.push(products_list.product1, products_list.product2, products_list.product3, products_list.product4, products_list.product5, products_list.product6);
    var list = [];
    var NumberOfClassicMalt = 0;
    var NumberOfMilkTea = 0;
    var NumberOfDoubleChocoFudge = 0;
    var NumberOfStrawberryCrush = 0;
    var NumberOfHokaidoMilk = 0;
    products_list_array.map((element) => {
      if (element === "คลาสสิค มอลต์") { NumberOfClassicMalt += 1; }
      if (element === "มิลค์ ที") { NumberOfMilkTea += 1 }
      if (element === "ดับเบิ้ล ช็อคโก้ ฟัดจ์") { NumberOfDoubleChocoFudge += 1 }
      if (element === "สตรอว์เบอร์รี่ ครัช") { NumberOfStrawberryCrush += 1 }
      if ((element === "ฮอกไกโด มิลค์") || (element === "นมฮอกไกโด")) { NumberOfHokaidoMilk += 1 }
    })
    if (NumberOfClassicMalt > 0) {
      list.push({ "sku": "240220202006", "name": "Fitto Plant Protein Classic Malt", "number": NumberOfClassicMalt, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfMilkTea > 0) {
      list.push({ "sku": "240220302001", "name": "Fitto Plant Protein Milk Tea Flavour", "number": NumberOfMilkTea, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfDoubleChocoFudge > 0) {
      list.push({ "sku": "240220602002", "name": "Fitto Plant Protein Double Choco Fudge", "number": NumberOfDoubleChocoFudge, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfStrawberryCrush > 0) {
      list.push({ "sku": "240220602001", "name": "Fitto Plant Protein Strawberry Crush", "number": NumberOfStrawberryCrush, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfHokaidoMilk > 0) {
      list.push({ "sku": "240220602003", "name": "Fitto Plant Protein Hokaido Milk", "number": NumberOfHokaidoMilk, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (program_id === "subscription_stay_fit_01") {
      list.push({ "sku": "2441", "name": "Bebe Fit Routine Shaker แก้วเชคเกอร์สีชมพู", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
      list.push({ "sku": "240220202010_1", "name": "Fitto Pre-Workout Green Lemonade 1 ซอง", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
      list.push({ "sku": "240220202009_1", "name": "Fitto Arabica Latte (Instant coffee mix) 1 Sachets", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
      list.push({ "sku": "240220202011_1", "name": "Fitto Plus COLLA C Unflavored 1 Sachets", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
    }
    const apiBody = {
      "number": referenceNo,
      "customername": customerName,
      "customeremail": customerEmail,
      "customerphone": customerTelephone,
      "customeraddress": shippingaddress,
      "shippingchannel": "Flash express",
      "shippingname": customerName,
      "shippingemail": customerEmail,
      "shippingphone": customerTelephone,
      "shippingaddress": shippingaddress,
      "saleschannel": "bebe stay fit",
      "orderdate": orderdate,
      "amount": amount,
      "paymentamount": amount,
      "shippingamount": 0,
      "vatamount": 0,
      "paymentmethod": "Cash",
      "list": list
    }
    axios.post(apiPath, apiBody, apiHeaders);  // เรียกใช้ api ของ zort

    //----------------------------------ส่งอีเมล--------------------------------------
    const to = customerEmail;
    const from = 'contact@planforfit.com';
    const subject = `การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว!`;

    if (program_id === "subscription_stay_fit_01") {
      await sendBebeHtmlMail(to, from, subject, orderdate, "subscription_stay_fit_01");
    }
    if (program_id === "starter_stay_fit_01") {
      await sendBebeHtmlMail(to, from, subject, orderdate, "starter_stay_fit_01");
    }

    return success(createSuccessBody({ message: "end of recurring background service" }));
  } catch (error) {
    return error;
  }

}

export async function GBQRResponse(event) {
  const {
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    merchantDefined1: program_id,
    merchantDefined2: products_list,
    merchantDefined3: delivery_address,
    merchantDefined4: receipt_address,
  } = JSON.parse(event.body);
  console.log("inside gbqr:",
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    program_id,
    products_list,
    delivery_address,
    receipt_address
  );
  console.log("before if");
  if (resultCode.toString() !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));
  console.log("after if");

  const queryPeriodProgram = ` SELECT period FROM program
    WHERE program_id = '${program_id}';`;

  const queryUserId = ` SELECT user_id FROM member
  WHERE member.email = '${customerEmail}';`;

  try {
    const resultUserId = await queryRaw(queryUserId);
    var user_id = resultUserId[0].user_id;
    const resultPeriodProgram = await queryRaw(queryPeriodProgram);
    console.log("afer run  queryRaw!");
    var period = resultPeriodProgram[0].period;
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    const startDate = `${moment(currTimeZone).format('YYYY-MM-DD')} 00:00:00`
    var expireDate;
    expireDate = new Date(currTimeZone);
    expireDate.setDate(expireDate.getDate() + period);
    expireDate = `${moment(expireDate).format('YYYY-MM-DD')} 23:59:59`

    const queryString = `
              UPDATE member INNER JOIN program
                ON program.program_id = '${program_id}'
              SET member.start_date = '${startDate}', member.expire_date = '${expireDate}',
                  member.program_id = '${program_id}'
              WHERE member.email = '${customerEmail}';
      `;
    await queryRaw(queryString);


    const queryString2 = `
      INSERT INTO register_log SET
      user_id = '${user_id}', program_id = '${program_id}', amount = '${amount}', referenceNo = '${referenceNo}', gbpReferenceNo = '${gbpReferenceNo}',
      start_date= '${startDate}', expire_date = '${expireDate}', round = 1
      ;
    `;
    await query(queryString2);


    const queryString3 = `
            INSERT INTO qr_status VALUES ('${customerEmail}','success')
            ON DUPLICATE KEY UPDATE status ='success';
    `;
    await query(queryString3);

    const queryString4 = `
            UPDATE subscription_products
            SET status_payment = 'success'
            WHERE user_id = '${user_id}';
    `;
    await query(queryString4);

    //----------------------------------สร้าง order ใน Zort--------------------------------------
    const apiPath = "https://api.zortout.com/api.aspx?method=ADDORDER&version=3&format=json"
    const apiHeaders = {
      headers: {
        storename: "saas@planforfit.com",
        apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
        apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ="
      }
    }
    const queryProducts = ` SELECT * FROM subscription_products
    WHERE user_id = '${user_id}';`;
    const resultProducts = await queryRaw(queryProducts);
    const delivery_address = JSON.parse(resultProducts[0].delivery_address);
    const receipt_address = JSON.parse(resultProducts[0].receipt_address);
    const shippingaddress = `
    ${delivery_address.address} ${delivery_address.subdistrict} ${delivery_address.district} ${delivery_address.province} ${delivery_address.zipcode}
    `
    const orderdate = `${moment(currTimeZone).format('YYYY-MM-DD')}`;
    const products_list = JSON.parse(resultProducts[0].products_list);
    var products_list_array = [];
    products_list_array.push(products_list.product1, products_list.product2, products_list.product3, products_list.product4, products_list.product5, products_list.product6);
    var list = [];
    var NumberOfClassicMalt = 0;
    var NumberOfMilkTea = 0;
    var NumberOfDoubleChocoFudge = 0;
    var NumberOfStrawberryCrush = 0;
    var NumberOfHokaidoMilk = 0;
    products_list_array.map((element) => {
      if (element === "คลาสสิค มอลต์") { NumberOfClassicMalt += 1; }
      if (element === "มิลค์ ที") { NumberOfMilkTea += 1 }
      if (element === "ดับเบิ้ล ช็อคโก้ ฟัดจ์") { NumberOfDoubleChocoFudge += 1 }
      if (element === "สตรอว์เบอร์รี่ ครัช") { NumberOfStrawberryCrush += 1 }
      if ((element === "ฮอกไกโด มิลค์") || (element === "นมฮอกไกโด")) { NumberOfHokaidoMilk += 1 }
    })
    if (NumberOfClassicMalt > 0) {
      list.push({ "sku": "240220202006", "name": "Fitto Plant Protein Classic Malt", "number": NumberOfClassicMalt, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfMilkTea > 0) {
      list.push({ "sku": "240220302001", "name": "Fitto Plant Protein Milk Tea Flavour", "number": NumberOfMilkTea, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfDoubleChocoFudge > 0) {
      list.push({ "sku": "240220602002", "name": "Fitto Plant Protein Double Choco Fudge", "number": NumberOfDoubleChocoFudge, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfStrawberryCrush > 0) {
      list.push({ "sku": "240220602001", "name": "Fitto Plant Protein Strawberry Crush", "number": NumberOfStrawberryCrush, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (NumberOfHokaidoMilk > 0) {
      list.push({ "sku": "240220602003", "name": "Fitto Plant Protein Hokaido Milk", "number": NumberOfHokaidoMilk, "pricepernumber": 0, "discount": "0", "totalprice": 0 })
    }
    if (program_id === "subscription_stay_fit_01") {
      list.push({ "sku": "2441", "name": "Bebe Fit Routine Shaker แก้วเชคเกอร์สีชมพู", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
      list.push({ "sku": "240220202010_1", "name": "Fitto Pre-Workout Green Lemonade 1 ซอง", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
      list.push({ "sku": "240220202009_1", "name": "Fitto Arabica Latte (Instant coffee mix) 1 Sachets", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
      list.push({ "sku": "240220202011_1", "name": "Fitto Plus COLLA C Unflavored 1 Sachets", "number": 1, "pricepernumber": 0, "discount": "0", "totalprice": 0 });
    }
    const apiBody = {
      "number": referenceNo,
      "customername": customerName,
      "customeremail": customerEmail,
      "customerphone": customerTelephone,
      "customeraddress": shippingaddress,
      "shippingchannel": "Flash express",
      "shippingname": customerName,
      "shippingemail": customerEmail,
      "shippingphone": customerTelephone,
      "shippingaddress": shippingaddress,
      "saleschannel": "Bebe Stay Fit",
      "orderdate": orderdate,
      "amount": amount,
      "paymentamount": amount,
      "shippingamount": 0,
      "vatamount": 0,
      "paymentmethod": "Cash",
      "list": list,
      "customeridnumber": receipt_address ? receipt_address.InvoiceTaxIdentificationNumber : ""
    }
    axios.post(apiPath, apiBody, apiHeaders);  // เรียกใช้ api ของ zort

    //---------------------------------- ส่งอีเมลสมัครสมาชิกสำเร็จ ไปยังผู้ใช้ --------------------------------------
    const to = customerEmail;
    const from = 'contact@planforfit.com';
    const subject = `การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว!`;

    if (program_id === "subscription_stay_fit_01") {
      await sendBebeHtmlMail(to, from, subject, orderdate, "subscription_stay_fit_01");
    }
    if (program_id === "starter_stay_fit_01") {
      await sendBebeHtmlMail(to, from, subject, orderdate, "starter_stay_fit_01");
    }

    //---------------------------------- ส่งอีเมลขอใบกำกับภาษี ไปยังฝ่ายบัญชี --------------------------------------
    const toAccountant = 'akkewach@planforfit.com'; //ใส่อีเมลของฝ่ายบัญชี (เทส)
    //const toAccountant = 'accounting@planforfit.com'; //ใส่อีเมลของฝ่ายบัญชี (ใช้จริง)
    const subjectRequestTaxInvoice = `ขอใบกำกับภาษี จากคำสั่งซื้อแพ็คเกจ Bebe Stay Fit`;

    if (receipt_address) { // ถ้ามี receipt_address แสดงว่าขอใบกำกับภาษี
      const taxInvoiceAddress = `
      ${receipt_address.InvoiceAddressUser} ${receipt_address.InvoiceSubdistrict} ${receipt_address.InvoiceDistrict} ${receipt_address.InvoiceProvince} ${receipt_address.InvoiceZipcode}
      `
      const contentRequestTaxInvoice = {
        "email": customerEmail,
        "order_id": referenceNo,
        "InvoiceTaxpayerName": receipt_address.InvoiceTaxpayerName,
        "InvoiceTaxpayerBranchName": receipt_address.InvoiceTaxpayerBranchName,
        "InvoiceTaxIdentificationNumber": receipt_address.InvoiceTaxIdentificationNumber,
        "InvoiceTelephone": receipt_address.InvoiceTelephone,
        "taxInvoiceAddress": taxInvoiceAddress,
        "shippingaddress": shippingaddress
      }
      console.log("contentRequestTaxInvoice :", contentRequestTaxInvoice);
      await sendBebeHtmlMail(toAccountant, from, subjectRequestTaxInvoice, contentRequestTaxInvoice, "requestTaxInvoice");
    }
    //return result;
  } catch (error) {
    return error;
  }
}

export async function signup(event) {
  const {
    email,
    password,
    first_name,
    last_name,
    phone
  } = JSON.parse(event.body);

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(password, salt);
  const period = 60;
  const start_date = `${moment().format('YYYY/MM/DD')} 00:00:00`;
  const expire_date = `${moment().add(period, 'days').format('YYYY/MM/DD')} 23:59:59`;
  const offset = 0;

  const queryString = `
            INSERT INTO member SET 
                user_id='${uuidv4()}', password='${hash}', 
                email='${email}', first_name='${first_name}', 
                last_name='${last_name}', phone='${phone}', 
                start_date='${start_date}', expire_date='${expire_date}', 
                offset=${offset}
            ON DUPLICATE KEY UPDATE
                first_name='${first_name}', last_name='${last_name}', 
                phone='${phone}', start_date='${start_date}', 
                expire_date='${expire_date}', offset=${offset};
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function register(event) {
  const {
    email,
    password,
    first_name,
    last_name,
    phone
  } = JSON.parse(event.body);

  //const salt = bcrypt.genSaltSync(10);
  //const hash = bcrypt.hashSync(password, salt);
  const hash = md5(password);

  const queryString = `
            INSERT INTO member SET 
                user_id='${uuidv4()}', password='${hash}', email='${email}', first_name='${first_name}', 
                last_name='${last_name}', phone='${phone}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function registerBebeStayFit(event) {
  const {
    email,
    password,
    phone
  } = JSON.parse(event.body);

  //const salt = bcrypt.genSaltSync(10);
  //const hash = bcrypt.hashSync(password, salt);
  const hash = md5(password);

  const queryString = `
              INSERT INTO member SET 
                  user_id='${uuidv4()}', password='${hash}', email='${email}', phone='${phone}'
              ON DUPLICATE KEY UPDATE 
                password='${hash}', phone='${phone}';
          `;

  const queryString2 = `select * from member where email='${email}'`;

  try {
    const queryResult = await queryRaw(queryString2);

    let result;
    //เช็ค ถ้า email ไม่มีในระบบ หรือ ยังไม่มี expire_date ถึงจะ INSERT, UPDATE
    if (queryResult.length <= 0) { // email ยังไม่มีในระบบ 
      await query(queryString);
      result = success(createSuccessBody({ message: 'success' }));
    } else {
      const user = queryResult[0];
      if (!user.expire_date) { //ถ้า  expire_date เป็น null แสดงว่าเคยสมัครแต่ยังจ่ายเงินไม่เสร็จ (ให้สมัครต่อได้)
        await query(queryString);
        result = success(createSuccessBody({ message: 'success' }));
      } else { // ถ้ามี expire_date อยู่แล้วไม่อนุญาติให้สมัคร
        if (user.program_id) {
          //มี email ใน Bebe Stay Fit อยู่แล้ว
          result = success(createSuccessBody({ message: 'existInStayFit' }));
        } else {
          //มี email อยู่ใน Platform Bebefitroutine เก่า (ต้องไปลบออกก่อนถึงจะสมัครได้)
          result = success(createSuccessBody({ message: 'existBebefitroutine' }));
        }
      }
    }
    return result;
  } catch (error) {
    return error;
  }
}


export async function trialRegister(event) {
  const {
    email,
    password,
    first_name,
    last_name,
    phone
  } = JSON.parse(event.body);

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(password, salt);

  const queryString = `
            INSERT INTO member SET 
                user_id='${uuidv4()}', password='${hash}', email='${email}', first_name='${first_name}', 
                last_name='${last_name}', phone='${phone}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function resetPassword(event) {
  const {
    email,
    user_id,
    expire_time
  } = JSON.parse(event.body);

  const curr = new Date().getTime();
  if (expire_time > curr) {
    const query = `select * from member where email='${email}' and user_id='${user_id}'`;
    const query2 = `UPDATE member SET password=${null}
                      WHERE email='${email}' and user_id='${user_id}'`;
    try {
      let queryResult = await queryRaw(query);
      let result;
      if (queryResult.length <= 0) {
        result = success(createSuccessBody({ message: 'no_user' }));
      } else {
        await queryRaw(query2);
        queryResult = await queryRaw(query);
        const user = queryResult[0];
        result = user
          ? success(createSuccessBody({ message: 'success', user: user }))
          : success(createSuccessBody({ message: 'fail' }));
      }
      return result;
    } catch (error) {
      return error;
    }
  }
}


export async function forgotPassword(event) {
  const { email } = event.queryStringParameters;
  const query = `select user_id, email from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      const user = queryResult[0];
      const email = user.email;
      const user_id = user.user_id;
      var date = new Date();
      const expire_time = date.setDate(date.getDate() + 1);
      const linkSuffix = `forgot-password?email=${email}&user_id=${user_id}&expire_time=${expire_time}`;
      //const hash = md5(email+user_id+expire_time);
      const link = (process.env.STAGE === "prod") ?
        `https://platform.bebefitroutine.com/#/${linkSuffix}`
        :
        (process.env.STAGE === "dev") ?
          `https://staging.platform.bebefitroutine.com/#/${linkSuffix}`
          :
          `http://localhost:3000/#/${linkSuffix}`;
      console.log("link : ", link);

      const sgMail = require('@sendgrid/mail');

      const API_KEY = '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';

      sgMail.setApiKey(API_KEY);

      const message = {
        to: email,
        from: 'no-reply@bebefitroutine.com',
        subject: 'คำร้องลืมรหัสผ่าน Bebe website',
        text: 'Link forgot password',
        html: bebeMailContent(link)
      };

      await sgMail
        .send(message)
        .then((repose) => console.log('Email sent...'))
        .catch((error) => console.log(error.message));

      result = user
        ? success(createSuccessBody({ message: 'success', user: user }))
        : success(createSuccessBody({ message: 'fail' }));
    }
    return result
  } catch (error) {
    return error;
  }
}

const bebeMailContent = (link) => (
  `
      <div leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:auto !important;width:100% !important; font-family: Helvetica,Arial,sans-serif !important; margin-bottom: 40px;">
          <center>
              <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" style="max-width:600px; background-color:#ffffff;border:1px solid #e4e2e2;border-collapse:separate !important; border-radius:4px;border-spacing:0;color:#242128; margin:0;padding:40px;"
                  heigth="auto">
                  <tbody>
                      <tr>
                          <td colSpan="2" style="padding-top:10px;">
                              <h3 style="color:#303030; font-size:18px; line-height: 1.6; font-weight:500;">แก้ไขรหัสผ่าน</h3>
                              <p style="color:#8f8f8f; font-size: 14px; padding-bottom: 20px; line-height: 1.4;">
                                  คุณได้ส่งคำขอในการลืมรหัสผ่าน กรุณากดปุ่มด้านล่างเพื่อดำเนินการตั้งรหัสผ่านใหม่
                              </p>
                          </td>
                      </tr>
                      <tr>
                          <td colSpan="2">
                              <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse;">
                                  <tbody>
                                      <tr>
                                          <td style="padding:15px 0px;" valign="top" align="center">
                                              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate !important;">
                                                  <tbody>
                                                      <tr>
                                                          <td align="center" valign="middle" style="padding:13px;">
                                                              <a 
                                                                  href="${link}" 
                                                                  title="แก้ไขรหัสผ่าน" 
                                                                  target="_blank" 
                                                                  style="font-size: 14px; line-height: 1.5; font-weight: 700; letter-spacing: 1px; padding: 15px 40px; text-align:center; text-decoration:none; color:#FFFFFF; border-radius: 50px; background-color:#922c88;"
                                                              >
                                                                  แก้ไขรหัสผ่าน
                                                              </a>
                                                          </td>
                                                      </tr>
                                                  </tbody>
                                              </table>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                          </td>
                      </tr>
                  </tbody>
              </table>
              <table style="margin-top:30px; padding-bottom:20px;; margin-bottom: 40px;">
                  <tbody>
                      <tr>
                          <td align="center" valign="center">
                              <p style="font-size: 12px; text-decoration: none;line-height: 1; color:#909090; margin-top:0px; margin-bottom:5px; ">
                                หากคุณไม่ได้ส่งคำขอในการตั้งรหัสผ่านใหม่ กรุณาเพิกเฉยต่ออีเมลฉบับนี้
                              </p>
                          </td>
                      </tr>
                  </tbody>
              </table>
          </center>
      </div>
  `
)

export async function forgotPasswordStayfit(event) {
  const { email } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;

  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      result = success(createSuccessBody({ message: 'success' }));
    }
    const to = email;
    const from = 'contact@planforfit.com';
    const subject = 'คำขอเปลี่ยนรหัสผ่านใหม่';

    await sendBebeHtmlMail(to, from, subject, email, "stay_fit_reset_passward");
    return result
  } catch (error) {
    return error;
  }
}

export async function setPassword(event) {
  const {
    email,
    password
  } = JSON.parse(event.body);

  const hash = md5(password);

  const queryString = `UPDATE member SET password='${hash}'
                       WHERE email = '${email}';`;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

/* TEST EMAIL */

export async function testSendEmail() {
  /*   var program_id = "subscription_stay_fit_01"; */
  var program_id = "starter_stay_fit_01";
  try {
    const to = 'thanet@planforfit.com';
    const from = 'contact@planforfit.com';
    const subject = 'การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว!';

    if (program_id === "subscription_stay_fit_01") {
      await sendBebeHtmlMail(to, from, subject, program_id, "subscription_stay_fit_01");
    }
    if (program_id === "starter_stay_fit_01") {
      await sendBebeHtmlMail(to, from, subject, program_id, "starter_stay_fit_01");
    }
  } catch (error) {
    return error;
  }
}

export async function testSendEmailRestPassword() {
  /*   var program_id = "subscription_stay_fit_01"; */
  var program_id = "starter_stay_fit_rest_passward";
  const to = 'thanet@planforfit.com';
  const from = 'contact@planforfit.com';
  const subject = 'คำขอเปลี่ยนรหัสผ่านใหม่';
  try {
    await sendBebeHtmlMail(to, from, subject, program_id, "stay_fit_reset_passward");

  } catch (error) {
    return error;
  }
}