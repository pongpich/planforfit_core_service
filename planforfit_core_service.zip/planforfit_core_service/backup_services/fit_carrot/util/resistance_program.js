export const get_resistance_program = () => {
  return {
    WT01: [
      {
        video_id: "00044",
        order: 1,
      },
      {
        video_id: "00020",
        order: 2,
      },
      {
        video_id: "00028",
        order: 3,
      },
      {
        video_id: "00022",
        order: 4,
      },
      {
        video_id: "00023",
        order: 5,
      },
    ],
    WT02: [
      {
        video_id: "00044",
        order: 1,
      },
      {
        video_id: "00021",
        order: 2,
      },
      {
        video_id: "00025",
        order: 3,
      },
      {
        video_id: "00026",
        order: 4,
      },
      {
        video_id: "00027",
        order: 5,
      },
    ],
    WT03: [
      {
        video_id: "00044",
        order: 1,
      },
      {
        video_id: "00045",
        order: 2,
      },
      {
        video_id: "00028",
        order: 3,
      },
      {
        video_id: "00026",
        order: 4,
      },
      {
        video_id: "00023",
        order: 5,
      },
    ],
    WT04: [
      {
        video_id: "00044",
        order: 1,
      },
      {
        video_id: "00045",
        order: 2,
      },
      {
        video_id: "00030",
        order: 3,
      },
      {
        video_id: "00029",
        order: 4,
      },
      {
        video_id: "00031",
        order: 5,
      },
    ],
    WT05: [
      {
        video_id: "00044",
        order: 1,
      },
      {
        video_id: "00021",
        order: 2,
      },
      {
        video_id: "00028",
        order: 3,
      },
      {
        video_id: "00033",
        order: 4,
      },
      {
        video_id: "00027",
        order: 5,
      },
    ],
    WT06: [
      {
        video_id: "00035",
        order: 1,
      },
      {
        video_id: "00036",
        order: 2,
      },
      {
        video_id: "00037",
        order: 3,
      },
      {
        video_id: "00039",
        order: 4,
      },
      {
        video_id: "00038",
        order: 5,
      },
    ],
    WT07: [
      {
        video_id: "00040",
        order: 1,
      },
      {
        video_id: "00041",
        order: 2,
      },
      {
        video_id: "00042",
        order: 3,
      },
      {
        video_id: "00039",
        order: 4,
      },
      {
        video_id: "00043",
        order: 5,
      },
    ],
    WT08: [
      {
        video_id: "00044",
        order: 1,
      },
      {
        video_id: "00045",
        order: 2,
      },
      {
        video_id: "00028",
        order: 3,
      },
      {
        video_id: "00022",
        order: 4,
      },
      {
        video_id: "00046",
        order: 5,
      },
    ],
  };
};
