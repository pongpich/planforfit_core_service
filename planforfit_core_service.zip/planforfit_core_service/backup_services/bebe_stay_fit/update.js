import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import moment from 'moment';
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
import { calculateWeekInProgram, generateVideos, getVideoTemplates } from './util/schedule';
import axios from 'axios';

export async function appendRow(event) { //ต้องปรับสิทธิ์ใน gg sheet เป็น anyone - editor
  const {
    spreadsheetId,
    data
  } = JSON.parse(event.body);

  const { google } = require('googleapis');
  const auth = new google.auth.GoogleAuth({
    credentials: {
      "type": "service_account",
      "project_id": "root-rarity-356012",
      "private_key_id": "90659528d768d855b542d73005989944803204f1",
      "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC4fdSnQ7oYvvh5\niu8sxgTeTn22zIccMcb6HyGAwu3upvGUnXd1ESsmqG9r0Ox0FU/jMra73SzvbEfe\nFLofZArdKbqvFbXSK5BQVJXrtRKM/pvBVorgQPc+t0yxT4wWqzPJYhCBvgdTFCYd\nWKa9MZOyMpmKVxhX7yhZUMOaXZt/Zypj9dKI73G6VljXgCrbjxiGnBSWOnRSWmd8\nRGNV7dfTmKIV4TJMQtFmH5OuAvZ2xrlZkE9WI4uFEfk8JYSR4mlFTQeHVKjKUZM4\nz0fE+Ns3Tw9dq0HIv2Ca3AOqgcm+HYAWGqzMv2SpBIWgHIyoyXhqUOXqinf11Pa4\nvNrr9YQxAgMBAAECggEAMC8pBaCCL6lc4v2e1u5G4jrUyZPka8AybCwKR4NhuhVe\n/gYcZ3Za80dFhn6z6uOQEFIz+J/c9xEsOfvm2oD592ZJLCY67Q/Uqq5U05FgrXNo\nAZhVQBmnmXktLhgNCfSf22Zh0kjrx8543+xB7CLRJNbjVAbIRFshiiY2WBA/pwe8\nd3zH5egbRrpZYMkkmltr8vulFajsKEuDWgyMoSuVPQ9XMN/lYu9pN/6miVQ6Q1xh\nMK0xuhgMQLO6Q2moryg61ttnf38EOEYxYh9drcP+/lrCpPuTNkkEvITOoPTdY18n\nEJtPb1LvDCzbunttDGIzh+39+IG8CCiP7nQEeULjIwKBgQDo3pNcWDdPsemd4n5t\nDydUJNSoxMS9aXG0vMu+goiBHXharR651DBfnmwB2DJWDRo5bqOLNyzSoyaOyBuf\nppD9xpbn0TMK4muPyTeiEXO0z9hQK4/0NLY5jz0b7wHYR/JEcQ0ok7bs7jlTwjqb\nq0JgwZM6GzWriMCnvG/gJ16KLwKBgQDK0RjqZ9klc/GjXIbW5SpI2BbxZWZ2NoPL\nDRDxBHq2cdtTloJ/mxC+nqA3OPyFpalZwXmiO6sXIEXXoeNwpsZEKn8E+n8ZHoUy\n4VEKmibNNt3wJOeHXyG7oORHJlzjTUj/PV6y5kRHrGCSk6UAWIpr5hGo7kmros0R\n+JHibB4fnwKBgFtzNTm5pxcUDmOjk/SuU8qWoDEa/QxJgY7x6a2KQ6M4+I/blspx\niwGyDEZ5KeNjR94wFefRJjgePEEsUrTSy/PtbkvhewMWQhl4cvGhmufyC8gII4NK\nxBk8qEn1BatzLbA1GW7K+7Z2I2tCRpPloK6wtmnGT8BqdwYoWWMU8uqfAoGADDVk\nA5A2wQtmq0fBkiP/VJ01XFiXP1xuuIVT1L5JSLw30KNJvbau3lqcGFbk1IKxXAbK\ndJqU5PJ7YcyL7VcMrkPEm58ckX2F1Rc9Ep9O4KGB4JfIHBz84deAhkvn4YLgdwTR\ns4Eq8QmOUqRylT+/LVmPDJUzeBJ3t7I3zeJmOc8CgYEAmk3VA7r3nu0HzKeo4bF6\nEGWkz9Gln8PE0mbl+8VbnLYu+UL+ipxra6SKIVDJLaS+CAr+/D7fVTmhFRoaHLaa\n2TvyIORVvJgfogOcNP+yGgZgii0C2KopzPXqgRcTKIzmrVXy40jdnoEmQwKyJvzS\nqkIOn77REZFrMAhlbeo6qNA=\n-----END PRIVATE KEY-----\n",
      "client_email": "akkewacheiei@root-rarity-356012.iam.gserviceaccount.com",
      "client_id": "109718169437483981766",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/akkewacheiei%40root-rarity-356012.iam.gserviceaccount.com"
    },
    scopes: "https://www.googleapis.com/auth/spreadsheets",
  })
  const googleSheets = google.sheets({ version: "v4" })
  try {

    const result = await googleSheets.spreadsheets.values.append({
      auth,
      spreadsheetId,
      range: "A2:Z",
      valueInputOption: "USER_ENTERED",
      resource: {
        values: [data]
      }
    });

    console.log('append!!');
    return success(result.data);
    
  } catch (error) {
    return error;
  }
}

export async function updateMembersGoogleSheets() {
  const selectMembersSQL = `
  select member.email, member.phone as เบอร์โทร, member.created_at as วันที่สมัคร, coalesce(member.program_id, 'สมัครไม่สำเร็จ') as แพ็คเกจ, coalesce(REPLACE(scp.status_payment, 'default', 'ยังไม่ชำระเงิน'), 'ไม่กรอกข้อมูลจัดส่ง') as สถานะ,
  coalesce(CONCAT(
  scp.delivery_address->>'$.firstname', ' ', 
  scp.delivery_address->>'$.lastname', ' ', 
  scp.delivery_address->>'$.phone', ' ', 
  scp.delivery_address->>'$.address', ' ', 
  scp.delivery_address->>'$.subdistrict', ' ', 
  scp.delivery_address->>'$.district', ' ',
  scp.delivery_address->>'$.province', ' ',
  scp.delivery_address->>'$.zipcode'), '-') as ข้อมูลจัดส่ง,
  coalesce(CONCAT('BST-',rl.referenceNo), '-') as 'เลขรายการขาย'
  from member 
  left join subscription_products scp on member.user_id = scp.user_id
  left join register_log rl on  member.user_id = rl.user_id and rl.round = 1
  order by  member.program_id, member.created_at desc
  `

  try {
    const selectMembersResult = await queryRaw(selectMembersSQL);

    const spreadsheetId = '1TTeJe3HJ4uK2M4Y4idKCXA-i5DOAnvLFgNVHREBGe6Q';
    const { google } = require('googleapis');
    const auth = new google.auth.GoogleAuth({
      credentials: {
        "type": "service_account",
        "project_id": "root-rarity-356012",
        "private_key_id": "90659528d768d855b542d73005989944803204f1",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC4fdSnQ7oYvvh5\niu8sxgTeTn22zIccMcb6HyGAwu3upvGUnXd1ESsmqG9r0Ox0FU/jMra73SzvbEfe\nFLofZArdKbqvFbXSK5BQVJXrtRKM/pvBVorgQPc+t0yxT4wWqzPJYhCBvgdTFCYd\nWKa9MZOyMpmKVxhX7yhZUMOaXZt/Zypj9dKI73G6VljXgCrbjxiGnBSWOnRSWmd8\nRGNV7dfTmKIV4TJMQtFmH5OuAvZ2xrlZkE9WI4uFEfk8JYSR4mlFTQeHVKjKUZM4\nz0fE+Ns3Tw9dq0HIv2Ca3AOqgcm+HYAWGqzMv2SpBIWgHIyoyXhqUOXqinf11Pa4\nvNrr9YQxAgMBAAECggEAMC8pBaCCL6lc4v2e1u5G4jrUyZPka8AybCwKR4NhuhVe\n/gYcZ3Za80dFhn6z6uOQEFIz+J/c9xEsOfvm2oD592ZJLCY67Q/Uqq5U05FgrXNo\nAZhVQBmnmXktLhgNCfSf22Zh0kjrx8543+xB7CLRJNbjVAbIRFshiiY2WBA/pwe8\nd3zH5egbRrpZYMkkmltr8vulFajsKEuDWgyMoSuVPQ9XMN/lYu9pN/6miVQ6Q1xh\nMK0xuhgMQLO6Q2moryg61ttnf38EOEYxYh9drcP+/lrCpPuTNkkEvITOoPTdY18n\nEJtPb1LvDCzbunttDGIzh+39+IG8CCiP7nQEeULjIwKBgQDo3pNcWDdPsemd4n5t\nDydUJNSoxMS9aXG0vMu+goiBHXharR651DBfnmwB2DJWDRo5bqOLNyzSoyaOyBuf\nppD9xpbn0TMK4muPyTeiEXO0z9hQK4/0NLY5jz0b7wHYR/JEcQ0ok7bs7jlTwjqb\nq0JgwZM6GzWriMCnvG/gJ16KLwKBgQDK0RjqZ9klc/GjXIbW5SpI2BbxZWZ2NoPL\nDRDxBHq2cdtTloJ/mxC+nqA3OPyFpalZwXmiO6sXIEXXoeNwpsZEKn8E+n8ZHoUy\n4VEKmibNNt3wJOeHXyG7oORHJlzjTUj/PV6y5kRHrGCSk6UAWIpr5hGo7kmros0R\n+JHibB4fnwKBgFtzNTm5pxcUDmOjk/SuU8qWoDEa/QxJgY7x6a2KQ6M4+I/blspx\niwGyDEZ5KeNjR94wFefRJjgePEEsUrTSy/PtbkvhewMWQhl4cvGhmufyC8gII4NK\nxBk8qEn1BatzLbA1GW7K+7Z2I2tCRpPloK6wtmnGT8BqdwYoWWMU8uqfAoGADDVk\nA5A2wQtmq0fBkiP/VJ01XFiXP1xuuIVT1L5JSLw30KNJvbau3lqcGFbk1IKxXAbK\ndJqU5PJ7YcyL7VcMrkPEm58ckX2F1Rc9Ep9O4KGB4JfIHBz84deAhkvn4YLgdwTR\ns4Eq8QmOUqRylT+/LVmPDJUzeBJ3t7I3zeJmOc8CgYEAmk3VA7r3nu0HzKeo4bF6\nEGWkz9Gln8PE0mbl+8VbnLYu+UL+ipxra6SKIVDJLaS+CAr+/D7fVTmhFRoaHLaa\n2TvyIORVvJgfogOcNP+yGgZgii0C2KopzPXqgRcTKIzmrVXy40jdnoEmQwKyJvzS\nqkIOn77REZFrMAhlbeo6qNA=\n-----END PRIVATE KEY-----\n",
        "client_email": "akkewacheiei@root-rarity-356012.iam.gserviceaccount.com",
        "client_id": "109718169437483981766",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/akkewacheiei%40root-rarity-356012.iam.gserviceaccount.com"
      },
      scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
    const googleSheets = google.sheets({ version: "v4" })

    await googleSheets.spreadsheets.values.clear({
      auth,
      spreadsheetId,
      range: "A2:Z"
    }).then((repose) => {
      console.log('clear!!')
    })

    //data formatting 
    let data = []
    if (selectMembersResult) (
      selectMembersResult.map(item => {
        data.push([item.email, item.เบอร์โทร, item.วันที่สมัคร, item.แพ็คเกจ, item.สถานะ, item.ข้อมูลจัดส่ง, item.เลขรายการขาย])
      })
    )

    await googleSheets.spreadsheets.values.append({
      auth,
      spreadsheetId,
      range: "A2:Z",
      valueInputOption: "USER_ENTERED",
      resource: {
        values: data
      }
    }).then((repose) => {
      console.log('append!!')
    })
  } catch (error) {
    return error;
  }
}

export async function cancelFriendRequest(event) {
  const {
    sender_id,
    receiver_id
  } = JSON.parse(event.body);

  const deleteFriendRequestSQL = `
  DELETE FROM friend_request 
  WHERE sender_id = '${sender_id}' and receiver_id = '${receiver_id}' and status = 'default';
  `;

  try {
    let result;
    await query(deleteFriendRequestSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function cancelTeamInvite(event) {
  const {
    sender_id,
    receiver_id
  } = JSON.parse(event.body);

  const deleteTeamInviteSQL = `
  DELETE FROM team_invite 
  WHERE sender_id = '${sender_id}' and receiver_id = '${receiver_id}' and status = 'default';
  `;

  try {
    let result;
    await query(deleteTeamInviteSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateAchievementLog(event) {
  const {
    user_id,
    achievement_name
  } = JSON.parse(event.body);

  const insertAchievementLog = `
    insert into achievement_log
    set user_id = '${user_id}', achievement = '${achievement_name}'
  `;

  try {
    let result;
    await query(insertAchievementLog);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkAllMissionCompelete(event) {
  const {
    user_id
  } = JSON.parse(event.body);

  const selectLastChallengeEvent = `
                                      select * from challenge_event
                                      order by created_at desc limit 1;
                                    `;

  const insertAchievementLog = `
    insert into achievement_log
    set user_id = '${user_id}', achievement = 'Finisher'
  `;

  try {
    let result;
    const selectLastChallengeEventResult = await queryRaw(selectLastChallengeEvent);
    const start_date = moment(selectLastChallengeEventResult[0].start_date);
    const expire_date = moment(selectLastChallengeEventResult[0].expire_date);
    const numbOfWeeks = expire_date.diff(start_date, 'week') + 1;
    const maxScoreOfWeek = 110; //ยกเว้น week ที่ 1 จะได้สูงสุดแค่ 100 เพราะไม่สามารถทำภารกิจน้ำหนักตัวน้อยกว่าสัปดาห์ก่อนได้
    const maxScoreOfSeason = (maxScoreOfWeek * numbOfWeeks) - 10; // -10 เพราะ Week ที่ 1 ไม่สามารถทำภารกิจน้ำหนักตัวน้อยกว่าสัปดาห์ก่อนได้
    console.log("maxScoreOfSeason :", maxScoreOfSeason);
    const selectTotalScore = `
    select m.user_id, m.email, m.first_name, m.last_name, m.facebook, m.start_date, m.expire_date, calcScore.total_score
    from (
      select user_id, sum(score) as total_score
      from member_event_log
      where created_at BETWEEN '${moment(selectLastChallengeEventResult[0].start_date).format('YYYYMMDD')}' AND '${moment(selectLastChallengeEventResult[0].expire_date).format('YYYYMMDD')}' 
      AND user_id = '${user_id}'
      group by user_id
        ) as calcScore JOIN member m
        ON m.user_id = calcScore.user_id
    order by total_score desc
    `;
    const selectTotalScoreResult = await queryRaw(selectTotalScore);
    const scoreOfUser = selectTotalScoreResult[0].total_score;
    console.log("scoreOfUser :", scoreOfUser);
    const allMissionCompelete = (scoreOfUser >= maxScoreOfSeason) ? true : false;
    console.log("allMissionCompelete :", allMissionCompelete);

    if (allMissionCompelete) {
      await query(insertAchievementLog);
      result = success(createSuccessBody({ message: 'success' }));
    } else {
      result = success(createSuccessBody({ message: 'fail' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkUpdateMaxFriends(event) {
  const {
    user_id
  } = JSON.parse(event.body);

  const selectActivitiesSQL = `
                              select * from exercise_activity
                              where user_id = '${user_id}'
                              order by week_in_program desc limit 1;
                            `;

  const selectLogActiveInWeekSQL = `
                                      select * from member_event_log
                                      where user_id = '${user_id}' 
                                      and log = 'active in week' 
                                      and DATE(created_at) BETWEEN getMondayOfTheWeek(CURDATE()) AND getSundayOfTheWeek(CURDATE());
                                    `;

  const insertLogActiveInWeekSQL = `
                                    INSERT INTO member_event_log ( user_id, log, log_value, log_type, score)
                                    VALUES ( '${user_id}', 'active in week', '0', 'individual', 0.00);
                                    `;

  const selectMaxFriendsSQL = `
                                select max_friends from member
                                where user_id = '${user_id}'
                              `;

  try {
    let result;
    const selectActivitiesResult = await queryRaw(selectActivitiesSQL);
    const activities = JSON.parse(selectActivitiesResult[0].activities);
    const completeVideoPlayPercentage = 0.9; //ถ้าดูคลิปเกิน 90% ของ duration นับว่าดูจบ
    var numbOfCompleteDay = 0;
    //เช็คจำนวนวันที่ผู้ใช้ดูครบทุปคลิป
    for (var i = 0; i < activities.length; i++) { //วนลูปเข้าไปแต่ละวันของ activities
      var numbOfCompleteVideo = 0;
      for (var j = 0; j < activities[i].length; j++) { //วนลูปเข้าไปแต่ละคลิปของวันนั้น
        if (activities[i][j].play_time / activities[i][j].duration >= completeVideoPlayPercentage) {
          numbOfCompleteVideo += 1;
        }
      }
      if (numbOfCompleteVideo === activities[i].length) {
        numbOfCompleteDay += 1;
      }
    }
    console.log("numbOfCompleteDay :", numbOfCompleteDay);

    const selectLogActiveInWeekResult = await queryRaw(selectLogActiveInWeekSQL);
    const selectMaxFriendsResult = await queryRaw(selectMaxFriendsSQL);
    const numbLogActiveInWeek = selectLogActiveInWeekResult.length;
    const max_friends = selectMaxFriendsResult[0].max_friends;
    console.log("numbLogActiveInWeek :", numbLogActiveInWeek);
    if (numbOfCompleteDay > 0 && numbLogActiveInWeek === 0 && max_friends < 14) { // ถ้ามีวันที่ออกกำลังกายสำเร็จอย่างน้อย1วันในสัปดาห์ ให้ทำการ + จำนวนเพื่อน 2 
      await query(insertLogActiveInWeekSQL);
      const updateMaxFriendsSQL = `
                                    update member 
                                    set max_friends = ${max_friends + 2}
                                    where user_id = '${user_id}'
                                  `;
      await query(updateMaxFriendsSQL);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function rejectTeamInvite(event) {
  const {
    log_id
  } = JSON.parse(event.body);

  const updteTeamInviteSQL = `
                                  update team_invite 
                                  set status = 'reject'
                                  where log_id = ${log_id}
                                `;
  try {
    let result;
    await query(updteTeamInviteSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateFittoPlant(event) {

  const { user_id, data } = JSON.parse(event.body);


  const updteFriendRequestSQL = `
                                  update subscription_products 
                                  set products_list = '${JSON.stringify(data)}'
                                  where user_id = '${user_id}'
                                `;
  try {
    let result;
    await query(updteFriendRequestSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateAddress(event) {

  const { user_id, data } = JSON.parse(event.body);

  console.log("user_id", user_id, data);
  const updteFriendRequestSQL = `
                                  update subscription_products 
                                  set delivery_address = '${JSON.stringify(data)}'
                                  where user_id = '${user_id}'
                                `;
  try {
    let result;
    await query(updteFriendRequestSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function rejectFriend(event) {
  const {
    log_id
  } = JSON.parse(event.body);

  const updteFriendRequestSQL = `
                                  update friend_request 
                                  set status = 'reject'
                                  where log_id = ${log_id}
                                `;
  try {
    let result;
    await query(updteFriendRequestSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function acceptTeamInvite(event) {
  const {
    user_id, //user_id = id ของผู้ที่ได้รับคำเชิญร่วมทีม 
    group_id, //group_id = id ของกลุ่มที่ผู้ส่งคำเชิญอาศัยอยู่
    log_id
  } = JSON.parse(event.body);

  const selectGroupIDSQL = `
                                select group_id from member
                                where user_id = '${user_id}'
                                `;

  const selectMembersOfTeamSQL = `
                                select count(*) as count from member
                                where group_id = ${group_id}
                                `;

  const updteTeamInviteSQL = `
                                update team_invite 
                                set status = 'accept'
                                where log_id = ${log_id}
                              `;

  const updteGroupIDSQL = `
                                update member 
                                set group_id = '${group_id}'
                                where user_id = '${user_id}'
                              `;

  try {
    let result;

    const selectGroupIDResult = await queryRaw(selectGroupIDSQL);
    const selectMembersOfTeamResult = await queryRaw(selectMembersOfTeamSQL);
    const numbOfMembers = selectMembersOfTeamResult[0].count;
    const maxMembersOfTeam = 10;
    if (selectGroupIDResult[0].group_id || numbOfMembers >= maxMembersOfTeam) { //เช็คว่าผู้ที่ได้รับคำเชิญมีทีมอยู่แล้วไหม? - ถ้ามี ไม่ต้องอัพเดท group_id || หรือ ถ้าจำนวนสมาชิกทีมนั้นครบ 10 ก็ไม่ต้องอัพเดท group_id
      await query(updteTeamInviteSQL);
      result = success(createSuccessBody({ message: 'already_have_team' }));
    } else { // ถ้าไม่มี ต้องอัพเดท group_id
      await query(updteGroupIDSQL);
      await query(updteTeamInviteSQL);
      result = success(createSuccessBody({ message: 'success' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function acceptFriend(event) {
  const {
    user_id,
    sender_id,
    log_id
  } = JSON.parse(event.body);

  const selectFriendListSQL = `
                                select friend_list, max_friends from member
                                where user_id = '${user_id}'
                                `;

  const selectFriendListSenderSQL = `
                                select friend_list from member
                                where user_id = '${sender_id}'
                                `;

  const updteFriendRequestSQL = `
                                update friend_request 
                                set status = 'accept'
                                where log_id = ${log_id}
                              `;

  try {
    let result;
    const selectFriendListResult = await queryRaw(selectFriendListSQL);
    const max_friends = selectFriendListResult[0].max_friends;
    var checkMaxNumbFriends = false;
    let new_friend_list = [];
    if (selectFriendListResult[0].friend_list) { //เช็คว่ามีเพื่อนไหม (ถ้ามีเพื่อน เพิ่ม id คนใหม่ต่อจากคนเก่า)
      const old_friend_list = JSON.parse(selectFriendListResult[0].friend_list);
      if (old_friend_list.includes(sender_id)) { //เช็คว่าถ้ามีคนนี้เป็นเพื่อนอยู่แล้ว ไม่ต้องเพิ่มเข้า friend_list
        result = success(createSuccessBody({ message: 'friend_list_exist' }));
      } else { //ถ้ายังไม่มีคนนี้เป็นเพื่อน 
        if (old_friend_list.length < max_friends) { //เช็คว่าถ้าเพื่อนยังไม่เต็ม ให้เพิ่มเข้า friend_list
          old_friend_list.push(sender_id);
          result = success(createSuccessBody({ message: 'success' }));
        } else { //ถ้าเพื่อนเต็มไม่ต้องเพิ่่ม
          checkMaxNumbFriends = true;
          result = success(createSuccessBody({ message: 'friend_list_exist' }));
        }
      }
      new_friend_list = old_friend_list;
    } else { //(ถ้าไม่มีเพื่อนเลย สามารถ เพิ่ม id คนใหม่ไปเลย)
      new_friend_list.push(sender_id);
      result = success(createSuccessBody({ message: 'success' }));
    }
    console.log("new_friend_list :", new_friend_list);
    const updteFriendListSQL = `
                                update member 
                                set friend_list = '${JSON.stringify(new_friend_list)}'
                                where user_id = '${user_id}'
                              `;
    await query(updteFriendListSQL);
    await query(updteFriendRequestSQL);

    const selectFriendListSenderResult = await queryRaw(selectFriendListSenderSQL);
    let new_friend_list_sender = [];
    if (selectFriendListSenderResult[0].friend_list) { //เช็คว่ามีเพื่อนไหม (ถ้ามีเพื่อน เพิ่ม id คนใหม่ต่อจากคนเก่า)
      const old_friend_list_sender = JSON.parse(selectFriendListSenderResult[0].friend_list);
      if (old_friend_list_sender.includes(user_id)) { //เช็คว่าถ้ามีคนนี้เป็นเพื่อนอยู่แล้ว ไม่ต้องเพิ่มเข้า friend_list
      } else { //ถ้ายังไม่มีคนนี้เป็นเพื่อน ให้เพิ่มเข้า friend_list
        old_friend_list_sender.push(user_id);
      }
      new_friend_list_sender = old_friend_list_sender;
    } else { //(ถ้าไม่มีเพื่อนเลย สามารถ เพิ่ม id คนใหม่ไปเลย)
      new_friend_list_sender.push(user_id);
    }
    console.log("new_friend_list_sender :", new_friend_list_sender);
    const updteFriendListSenderSQL = `
    update member 
    set friend_list = '${JSON.stringify(new_friend_list_sender)}'
    where user_id = '${sender_id}'
  `;
    console.log("checkMaxNumbFriends :", checkMaxNumbFriends);
    if (!checkMaxNumbFriends) { //เช็คผู้ที่ได้รับคำขอเพื่อนถ้าเพื่อนยังไม่เต็มถึงจะอัพเดท
      await query(updteFriendListSenderSQL);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function deleteFriend(event) {
  const {
    user_id,
    friend_email
  } = JSON.parse(event.body);

  const selectFriendListSQL = `
                              select friend_list from member
                              where user_id = '${user_id}'
                              `;

  const selectFriendIDSQL = `
                              select user_id from member
                              where email = '${friend_email}'
                              `;

  try {
    let result;
    const selectFriendListResult = await queryRaw(selectFriendListSQL);
    const selectFriendIDResult = await queryRaw(selectFriendIDSQL);
    const friend_id = selectFriendIDResult[0].user_id;
    let new_friend_list = [];
    if (selectFriendListResult[0].friend_list) { //เช็คว่ามีเพื่อนไหม 
      const old_friend_list = JSON.parse(selectFriendListResult[0].friend_list);
      console.log("old_friend_list1 :", old_friend_list);
      //ลบรายช่ือเพื่อนตามอีเมลที่นับมาออก
      new_friend_list = old_friend_list.filter((item) => { return item !== friend_id }) //กำหนดให้ new_friend_list = list อันใหม่ที่ลบเพื่อนคนที่ต้องการออกแล้ว
      const updteFriendListSQL = `
                                    update member 
                                    set friend_list = '${JSON.stringify(new_friend_list)}'
                                    where user_id = '${user_id}'
                                  `;
      await query(updteFriendListSQL);
      result = success(createSuccessBody({ message: 'success' }));
    } else {
      result = success(createSuccessBody({ message: 'friendless' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function changeEmail(event) {
  const {
    email,
    new_email
  } = JSON.parse(event.body);

  const selectEmailSQL = `SELECT email FROM member
                          WHERE email = '${email}';`;

  const selectNewEmailSQL = `SELECT email FROM member
                          WHERE email = '${new_email}';`;

  const updateEmailSQL = `UPDATE member
                          SET email = '${new_email}'
                          WHERE email = '${email}';`;

  try {
    const selectEmailResult = await queryRaw(selectEmailSQL);
    const selectNewEmailResult = await queryRaw(selectNewEmailSQL);
    let result;
    if (selectEmailResult.length > 0) {
      if (selectNewEmailResult.length > 0) {
        // ส่ง message อีเมลมีในระบบอยู่แล้ว
        result = success(createSuccessBody({ message: 'email_exist' }));
      } else {
        // ทำการเปลี่ยนอีเมลให้
        await query(updateEmailSQL);
        result = success(createSuccessBody({ message: 'success' }));
      }
    } else {
      // ส่ง message อีเมลไม่ถูกต้อง
      result = success(createSuccessBody({ message: 'email_incorrect' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateStayFitProfile(event) {
  const {
    user_id,
    other_attributes,
    start_date,
    program_id,
    is_beginner = false,
    is_firsttime = true,
    display_name
  } = JSON.parse(event.body);
  const queryString = `
            UPDATE member SET
              other_attributes='${JSON.stringify(other_attributes)}',display_name=${display_name ? `'${display_name}'` : null}
            WHERE user_id='${user_id}';
        `;

  try {


    let videosQuery = 'select * from vdo_detail;';

    if (is_beginner && is_firsttime) { //หมวดหมู่ Cardio มี tag beginner แต่ต้องเอาออกจากเงื่อนไขเพราะคลิปสำหรับ beginner มีไม่พอจัดตาราง
      videosQuery = `
                      SELECT * 
                      FROM vdo_detail
                      WHERE (tag LIKE '%beginner%')
                      OR (category NOT IN ('Main Circuit', 'Sub circuit'));
                    `
    }
    const videos = await queryRaw(videosQuery);
    let delVideos = [];
    // bebe stay fit มี requirement ว่า ทุกๆ รอบจะต้องได้วิดีโอใหม่เสมอ ดังนั้น จึงต้องคอยลบคลิปซ้ำที่สุ่มมาตั้งแต่การต่ออายุรอบสองเป็นต้นมา
    // code ข้างล่างจะสร้าง list ของวิดีโอที่ซ้ำออกมาเพื่อนำไปลบออกจากรายกายวิดีโอที่จะนำมาสุ่มในรอบสองเป็นต้นไป
    if (!is_firsttime) {
      delVideos = await getVideoTemplates(user_id);
    }
    const schedule = JSON.stringify(generateVideos(start_date, 0, other_attributes.weight, videos, delVideos));
    const queryString2 = `
    UPDATE register_log SET
    video_template = '${schedule}'
    WHERE user_id = '${user_id}' AND round = 1 AND program_id = '${program_id}'
    `

    const queryStrings = [queryString, queryString2];

    const result = await transaction(queryStrings);
    return result;
  } catch (error) {
    return error;
  }

}

export async function updateDisplayName(event) {
  const { user_id, display_name } = JSON.parse(event.body);
  const selectDisplayNameSQL = `select * from member where display_name='${display_name}'`;
  const updateDisplayNameSQL = `
  update member
  set display_name = '${display_name}'
  where user_id = '${user_id}';
  `;
  try {
    let result;
    const selectDisplayNameResult = await queryRaw(selectDisplayNameSQL);
    if (selectDisplayNameResult.length <= 0) {
      result = success(createSuccessBody({ message: 'new' }));
      await query(updateDisplayNameSQL);
    } else {
      result = success(createSuccessBody({ message: 'exist' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateDeliveryAddress(event) {

  const { user_id, data } = JSON.parse(event.body);
  const queryString = `
            UPDATE subscription_products SET
              delivery_address='${JSON.stringify(data)}'
            WHERE user_id='${user_id}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}


export async function updateProfile(event) {
  const {
    email,
    other_attributes
  } = JSON.parse(event.body);

  const queryString = `
            UPDATE member SET
              other_attributes='${JSON.stringify(other_attributes)}'
            WHERE email='${email}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateBodyInfo(event) {
  const {
    user_id,
    start_date,
    expire_date,
    other_attributes
  } = JSON.parse(event.body);
  var curr = new Date().getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  const queryString = `
            UPDATE exercise_activity SET
              body_info='${JSON.stringify(other_attributes)}'
            WHERE user_id='${user_id}' AND week_in_program='${week}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function trialPackage(event) {
  const {
    email
  } = JSON.parse(event.body);

  const period = 14;
  const expire_date = `${moment().add(period, 'days').format('YYYY/MM/DD')} 23:59:59`;
  const start_date = `${moment().add(0, 'days').format('YYYY/MM/DD')} 00:00:00`;

  const queryString = `
            UPDATE member SET 
                start_date='${start_date}', expire_date='${expire_date}'
                WHERE email = '${email}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}