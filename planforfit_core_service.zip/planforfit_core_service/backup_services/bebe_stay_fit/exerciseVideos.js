import { query, queryRaw } from "./local_lib/dbhelper";
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
import { generateVideos, calculateWeekInProgram } from './util/schedule';
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

export async function updatePlayTimeLastWeek(event) {
  const {
    user_id,
    start_date,
    expire_date,
    day_number,
    video_number,
    play_time,
    duration
  } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }
  const lastweek = week - 1;

  const queryString = ` UPDATE exercise_activity 
                        SET activities = JSON_SET(activities,
                                                    '$[${day_number}][${video_number}].play_time', ${play_time},
                                                    '$[${day_number}][${video_number}].duration', ${duration}
                                          )
                        WHERE user_id = '${user_id}' AND week_in_program = ${lastweek};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updatePlayTime(event) {
  const {
    user_id,
    start_date,
    expire_date,
    day_number,
    video_number,
    play_time,
    duration
  } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }
  const queryString = ` UPDATE exercise_activity 
                        SET activities = JSON_SET(activities,
                                                    '$[${day_number}][${video_number}].play_time', ${play_time},
                                                    '$[${day_number}][${video_number}].duration', ${duration}
                                          )
                        WHERE user_id = '${user_id}' AND week_in_program = ${week};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateVDO(event) {
  const {
    user_id,
    start_date,
    day_number,
    video_number,
    video_id,
    name,
    thumbnail = "",
    rep = 1,
    play_set = 1,
    rest_time = 0,
    duration,
    type = "",
    category,
    clip_gen
  } = JSON.parse(event.body);
  const weekInProgram = calculateWeekInProgram(start_date);
  const queryString = `UPDATE exercise_activity 
              SET activities = JSON_SET(activities, 
                '$[${day_number}][${video_number}].video_id', '${video_id}',
                '$[${day_number}][${video_number}].name', '${name}',
                '$[${day_number}][${video_number}].thumbnail', '${thumbnail}',
                '$[${day_number}][${video_number}].rep', ${rep},
                '$[${day_number}][${video_number}].play_set', ${play_set},
                '$[${day_number}][${video_number}].rest_time', ${rest_time},
                '$[${day_number}][${video_number}].duration', ${duration},
                '$[${day_number}][${video_number}].type', '${type}',
                '$[${day_number}][${video_number}].category', '${category}',
                '$[${day_number}][${video_number}].clip_gen', '${clip_gen}'
              )
              WHERE user_id = '${user_id}' AND week_in_program = ${weekInProgram};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updatePlaylist(event) {
  const {
    user_id,
    start_date,
    day_number,
    playlist
  } = JSON.parse(event.body);
  const weekInProgram = calculateWeekInProgram(start_date);
  const queryString = `UPDATE exercise_activity 
              SET activities = JSON_SET(activities, 
                '$[${day_number}]', CAST('${JSON.stringify(playlist)}' AS JSON)
              )
              WHERE user_id = '${user_id}' AND week_in_program = ${weekInProgram};`;
  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function createWeeklyStayfitProgram(event) {
  const { user_id, start_date, expire_date } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  try {
    const queryString = `
            INSERT INTO exercise_activity SET 
                user_id='${user_id}', week_in_program='${week}', 
                activities= ( 
                              SELECT video_template FROM register_log
                              WHERE user_id = '${user_id}' AND curdate() BETWEEN start_date AND expire_date
                              AND program_id like '%stay_fit%'
                            );
        `;
    let result;
    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      result = result;
    } else {
      result = await query(queryString);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function createCustomWeekForUser(event) {
  const { user_id, weight, start_date, expire_date, offset } = JSON.parse(event.body);
  var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  try {
    const videosQuery = 'select * from vdo_detail;';
    const videos = await queryRaw(videosQuery);
    const schedule = JSON.stringify(generateVideos(start_date, offset, weight, videos));
    const queryString = `
            INSERT INTO exercise_activity SET 
                user_id='${user_id}', week_in_program='${week}', 
                activities='${schedule}';
        `;
    let result;
    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      result = result;
    } else {
      result = await query(queryString);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function videoListForUserLastWeek(event) {
  const { user_id, weight, start_date, expire_date, offset } = event.queryStringParameters;
  var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;

  //exerciseActivitySQL ใช้เช็คโปรแกรมออกกำลังกายสัปดาห์ล่าสุดที่มีการ gen 
  const exerciseActivitySQL = ` select week_in_program from exercise_activity
                                where user_id = '${user_id}'
                                order by week_in_program DESC LIMIT 1`;
  const exerciseActivityResult = await queryRaw(exerciseActivitySQL);

  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = exerciseActivityResult[0].week_in_program;
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }
  const lastweek = week - 1;

  const queryString = `select week_in_program, activities from exercise_activity where user_id='${user_id}' 
                        AND week_in_program='${lastweek}'`;
  try {
    let queryResult = await query(queryString);
    let result;
    let bodyLength = JSON.parse(queryResult.body)

    if (bodyLength.results.length <= 0) {
      const videosQuery = 'select * from vdo_detail;';
      const videos = await queryRaw(videosQuery);
      const schedule = JSON.stringify(generateVideos(start_date, offset, weight, videos));
      const queryStringVideo = `
              INSERT INTO exercise_activity SET 
                  user_id='${user_id}', week_in_program='${lastweek}', 
                  activities='${schedule}';
          `;
      if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
        // not to do
      } else {
        await query(queryStringVideo);
      }
      let queryResult = await query(queryString);
      result = queryResult;
    } else {
      result = queryResult;
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function videoListForUser(event) {
  const { user_id, weight, start_date, expire_date, offset } = event.queryStringParameters;
  var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
  var curr = currTimeZone.getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;

  //exerciseActivitySQL ใช้เช็คโปรแกรมออกกำลังกายสัปดาห์ล่าสุดที่มีการ gen 
  const exerciseActivitySQL = ` select week_in_program from exercise_activity
                                where user_id = '${user_id}'
                                order by week_in_program DESC LIMIT 1`;
  const exerciseActivityResult = await queryRaw(exerciseActivitySQL);

  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = exerciseActivityResult[0].week_in_program;
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  const queryString = `select week_in_program, activities from exercise_activity where user_id='${user_id}' 
                        AND week_in_program='${week}'`;
  try {
    let queryResult = await query(queryString);
    let result;
    let bodyLength = JSON.parse(queryResult.body)

    if (bodyLength.results.length <= 0) {
      result = success(createSuccessBody({ message: 'no_video' }));
    } else {
      result = queryResult;
    }
    return result;

  } catch (error) {
    return error;
  }
}

export async function randomVideo(event) {
  const { video_id, category, type } = event.queryStringParameters;
  const query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND type='${type}' `;

  try {
    const queryResult = await queryRaw(query);
    queryResult.sort(() => Math.random() - 0.5);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_video' }));
    } else {
      result = success(createSuccessBody({ video: queryResult[0] }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectChangeVideo(event) {
  const { video_id, category, type } = event.queryStringParameters;
  const query = `SELECT * from vdo_detail WHERE video_id != '${video_id}' AND category='${category}' AND type='${type}'`;

  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_video' }));
    } else {
      result = success(createSuccessBody({ videos: queryResult }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function deleteProgramInWeek(event) { //Adminใช้ลบโปรแกรมออกกำลังกายในสัปดาห์นั้นของผู้ใช้ เพื่อให้ผู้ใช้ได้กรอกข้อมูลใหม่ เช่น กรณีกรอก นน. ผิด
  const { email } = JSON.parse(event.body);
  const selectStartDateSQL = ` SELECT start_date FROM member WHERE email='${email}';`;
  const selectStartDateResult = await queryRaw(selectStartDateSQL);
  const start_date = selectStartDateResult[0].start_date;

  const week = calculateWeekInProgram(start_date);

  const deleteProgramInWeekSQL = `  DELETE FROM exercise_activity 
                                    WHERE user_id=(SELECT user_id FROM member WHERE email='${email}') 
                                    AND week_in_program='${week}';`;

  const updateOtherAttributeSQL = ` UPDATE member
                                    SET other_attributes = NULL
                                    WHERE email = '${email}' ;`;

  try {
    await queryRaw(deleteProgramInWeekSQL);
    if (week === 1) { //ถ้าเป็นสัปดาห์แรก ให้Update OtherAttribute = NULL ด้วย 
      await queryRaw(updateOtherAttributeSQL);
    }
  } catch (error) {
    return error;
  }
}

export async function selectProgramInWeek(event) { //Adminใช้ดูโปรแกรมออกกำลังกายในสัปดาห์นั้นของผู้ใช้
  const { email } = event.queryStringParameters;
  const selectStartDateSQL = ` SELECT start_date FROM member WHERE email='${email}';`;
  const selectStartDateResult = await queryRaw(selectStartDateSQL);
  const start_date = selectStartDateResult[0].start_date;

  const week = calculateWeekInProgram(start_date);

  const selectProgramInWeekSQL = `  SELECT * FROM exercise_activity 
                                    WHERE user_id=(SELECT user_id FROM member WHERE email='${email}') 
                                    AND week_in_program='${week}';`;
  try {
    let result;
    const selectProgramInWeekResult = await queryRaw(selectProgramInWeekSQL);
    const programInWeek = selectProgramInWeekResult[0];
    result = success(createSuccessBody({ programInWeek: programInWeek }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectMemberInfo(event) { //Admin ใช้ดูข้อมูลของผู้ใช้คนนั้นๆ
  const { email } = event.queryStringParameters;

  const selectMemberInfoSQL = ` SELECT * FROM member 
                                WHERE user_id=(SELECT user_id FROM member WHERE email='${email}');`;

  try {
    let result;
    const selectMemberInfoResult = await queryRaw(selectMemberInfoSQL);
    const memberInfo = selectMemberInfoResult[0];
    result = success(createSuccessBody({ memberInfo: memberInfo }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function selectBodyInfo(event) { //Admin ใช้ดูข้อมูล Body Info ในแต่ละ week ของผู้ใช้
  const { email } = event.queryStringParameters;

  const selectBodyInfoSQL = ` SELECT week_in_program, body_info FROM exercise_activity 
                              WHERE user_id=(SELECT user_id FROM member WHERE email='${email}');`;

  try {
    let result;
    const selectBodyInfoResult = await queryRaw(selectBodyInfoSQL);
    const bodyInfo = selectBodyInfoResult;
    result = success(createSuccessBody({ bodyInfo: bodyInfo }));
    return result;
  } catch (error) {
    return error;
  }
}