import mysql from 'mysql';

const config = {
  connectionLimit: 10,
  host: "db.planforfit.com",
  port: 3306,
  user: "admin",
  password: ',kpgvl8b;cv]ruFagva543',
  database: "bebe_stay_fit",
  multipleStatements: true,
  ssl: { rejectUnauthorized: false },
  timezone: 'UTC+0',
  dateString: [
    'DATE',
    'DATETIME',
    'TIMESTAMP'
  ]
}

const db_pool = mysql.createPool(config);

export default db_pool;
