import { query, queryRaw } from "./local_lib/dbhelper";
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
import axios from 'axios';

export async function getMemberGroupProduct(event) {
    const { group_name } = event.queryStringParameters;

    const selectMemberGroupSQL = ` SELECT * FROM products where group_name = '${group_name}' ; `;

    try {
        let result;

        const memberGroupResult = await queryRaw(selectMemberGroupSQL);
        result = success(createSuccessBody({ queryResult: memberGroupResult }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function getAllGroupProduct() {
    const selectSQL = `select * from product_groups order by group_id desc;`;
    try {
        let result;
        const queryResult = await queryRaw(selectSQL);
        result = success(createSuccessBody({ queryResult: queryResult }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function setGroupProduct(event) {
    const {
        product_id,
        group_name,
        property
    } = JSON.parse(event.body);
    const getProductSQL = `
                select * from products
                where product_id = '${product_id}'
                `;

    const setGroupProductSQL = `
                                update products 
                                set group_name = '${group_name}', property = '${property}'
                                where product_id = '${product_id}'
                                `;
    try {
        let result;
        const product = await queryRaw(getProductSQL);
        if (product[0]) {
            result = success(createSuccessBody({ message: 'success' }));
            await query(setGroupProductSQL);
        } else {
            result = success(createSuccessBody({ message: 'fail' }));
        }
        return result;
    } catch (error) {
        return error;
    }
}

export async function addGroupProduct(event) {
    const {
        group_name
    } = JSON.parse(event.body);
    const getGroupsSQL = `
    select * from product_groups
    where group_name = '${group_name}'
    `;
    const addGroupProductSQL = `INSERT INTO product_groups SET group_name = '${group_name}'`;

    try {
        let result;
        const groups = await queryRaw(getGroupsSQL);
        if (groups[0]) {//ถ้ามี groups[0] แสดงว่าชื่อกลุ่มซ้ำ
            result = success(createSuccessBody({ message: 'fail' }));
        } else {
            await query(addGroupProductSQL);
            result = success(createSuccessBody({ message: 'success' }));
        }
        return result;
    } catch (error) {
        return error;
    }
}

export async function add_product(event) {
    let {
        product_id,
        product_name,
        category,
        price,
        available_stock,
        image_list,
        description,
        nutritional_value,
        detail
    } = JSON.parse(event.body);

    //ทุกค่าที่เป็น String -> ก่อนไปใส่ในคำสั่ง SQL ให้ทำการนำ ' ออก
    product_name = product_name.replace(/'/g, '');
    if (description) {
        description = description.replace(/'/g, '');
    }
    if (detail) {
        detail = detail.replace(/'/g, '');
    }

    const add_product_SQL = `
        INSERT INTO products SET
            product_id = '${product_id}',
            product_name = '${product_name}',
            category =  '${category}',
            price = ${price},
            available_stock = ${available_stock},
            image_url =   ${(image_list.length > 0) ? `'${image_list[0]}'` : null},
            image_list =  '${JSON.stringify(image_list)}',
            description =  ${description !== null ? `'${description}'` : null},
            nutritional_value = ${nutritional_value !== null ? `'${JSON.stringify(nutritional_value)}'` : null},
            detail = ${detail !== null ? `'${detail}'` : null} ;
    `;

    try {
        await query(add_product_SQL);
        const result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function update_product(event) {
    let {
        product_id,
        product_name,
        category,
        available_stock,
        image_list,
        description,
        nutritional_value,
        detail,
        after_discount
    } = JSON.parse(event.body);

    //ทุกค่าที่เป็น String -> ก่อนไปใส่ในคำสั่ง SQL ให้ทำการนำ ' ออก
    product_name = product_name.replace(/'/g, '');
    if (description) {
        description = description.replace(/'/g, '');
    }
    if (detail) {
        detail = detail.replace(/'/g, '');
    }

    const update_product_SQL = `
        UPDATE products SET
            product_name = '${product_name}',
            category =  '${category}',
            available_stock = ${available_stock},
            image_url =   ${(image_list.length > 0) ? `'${image_list[0]}'` : null},
            image_list =  '${JSON.stringify(image_list)}',
            description =  ${description !== null ? `'${description}'` : null},
            nutritional_value = ${nutritional_value !== null ? `'${JSON.stringify(nutritional_value)}'` : null},
            detail = ${detail !== null ? `'${detail}'` : null},
            after_discount = ${after_discount !== null ? `${after_discount}` : null}
        WHERE product_id = '${product_id}';
    `;

    try {
        await query(update_product_SQL);
        const result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function delete_product(event) {
    const {
        product_id
    } = JSON.parse(event.body);

    const delete_product_SQL = `DELETE FROM products WHERE product_id = '${product_id}';`;

    try {
        await query(delete_product_SQL);
        const result = success(createSuccessBody({ message: 'success' }));
        return result;
    } catch (error) {
        return error;
    }
}

export async function updateProductStock(event) { //ดึงข้อมูล Product Detail จาก Zortout เพิ่อมาอัพเดทจำนวนสินค้า
    const {
        product_id
    } = JSON.parse(event.body);

    const apiPath = `https://open-api.zortout.com/v4/Product/GetProducts?searchsku=${product_id}`;
    const apiHeaders = {
        headers: {
            storename: "saas@planforfit.com",
            apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
            apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ="
        }
    }

    try {
        let result;
        let availablestock;

        await axios.get(apiPath, apiHeaders)
            .then(response => {
                const data = response.data;
                const list = data.list;

                if (list.length > 0) { //เช็คว่ามีข้อมูลสินค้า
                    // เลือก product ที่ sku ตรงแบบเป๊ะๆ - ต้องมีไม่งั้น api ของ zort จะดึงตัวที่ sku คล้ายๆกันมาด้วย
                    const filter_list = list.filter(item => item.sku === product_id)[0];

                    availablestock = filter_list.availablestock;

                    result = success(createSuccessBody({ message: "success", product: filter_list }));
                } else { // ไม่มีข้อมูลสินค้า
                    result = success(createSuccessBody({ message: "fail" }));
                }

            })
            .catch(error => {
                // จัดการข้อผิดพลาด
                console.error('Error:', error);
            });
        const updateStockSQL = `
                UPDATE products
                SET available_stock = ${availablestock}
                WHERE product_id = '${product_id}';
                `;
        await query(updateStockSQL);
        return result;
    } catch (error) {
        return error;
    }
}