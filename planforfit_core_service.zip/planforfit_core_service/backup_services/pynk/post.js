import { queryRaw } from "./local_lib/dbhelper";
import { success, createSuccessBody } from "./local_lib/response-lib";

export async function postTest(event) {
  const { title, description } = JSON.parse(event.body);
  const query = `INSERT INTO content (title, description)
                    VALUES ('${title}', '${description}');`;
  try {
    await queryRaw(query);
    console.log(title, description);
    result = success(createSuccessBody({ message: "success" }));
    return result;
  } catch (error) {
    return error;
  }
}
