import sgMail from "@sendgrid/mail";
import { datacatalog } from "googleapis/build/src/apis/datacatalog";
import { dataflow } from "googleapis/build/src/apis/dataflow";
//sgMail.setApiKey("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");
sgMail.setApiKey(
  "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"
); //api ใหม่
//sgMail.setApiKey(process.env.NEW_SG_API);

export const sendPynkHtmlMail = async (to, from, subject, data, type) => {
  let html = {};
  switch (type) {
    case "order_thank":
      html = pynkOrderThank(data);
      break;
    case "requestTaxInvoice":
      html = pynkRequestTaxInvoice(data);
      break;
    default:
      html = pynkOrderThank(data);
  }
  const msg = {
    to,
    from,
    subject,
    html,
  };
  console.log("before send mail:", msg);
  try {
    await sgMail.send(msg);
    console.log("sending to ", to, " success");
  } catch (error) {
    console.error(error);

    if (error.response) {
      console.error(error.response.body);
    }
  }
};

export const sendHtmlMail = async (
  to,
  from,
  subject,
  content,
  mainLink,
  mainButtonLabel,
  type = "simple"
) => {
  let html = {};
  switch (type) {
    case "simple":
      html = simpleTemplate(subject, content, mainLink, mainButtonLabel);
      break;
    case "tbpa_register":
      html = registerTemplate();
      break;
    default:
      html = simpleTemplate(subject, content, mainLink, mainButtonLabel);
  }
  const msg = {
    to,
    from,
    subject,
    html,
  };
  try {
    await sgMail.send(msg);
  } catch (error) {
    console.error(error);
  }
};

export const pynkOrderThank = (data) =>
  `
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/bebeStayFit_Logo.png" type="image/x-icon" />
    <title>PYNK</title>
    <style>
        .body-email {
            margin: 0;
        }
       .head-email {
        background: -webkit-linear-gradient(#F45197, #ED0876); /* For Safari 5.1 to 6.0 */
        width: 100%;
        height: 94px;
       }
       .image-pynk {
        width: 105px;
        height: 35px;
        margin-top: 32px;
        margin-left: 45%;
    
       }
       .image-thank-you {
          width: 100%;
          height: 300px; 
          background-size: cover; 
          background-position: center center; 
          padding-top: 20%; 
          display: flex;
          align-items: center;
          justify-content: center;
       }   
       .span-thank-you { 
        color: #000000;
        font-size: 32px;
        font-weight: bold;
        margin-left: 35%;
     
       }
       .hello-you {
        margin-top: 32px;
        margin-left: 24px;
        margin-right: 24px;
        color: #000000;
        font-size: 16px;
        font-weight: bold;
       }
       .ordering {
        margin-top: 16px;
        margin-left: 24px;
        margin-right: 24px;
        color: #597284;
        font-size: 14px;
        margin-bottom: 50px;
       }
       .order-details-box {
        background-color: #E8E8E8;
        width: 100%;
        height: 300px;
        padding-top: 41px;
        padding-bottom: 80px;


       }
       .text-details {
        color: #131416;
        font-size: 16px;
        font-weight: bold;
        margin-left: 24px;
        margin-right: 24px;
    
       }
       .box-details {
        background-color: #FFFFFF;
        margin-left: 24px;
        width: 90%;
        min-height: 141px;
        padding: 16px;
       }
       .btn-pynk {
        margin-top: 32px;
   
        width: 321px;
        height: 49px;
        background-color: #EF60A3;
        color:#FFFFFF;
        border-radius: 50px;
        border: #EF60A3;
        font-size: 16px;
        font-weight: bold;
       }
       .ju-center {
        justify-content: center;
        display: flex;
       
       }
       .ju-center {
        margin-left: 35%;
       }
       .image-Layer_1 {
        margin-top: 32px;
        width: 108px;
        height: 33px;
        margin-left: 64px;
       }
       .online-training {
        margin-top: 32px;
        width: 100%;
        justify-content: center;
        display: flex;
        color: #7A7A7A;
        
       }
       .span-hr {
        margin-left: 16px;
        margin-right: 16px;
        border-left: 2px solid #7A7A7A;
        height: 22px;
       }
       .ml-icon {
        margin-left: 24px;
       }
       .img-icon {
        margin-top: 32px;
            width: 32px;
            height: 32px;
            margin-right: 12px;
        }
        .bbpt {
            margin-top: 32px;
            margin-bottom: 72px;
            font-weight: bold;
            font-size: 14px;
            color: #131416;
        }
        .ml-online {
          margin-left: 25%;
        }
        .between {
          justify-content: space-between;
          display: flex;
      }
      .right-align {
        
        margin-left: 15%;
    }
    </style>
</head>
<body class="body-email">
    <div class="head-email">
        <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/pynk.png" alt="" class="image-pynk">
    </div>

    <div style="background-image: url('https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/thank_you.png');" class="image-thank-you">
        <span class="span-thank-you">ขอบคุณที่ใช้บริการ PYNK</span>
    </div>
    <div class="hello-you">
        สวัสดีคุณ  ${data.name}
        <br>
        หวังว่าคุณจะเพลิดเพลินกับการซื้อสินค้าและบริการของเรา!
    </div>
    <div class="ordering">
        ข้อมูลการสั่งซื้อ 
        <br> หมายเลขคำสั่งซื้อ :  ${data.order_id}
        <br>วันที่ทำรายการ :  ${data.order_date}
        <br>ช่องทางการชำระเงิน: ${data.payment_method}
    </div>
    <div class="order-details-box">
        <p class="text-details">รายละเอียดคำสั่งซื้อ</p>
        <div class="box-details">
        ${data &&
  data.list
    .map(
      (item, index) =>
        `<div key=${index}>
               <div>${item.sku}</div>
               <div>${item.name
        } <span class="right-align">${item.totalprice.toLocaleString()} บาท </span></div>
               <div>ค่าจัดส่ง <span class="right-align">ฟรี  </span></div>
              
             </div>`
    )
    .join("")
  }
        <div>ยอดที่ชำระ <span class="right-align">${data.amount.toLocaleString()} บาท </span></div>
      </div>
    </div>
    <!--  <div class="ju-center">
        <button class="btn btn-pynk">
            ตรวจสอบสถานะคำสั่งซื้อ
        </button>
       
    </div> -->
    <div class="ju-center">
        <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/Layer_1.png" alt="" class="image-Layer_1">
    </div>

          <div class="online-training">
              <div class="ml-online">Online Training</div>
              <span class="span-hr"></span>
              <div>Stay Fit</div>
              <span class="span-hr"></span>
              <div>Exclusive Coaching</div>
              <span class="span-hr"></span>
              <div>สินค้า</div>
              <span class="span-hr"></span>
              <div>บทความ</div>
          </div>
       

       <div class="ju-center ">
        <div className="row ">
            <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/fb.png" class="img-icon ml-icon" />
            <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/Instagram.png" class="img-icon" />
            <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/line.png" class="img-icon" />
            <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/te.png" class="img-icon" />
          </div>
       </div>
       <div class="ju-center">
        <p class="bbpt">© 2022 BBPF RIGHTS RESERVED</p>
       </div>
      
</body>
</html>
`;

export const pynkRequestTaxInvoice = (content) =>
  `
<!DOCTYPE html>
  <html lang="en">
  
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <title>Bebe Stay Fit</title>
  
      <style type="text/css">
      @import url('https://fonts.googleapis.com/css2?family=Kanit&family=Prompt:wght@200;600;700;900&display=swap');
        .colored {
          color: #000000;
        }
        .center {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      body {
        font-family: 'Prompt', sans-serif;
      }
      table {
        font-size: 15px;
        border-collapse: collapse;
        width: 100%;
        background-color: white;
      }
      td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
      }
      
      </style>
  </head>
  
  <body>
    <div style="width: 100%;">
      <center>
          <div class='colored'>
              <div style="width: 900px; padding-bottom: 20px; display: table-cell;text-align: center;vertical-align: middle;border: 1px solid #FFF; box-shadow: 1px 3px 5px 5px #c4c4c4; border-radius: 10px;">
                <div style="background-color: #FFF; font-family: 'Prompt', sans-serif;">
                    <div style="margin-top: 60px;">
                        <div style="line-height:100%;">
                        <img src="https://pynk.s3.ap-southeast-1.amazonaws.com/products/emailOrderThank/Layer_1.png" style="padding-bottom: 20px">
                            <div>
                                <div style="border-bottom: 1px solid #707174; margin: 0px 40px 0px 40px;"></div>
                                <p style="font-size: 32px; font-weight: 600;">ขอใบกำกับภาษี</p>
                                <div style="border-bottom: 1px solid #707174;  margin: 0px 40px 0px 40px;"></div>
                            </div>
                        </div>
                        <div style="text-align:left; padding-left: 100px;  mmargin-top: 40px; font-size: 24px; line-height:100%;">
                            <p>เรียนฝ่ายบัญชี</p>
                            <br>
                            <p>ผู้ใช้ <span style="font-weight: 600;">${content.email}</span></p>
                            <p>ต้องการขอรับใบกำกับภาษี</p>
                            <div style=" box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); width: 90%; background-color: #F2F2F2;">
                              <div style="padding: 2px 16px;">
                                <p>Order ID : <span style="font-weight: 600;"> ${content.order_id} </span></p>
                                <p>ชื่อผู้เสียภาษี : <span style="font-weight: 600;"> ${content.InvoiceTaxpayerName} </span></p>    
                                <p>ชื่อสาขา (สำหรับนิติบุคคล) : <span style="font-weight: 600;"> ${content.InvoiceTaxpayerBranchName} </span></p>   
                                <p>เลขประจำตัวผู้เสียภาษี : <span style="font-weight: 600;"> ${content.InvoiceTaxIdentificationNumber} </span></p>   
                                <p>เบอร์โทรศัพท์ : <span style="font-weight: 600;"> ${content.InvoiceTelephone} </span></p>   
                                <p>ที่อยู่ออกใบกำกับภาษี : <span style="font-weight: 600;"> ${content.taxInvoiceAddress} </span></p>   
                                <p>ที่อยู่จัดส่งสินค้า : <span style="font-weight: 600;"> ${content.shippingaddress} </span></p> 
                                <p><span style="font-weight: 600;">รายการสินค้า</span></p>                          
                                <table>
                                  <tr>
                                    <th>#</th>
                                    <th>รหัส</th>
                                    <th>ชื่อสินค้า</th>
                                    <th>จำนวน</th>
                                  </tr>
                                  ${content.list.map((item, index) =>
    `
                                      <tr>
                                       <td>${index + 1}</td>
                                       <td>${item.sku}</td>
                                       <td>${item.name}</td>
                                       <td>${item.number}</td>
                                      </tr>
                                      `
  )}
                                </table>
                                <p>มูลค่ารวมสุทธิ : <span style="font-weight: 600;"> ${parseFloat(content.amount).toLocaleString('en')} บาท</span></p> 
                              </div> 
                            </div> 
                        </div>
                    </div>
                    <div style="font-family: 'Prompt', sans-serif; background-color: #F2F2F2; height: 100px; margin-top: 30px; line-height:70%; padding-top: 5px; padding-bottom: 5px;">
                        <p>ติดต่อเราที่</p>
                        <p>contact@bebefitroutine.com</p>
                        <p>โทร 028216146</p>
                    </div>
                </div>
            </div>
          </div>
      </center>
    </div>
  </body>
  </html>
`;