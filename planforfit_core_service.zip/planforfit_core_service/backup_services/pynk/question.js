import { query, queryRaw } from "./local_lib/dbhelper";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody,
} from "./local_lib/response-lib";

export async function insert_question(event) {
    const {
      user_id,
      data,
    } = JSON.parse(event.body);
  
    const insert_question = `
          INSERT INTO question SET
          user_id = '${user_id}',
          data = '${JSON.stringify(data)}';
      `;
  
    try {
      await query(insert_question);
      const result = success(
        createSuccessBody({ message: "success" })
      );
      return result;
    } catch (error) {
      return error;
    }
  }