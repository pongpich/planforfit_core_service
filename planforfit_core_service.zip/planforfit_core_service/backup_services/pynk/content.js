import { queryRaw } from "./local_lib/dbhelper";
import { success, createSuccessBody } from "./local_lib/response-lib";
import axios from 'axios';

export async function getContent() { //ดึงข้อมูล Products จาก DB ของ PYNK
  const query = `select * from content `;

  try {
    let result;
    const queryResult = await queryRaw(query);
    result = success(createSuccessBody({ contents: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}

