import { query, queryRaw } from "./local_lib/dbhelper";
import { success, createSuccessBody } from "./local_lib/response-lib";
import md5 from "md5";
import { uuidv4 } from "./local_lib/Utils";

export async function login(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: "no_user" }));
    } else {
      const user = queryResult[0];
      const hash = md5(password);
      const isMatch = hash === user.password;
      result =
        isMatch && user.authorization === "member"
          ? success(createSuccessBody({ message: "success", user: user }))
          : success(createSuccessBody({ message: "fail" }));
    }

    return result;
  } catch (error) {
    return error;
  }
}

export async function login_admin(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: "no_user" }));
    } else {
      const user = queryResult[0];
      const hash = md5(password);
      const isMatch = hash === user.password;
      result =
        isMatch && user.authorization === "admin"
          ? success(createSuccessBody({ message: "success", user: user }))
          : success(createSuccessBody({ message: "fail" }));
    }

    return result;
  } catch (error) {
    return error;
  }
}

export async function register(event) {
  const { email, password, first_name, last_name, phone } = JSON.parse(
    event.body
  );

  const hash = md5(password);
  const selectUser = `select * from member where email='${email}';`;
  const queryString = `
              INSERT INTO member SET 
                  user_id='${uuidv4()}', 
                  email='${email}',
                  password='${hash}',
                  first_name='${first_name}',
                  last_name='${last_name}',
                  phone='${phone}'
                  ;`;
  try {
    let result;
    const userResult = await queryRaw(selectUser);
    //เช็คว่ามี user ในระบบไหม
    if (userResult.length <= 0) {
      await query(queryString);
      result = success(createSuccessBody({ message: "success" }));
    } else {
      result = success(createSuccessBody({ message: "fail" }));
    }

    return result;
  } catch (error) {
    return error;
  }
}

export async function registerLoginGoogle(event) {
  const { email, first_name, last_name } = JSON.parse(event.body);

  const selectUser = `select * from member where email='${email}';`;
  const queryString = `
              INSERT INTO member SET 
                  user_id='${uuidv4()}', 
                  email='${email}',
                  first_name='${first_name}',
                  last_name='${last_name}'
                  ;`;
  try {
    let result;
    const userResult = await queryRaw(selectUser);
    //เช็คว่ามี user ในระบบไหม
    if (userResult.length <= 0) {
      await query(queryString);
      result = success(createSuccessBody({ message: "success" }));
    } else {
      result = success(createSuccessBody({ message: "fail" }));
    }

    return result;
  } catch (error) {
    return error;
  }
}

export async function updateRegister(event) {
  const {
    id,
    email,
    password,
    first_name,
    last_name,
    phone,
    name_display_system,
    facebook,
    birthday,
    sex,
  } = JSON.parse(event.body);

  const selectPass = `SELECT password FROM member WHERE user_id = '${id}';`;

  const pass = await queryRaw(selectPass);
  const passwordFromQuery = pass[0].password;

  var hash = password;
  if (password != passwordFromQuery) {
    hash = md5(password);
  }

  const selectUser = `select * from member where email='${email}'  AND user_id != '${id}';`;
  const selectData = `select * from member where user_id = '${id}';`;
  const queryString = `
  UPDATE member
  SET 
      email = '${email}',
      password = '${hash}',
      first_name = '${first_name}',
      last_name = '${last_name}',
      phone = '${phone}',
      name_display_system = '${name_display_system}',
      facebook = '${facebook}',
      birthday = '${JSON.stringify(birthday)}',
      sex = '${sex}'
  WHERE user_id = '${id}';`;
  try {
    let result;
    const userResult = await queryRaw(selectUser);
    //เช็คว่ามี user ในระบบไหม
    if (userResult.length <= 0) {
      await query(queryString);
      const updatedUser = await queryRaw(selectData);
      const updatedUserData = updatedUser[0]; // อาจต้องแก้ไข
      const result = success(
        createSuccessBody({
          message: "success",
          user: updatedUserData,
        })
      );
      return result;
    } else {
      result = success(createSuccessBody({ message: "fail" }));
      return result;
    }
  } catch (error) {
    return error;
  }
}

export async function postAddress(event) {
  const { id, address, addressStatus } = JSON.parse(event.body);
  const selectUser = `SELECT * FROM member WHERE (address IS NULL) AND (user_id = '${id}');`;
  const selectData = `SELECT * FROM member WHERE  user_id = '${id}';`;

  const query = `UPDATE member
                    SET address = '${JSON.stringify(address)}'
                    WHERE user_id = '${id}';`;
  try {
    const queryResult = await queryRaw(selectUser);
    let result;
    if (queryResult.length <= 0) {
      // กรณี มีข้อมูล อยู่เเล้ว เเละ updateAddress  true
      if (addressStatus == "true") {
        await queryRaw(query); // มีข้อมูล ให้เพิ่มข้อมูล เเละ = true
        const dataQuery = await queryRaw(selectData); // มีข้อมูล ให้เพิ่มข้อมูล เเละ = true

        console.log("dataQuery", dataQuery[0]);
        result = success(
          createSuccessBody({ message: "success", user: dataQuery[0] })
        );
      }
    } else {
      await queryRaw(query); // กรณี ไม่มีข้อมูล ให้เพิ่มข้อมูล เเละ = false
      const dataQuery = await queryRaw(selectData); // มีข้อมูล ให้เพิ่มข้อมูล เเละ = true
      result = success(
        createSuccessBody({ message: "success", user: dataQuery[0] })
      );
    }

    return result;
  } catch (error) {
    return error;
  }
}
