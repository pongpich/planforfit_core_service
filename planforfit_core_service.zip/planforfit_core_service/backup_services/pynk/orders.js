import { query, queryRaw } from "./local_lib/dbhelper";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody,
} from "./local_lib/response-lib";
import axios from "axios";

export async function create_order(event) {
  const {
    user_id,
    product_list,
    total_amount,
    customer_data,
    shipping_address,
    tax_invoice_address,
    note,
    payment_method,
  } = JSON.parse(event.body);

  const create_order_SQL = `
        INSERT INTO orders SET
        user_id = '${user_id}', 
        product_list = '${JSON.stringify(product_list)}', 
        total_amount = ${total_amount}, 
        customer_data = '${JSON.stringify(customer_data)}', 
        shipping_address = '${JSON.stringify(shipping_address)}',
        tax_invoice_address = ${
          tax_invoice_address
            ? `'${JSON.stringify(tax_invoice_address)}'`
            : "NULL"
        },
        note = '${note}',
        payment_method = '${payment_method}';
        SELECT LAST_INSERT_ID() as order_id;
    `;

  try {
    const resultCreateOrder = await query(create_order_SQL);
    const resultCreateOrderJSON = JSON.parse(resultCreateOrder.body);
    const order_id = resultCreateOrderJSON.results[1][0].order_id;
    const result = success(
      createSuccessBody({ message: "success", order_id: order_id })
    );
    return result;
  } catch (error) {
    return error;
  }
}

export async function getTrackingOrders(event) {
  //ผู้ใช้แต่ละคน ใช้ดึงข้อมูล orders และเช็คสถานะสินค้าของตัวเอง
  const { user_id } = event.queryStringParameters;

  const selectOrdersSQL = `
    select * from orders
    where user_id = '${user_id}'
    `;

  try {
    let result;
    const queryResult = await queryRaw(selectOrdersSQL);
    const orders = queryResult.filter((order) => order.zort_order_id !== null);
    if (orders.length > 0) {
      //เข้าเคส มี Orders
      const numberlist = orders.map((order) => order.zort_order_id).join(",");
      const apiPath = `https://open-api.zortout.com/v4/Order/GetOrders?numberlist=${numberlist}`;
      const apiHeaders = {
        headers: {
          storename: "saas@planforfit.com",
          apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
          apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ=",
        },
      };

      await axios
        .get(apiPath, apiHeaders)
        .then((response) => {
          const data = response.data;
          const list = data.list;

          // สร้าง map จาก list เพื่อเข้าถึง status โดยใช้ number เป็น key
          const statusMap = list.reduce((acc, item) => {
            acc[item.number] = {
              status: item.status,
              trackingno: item.trackingno,
              shippingchannel: item.shippingchannel,
            };
            return acc;
          }, {});

          // นำ status จาก statusMap มาใส่ใน orders ที่ตรงกับ number ของแต่ละ order_id
          const updatedOrders = orders.map((order) => {
            const data = statusMap[order.zort_order_id];
            return {
              ...order,
              delivery_status: data ? data.status : "", // ถ้าไม่พบ status จะกำหนดเป็นค่าที่ต้องการ
              tracking_no: data ? data.trackingno : "", // เพิ่มข้อมูล trackingno
              shipping_channel: data ? data.shippingchannel : "",
            };
          });
          result = success(
            createSuccessBody({
              message: "success",
              tracking_orders: updatedOrders,
            })
          );
        })
        .catch((error) => {
          // จัดการข้อผิดพลาด
          console.error("Error:", error);
        });
    } else {
      //เข้าเคส ไม่มี Orders
      result = success(createSuccessBody({ message: "fail" }));
    }

    return result;
  } catch (error) {
    return error;
  }
}

export async function getAllOrders() {
  //แอดมินใช้ดึงข้อมูล Order ทั้งหมดในระบบ
  const selectSQL = `select * from orders`;
  try {
    let result;

    const queryResult = await queryRaw(selectSQL);
    result = success(createSuccessBody({ all_orders: queryResult }));
    return result;
  } catch (error) {
    return error;
  }
}
