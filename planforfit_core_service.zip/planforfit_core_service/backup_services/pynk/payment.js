import { query, queryRaw } from "./local_lib/dbhelper";
import axios from "axios";
import {
    success,
    failure,
    createSuccessBody,
    createFailureBody,
} from "./local_lib/response-lib";
import { sendPynkHtmlMail } from "./local_lib/mail-helper";

var moment = require("moment-timezone");
moment.tz.setDefault("Asia/Bangkok");

export async function ocr(event) {
    const { image, language, type } = JSON.parse(event.body);

    try {
        const apiPath = "https://apis.aigen.online/aiscript/general-ocr/v1";
        const apiHeaders = {
            headers: {
                "x-aigen-key": "SBn3r6odpzkaiqgyz7b75eu4h03ga7q8xc",
            },
        };
        const apiBody = {
            image: image,
            language: language,
            type: type,
        };

        const respond = await axios.post(apiPath, apiBody, apiHeaders);
        const data = respond.data.result;
        const result = success(createSuccessBody({ data: data }));
        return result;
    } catch (error) {
        return error;
    }
}

async function create_zort_order(
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    order_id,
    zort_order_id,
    shippingaddress,
    list,
    total_amount,
    tax_invoice_address_full
) {
    const apiPath =
        "https://api.zortout.com/api.aspx?method=ADDORDER&version=3&format=json";
    const apiHeaders = {
        headers: {
            storename: "saas@planforfit.com",
            apikey: "JL2of5yQGP8AFEiIOC9iV8sF9Z6JfdL9T0H8uOPkJHA=",
            apisecret: "/CWMFFMPyvTh/ZniGz1YtjVlGgAdg1pnFRkug4CRqQ=",
        },
    };

    const currTimeZone = new Date(moment(new Date()).format("YYYY-MM-DD")); //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    const orderdate = `${moment(currTimeZone).format("YYYY-MM-DD")}`;
    const vatamount = `${(total_amount * (7 / 107)).toFixed(2)}`;

    const apiBody = {
        number: zort_order_id,
        customername: customerName,
        customeremail: customerEmail,
        customerphone: customerTelephone,
        customeraddress: shippingaddress,
        shippingchannel: "Flash express",
        shippingname: customerName,
        shippingemail: customerEmail,
        shippingphone: customerTelephone,
        shippingaddress: shippingaddress,
        saleschannel: "PYNK",
        orderdate: orderdate,
        amount: amount,
        paymentamount: amount,
        shippingamount: 0,
        vatamount: vatamount,
        vattype: 3,
        paymentmethod: "GBPay",
        list: list,
        customeridnumber: tax_invoice_address_full? tax_invoice_address_full.InvoiceTaxIdentificationNumber : "",
    };
    console.log("apiBody :", apiBody);
    await axios.post(apiPath, apiBody, apiHeaders); // เรียกใช้ api ของ zort
}

export async function setQRStatus(event) {
    const { customerEmail: email, status } = JSON.parse(event.body);

    console.log("inside setQRStatus:", event.body);
    const queryString = `
      INSERT INTO qr_status VALUES ('${email}','${status}') 
      ON DUPLICATE KEY UPDATE \`status\`='${status}';
    `;

    try {
        const result = await query(queryString);
        return result;
    } catch (error) {
        return error;
    }
}

export async function checkQRStatus(event) {
    const { email } = event.queryStringParameters;

    const queryString = `
      SELECT status 
      FROM qr_status
      WHERE email = '${email}';
    `;

    try {
        const result = await query(queryString);
        return result;
    } catch (error) {
        return error;
    }
}

export async function GBResponse(event) {
    //เรียกใช้ตอนผู้ใช้จ่ายเงิน QR code และ บัตรเครดิต
    const {
        amount,
        referenceNo,
        gbpReferenceNo,
        resultCode,
        date,
        detail,
        customerName,
        customerEmail,
        customerTelephone,
        customerAddress,
        merchantDefined1: order_id,
    } = JSON.parse(event.body);
    console.log(
        "inside gbpp:",
        amount,
        referenceNo,
        gbpReferenceNo,
        resultCode,
        date,
        detail,
        customerName,
        customerEmail,
        customerTelephone,
        customerAddress,
        order_id
    );

    console.log("before if");
    //เช็คว่าชำระเงินสำเร็จหรือไม่
    if (resultCode.toString() !== "00")
        return success(createSuccessBody({ message: "unsuccess payment" }));
    console.log("after if");

    try {
        const zort_order_id = `PYNK-${order_id}`;
        const queryString = `
            UPDATE orders
            SET payment_status = 'success', gb_reference_no = '${gbpReferenceNo}', zort_order_id = '${zort_order_id}'
            WHERE order_id = '${order_id}';
        `;
        await query(queryString);

        const queryString2 = `
            INSERT INTO qr_status VALUES ('${customerEmail}','success')
            ON DUPLICATE KEY UPDATE status ='success';
    `;
        await query(queryString2);

        //ดึงข้อมูลต่างๆ จาก Order เพื่อนำไปใช้สร้าง Order ใน Zortout
        const queryOrder = ` SELECT * FROM orders
        WHERE order_id = '${order_id}';`;
        const resultOrder = await queryRaw(queryOrder);
        const shippingaddress_full = JSON.parse(resultOrder[0].shipping_address);
        const shippingaddress = `${shippingaddress_full.address} ${shippingaddress_full.subdistrict} ${shippingaddress_full.district} ${shippingaddress_full.province} ${shippingaddress_full.zipcode}`;
        const tax_invoice_address_full = resultOrder[0].tax_invoice_address
            ? JSON.parse(resultOrder[0].tax_invoice_address)
            : "";
        console.log("tax_invoice_address_full :", tax_invoice_address_full);
        const list = JSON.parse(resultOrder[0].product_list);
        const total_amount = JSON.parse(resultOrder[0].total_amount);
        const payment_method = resultOrder[0].payment_method;

        //สร้าง order ใน Zortout
        await create_zort_order(
            amount,
            referenceNo,
            gbpReferenceNo,
            resultCode,
            date,
            detail,
            customerName,
            customerEmail,
            customerTelephone,
            customerAddress,
            order_id,
            zort_order_id,
            shippingaddress,
            list,
            total_amount,
            tax_invoice_address_full
        );

        const currentDate = new Date();

        // สร้างอ็อบเจ็กต์ DateTimeFormat ในภาษาไทย
        const thaiDateFormatter = new Intl.DateTimeFormat("th-TH", {
            year: "2-digit",
            month: "short",
            day: "numeric",
            hour: "numeric",
            minute: "numeric",
            second: "numeric",
            hour12: false, // ให้แสดงในรูปแบบ 24 ชั่วโมง
        });

        // ใช้ DateTimeFormat เพื่อรับวันที่แบบเต็มในภาษาไทย
        const formattedDate = thaiDateFormatter.format(currentDate);

        const to = customerEmail;
        const from = "contact@planforfit.com";
        const subject = `ยืนยันคำสั่งซื้อหมายเลข ${zort_order_id}`;
        const data = {
            name: customerName,
            order_id: zort_order_id,
            order_date: `${formattedDate} น.`,
            payment_method: payment_method,
            list: list,
            amount: amount,
        };
        console.log("data:", data);

        await sendPynkHtmlMail(to, from, subject, data, "order_thank");
        console.log("after sendPynkHtmlMail!");

        //---------------------------------- ส่งอีเมลขอใบกำกับภาษี ไปยังฝ่ายบัญชี --------------------------------------
        //const toAccountant = "thanet@planforfit.com"; //ใส่อีเมลของฝ่ายบัญชี (เทส)
        //const toAccountant = "akkewach@planforfit.com"; //ใส่อีเมลของฝ่ายบัญชี (เทส)
        const toAccountant = 'acc@planforfit.com'; //ใส่อีเมลของฝ่ายบัญชี (ใช้จริง)
        const subjectRequestTaxInvoice = `ขอใบกำกับภาษี จากคำสั่งซื้อสินค้า Pynk`;

        if (tax_invoice_address_full) {
            // ถ้ามี receipt_address แสดงว่าขอใบกำกับภาษี
            const taxInvoiceAddress = `${tax_invoice_address_full.address} ${tax_invoice_address_full.subdistrict} ${tax_invoice_address_full.district} ${tax_invoice_address_full.province} ${tax_invoice_address_full.zipcode}`;
            console.log("taxInvoiceAddress :", taxInvoiceAddress);
            const contentRequestTaxInvoice = {
                email: customerEmail,
                order_id: zort_order_id,
                InvoiceTaxpayerName: tax_invoice_address_full.InvoiceTaxpayerName,
                InvoiceTaxpayerBranchName:
                    tax_invoice_address_full.InvoiceTaxpayerBranchName,
                InvoiceTaxIdentificationNumber:
                    tax_invoice_address_full.InvoiceTaxIdentificationNumber,
                InvoiceTelephone: tax_invoice_address_full.InvoiceTelephone,
                taxInvoiceAddress: taxInvoiceAddress,
                shippingaddress: shippingaddress,
                list: list,
                amount: amount,
            };
            console.log("contentRequestTaxInvoice :", contentRequestTaxInvoice);
            await sendPynkHtmlMail(
                toAccountant,
                from,
                subjectRequestTaxInvoice,
                contentRequestTaxInvoice,
                "requestTaxInvoice"
            );
            console.log("after sendPynkHtmlMail");
        }
    } catch (error) {
        return error;
    }
}

function getResultCode(body) {
    if (!body) return "01";

    const bodyParsed = body.split("&");
    const resultArray = bodyParsed.filter((elem) =>
        elem.toLowerCase().includes("resultcode")
    );

    if (resultArray.length > 0) {
        const resultCode = resultArray[0].split("=")[1];
        return resultCode;
    } else {
        return "01";
    }
}

export async function thankyouRoute(event, context, callback) {
    console.log("inside thankyouRoute:", event);
    const resultCode = getResultCode(event.body);
    if (resultCode !== "00") {
        const responseErr = {
            statusCode: 200,
            headers: {
                "content-type": "text/html; charset=UTF-8",
            },
            body: `
        <!DOCTYPE html>
        <html lang="en">
            
            <head>
              <title>PYNK</title>
            </head>
            
            <body>
              <div>
              </div>
              <script>
                window.location = "https://pynk.co/#/error-payment"
              </script>
            </body>
        </html>
        `,
        };
        callback(null, responseErr);
        //ตัวลิงค์ https://pynk.co/#/error-payment ไปทำเป็นหน้าชำระเงินด้วยบัตรไม่สำเร็จแจ้งผู้ใช้ (ปัจจุบันยังไม่ได้ทำ)
    }

    const response = {
        statusCode: 200,
        headers: {
            "content-type": "text/html; charset=UTF-8",
        },
        body: `
      <!DOCTYPE html>
      <html lang="en">
          
          <head>
            <title>PYNK</title>
          </head>
          
          <body>
            <div>
            </div>
            <script>
              window.location = "https://pynk.co/#/successful-payment"
            </script>
          </body>
      </html>
      `,
    };
    callback(null, response);
}
