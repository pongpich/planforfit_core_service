import md5 from 'md5';
import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import { getUrlVars } from "./local_lib/Utils";
import { uuidv4 } from "./local_lib/Utils";
import { htmlSuccess, success, createSuccessBody } from "./local_lib/response-lib";
import {
  formatLogs,
  checkTeamWeightCompleteness,
  distributeTeamScore,
  addIndividualScore,
  isAVGWeightLessThanLastWeek,
  isExerciseCompleted,
  getBonusScoreFromRank,
  sumOldScore,
  calculateEndRank
} from "./util/challengeScore";
import { legend } from "./util/scoreLegend";
import { sendHtmlMail } from "./local_lib/mail-helper";
import moment from 'moment';
import { calculateWeekInProgram } from './util/schedule';

export async function insertQuestionnaireLog(event) {
  const {
    user_id,
    log
  } = JSON.parse(event.body);

  const selectSQL = `
  select * from questionnaire_log 
  where user_id = '${user_id}' and log = '${log}'
`;

  const insertSQL = `
  insert into questionnaire_log 
  set user_id = '${user_id}', log = '${log}', log_value = 'done'
  `;

  try {
    let result;
    const queryResult = await queryRaw(selectSQL);
    if (queryResult.length > 0) {
      //not to do
    } else {
      await queryRaw(insertSQL);
    }
    result = success(createSuccessBody({ message: 'success' })) //สำเร็จ
    return result;
  } catch (error) {
    return error;
  }
}

export async function insertNewsLog(event) {
  const {
    user_id,
    log
  } = JSON.parse(event.body);

  const selectSQL = `
  select * from news_log 
  where user_id = '${user_id}' and log = '${log}'
`;

  const insertSQL = `
  insert into news_log 
  set user_id = '${user_id}', log = '${log}', log_value = 'done'
  `;

  try {
    let result;
    const queryResult = await queryRaw(selectSQL);
    if (queryResult.length > 0) {
      //not to do
    } else {
      await queryRaw(insertSQL);
    }
    result = success(createSuccessBody({ message: 'success' })) //สำเร็จ
    return result;
  } catch (error) {
    return error;
  }
}

export async function sendTeamInvite(event) {
  const {
    user_id,
    to
  } = JSON.parse(event.body); // user_id = ของผู้ส่งคำเชิญร่วมทีม, to = email ปลายทางที่ต้องการเชิญ

  //เพิ่มการเช็คว่าผู้ได้รับคำเชิญ และผู้ส่งคำเชิญ เข้ามร่วมทีม ต้องอยู่ fb_group เดียวกัน (สำหรับ Platform Bebe เก่า)
  const selectReceiverSQL = `
                                select * from member
                                where email = '${to}' and fb_group = (select fb_group from member where user_id = '${user_id}')
                                `

  const selectTeamInviteSQL = `
                                select * from team_invite
                                where sender_id = '${user_id}' and receiver_id = (select user_id from member where email = '${to}') and status = 'default'
                                `

  const insertTeamInviteSQL = `
                                insert into  team_invite
                                set sender_id = '${user_id}', receiver_id = (select user_id from member where email = '${to}')
                                `

  try {
    let result;
    const selectTeamInviteResult = await queryRaw(selectTeamInviteSQL);
    const selectReceiverResult = await queryRaw(selectReceiverSQL);
    if (selectReceiverResult.length > 0) { //เช็คว่าอีเมลที่กรอกตอนเชิญเข้าร่วมทีมมีอยู่จริงไหมในระบบ
      if (selectTeamInviteResult.length > 0) { //เช็คว่าผู้ส่ง เคยส่งคำเชิญเข้าร่วมทีมให้ผู้รับคนนี้หรือยัง
        result = success(createSuccessBody({ message: 'team_invite_exists' })) //คำเชิญซ้ำ
      } else {
        await queryRaw(insertTeamInviteSQL);
        result = success(createSuccessBody({ message: 'success' })) //สำเร็จ
      }
    } else {
      result = success(createSuccessBody({ message: 'user_not_exists' })) //ไม่มี user ที่ต้้องการเชิญเข้าร่วมทีมอยู่ในระบบ
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function sendFriendRequest(event) {
  const {
    user_id,
    to
  } = JSON.parse(event.body); // user_id = ของผู้ส่งคำขอเพื่อน, to = email ปลายทางที่ต้องการแอดไป

  const selectReceiverSQL = `
                                select * from member
                                where email = '${to}'
                                `

  const selectFriendRequstSQL = `
                                select * from friend_request
                                where sender_id = '${user_id}' and receiver_id = (select user_id from member where email = '${to}') and status = 'default'
                                `

  const insertFriendRequstSQL = `
                                insert into  friend_request
                                set sender_id = '${user_id}', receiver_id = (select user_id from member where email = '${to}')
                                `

  try {
    let result;
    const selectFriendRequstResult = await queryRaw(selectFriendRequstSQL);
    const selectReceiverResult = await queryRaw(selectReceiverSQL);
    if (selectReceiverResult.length > 0) { //เช็คว่าอีเมลที่กรอกตอนแอดเพื่อนมีอยู่จริงไหมในระบบ
      if (selectFriendRequstResult.length > 0) { //เช็คว่าผู้ส่ง เคยส่งคำขอเพื่อนให้ผู้รับคนนี้หรือยัง
        result = success(createSuccessBody({ message: 'friend_request_exists' })) //คำขอซ้ำ
      } else {
        await queryRaw(insertFriendRequstSQL);
        result = success(createSuccessBody({ message: 'success' })) //สำเร็จ
      }
    } else {
      result = success(createSuccessBody({ message: 'user_not_exists' })) //ไม่มี user ที่ต้้องการเพิ่มเพื่อนอยู่ในระบบ
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function leaveTeam(event) {
  const {
    user_id
  } = JSON.parse(event.body);

  const selectNumbOfMemberSQL = `
                                select Count(*) as count from member
                                where group_id in (select group_id from member where user_id = '${user_id}');
                                `;

  const updateGroupIDSQL = `  UPDATE member
                              SET group_id = NULL
                              WHERE user_id = '${user_id}'`;

  const deleteGroupSQL = `  DELETE FROM challenge_group 
                              WHERE group_id in (select group_id from member where user_id = '${user_id}');`;

  try {
    const selectNumbOfMemberResult = await queryRaw(selectNumbOfMemberSQL);
    const numbOfMember = selectNumbOfMemberResult[0].count;
    console.log("numbOfMember :", numbOfMember);
    if (numbOfMember <= 1) { //ถ้าสมาชิกเหลือคนสุดท้าย ให้ทำการลบทีมนั้นหลังจากออกด้วย 
      await queryRaw(deleteGroupSQL);
    }
    await queryRaw(updateGroupIDSQL);
  } catch (error) {
    return error;
  }
}


/* export async function assignGroupToMember(event) { // Ver.ไม่มี fb_group
  const {
    user_id,
    start_date
  } = JSON.parse(event.body);

  const MaxNumberOfMember = 10;
  const randomGroupSQL = `  
    SELECT group_id FROM challenge_group
    WHERE (SELECT count(*) AS count FROM member WHERE group_id = challenge_group.group_id)<${MaxNumberOfMember}
    ORDER BY (SELECT count(*) AS count FROM member WHERE group_id = challenge_group.group_id)
    LIMIT 1;
  ` ;

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน
  const challengeActivityInWeekCountSQL = ` SELECT count(*) AS count FROM challenge_activity
                                            WHERE user_id = '${user_id}' AND week_in_program = '${week}';`;
  const createChallengeActivitySQL = `  INSERT INTO challenge_activity
                                        SET user_id = '${user_id}', week_in_program = '${week}', 
                                            start_rank = 'newbie' ; `;
  const updateChallengeActivitySQL = `  UPDATE challenge_activity
                                        SET start_rank = 'newbie' 
                                        WHERE user_id = '${user_id}' AND week_in_program = '${week}'`;

  try {
    const randomGroupResult = await queryRaw(randomGroupSQL);
    const group_id = randomGroupResult[0].group_id;
    const assignGroupToMemberSQL = `  UPDATE member 
                                      SET group_id = '${group_id}'
                                      WHERE user_id = '${user_id}'; `;
    await queryRaw(assignGroupToMemberSQL);

    const challengeActivityInWeekCountResult = await queryRaw(challengeActivityInWeekCountSQL);
    const challengeActivityInWeekCount = challengeActivityInWeekCountResult[0].count;
    if (challengeActivityInWeekCount > 0) { //เช็คว่าweekนั้น มีchallengeActivityอยุ๋แล้วไหม 
      await queryRaw(updateChallengeActivitySQL); //ถ้ามี ใช้การ update
    } else {
      await queryRaw(createChallengeActivitySQL); //ถ้าไม่มี ใช้การ insert
    }
  } catch (error) {
    return error;
  }
} */

export async function insertSubscriptionProducts(event) {
  const {
    email,
    products_list,
    delivery_address,
    receipt_address
  } = JSON.parse(event.body);

  const queryUserId = ` SELECT user_id FROM member
  WHERE member.email = '${email}';`;

  console.log("products_list :", products_list);
  console.log("delivery_address :", delivery_address);
  console.log("receipt_address :", receipt_address);

  try {
    const resultUserId = await queryRaw(queryUserId);
    var user_id = resultUserId[0].user_id;
    console.log("user_id :", user_id);
    const queryString4 = `
          INSERT INTO subscription_products SET user_id = '${user_id}', products_list = '${JSON.stringify(products_list)}', delivery_address='${JSON.stringify(delivery_address)}', receipt_address='${JSON.stringify(receipt_address)}'
          ON DUPLICATE KEY UPDATE products_list = '${JSON.stringify(products_list)}', delivery_address='${JSON.stringify(delivery_address)}', receipt_address='${JSON.stringify(receipt_address)}';
  `;
    await query(queryString4);
  } catch (error) {
    return error;
  }
}

export async function assignGroupToMember(event) { // Ver.มี fb_group
  const {
    user_id,
    start_date,
    fb_group
  } = JSON.parse(event.body);

  const MaxNumberOfMember = 10;
  const randomGroupSQL = `  
    SELECT group_id FROM challenge_group
    WHERE fb_group = '${fb_group}'
    AND 
    (SELECT count(*) AS count FROM member WHERE group_id = challenge_group.group_id)<${MaxNumberOfMember}
    ORDER BY (SELECT count(*) AS count FROM member WHERE group_id = challenge_group.group_id)
    LIMIT 1;
  ` ;

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน
  const challengeActivityInWeekCountSQL = ` SELECT count(*) AS count FROM challenge_activity
                                            WHERE user_id = '${user_id}' AND week_in_program = '${week}';`;
  const createChallengeActivitySQL = `  INSERT INTO challenge_activity
                                        SET user_id = '${user_id}', week_in_program = '${week}', 
                                            start_rank = 'newbie' ; `;
  const updateChallengeActivitySQL = `  UPDATE challenge_activity
                                        SET start_rank = 'newbie' 
                                        WHERE user_id = '${user_id}' AND week_in_program = '${week}'`;
  const currentGroupIDSQL = `SELECT group_id FROM member WHERE user_id = '${user_id}';`;
  const userPeriodSQL = ` SELECT start_date, expire_date FROM member 
                          WHERE user_id = '${user_id}';`;

  try {
    const randomGroupResult = await queryRaw(randomGroupSQL);
    const userPeriodResult = await queryRaw(userPeriodSQL);
    var curr = new Date().getTime();
    var expireDate_user = new Date(userPeriodResult[0].expire_date).getTime();
    const group_id = randomGroupResult[0].group_id;
    const assignGroupToMemberSQL = `  UPDATE member 
                                      SET group_id = '${group_id}'
                                      WHERE user_id = '${user_id}'; `;
    const currentGroupIDResult = await queryRaw(currentGroupIDSQL);
    const currentGroup = currentGroupIDResult[0].group_id; //ใช้เช็ค group_id ปัจจุบัน  
    if (!currentGroup && (curr < expireDate_user)) { // ถ้า group_id ปัจจุบันเป็น null และ ผู้ใช้ยังไม่หมดอายุ เท่านั้น ถึงจะทำการ assign group_id ที่สุ่มได้ให้ (เคยมีบัคผู้ใช้กดสุ่มทีมหลายครั้งจาก frontend )
      await queryRaw(assignGroupToMemberSQL);

      const challengeActivityInWeekCountResult = await queryRaw(challengeActivityInWeekCountSQL);
      const challengeActivityInWeekCount = challengeActivityInWeekCountResult[0].count;
      if (challengeActivityInWeekCount > 0) { //เช็คว่าweekนั้น มีchallengeActivityอยุ๋แล้วไหม 
        //await queryRaw(updateChallengeActivitySQL); //ถ้ามี ใช้การ update
      } else {
        await queryRaw(createChallengeActivitySQL); //ถ้าไม่มี ใช้การ insert
      }
    }
  } catch (error) {
    return error;
  }
}

/* export async function createChallengeGroup(event) { // Ver.ไม่มี fb_group
  const {
    user_id,
    group_name,
    start_date
  } = JSON.parse(event.body);

  const createChallengeGroupSQL = ` INSERT INTO challenge_group
                                    SET group_name = '${group_name}'; `;

  const assignGroupToMemberSQL = ` UPDATE member 
                                SET group_id = (SELECT group_id FROM challenge_group WHERE group_name='${group_name}')
                                WHERE user_id = '${user_id}'; `;

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน
  const challengeActivityInWeekCountSQL = ` SELECT count(*) AS count FROM challenge_activity
                                            WHERE user_id = '${user_id}' AND week_in_program = '${week}';`;
  const createChallengeActivitySQL = `  INSERT INTO challenge_activity
                                        SET user_id = '${user_id}', week_in_program = '${week}', 
                                        start_rank = 'newbie' ; `;
  const updateChallengeActivitySQL = `  UPDATE challenge_activity
                                        SET start_rank = 'newbie' 
                                        WHERE user_id = '${user_id}' AND week_in_program = '${week}'`;
  try {
    await queryRaw(createChallengeGroupSQL);
    await queryRaw(assignGroupToMemberSQL);
    const challengeActivityInWeekCountResult = await queryRaw(challengeActivityInWeekCountSQL);
    const challengeActivityInWeekCount = challengeActivityInWeekCountResult[0].count;
    if (challengeActivityInWeekCount > 0) { //เช็คว่าweekนั้น มีchallengeActivityอยุ๋แล้วไหม 
      await queryRaw(updateChallengeActivitySQL); //ถ้ามี ใช้การ update
    } else {
      await queryRaw(createChallengeActivitySQL); //ถ้าไม่มี ใช้การ insert
    }
  } catch (error) {
    return error;
  }
} */

export async function createChallengeGroup(event) { // Ver.มี fb_group
  const {
    user_id,
    group_name,
    start_date,
    fb_group
  } = JSON.parse(event.body);

  const createChallengeGroupSQL = ` INSERT INTO challenge_group
                                    SET group_name = '${group_name}', fb_group = '${fb_group}'; `;

  const assignGroupToMemberSQL = ` UPDATE member 
                                SET group_id = (SELECT group_id FROM challenge_group WHERE group_name='${group_name}')
                                WHERE user_id = '${user_id}'; `;

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน
  const challengeActivityInWeekCountSQL = ` SELECT count(*) AS count FROM challenge_activity
                                            WHERE user_id = '${user_id}' AND week_in_program = '${week}';`;
  const createChallengeActivitySQL = `  INSERT INTO challenge_activity
                                        SET user_id = '${user_id}', week_in_program = '${week}', 
                                        start_rank = 'newbie' ; `;
  const updateChallengeActivitySQL = `  UPDATE challenge_activity
                                        SET start_rank = 'newbie' 
                                        WHERE user_id = '${user_id}' AND week_in_program = '${week}'`;
  const checkGroupNameCountSQL = `  SELECT count(*) AS count FROM challenge_group
                                        WHERE group_name = '${group_name}';`;
  const currentGroupIDSQL = `SELECT group_id FROM member WHERE user_id = '${user_id}';`;
  const userPeriodSQL = ` SELECT start_date, expire_date FROM member 
                          WHERE user_id = '${user_id}';`;

  try {
    let result;
    const currentGroupIDResult = await queryRaw(currentGroupIDSQL);
    const currentGroup = currentGroupIDResult[0].group_id; //ใช้เช็ค group_id ปัจจุบัน  
    const userPeriodResult = await queryRaw(userPeriodSQL);
    var curr = new Date().getTime();
    var expireDate_user = new Date(userPeriodResult[0].expire_date).getTime();
    const checkGroupNameCountResult = await queryRaw(checkGroupNameCountSQL);
    const checkGroupNameCount = checkGroupNameCountResult[0].count;
    if (!currentGroup && (curr < expireDate_user) && (checkGroupNameCount === 0)) { // ถ้า group_id ปัจจุบันเป็น null และ ผู้ใช้ยังไม่หมดอายุ เท่านั้น ถึงจะทำการ สร้างทีม และ assign group_id ให้ 
      await queryRaw(createChallengeGroupSQL);
      await queryRaw(assignGroupToMemberSQL);
      result = success(createSuccessBody({ message: 'success' }))

      const challengeActivityInWeekCountResult = await queryRaw(challengeActivityInWeekCountSQL);
      const challengeActivityInWeekCount = challengeActivityInWeekCountResult[0].count;
      if (challengeActivityInWeekCount > 0) { //เช็คว่าweekนั้น มีchallengeActivityอยุ๋แล้วไหม 
        //await queryRaw(updateChallengeActivitySQL); //ถ้ามี ใช้การ update
      } else {
        await queryRaw(createChallengeActivitySQL); //ถ้าไม่มี ใช้การ insert
      }
    } else {
      if (checkGroupNameCount > 0) {
        result = success(createSuccessBody({ message: 'teamNameExist' }))
      }
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function importMembers(event) {
  const {
    members,
    start_date,
    expire_date,
    kol = 'จินนี่'
  } = JSON.parse(event.body);

  const week = calculateWeekInProgram(start_date);
  const batch = Math.ceil(week / 8);
  console.log("week :", week);
  console.log("batch :", batch);

  const password = md5("123456");
  //start_date = IF(datediff('${start_date}', expire_date) >= 30, '${start_date}', start_date), สำหรับเช็คว่าหมดอายุเกิน 30วัน
  let queryStrings = members.map(member => `
      INSERT INTO member (user_id, email, \`password\`, first_name, last_name, phone, facebook, kol, start_date, expire_date)
      VALUES
        ('${uuidv4()}', '${member.email}', '${password}', '${member.first_name}', '${member.last_name}', '${member.phone}', '${member.facebook}', '${kol}', '${start_date}', '${expire_date}')
      ON DUPLICATE KEY UPDATE
        kol = '${kol}',
        start_date = '${start_date}',
        expire_date = '${expire_date}';
    `);
  try {
    const result = await transaction(queryStrings);
    return success(createSuccessBody({ message: "success" }));;
  } catch (error) {
    return error;
  }
}

export async function createMemberFromContent(event) {
  const {
    email,
    order_status,
    first_name,
    last_name,
    items
  } = event;//JSON.parse(event.body);//

  const { isOnlineCourse, coursePeriod } = findCourseInOrder(items, order_status);

  if (isOnlineCourse) {
    const expire_date = `${moment().add(coursePeriod, 'days').format('YYYY/MM/DD')} 23:59:59`;
    const start_date = `${moment().add(0, 'days').format('YYYY/MM/DD')} 00:00:00`;

    const queryString = `
        INSERT INTO member (user_id, email, first_name, last_name, start_date, expire_date)
        VALUES
          ('${uuidv4()}', '${email}', '${first_name}', '${last_name}', '${start_date}', '${expire_date}')
        ON DUPLICATE KEY UPDATE
          start_date = IF(datediff('${start_date}', expire_date) >= 30, '${start_date}', start_date),
          expire_date = DATE_ADD(COALESCE(expire_date, '${expire_date}'), INTERVAL ${coursePeriod} DAY);
      `;

    try {
      const result = await query(queryString);

      const to = email;
      const from = 'contact@bebefitroutine.com';
      const subject = "การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว!"
      const content = `การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว
                        รับความสนุกและสุขภาพดีจาก BEBE FIT ROUTINE ได้ที่ปุ่มด้านล่างนี้เลย
                      `
      const mainLink = process.env.STAGE === "prod"
        ? "https://platform.bebefitroutine.com"
        : "http://localhost:3000";
      const mainButtonLabel = "เข้าระบบ Platform";

      console.log("to:", to, "from:", from, "mainLink:", mainLink);
      await sendHtmlMail(to, from, subject, content, mainLink, mainButtonLabel);

      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  } else {
    const failMessage = "There is no online course in this order";
    console.log(failMessage)
    return success(createSuccessBody(failMessage));
  }
}

async function hasChallengeEventActive() {
  const getLatestChallengeEventSQL = `SELECT  master.event_id, master.event_name, master.start_date, 
                                                master.expire_date, detail.week_in_event, detail.is_processed
                                        FROM challenge_event master LEFT OUTER JOIN challenge_event_log detail
                                            ON master.event_id = detail.event_id
                                            AND detail.week_in_event = CalcWeekInProgram(master.start_date)
                                        WHERE curdate() BETWEEN start_date AND expire_date
                                        ORDER BY start_date DESC
                                        LIMIT 1;`;
  try {
    const latestChallengeEvent = await queryRaw(getLatestChallengeEventSQL);
    if (latestChallengeEvent && latestChallengeEvent.length > 0 && !latestChallengeEvent[0].is_processed) {
      return latestChallengeEvent[0];
    } else {
      return false;
    }
  } catch (error) {
    return false;
  };
}

function generateMemberLogEventInsertStmt(pUserId, logData, logValue, score) {
  return `
          INSERT INTO member_event_log (user_id, log, log_value, log_type, score)
          VALUES ('${pUserId}', '${logData.log}', '${logValue}', '${logData.log_type}', ${score});
        `;
}

export async function dailyWeightScore(event) {
  const {
    user_id,
    weight
  } = JSON.parse(event.body);

  //หากในจังหวะที่มีการเรียกใช้ฟังก์ชั่นนี้เพื่อคำนวณคะแนนรายสัปดาห์
  //จะต้องตรวจดูก่อนว่ามี challenge event ที่ active อยู่หรือไม่ 
  //หากไม่มีจะไม่ทำการรันฟังก์ชั่น
  const hasActiveChallenge = await hasChallengeEventActive();
  if (!hasActiveChallenge) {
    console.log("Not allow to execute this service!");
    return success(createSuccessBody({ message: "Not allow to execute this service!" }));
  }

  const dailyIndividualWeightCountSQL = `
  select count(*) as count
  from member_event_log
  where user_id = '${user_id}'
    AND log = 'weight'
      ANd log_type = 'individual'
      AND DATE(created_at) =  CURDATE();
    `;

  /*เช็คว่าหากผู้ใใช้คนนี้เคยมีข้อมูลการกรอกน้ำหนักในสัปดาห์นั้นมาแล้ว 1 ครั้ง ให้เพิมคะแนนให้ผู้ใช้คนนี้*/
  const weeklyIndividualWeightCountSQL = `
        select count(*) as count
        from member_event_log
        where user_id = '${user_id}'
          AND log = 'weight'
            ANd log_type = 'individual'
            AND created_at BETWEEN 
              getMondayOfTheWeek(CURDATE())
              AND 
              getSundayOfTheWeek(CURDATE());
          `;

  try {
    const dailyIndividualWeightCountResult = await queryRaw(dailyIndividualWeightCountSQL);
    if (dailyIndividualWeightCountResult[0].count > 0) { // เช็คเพื่อแก้บัค service dailyIndividualWeight ทำงานเกิน 1ครั้ง ภายใน 1วัน
      console.log("this user was already enter weight data today")
      return success(createSuccessBody({ message: "this user was already enter weight data today" }));
    }
    const weeklyIndividualWeightCountResult = await queryRaw(weeklyIndividualWeightCountSQL);
    const weeklyIndividualWeightCount = weeklyIndividualWeightCountResult[0].count;


    //เช็คว่าหากผู้ใช้คนนี้เคยมีข้อมูลการกรอกน้ำหนักในสัปดาห์นั้นมาแล้ว 1 ครั้ง ให้เพิมคะแนนให้ผู้ใช้คนนี้
    const individualScore = weeklyIndividualWeightCount === 1 ? 10 : 0;

    //เมื่อไหร่ก็ตามที่สมาชิกคนใดคนหนึ่งในทีมกรอกน้ำหนัก (เรียก service ตัวนี้) จะมีการแจกคะแนนให้สมาชิกทั้งทีม
    //แต่หากในวันดังกล่าวเคยมีการแจกคะแนนไปแล้ว (count ที่ได้มามีค่ามากกว่า 0) จะไม่มีการแจกอีก
    let transactionStatements = [];
    const individualLogData = legend[0];
    transactionStatements.push(generateMemberLogEventInsertStmt(user_id, individualLogData, weight, individualScore));
    const teamLogData = legend[1];

    const groupMembersSQL = `
                              select m.user_id, COALESCE(log.score, 0) as team_score
                              from member m LEFT OUTER JOIN member_event_log log
                                ON m.user_id = log.user_id
                                AND log.log = 'weight bonus'
                                AND log.log_type = 'team'
                                AND DATE(log.created_at) = CURDATE()
                              where m.user_id IN (
                                    select m2.user_id from member m2
                                    where m2.group_id = (select m3.group_id from member m3 where m3.user_id='${user_id}')
                                  );
            `;
    const groupMembers = await queryRaw(groupMembersSQL);
    //zeroScoreGroupMembers คือ กรองเอาเฉพาะคนที่ยังไม่ได้รับคะแนน team_score ในวันนั้น
    const zeroScoreGroupMembers = groupMembers.filter(member => member.team_score === 0);
    const groupMembersTransaction = zeroScoreGroupMembers.map(element => generateMemberLogEventInsertStmt(element.user_id, teamLogData, 0, 10));
    transactionStatements = transactionStatements.concat(groupMembersTransaction);
    const result = await transaction(transactionStatements);
    return result;
  } catch (error) {
    return error;
  }
}

export async function weeklyScore() {
  //หากในจังหวะที่มีการเรียกใช้ฟังก์ชั่นนี้เพื่อคำนวณคะแนนรายสัปดาห์
  //จะต้องตรวจดูก่อนว่ามี challenge event ที่ active อยู่หรือไม่ 
  //หากไม่มีจะไม่ทำการรันฟังก์ชั่น
  const latestChallengeEvent = await hasChallengeEventActive();
  if (!latestChallengeEvent) {
    console.log("Not allow to execute this service!")
    return success(createSuccessBody({ message: "Not allow to execute this service!" }));
  }
  //ดึงข้อมูล log ของทั้งระบบเฉพาะในสัปดาห์ทีกำลังคำนวณคะแนน
  //ด้วยเหตุที่ฟังก์ชั่นนี้จะถูกเรียกใช้ทุกวันอาทิตย์เวลาใกล้เที่ยงคืน 
  //ทางทีมพัฒนาเกรงว่า อาจจะเกิดอุบัตเหตุอะไรบางอย่างจนทำให้การคำนวณล่วงเลยไปจนถึงวันจันทร์ซึ่งเป็นสัปดาห์ถัดไปได้
  //หากเกิดกรณีนี้ขึ้นจริง ค่าขอบเขตเวลาที่จะดึงข้อมูล log จะผิดเพี้ยน 
  //จึงทำการป้องกันด้วยประโยค getMondayOfTheWeek(DATE_SUB(CURDATE(), INTERVAL 1 DAY)) และ
  //getSundayOfTheWeek(DATE_SUB(CURDATE(), INTERVAL 1 DAY)) 
  //ซึ่งหมายความถึงดึงข้อมูลวันจันทร์ และวันอาทิตย์จากวันเสาร์ แทนที่จะเป็นวันเวลาปัจจุบันที่ใกล้กลับสัปดาห์มากเกินไปอย่างที่แจ้งไปแล้ว
  const getLogsSQL = `  
                        SELECT mlog.*, DATE_FORMAT(mlog.created_at, '%Y-%m-%d') as activity_date, m.group_id 
                        FROM member_event_log mlog JOIN member m
                          ON mlog.user_id = m.user_id
                        WHERE mlog.created_at BETWEEN
                          date_sub(getMondayOfTheWeek(DATE_SUB(CURDATE(), INTERVAL 1 DAY)), INTERVAL 7 DAY)
                            AND
                            getSundayOfTheWeek(DATE_SUB(CURDATE(), INTERVAL 1 DAY))
                        ;
                      `;

  //ดึงข้อมูลครั้งเดียวได้ทั้ง member และ exercise_activity ไปพร้อม ๆ กัน
  const getMembersSQL = `  select m.user_id, m.group_id, act.activities, m.start_date,
                            coalesce(cact.start_rank, "newbie") as start_rank, coalesce(cact.end_rank, "") as end_rank
                          from member m LEFT OUTER JOIN exercise_activity act
                            ON m.user_id = act.user_id
                              AND act.week_in_program = CalcWeekInProgram(m.start_date) LEFT OUTER JOIN challenge_activity cact
                              ON m.user_id = cact.user_id
                              AND cact.week_in_program = CalcWeekInProgram(m.start_date)
                          where CURDATE() <= expire_date;`;

  try {
    const logs = await queryRaw(getLogsSQL);
    const members = await queryRaw(getMembersSQL);
    //formatLogs เป็นการจัดระเบียน log ดิบ ๆ ให้อยู่ในรูปแบบของการแบ่ง group 
    //โดยแต่ละ group จะมีทั้ง group_id, log data และ members โดยละเอียดเพื่อสะดวกต่อการนำไปใช้งานต่อ 
    //จุดประสงค์เพื่อมิให้มีการ interact กับฐานข้อมูลระหว่างการคำนวณโดยไม่จำเป็น 
    //(เป้าหมายคือการติดต่อกับ DB เฉพาะตอนเริ่มกับตอนจบเท่านั้น)
    const formatedLogs = formatLogs(logs, members);
    const transactionStatements = [];
    const step1LogData = legend[2];
    const step2LogData = legend[3];
    const step3LogData = legend[4];
    const step4LogData = legend[5];
    //console.log("formatedLogs :", formatedLogs)

    for (let index = 0; index < formatedLogs.length; index++) {
      //ขั้นที่ 1: สำหรับทีมที่มีสมาชิกในทีมชั่งและบันทึกน้ำหนักมาครบทั้งสัปดาห์จะได้คะแนนทีม 10 คะแนน
      //ฟังก์ชั่น checkTeamWeightCompleteness ใช้สำหรับ
      //ตรวจสอบว่าสมาชิกในแต่ละ group 
      //1.1. ได้ชั่งน้ำหนักครบทุกคนในสัปดาห์ปัจจุบัน
      //1.2. แต่ละคนชั่งครบสองครั้งในสัปดาห์ปัจจุบัน
      if (formatedLogs[index].group_id) { //ส่งไปเช็คแค่คนที่มีทีม ถ้าผู้เล่นไม่มีทีมไม่ต้องส่งไปเช็ค
        if (checkTeamWeightCompleteness(formatedLogs[index])) {
          //distributeTramScore จะเป็นการแจกคะแนนเข้าไปใน field members ของ 
          //log ที่ได้รับการจัดระเบียบไปเรียบร้อยแล้ว ซึ่งในที่นี้คือตัวแปร formatedLogs
          const newMembers = distributeTeamScore(formatedLogs[index]);
          formatedLogs[index] = { ...formatedLogs[index], members: newMembers };
          //create insert statement
          for (let index = 0; index < newMembers.length; index++) {
            const { user_id, new_score } = newMembers[index];
            transactionStatements.push(generateMemberLogEventInsertStmt(user_id, step1LogData, 0, new_score));
          }
        }
      }

      //ไล่จัดการกับสมาชิกแต่ละคนภายในทีมนี้ (external for loop)
      const { members } = formatedLogs[index];
      for (let memberIndex = 0; memberIndex < members.length; memberIndex++) {
        let member = members[memberIndex];
        const { user_id } = member;

        //ขั้นที่ 2: ถ้าค่าเฉลี่ยน้ำหนักลดลง (Wkn  < Wkn-1) จะได้คะแนน 10 คะแนน
        //การที่ต้องถอยวันคำนวนหนึ่งวัน ด้วยเหตุผลเดียวกับการเรียก sql ตรงตำแหน่งบรรทัดแรกสุดของฟังก์ชั่นนี้
        const dateToCheck = moment().subtract(1, 'days').format("YYYY-MM-DD");
        if (isAVGWeightLessThanLastWeek(formatedLogs[index], member.user_id, dateToCheck)) {
          const step2Score = 10;
          const memberGotWeightLossScore = addIndividualScore(member, step2Score);
          member = memberGotWeightLossScore;
          transactionStatements.push(generateMemberLogEventInsertStmt(user_id, step2LogData, 0, step2Score));
        }

        //ขั้นที่ 3: หาก member คนนี้เล่นวิดีโอครบทุกคลิป จะได้บวกเพิ่มอีก 10 คะแนน
        if (isExerciseCompleted(JSON.parse(member.activities))) {
          const step3Score = 10;
          const memberGotExerciseCompleteScore = addIndividualScore(member, step3Score);
          member = memberGotExerciseCompleteScore;
          transactionStatements.push(generateMemberLogEventInsertStmt(user_id, step3LogData, 0, step3Score));
        }

        //ขั้นที่ 4: หาก rank เป็น gold จะได้ 5 แต้ม หากเป็น platinum จะได้ 10 แต้ม
        const step4Score = getBonusScoreFromRank(member.start_rank);
        member.new_score = (member.new_score ? member.new_score : 0) + step4Score
        transactionStatements.push(generateMemberLogEventInsertStmt(user_id, step4LogData, member.start_rank, step4Score));

        //ขั้นที่ 5: ลด/เลื่อนขั้น โดยใช้เงื่อนไขดังต่อไปนี้
        //* ถ้าคะแนนส่วนบุคคล + คะแนนทีม > 40 คะแนน จะได้เลื่อนขั้น
        //* ถ้าคะแนนส่วนบุคคล + คะแนนทีม <= 40 คะแนน จะถูกลดขั้น
        //เริ่มต้นด้วยการรวมคะแนนทั้งสัปดาห์ที่ได้รับมาจาก service dailyWeightScore ทั้งหมด
        const old_score = sumOldScore(formatedLogs[index], member.user_id, dateToCheck);
        member.old_score = old_score;

        const totalScore = member.new_score + member.old_score;
        const end_rank = calculateEndRank(member.start_rank, totalScore);
        member.end_rank = end_rank;
        members[memberIndex] = member;

        //========= SQL section =============
        const programStartDate = moment(member.start_date).format('YYYY-MM-DD');

        //สำหรับกรณี rank ใหม่นั้น เราจะต้องทำงานสองชั้น
        //1. update field end_rank ในตาราง challenge_activity ของ member คนนี้โดยใช้ end_rank ที่คำนวณได้ในปัจจุบัน
        const updateCurrentActivitySQL = `
        UPDATE challenge_activity SET end_rank = '${member.end_rank}' 
        WHERE user_id = '${user_id}' AND week_in_program = CalcWeekInProgram('${programStartDate}');
        `;
        transactionStatements.push(updateCurrentActivitySQL);

        //2. insert ข้อมูลสัปดาห์ใหม่ในตาราง challenge_activity ของ member คนนี้เพื่อนำ end_rank ที่คำนวณได้ในปัจจุบันไปใช้ในสัปดาห์หน้า
        const newChallengeActivityInsertSQL = `
        INSERT INTO challenge_activity (user_id, week_in_program, start_rank, end_rank)
        VALUES ('${user_id}', CalcWeekInProgram('${programStartDate}') + 1, '${member.end_rank}', '');
        `;
        transactionStatements.push(newChallengeActivityInsertSQL);

      }
    }

    //ท้ายสุด เราต้องทำการใส่ข้อมูลเพื่อแสดงให้เห็นว่า สัปดาห์นี้ได้มีการคำนวน weekly score ให้กับสมาชิกแล้ว
    //วิธีการคือ แทรกข้อมูลใน table challenge_event_log
    const formatedEventStartDate = moment(latestChallengeEvent.start_date).format('YYYY-MM-DD');
    const insertNewWeekChallengeActLog = `
    INSERT INTO challenge_event_log (event_id, week_in_event, is_processed)
    VALUES ('${latestChallengeEvent.event_id}', CalcWeekInProgram('${formatedEventStartDate}'), 1);
    `;
    transactionStatements.push(insertNewWeekChallengeActLog);

    const result = await transaction(transactionStatements);
    return result;
  } catch (error) {
    return error;
  }
}

function findCourseInOrder(items, orderStatus) {
  const minCoursePeriod = 60;
  let coursePeriod = minCoursePeriod;
  let isOnlineCourse = false;
  if (orderStatus === "completed") {
    for (let index = 0; index < items.length; index++) {
      const item = items[index];

      isOnlineCourse = item.name.toLowerCase().indexOf("course") >= 0;
      if (isOnlineCourse) {
        const periodMatchs = item.name.match(/\d+/g);
        coursePeriod = periodMatchs && (periodMatchs.length > 0) && (parseInt(periodMatchs[0]) >= minCoursePeriod)
          ? parseInt(periodMatchs[0])
          : minCoursePeriod;
        break;
      }
    }
  }

  return { isOnlineCourse, coursePeriod };
}

export async function createOrder(event) {
  const { order_no, user_id, program_id, price, pay_type, urlPaySlip } = JSON.parse(event.body);
  try {
    const queryString = `
            INSERT INTO \`order\` SET
              order_no='${order_no}', user_id='${user_id}', program_id='${program_id}', 
              amount='${price}', pay_type='${pay_type}', slip='${urlPaySlip}';
        `;
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function createBestClipDashboard(event) {
  const { event_id, clip_quality = "best" } = JSON.parse(event.body);
  const reduceCriteria = (clip_quality === "best") ? "count(log.user_id) > 2" : "count(log.user_id) <= 2";
  try {
    const queryString = `
    select act.activities, reduced.user_id, reduced.event_name, reduced.start_date, reduced.expire_date
    from exercise_activity act JOIN
        (SELECT log.user_id,
                log.log,
                log.log_type,
                ce.event_id,
                ce.event_name,
                ce.start_date,
                ce.expire_date,
                count(log.user_id) as reduced_weight_count
        FROM member_event_log log
                JOIN challenge_event ce ON log.created_at BETWEEN ce.start_date AND ce.expire_date
        GROUP BY log.user_id, log.log, log.log_type, ce.event_id, ce.event_name, ce.start_date, ce.expire_date
        HAVING log.log_type = 'individual'
            AND log.log = 'reduced weight'
            AND ${reduceCriteria}
            AND ce.event_id = ${event_id}
        ORDER BY ce.event_name) as reduced
      ON act.user_id = reduced.user_id
      AND act.created_at BETWEEN  reduced.start_date AND reduced.expire_date;
        `;
    const results = await queryRaw(queryString);
    const event_name = results[0].event_name;
    let bestClipCount = {};
    for (let index = 0; index < results.length; index++) {
      const activities = JSON.parse(results[index].activities);
      const allActs = activities.flat();
      for (let i = 0; i < allActs.length; i++) {
        const act = allActs[i];
        if (act.play_time >= (0.9 * act.duration)) {
          const typeField = act.type.toLowerCase().replace(" ", "_");
          if (bestClipCount[typeField]) {
            if (bestClipCount[typeField][act.name]) {
              bestClipCount[typeField] = { ...bestClipCount[typeField], [act.name]: bestClipCount[typeField][act.name] + 1 }
            } else {
              bestClipCount[typeField] = { ...bestClipCount[typeField], [act.name]: 1 }
            }
          } else {
            bestClipCount[typeField] = { [act.name]: 1 }
          }
        }
      }
    }

    for (const type in bestClipCount) {
      if (Object.hasOwnProperty.call(bestClipCount, type)) {
        const clipType = bestClipCount[type];
        const sortClip = Object.entries(clipType)
          .sort(([, a], [, b]) => b - a)[0][0];
        bestClipCount[type] = sortClip;
      }
    }

    const {
      warm_up,
      chest_focus,
      sub_circuit,
      cardio,
      cool_down,
      back_focus,
      leg_focus,
      arm_focus
    } = bestClipCount;

    const biInsertQuery = `
        INSERT INTO bi_clip_count 
          ( event_id, event_name, warm_up, 
            chest_focus, sub_circuit, cardio, 
            cool_down, back_focus, leg_focus, 
            arm_focus, clip_quality
          )
        VALUES
          (
            '${event_id}', '${event_name}', '${warm_up}',
            '${chest_focus}', '${sub_circuit}', '${cardio}',
            '${cool_down}', '${back_focus}', '${leg_focus}', 
            '${arm_focus}', '${clip_quality}'
          )
        ON DUPLICATE KEY UPDATE
          warm_up = '${warm_up}',
          chest_focus = '${chest_focus}',
          sub_circuit = '${sub_circuit}',
          cardio = '${cardio}',
          cool_down = '${cool_down}',
          back_focus = '${back_focus}',
          leg_focus = '${leg_focus}',
          arm_focus = '${arm_focus}',
          clip_quality= '${clip_quality}';
      `

    const result = await query(biInsertQuery);
    return result;
  } catch (error) {
    return error;
  }
}

export async function executePaytree(event) {
  const urlParams = getUrlVars(event.body);

  const order_no = urlParams.order_no;
  const user_idQueryString = `select user_id from \`order\` where order_no ='${order_no}' ;`;
  const user_idQuery = await queryRaw(user_idQueryString);
  const user_id = user_idQuery[0].user_id;
  const program_idQueryString = `select program_id from \`order\` where order_no ='${order_no}' ;`;
  const program_idQuery = await queryRaw(program_idQueryString);
  const program_id = program_idQuery[0].program_id;
  const periodQueryString = `select period from program where program_id ='${program_id}' ;`;
  const periodQuery = await queryRaw(periodQueryString);
  const period = periodQuery[0].period;

  const expire_date = `${moment().add(period, 'days').format('YYYY/MM/DD')} 23:59:59`;
  const start_date = `${moment().add(0, 'days').format('YYYY/MM/DD')} 00:00:00`;

  const status = (urlParams.res_msg === "success") ? "Approve" : urlParams.res_msg;

  const queryString = `
            UPDATE \`order\` SET 
            status= '${status}'
            WHERE order_no='${order_no}';
        `;
  const queryString2 = `
        UPDATE member SET 
            start_date='${start_date}', expire_date='${expire_date}'
            WHERE user_id = '${user_id}';
    `;

  const urlBebePlatform = (process.env.STAGE === "prod") ?
    `https://platform.bebefitroutine.com/`
    :
    (process.env.STAGE === "dev") ?
      `https://staging.platform.bebefitroutine.com/`
      :
      "http://localhost:3000";

  try {
    if (urlParams.res_msg === "success") { //ระบบทำการต่ออายุอัตโนมัติ หากชำระเงินสำเร็จ
      await query(queryString2);
    }
    await query(queryString);


    const html = (urlParams.res_msg === "success") ?
      renderExecutePaytreeSuccess(urlBebePlatform)
      :
      renderExecutePaytreeFail(urlBebePlatform);

    return htmlSuccess(html);
  } catch (error) {
    return htmlSuccess(renderExecutePaytreeFail(urlBebePlatform));
  }
}

const renderExecutePaytreeSuccess = (urlBebePlatform) => (
  `
  <html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title>Bebe Fit</title>
    </head>
    <body>
      <div class="center">
          <div class="row mt-5">
          <div class="col-lg-4 mt-5">
          </div>
          <div class="col-lg-8 mt-5">
            <h2 class="mt-5 ml-2">ชำระเงินสำเร็จ</h2>
            <div class="card col-lg-11 mt-3 shadow-sm">
              <div class="card-body">
                  <center><h4 class="mt-3">thank you</h4></center>
              </div>
            </div>
            <div class="col-lg-11 mt-4">
              <button type="button" class="btn btn-danger" style= "width: 100%" onclick="location.href='${urlBebePlatform}'">
                ใช้งาน Platform
              </button>
            </div>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
          </div>
        </div>
      </div>
    </body>
  </html>

  `
)

const renderExecutePaytreeFail = (urlBebePlatform) => (
  `
  <html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title>Bebe Fit</title>
    </head>
    <body>
      <div class="center">
          <div class="row mt-5">
          <div class="col-lg-4 mt-5">
          </div>
          <div class="col-lg-8 mt-5">
            <h2 class="mt-5 ml-2">ชำระเงินไม่สำเร็จ</h2>
            <div class="card col-lg-11 mt-3 shadow-sm">
              <div class="card-body">
                  <center><h4 class="mt-3">ระบบชำระเงินไม่สำเร็จกรุณาชำระเงินใหม่อีกครั้ง</h4></center>
              </div>
            </div>
            <div class="col-lg-11 mt-4">
              <button type="button" class="btn btn-danger" style= "width: 100%" onclick="location.href='${urlBebePlatform}'">
                กลับหน้าหลัก
              </button>
            </div>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
            <h1 class="mt-5 text-light">.</h1>
          </div>
        </div>
      </div>
    </body>
  </html>

  `
)
