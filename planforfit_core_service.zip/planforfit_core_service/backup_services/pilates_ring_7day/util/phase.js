//import moment from 'moment';
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");
const phase = () => {
  return {
    "1-28": [
      {
        category: "warm up",
        amount: 1
      },
      {
        category: "main circuit",
        amount: 1
      },
      {
        category: "sub circuit",
        amount: 1
      },
      {
        category: "cardio",
        amount: 0
      },
      {
        category: "cool down",
        amount: 1
      }
    ]
  }
}

export const calculatePhase = (dayInProgram, weight, program_level, set_phase) => {
  const returnPhase = phase(weight, program_level);
  if (set_phase === 'none') {//กรณีผู้ใช้เลื่อน Phase ตามโปรแกรมปกติ (แบบดั้งเดิม)
    if (dayInProgram <= 28) {
      return returnPhase["1-28"]; // Phase 1
    } else if (dayInProgram <= 56) {
      return returnPhase["29-56"]; // Phase 2 (1)
    } else if (dayInProgram <= 112) {
      return returnPhase["57-112"] // Phase 3 (2)
    } else if (dayInProgram <= 168) {
      return returnPhase["113-168"] // Phase 4 (3)
    } else if (dayInProgram <= 224) {
      return returnPhase["169-224"] // Phase 5 (4)
    } else if (dayInProgram <= 280) {
      return returnPhase["225-280"] // Phase 6 (5)
    } else if (dayInProgram <= 336) {
      return returnPhase["281-336"] // Phase 7 (6)
    } else {
      return returnPhase["337-392"] // Phase 8 (7)
    }
  } else { //กรณีผู้ใช้ไม่ยอมเลื่อน Phase ตามโปรแกรมปกติ หรือเคยมีการขอไม่เลื่อน Phase (จะมีการ set_phase ไว้)
    if (set_phase === 'phase1') {
      return returnPhase["1-28"]; // Phase 1
    }
    if (set_phase === 'phase2') {
      return returnPhase["29-56"]; // Phase 2 (1)
    }
    if (set_phase === 'phase3') {
      return returnPhase["57-112"] // Phase 3 (2)
    }
    if (set_phase === 'phase4') {
      return returnPhase["113-168"] // Phase 4 (3)
    }
    if (set_phase === 'phase5') {
      return returnPhase["169-224"] // Phase 5 (4)
    }
    if (set_phase === 'phase6') {
      return returnPhase["225-280"] // Phase 6 (5)
    }
    if (set_phase === 'phase7') {
      return returnPhase["281-336"] // Phase 7 (6)
    }
    if (set_phase === 'phase8') {
      return returnPhase["337-392"] // Phase 8 (7)
    }
  }

}

export const getPhase = (startDate, offset, weight, endDate, program_level, set_phase) => {
  startDate = moment(startDate).format('YYYY-MM-DD');
  endDate = moment(endDate).format('YYYY-MM-DD');
  let endDateMoment = endDate ? moment(endDate) : moment();
  const programStartDate = moment(startDate).add(offset, 'days');
  // ต้อง +2 เพราะว่า diff นับระยะห่างวันแค่ตรงกลางไม่นับวันที่เป็นจุดเริ่มต้น และ วันที่เป็นจุดสิ้นสุด
  console.log("programStartDate :", programStartDate);
  console.log("endDateMoment :", endDateMoment);
  let dayInProgram = endDateMoment.diff(programStartDate, 'days') + 2;
  console.log("dayInProgram :", dayInProgram);
  // กรณีที่ endDateMoment ไม่มากกว่า programStartDate (คือวันแรก) ต้องกำหนด dayInProgram = 1 (ถ้าไม่กำหนดจะได้เป็น 2 ซึ่งผิด)
  if (!(endDateMoment > programStartDate)) { dayInProgram = 1 };
  return calculatePhase(dayInProgram, weight, program_level, set_phase);
}
