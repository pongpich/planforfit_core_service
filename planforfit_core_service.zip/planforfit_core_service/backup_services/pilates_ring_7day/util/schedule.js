import { query, queryRaw } from "../local_lib/dbhelper";
//import moment from 'moment';
import { getPhase } from "./phase";

var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

// ------------------------schedule video-------------------------------

function array_rand(array, amount) {
  const min = 0;
  const max = array.length - 1;
  let arr = [];
  while (arr.length < amount) {
    var r = Math.round(Math.random() * (max - min) + min);
    if (arr.indexOf(r) === -1) arr.push(r);
  }
  return arr;
}

export function getWarmUp(videos) {
  let rt = videos.filter(element => element.category.toLowerCase() === 'warm up') || '';
  return rt;
}

export function getCoolDown(videos) {
  let rt = videos.filter(element => element.category.toLowerCase() === 'cool down') || '';
  return rt;
}

export function getMainCircuitByType(type, clipGen = ['1'], videos) { //array[('2')]
  let rt = videos.filter(element =>
    (element.category.toLowerCase() === 'main circuit')
    && (element.type.toLowerCase() === type.toLowerCase())
    && (clipGen.includes(element.clip_gen))
  ) || '';
  return rt;
}

/* export  function getChallengeByType(type, clipGen = ["('1')"]) {
  const queryString = `
            select * from vdo_detail 
            where (lower(category) = 'challenge' and type='${type}' and clip_gen in ${clipGen})
            `;
  let rt = await queryRaw(queryString);
  rt = rt[0] || '';
  return rt;
} */

export function groupSchedule(allVDO, gen = 1) {
  var rs = [];
  if (gen === 3) {
    rs.push(allVDO[0]); // Warm Up
    rs.push(allVDO[1]); // Main Circuit
    rs.push(allVDO[2]); // Challange
    if (allVDO[3]) {     // subcircuit
      allVDO[3].forEach(subCircuit => {
        rs.push(subCircuit);
      });
    }
    if (allVDO[4]) {     // cardio
      allVDO[4].forEach(aVDO => {
        rs.push(aVDO);
      });
    }
    rs.push(allVDO[5]); // coolDown
  } else {
    rs.push(allVDO[0]); // Warm Up
    rs.push(allVDO[1]); // Main Circuit
    if (allVDO[2]) {     // subcircuit
      allVDO[2].forEach(subCircuit => {
        rs.push(subCircuit);
      });
    }
    if (allVDO[3]) {     // cardio
      allVDO[3].forEach(aVDO => {
        rs.push(aVDO);
      });
    }
    rs.push(allVDO[4]); // coolDown
  }
  return rs;
}

export function getCardioFourDay(amountCardioPerDay = 0, clipGen = ['1'], videos) {
  var cardio = [];
  if (clipGen.length == 2) {
    //Gen 2
    var amount = amountCardioPerDay;

    var firstGenCardio = videos.filter(element => element.clip_gen === '1' && element.category.toLowerCase() === 'cardio');
    firstGenCardio.sort(() => Math.random() - 0.5);
    var secondGenCardio = videos.filter(element => element.clip_gen === '2' && element.category.toLowerCase() === 'cardio');
    secondGenCardio.sort(() => Math.random() - 0.5);
    var clipGen2PerDay = Math.ceil(amount / 2);
    var clipGen1PerDay = amount - clipGen2PerDay;
    var cardioGen1Count = 0;
    var cardioGen2Count = 0;
    var rt = [];
    for (let day = 1; day <= 4; day++) {
      /*  เริ่มตัวที่ 0 ตัดไป 2 ตัว เพราะงั้นรอบที่ 2 มันก็เริ่มตัวที่ 0 ตัดไป 2 เหมือนเดิมครับ
          มันก็จะตัด 2 ตัวแรกออกมาในทุกๆรอบครับ */
      const result1 = firstGenCardio.splice(cardioGen1Count, clipGen1PerDay);
      const result2 = secondGenCardio.splice(cardioGen2Count, clipGen2PerDay);
      let result = result1.concat(result2);
      result.sort(() => Math.random() - 0.5);
      rt.push(result);
    }
  } else if (clipGen.length == 3) {
    //Gen 3
    var amount = amountCardioPerDay;
    var cardioGen3 = [];
    var cardioPreGen3 = [];

    cardioGen3 = videos.filter(element => element.clip_gen === '3'); //clip_gen 3
    cardioGen3.sort(() => Math.random() - 0.5);
    cardioPreGen3 = videos.filter(element => element.clip_gen === '1' || element.clip_gen === '2'); // clip_gen 1,2
    cardioPreGen3.sort(() => Math.random() - 0.5);

    // $amount = 2;//TODO:

    var clipGen3PerDay = Math.ceil(amount / 2);
    var clipPreGen3PerDay = amount - clipGen3PerDay;
    var cardioGen3Count = 0;
    var cardioPreGen3Count = 0;
    var rt = [];
    for (let day = 1; day <= 4; day++) {
      let final = [];
      if (amount > 1) {
        var result = cardioGen3.slice(cardioGen3Count, clipGen3PerDay + cardioGen3Count);
        if (result.length < clipGen3PerDay) {
          cardioGen3Count = 0;
          cardioGen3.sort(() => Math.random() - 0.5);
          result = cardioGen3.slice(cardioGen3Count, clipGen3PerDay + cardioGen3Count);
          cardioGen3Count += clipGen3PerDay;
        } else {
          cardioGen3Count += clipGen3PerDay;
        }

        var result2 = cardioPreGen3.slice(cardioPreGen3Count, clipPreGen3PerDay + cardioPreGen3Count);
        if (result2.length < clipPreGen3PerDay) {
          cardioPreGen3Count = 0;
          cardioPreGen3.sort(() => Math.random() - 0.5);
          result2 = cardioPreGen3.slice(cardioPreGen3Count, clipPreGen3PerDay + cardioPreGen3Count);
          cardioPreGen3Count += clipPreGen3PerDay;
        } else {
          cardioPreGen3Count += clipPreGen3PerDay;
        }

        final = result.concat(result2);
        final.sort(() => Math.random() - 0.5);
      } else {
        final[0] = cardioGen3[day - 1];
      }
      rt.push(final);
    }
  } else {
    var amount = amountCardioPerDay;

    cardio = videos.filter(element => clipGen.includes(element.clip_gen)); //clip_gen 3
    cardio.sort(() => Math.random() - 0.5);

    var cardioTotalCount = cardio.length;
    var cardioCount = 0;
    var rt = [];

    for (let day = 1; day <= 4; day++) {
      var result = cardio.slice(cardioCount, amount + cardioCount);
      if (result.length < amount) {
        cardioCount = 0;
        cardio.sort(() => Math.random() - 0.5);
        var remainingAmount = amount - result.length;
        result = cardio.slice(cardioCount, remainingAmount + cardioCount);
        cardioCount += remainingAmount;
      } else {
        cardioCount += amount;
      }
      result.sort(() => Math.random() - 0.5);
      rt.push(result);
    }
  }

  // print_r($rt);//TODO:
  // exit();
  return rt;
}

export function getSubcurcitFourDay(amountsubCircutPerDay = 0, clipGen = ['1'], videos) {

  let result = videos.filter(element => clipGen.includes(element.clip_gen));
  result.sort(() => Math.random() - 0.5);
  let vdoGen = [[], [], [], []];
  vdoGen[3] = result.filter(element => element.clip_gen === '3' && element.category.toLowerCase() === 'sub circuit');
  vdoGen[2] = result.filter(element => element.clip_gen === '2' && element.category.toLowerCase() === 'sub circuit');
  vdoGen[1] = result.filter(element => element.clip_gen === '1' && element.category.toLowerCase() === 'sub circuit');

  var rt = [[], [], [], []];

  if (clipGen.length == 2) {
    rt[0] = [vdoGen[2][0], vdoGen[1][0]];
    rt[1] = [vdoGen[2][1], vdoGen[1][1]];
    rt[2] = [vdoGen[2][2], vdoGen[1][2]];
    rt[3] = [vdoGen[2][3], vdoGen[1][3]];
  } else if (clipGen.length == 3) {
    var tempArr = [];
    tempArr[0] = [vdoGen[3][0]];
    tempArr[1] = [vdoGen[3][1]];
    tempArr[2] = [vdoGen[1][1]];
    tempArr[3] = [vdoGen[2][1]];
    tempArr.sort(() => Math.random() - 0.5);

    rt[0] = tempArr[0];
    rt[1] = tempArr[1];
    rt[2] = tempArr[2];
    rt[3] = tempArr[3];
  } else {
    if (amountsubCircutPerDay != 0) {
      rt[0] = [vdoGen[1][0]];
      rt[1] = [vdoGen[1][1]];
      rt[2] = [vdoGen[1][2]];
      rt[3] = [vdoGen[1][3]];
    }
  }
  return rt;
}

export function scheduleGeneratorGen1Value(userWeight, week, videos) {
  //const { user_id, userWeight, week } = JSON.parse(event.body);
  var day1 = [];
  var day2 = [];
  var day3 = [];
  var day4 = [];
  const clipGen = ['1'];

  //Condition Check
  if (userWeight < 50) {
    var cardioAmount = 1;
    var subCircuitAmount = 0;
  } else if (userWeight >= 50 && userWeight <= 60) {
    var cardioAmount = 1;
    var subCircuitAmount = 1;
  } else if (userWeight >= 61 && userWeight <= 70) {
    var cardioAmount = 2;
    var subCircuitAmount = 1;
  } else {
    var cardioAmount = 3;
    var subCircuitAmount = 1;
  }

  // Week 5 - 9 
  if (week >= 5) {
    if (userWeight < 50) {
      subCircuitAmount = 1;
    } else {
      cardioAmount += 1;
    }
  }

  var warmUp = getWarmUp(videos);
  var coolDown = getCoolDown(videos);
  var arrCardio = getCardioFourDay(cardioAmount, ['1'], videos);
  var arrSubCurcit = getSubcurcitFourDay(subCircuitAmount, ['1'], videos);

  // Loop 4 Day
  for (let day = 1; day <= 4; day++) {
    let cardio_ = arrCardio[day - 1];
    let warmUp_ = warmUp[0];
    let coolDown_ = coolDown[0];
    let subCircuit_ = arrSubCurcit[day - 1];

    switch (day) {
      case 1:
        //Chest focus
        var mainCircuit_ = getMainCircuitByType('Chest focus', ['1'], videos)[0];
        day1 = groupSchedule([warmUp_, mainCircuit_, subCircuit_, cardio_, coolDown_]);
        day1 = JSON.stringify(day1);
        break;
      case 2:
        //Back focus
        var mainCircuit_ = getMainCircuitByType('Back focus', ['1'], videos)[0];
        day2 = groupSchedule([warmUp_, mainCircuit_, subCircuit_, cardio_, coolDown_]);
        day2 = JSON.stringify(day2);
        break;
      case 3:
        //Leg focus
        var mainCircuit_ = getMainCircuitByType('Leg focus', ['1'], videos)[0];
        day3 = groupSchedule([warmUp_, mainCircuit_, subCircuit_, cardio_, coolDown_]);
        day3 = JSON.stringify(day3);
        break;
      case 4:
        //Arm focus
        var mainCircuit_ = getMainCircuitByType('Arm focus', ['1'], videos)[0];
        day4 = groupSchedule([warmUp_, mainCircuit_, subCircuit_, cardio_, coolDown_]);
        day4 = JSON.stringify(day4);
        break;
      default:
        // # code...
        break;
    }
  }

  return { day1, day2, day3, day4 };
}

export const processByCategoryAndType = (videos, delVideos, category, type, coach = '') => {
  const toRemove = delVideos
    .filter(video => (video.category.toLowerCase() === category) && (video.type.toLowerCase() === type));

  let vdoDetail = videos
    .filter(video => (video.category.toLowerCase() === category) && (video.type.toLowerCase() === type))
    .sort(() => Math.random() - 0.5);

  if (coach) {
    vdoDetail = videos
      .filter(video => (video.category.toLowerCase() === category) && (video.type.toLowerCase() === type) && (video.coach === coach))
      .sort(() => Math.random() - 0.5);
  }
  //ถ้าจำนวนวิดีโอที่จะลบเท่ากับข้อมูลทั้งหมดใน categorty and type and coach นั้น 
  //ก็ไม่ต้องลบ เพราะจะไม่เหลือวิดีโอให้ใช้เลย
  if (toRemove.length < vdoDetail.length) {
    const filtered = vdoDetail.filter(vdo => !toRemove.some(
      delVdo => delVdo.video_id === vdo.video_id
    )
    );
    return filtered;
  }



  return vdoDetail;
}

export const getVideoTemplates = async (user_id) => {
  return new Promise(async (resolve, reject) => {
    try {
      const queryString = ` 
        SELECT video_template 
        FROM register_log 
        WHERE user_id='${user_id}';`;
      const results = await queryRaw(queryString);
      let videoTemplates = [];
      for (const result of results) {
        videoTemplates.push(JSON.parse(result.video_template));
      }
      videoTemplates = videoTemplates.flat(2);
      const toRemove = generateToRemoveVideos(videoTemplates);
      resolve(toRemove);
    } catch (error) {
      reject(error);
    }
  });
}

export const generateToRemoveVideos = (videos) => {
  let toRemove = [];
  let videoIDs = []
  for (const video of videos) {
    if (!videoIDs.includes(video.video_id)) {
      delete video.order;
      delete video.play_time;
      videoIDs.push(video.video_id);
      if (video.category.toLowerCase() !== 'warm up' &&
        video.category.toLowerCase() !== 'cool down' &&
        video.category.toLowerCase() !== 'challenge') {
        toRemove.push(video)
      }
    }

  }

  return toRemove;
}

export const generateVideos = (startDate, videos, endDate, delVideos = [], kol) => {
  let endDateString = endDate ? endDate : moment().format('YYYY-MM-DD');
  let scheculeVideos = [];

  const coach = ["จินนี่", "ลิตา"];
  const subCircuits = processByCategoryAndType(videos, delVideos, 'sub circuit', 'sub circuit');

  const stabilization = processByCategoryAndType(videos, delVideos, 'main circuit', 'stabilization');
  const strength = processByCategoryAndType(videos, delVideos, 'main circuit', 'strength');
  const advance = processByCategoryAndType(videos, delVideos, 'main circuit', 'advance');

  const dayPerWeek = 7;
  for (let day = 1; day <= dayPerWeek; day++) { //จัดให้มีออกกำลังกาย 7วัน
    let exerciseInDay = [];
    let order = 0;
    const structure1_3_5 = ["Warm Up", "Main Circuit", "Sub Circuit", "Cool Down", "Sub Circuit"]
    const structure2_4 = ["Warm Up", "Cardio"]
    const structure6 = ["Warm Up", "Active Rest"]
    const structure7 = ["Warm Up", "Rest"]

    const videoNumbInDay = (day === 1 || day === 3 || day === 5) ? structure1_3_5.length : 2;
    for (let index = 0; index < videoNumbInDay; index++) {
      const category = (day === 1 || day === 3 || day === 5) ? structure1_3_5[index] : (day === 2 || day === 4) ? structure2_4[index] : (day === 6) ? structure6[index] : structure7[index];
      const lastVideoInday1_3_5 = (index === (videoNumbInDay - 1)) ? true : false;
      let focusVideos = [];

      switch (category) {
        case 'Warm Up':
          focusVideos = videos.filter(video => video.category === category);
          focusVideos.sort(() => Math.random() - 0.5);
          break;
        case 'Main Circuit':
          if (day === 1) {
            focusVideos = stabilization;
          } else if (day === 3) {
            focusVideos = strength;
          } else if (day === 5) {
            focusVideos = advance;
          }
          break;
        case 'Sub Circuit':
          if (lastVideoInday1_3_5) {
            //เช็คว่าคลิปที่ 3 ได้ใครเป็นโค้ช และให้ทำการกำหนดโค้ชตรงข้ามเป็น option_video
            if (exerciseInDay[2].coach === coach[1]) {
              focusVideos = videos.filter(video => (video.category === category) && (video.coach === coach[0]))
                .sort(() => Math.random() - 0.5);;

              focusVideos = focusVideos.filter(vdo => !delVideos.some(
                delVdo => delVdo.video_id === vdo.video_id
              ));
            } else {
              focusVideos = videos.filter(video => (video.category === category) && (video.coach === coach[1]))
                .sort(() => Math.random() - 0.5);;

              focusVideos = focusVideos.filter(vdo => !delVideos.some(
                delVdo => delVdo.video_id === vdo.video_id
              ));
            }
          } else {
            //สั่งให้เจนคลิป Sub Circuit ตาม kol และไม่เอาคลิปซ้ำ
            focusVideos = videos.filter(video => (video.category === category) && (video.coach === kol))
              .sort(() => Math.random() - 0.5);;

            focusVideos = focusVideos.filter(vdo => !delVideos.some(
              delVdo => delVdo.video_id === vdo.video_id
            ));
          }

          break;
        case 'Cool Down':
          focusVideos = videos.filter(video => video.category === category);
          focusVideos.sort(() => Math.random() - 0.5);
          break;
        default:
          focusVideos = videos.filter(video => video.category === category);
          focusVideos.sort(() => Math.random() - 0.5);
          break;
      }
      if (focusVideos.length === 0) {
        continue;
      };


      for (let inner = 0; inner < 1; inner++) {
        // ลบ videos ที่เพิ่งใส่เข้าไปออกจาก videos
        const newVideo = focusVideos.pop();
        if (category === 'Sub Circuit') {
          delVideos.push({ ...newVideo, play_time: 0, order, priority_video: lastVideoInday1_3_5 ? "option_video" : "main_video" });
        }
        exerciseInDay.push({ ...newVideo, play_time: 0, order, priority_video: lastVideoInday1_3_5 ? "option_video" : "main_video" });
        order++;
      }

    }
    scheculeVideos.push(exerciseInDay);
  }
  return scheculeVideos;
}

export const calculateWeekInProgram = (startDate, endDate) => {
  let startDateMoment = moment(startDate).startOf('isoWeek');
  let endDateMoment = endDate ? moment(endDate) : moment();
  return endDateMoment.diff(startDateMoment, 'week') + 1
}