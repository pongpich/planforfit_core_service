export const genActivitiesInsertState = (user_id, product_id) => 
    `
        INSERT INTO daily_activity (user_id, program_id, week_in_program, activities)
        SELECT hp.user_id, hp.program_id, calcWeekInProgram(hp.start_date) as week_in_program,
            JSON_SET(tem.template,
                '$.daily_activities[0].date', SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY),
                '$.daily_activities[1].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 1 DAY),
                '$.daily_activities[2].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 2 DAY),
                '$.daily_activities[3].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 3 DAY),
                '$.daily_activities[4].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 4 DAY),
                '$.daily_activities[5].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 5 DAY),
                '$.daily_activities[6].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 6 DAY)
            ) as activities
        FROM health_profile hp JOIN activity_template tem
            ON hp.product_id = tem.product_id
        WHERE hp.user_id = '${user_id}'
            AND DATEDIFF(hp.expire_date, NOW()) >= 0
            AND (calcWeekInProgram(hp.start_date)) > 0
            AND hp.product_id = '${product_id}'
            AND NOT EXISTS (
                SELECT * 
                FROM daily_activity
                WHERE user_id = '${user_id}'
                    AND program_id = hp.program_id
                    AND week_in_program = calcWeekInProgram(hp.start_date)
            ) LIMIT 0, 1;
    `
export const genTBPAActivitiesInsertState = (user_id) => 
    `
        INSERT INTO daily_activity (user_id, program_id, week_in_program, activities)
        SELECT hp.user_id, hp.program_id, calcWeekInProgram(hp.start_date) as week_in_program,
            JSON_SET(tem.template,
            	'$.weekly_plan.exercise_plan.weekly_exercise_score', 
            	JSON_EXTRACT(tem.template,
            		CONCAT(
            			'$.weekly_plan.templates[',
            			IF(calcWeekInProgram(hp.start_date) > JSON_LENGTH(JSON_EXTRACT(tem.template, "$.weekly_plan.templates")),
            				JSON_LENGTH(JSON_EXTRACT(tem.template, "$.weekly_plan.templates"))-1, 
            				calcWeekInProgram(hp.start_date)-1
            			),
            			'].exercise_plan'
            		)
            	),
                '$.daily_activities[0].date', SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY),
                '$.daily_activities[1].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 1 DAY),
                '$.daily_activities[2].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 2 DAY),
                '$.daily_activities[3].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 3 DAY),
                '$.daily_activities[4].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 4 DAY),
                '$.daily_activities[5].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 5 DAY),
                '$.daily_activities[6].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 6 DAY)
            ) as activities
        FROM health_profile hp JOIN activity_template tem
            ON hp.product_id = tem.product_id
        WHERE hp.user_id = '${user_id}'
            AND DATEDIFF(hp.expire_date, NOW()) >= 0
            AND (calcWeekInProgram(hp.start_date)) > 0
            AND hp.product_id = 'tbpa'
            AND NOT EXISTS (
                SELECT * 
                FROM daily_activity
                WHERE user_id = '${user_id}'
                    AND program_id = hp.program_id
                    AND week_in_program = calcWeekInProgram(hp.start_date)
            ) LIMIT 0, 1;
    `;

export const genCCRActivitiesInsertState = (user_id) => `CALL ccrAdjustProgram('${user_id}');`

export const genGetMooveHomeworks = (product_id) => `
    SET @queryDate = NOW();
    SELECT da.act_id, da.user_id, da.program_id, da.week_in_program, da.activities,
      CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
      m.email, m.fb_link,
      COALESCE(da.activities->>'$.weekly_plan.status', "init") as status,
        (
        select 	CONCAT(
          '[ ',
          GROUP_CONCAT(
            JSON_OBJECT(
              'week_in_program', ida.week_in_program, 
              'exercise_note', ida.activities->>'$.weekly_plan.exercise_note', 
              'nutrition_note', ida.activities->>'$.weekly_plan.nutrition_note',
              'weekly_exercise_score', CAST(ida.activities->>'$.weekly_plan.exercise_plan.weekly_exercise_score' as UNSIGNED),
              'weekly_progress', CAST(ida.activities->>'$.weekly_progress' as JSON)
            )
          ),
          ' ]'
        )
        FROM daily_activity ida
        WHERE ida.program_id = da.program_id
          AND ida.user_id = da.user_id
          AND ida.week_in_program < da.week_in_program
        ) as history
    FROM daily_activity da JOIN health_profile hp    
      ON da.program_id = hp.program_id AND da.user_id = hp.user_id
      JOIN member m ON hp.user_id = m.user_id
    WHERE da.week_in_program = (CASE
                    WHEN (	DAYNAME(@queryDate) = 'Friday' OR
                        DAYNAME(@queryDate) = 'Saturday' OR
                        DAYNAME(@queryDate) = 'Sunday') THEN (calcWeekInProgram(hp.start_date))
                    ELSE (calcWeekInProgram(hp.start_date) - 1)
                    END)
      AND DATEDIFF(@queryDate , getFirstMonday(hp.start_date)) >= 0
      AND DATEDIFF(hp.expire_date, @queryDate) >= 0
      AND hp.product_id = '${product_id}';        
  `;

export const genPageMooveHomeworks = (product_id, limit, offset) => `
    SET @queryDate = NOW();
    SELECT da.act_id, da.user_id, da.program_id, da.week_in_program, da.activities,
      CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
      m.email, m.fb_link,
      COALESCE(da.activities->>'$.weekly_plan.status', "init") as status,
        (
        select 	CONCAT(
          '[ ',
          GROUP_CONCAT(
            JSON_OBJECT(
              'week_in_program', ida.week_in_program, 
              'exercise_note', ida.activities->>'$.weekly_plan.exercise_note', 
              'nutrition_note', ida.activities->>'$.weekly_plan.nutrition_note',
              'weekly_exercise_score', CAST(ida.activities->>'$.weekly_plan.exercise_plan.weekly_exercise_score' as UNSIGNED),
              'weekly_progress', CAST(ida.activities->>'$.weekly_progress' as JSON)
            )
          ),
          ' ]'
        )
        FROM daily_activity ida
        WHERE ida.program_id = da.program_id
          AND ida.user_id = da.user_id
          AND ida.week_in_program < da.week_in_program
        ) as history
    FROM daily_activity da JOIN health_profile hp    
      ON da.program_id = hp.program_id AND da.user_id = hp.user_id
      JOIN member m ON hp.user_id = m.user_id
    WHERE da.week_in_program = (CASE
                    WHEN (	DAYNAME(@queryDate) = 'Friday' OR
                        DAYNAME(@queryDate) = 'Saturday' OR
                        DAYNAME(@queryDate) = 'Sunday') THEN (calcWeekInProgram(hp.start_date))
                    ELSE (calcWeekInProgram(hp.start_date) - 1)
                    END)
      AND DATEDIFF(@queryDate , getFirstMonday(hp.start_date)) >= 0
      AND DATEDIFF(hp.expire_date, @queryDate) >= 0
      AND hp.product_id = '${product_id}'
      LIMIT ${limit} OFFSET ${offset};        
  `;

export const genGetCCRHomeworks = (product_id) => `
    SET @queryDate = NOW();
    SELECT da.act_id, da.user_id, da.program_id, da.week_in_program, da.activities,
      CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
      m.email, m.fb_link, hp.main_info,
      COALESCE(da.activities->>'$.weekly_plan.status', "init") as status,
      da.week_in_program +1 as next_week_in_program,
      (	
        SELECT ida.activities
        FROM daily_activity ida
        WHERE ida.week_in_program = da.week_in_program+1
          AND ida.user_id = da.user_id
          AND ida.program_id = da.program_id
      ) next_activities, DATE_FORMAT(da.updated_at, "%d/%m/%Y %H:%i:%s") as update_time
    FROM daily_activity da JOIN health_profile hp 
      ON da.program_id = hp.program_id AND da.user_id = hp.user_id 
      JOIN member m ON hp.user_id = m.user_id
    WHERE da.week_in_program = (CASE
                    WHEN (	DAYNAME(@queryDate) = 'Friday' OR
                        DAYNAME(@queryDate) = 'Saturday' OR
                        DAYNAME(@queryDate) = 'Sunday') THEN (calcWeekInProgram(hp.start_date))
                    ELSE (calcWeekInProgram(hp.start_date) - 1)
                    END)
      AND DATEDIFF(@queryDate , getFirstMonday(hp.start_date)) >= 0
      AND DATEDIFF(hp.expire_date, @queryDate) >= 0
      AND hp.product_id = '${product_id}'
      AND da.activities->'$.weekly_progress.images.side' != ""
      AND da.activities->'$.weekly_progress.images.front' != ""
   ORDER BY da.updated_at; 
  `;

export const genExerciseScoreCalculation = (product_id) => `
      SELECT da.act_id, da.user_id, da.program_id, da.week_in_program,
      CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
      m.email, fb_link, 
      da.activities->"$.daily_activities[0].exercise_score" + 
      da.activities->"$.daily_activities[1].exercise_score" + 
      da.activities->"$.daily_activities[2].exercise_score" +
      da.activities->"$.daily_activities[3].exercise_score" +
      da.activities->"$.daily_activities[4].exercise_score" +
      da.activities->"$.daily_activities[5].exercise_score" +
      da.activities->"$.daily_activities[6].exercise_score" as total_score
      FROM daily_activity da JOIN health_profile hp    
      ON da.program_id = hp.program_id AND da.user_id = hp.user_id
      JOIN member m ON hp.user_id = m.user_id
      WHERE da.week_in_program = (CASE
                    WHEN (	DAYNAME(NOW()) = 'Friday' OR
                        DAYNAME(NOW()) = 'Saturday' OR
                        DAYNAME(NOW()) = 'Sunday') THEN (calcWeekInProgram(hp.start_date))
                    ELSE (calcWeekInProgram(hp.start_date) - 1)
                    END)
      AND DATEDIFF(NOW() , getFirstMonday(hp.start_date)) >= 0
      AND DATEDIFF(hp.expire_date, NOW()) >= 0
      AND hp.product_id = '${product_id}';  
`


export const calculateProgramPeriod = (user_id, program_id, product_id) => (
  `
  INSERT INTO health_profile 
    (user_id, product_id, base_info, main_info, program_id, start_date, expire_date)
  SELECT '${user_id}', '${product_id}', '{}', '[]', '${program_id}', pp.start_date, pp.expire_date
  FROM (
    SELECT 
    CASE 
      WHEN hp.start_date IS NOT NULL THEN hp.start_date
      WHEN pg.period IS NOT NULL AND period > 0 THEN CURDATE()
      WHEN pg.program_start_date IS NOT NULL THEN pg.program_start_date
      ELSE CURDATE()
    END AS start_date,
    CASE
      WHEN hp.expire_date IS NOT NULL AND hp.expire_date >= NOW() THEN 
        CASE
          WHEN pg.period IS NOT NULL AND period > 0 THEN DATE_ADD(hp.expire_date, INTERVAL pg.period DAY)
          ELSE DATE_ADD(hp.expire_date, INTERVAL 60 DAY)
        END
      WHEN pg.period IS NOT NULL AND period > 0 THEN DATE_ADD(CURDATE(), INTERVAL pg.period DAY)
      WHEN pg.program_expire_date IS NOT NULL AND pg.program_expire_date >= NOW() THEN pg.program_expire_date
      ELSE DATE_ADD(CURDATE(), INTERVAL 60 DAY)
    END AS expire_date
    FROM program pg LEFT JOIN health_profile hp
      ON hp.program_id = pg.program_id
      AND hp.user_id = '${user_id}' 
    WHERE pg.program_id = '${program_id}'
  ) AS pp
  ON DUPLICATE KEY UPDATE expire_date = pp.expire_date;
  `
)
