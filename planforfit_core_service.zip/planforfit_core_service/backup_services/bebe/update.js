import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import moment from 'moment';
import { success, failure, createSuccessBody, createFailureBody } from "./local_lib/response-lib";
import { calculateWeekInProgram, generateVideos, getVideoTemplates } from './util/schedule';

//ปรับอันเก่า และเพิ่มการ update lv. อัตโนมัติตอน week 5
export async function checkProgramLevel(event) { //ใช้สำหรับตอนผู้ใช้มีการเปลี่ยนแปลงชนิดระหว่าง low impact หรือ ธรรมดา มีโอกาสทำให้ program_level ไม่ตรง
  const {
    user_id
  } = JSON.parse(event.body);

  const selectMemberInfo = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    let result;
    const memberInfo = await queryRaw(selectMemberInfo);
    const start_date = memberInfo[0].start_date;
    const program_level = memberInfo[0].program_level;
    const low_impact = memberInfo[0].low_impact;
    const week = calculateWeekInProgram(start_date);
    const batch = Math.ceil(week / 8);

    var new_level;
    var updateProgramLevel;

    //กรณีเป็น low impact แต่ program_level ดันเป็น bfr - ให้ทำการ set program_level = lowimp_lv1
    if ((low_impact === 'yes') && (program_level.includes('bfr_lv'))) {
      new_level = 'lowimp_lv1';
      console.log("new_level :", new_level);
      updateProgramLevel = `
        update member
        set program_level = '${new_level}'
        where user_id = '${user_id}';
      `;
      await query(updateProgramLevel);
    }

    //กรณีไม่ได้เป็น low impact แต่ program_level ดันเป็น lowimp - ให้ทำการ set program_level = bfr_lv1, bfr_lv2
    if ((low_impact === 'no') && (program_level.includes('lowimp_lv'))) {
      if (batch > 1) {
        const last_batch = batch - 1;
        const start_week = ((last_batch - 1) * 8) + 1;
        const end_week = start_week + 7;
        const selectExerciseHistory = `
        select week_in_program, program_level from exercise_activity
        where user_id = '${user_id}' and week_in_program >= ${start_week} and  week_in_program <= ${end_week}
      `;
        const exerciseHistory = await queryRaw(selectExerciseHistory);
        //วน loop เข้าไปใน exerciseHistory เช็คว่าเป็น low imp ไหม
        var lowimp = false;
        for (var i = 0; i < exerciseHistory.length; i++) {
          if (exerciseHistory[i].program_level.includes("lowimp")) {
            lowimp = true;
          }
        }
        //เช็ค Batch ก่อนหน้าถ้าเป็น lowimp มาก่อนกำหนดเป็น lv1 ถ้าไม่ใช่กำหนดเป็น lv2
        if (lowimp) {
          //new_level = 'bfr_lv1'; // หมายเหตุ ตาม requiment อยากให้เป็น bfr_lv1 แต่หน้างานจริงมีแต่ผู้ใช้ขอ bfr_lv2 จึงทำการปรับ
          new_level = 'bfr_lv2';
        } else {
          new_level = 'bfr_lv2';
        }
        console.log("new_level :", new_level);
        updateProgramLevel = `
          update member
          set program_level = '${new_level}'
          where user_id = '${user_id}';
        `;
        await query(updateProgramLevel);
      } else { //กรณี batch = 1
        new_level = 'bfr_lv1.5';
        console.log("new_level :", new_level);
        updateProgramLevel = `
          update member
          set program_level = '${new_level}'
          where user_id = '${user_id}';
        `;
        await query(updateProgramLevel);
      }
    }

    //เพิ่มการบังคับ ถ้าไม่ใช่ low_impact และ week >= 5 กำหนดเป็น bfr_lv2
    if ((low_impact === 'no') && (week >= 5)) {
      new_level = 'bfr_lv2';
      console.log("new_level :", new_level);
      updateProgramLevel = `
        update member
        set program_level = '${new_level}'
        where user_id = '${user_id}';
      `;
      await query(updateProgramLevel);
    }

    //เพิ่มการบังคับ ถ้าไม่ใช่ low_impact และ week === 1 กำหนดเป็น bfr_lv1.5
    /* if ((low_impact === 'no') && (week === 1)) {
      new_level = 'bfr_lv1.5';
      console.log("new_level :", new_level);
      updateProgramLevel = `
        update member
        set program_level = '${new_level}'
        where user_id = '${user_id}';
      `;
      await query(updateProgramLevel);
    } */

    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateStatusLowImpact(event) {
  const {
    user_id,
    status_low_impact //yes or no
  } = JSON.parse(event.body);

  console.log("status_low_impact :", status_low_impact);
  console.log("user_id :", user_id);
  const updateStatusLowImpact = `
  update member
  set low_impact = '${status_low_impact}'
  where user_id = '${user_id}';
  `

  try {
    let result;
    await query(updateStatusLowImpact);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateProgramLevel(event) {
  const {
    user_id,
    program_level //bfr_lv1, bfr_lv1.5, bfr_lv2 (ปัจจุบัน lv1 เลิกใช้)
  } = JSON.parse(event.body);

  console.log("program_level :", program_level);
  console.log("user_id :", user_id);
  const updateProgramLevel = `
  update member
  set program_level = '${program_level}'
  where user_id = '${user_id}';
  `

  try {
    let result;
    await query(updateProgramLevel);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateProgramPromptLog(event) { //ใช้สำหรับ update level และ log ตาม ProgramPrompt
  const {
    user_id,
    log_name,
    log_value
  } = JSON.parse(event.body);

  const selectMemberInfo = `
  select * from member
  where user_id = '${user_id}'
  `;

  try {
    let result;
    const memberInfo = await queryRaw(selectMemberInfo);
    const start_date = memberInfo[0].start_date;
    const program_level = memberInfo[0].program_level;
    const week = calculateWeekInProgram(start_date);
    const batch = Math.ceil(week / 8);
    console.log("program_level :", program_level);

    if (log_value === 'level up') {
      var next_level;
      if (program_level === 'bfr_lv1') {
        next_level = 'bfr_lv2';
      }
      if (program_level === 'bfr_lv1.5') {
        next_level = 'bfr_lv2';
      }
      if (program_level === 'bfr_lv2') { //ปัจจุบัน levelตันที่ bfr_lv2
        next_level = 'bfr_lv2';
      }
      console.log("next_level :", next_level);
      const updateProgramLevel = `
      update member
      set program_level = '${next_level}'
      where user_id = '${user_id}';
      `;
      await query(updateProgramLevel);
    }

    const insertProgramPromptLog = `
    insert into program_prompt_log
    set user_id = '${user_id}', log = '${log_name}', log_value = '${log_value}', batch = ${batch}
    `;
    await query(insertProgramPromptLog);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateAchievementLog(event) {
  const {
    user_id,
    achievement_name
  } = JSON.parse(event.body);

  const insertAchievementLog = `
    insert into achievement_log
    set user_id = '${user_id}', achievement = '${achievement_name}'
  `;

  try {
    let result;
    await query(insertAchievementLog);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkAllMissionCompelete(event) {
  const {
    user_id
  } = JSON.parse(event.body);

  const selectLastChallengeEvent = `
                                      select * from challenge_event
                                      order by created_at desc limit 1;
                                    `;

  const insertAchievementLog = `
    insert into achievement_log
    set user_id = '${user_id}', achievement = 'Finisher'
  `;

  try {
    let result;
    const selectLastChallengeEventResult = await queryRaw(selectLastChallengeEvent);
    const start_date = moment(selectLastChallengeEventResult[0].start_date);
    const expire_date = moment(selectLastChallengeEventResult[0].expire_date);
    const numbOfWeeks = expire_date.diff(start_date, 'week') + 1;
    const maxScoreOfWeek = 110; //ยกเว้น week ที่ 1 จะได้สูงสุดแค่ 100 เพราะไม่สามารถทำภารกิจน้ำหนักตัวน้อยกว่าสัปดาห์ก่อนได้
    const maxScoreOfSeason = (maxScoreOfWeek * numbOfWeeks) - 10; // -10 เพราะ Week ที่ 1 ไม่สามารถทำภารกิจน้ำหนักตัวน้อยกว่าสัปดาห์ก่อนได้
    console.log("maxScoreOfSeason :", maxScoreOfSeason);
    const selectTotalScore = `
    select m.user_id, m.email, m.first_name, m.last_name, m.facebook, m.start_date, m.expire_date, calcScore.total_score
    from (
      select user_id, sum(score) as total_score
      from member_event_log
      where created_at BETWEEN '${moment(selectLastChallengeEventResult[0].start_date).format('YYYYMMDD')}' AND '${moment(selectLastChallengeEventResult[0].expire_date).format('YYYYMMDD')}' 
      AND user_id = '${user_id}'
      group by user_id
        ) as calcScore JOIN member m
        ON m.user_id = calcScore.user_id
    order by total_score desc
    `;
    const selectTotalScoreResult = await queryRaw(selectTotalScore);
    const scoreOfUser = selectTotalScoreResult[0].total_score;
    console.log("scoreOfUser :", scoreOfUser);
    const allMissionCompelete = (scoreOfUser >= maxScoreOfSeason) ? true : false;
    console.log("allMissionCompelete :", allMissionCompelete);

    if (allMissionCompelete) {
      await query(insertAchievementLog);
      result = success(createSuccessBody({ message: 'success' }));
    } else {
      result = success(createSuccessBody({ message: 'fail' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function rejectTeamInvite(event) {
  const {
    log_id
  } = JSON.parse(event.body);

  const updteTeamInviteSQL = `
                                  update team_invite 
                                  set status = 'reject'
                                  where log_id = ${log_id}
                                `;
  try {
    let result;
    await query(updteTeamInviteSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function acceptTeamInvite(event) {
  const {
    user_id, //user_id = id ของผู้ที่ได้รับคำเชิญร่วมทีม 
    group_id, //group_id = id ของกลุ่มที่ผู้ส่งคำเชิญอาศัยอยู่
    log_id
  } = JSON.parse(event.body);

  const selectGroupIDSQL = `
                                select group_id from member
                                where user_id = '${user_id}'
                                `;

  const selectMembersOfTeamSQL = `
                                select count(*) as count from member
                                where group_id = ${group_id}
                                `;

  const updteTeamInviteSQL = `
                                update team_invite 
                                set status = 'accept'
                                where log_id = ${log_id}
                              `;

  const updteGroupIDSQL = `
                                update member 
                                set group_id = '${group_id}'
                                where user_id = '${user_id}'
                              `;

  try {
    let result;

    const selectGroupIDResult = await queryRaw(selectGroupIDSQL);
    const selectMembersOfTeamResult = await queryRaw(selectMembersOfTeamSQL);
    const numbOfMembers = selectMembersOfTeamResult[0].count;
    const maxMembersOfTeam = 10;
    if (selectGroupIDResult[0].group_id || numbOfMembers >= maxMembersOfTeam) { //เช็คว่าผู้ที่ได้รับคำเชิญมีทีมอยู่แล้วไหม? - ถ้ามี ไม่ต้องอัพเดท group_id || หรือ ถ้าจำนวนสมาชิกทีมนั้นครบ 10 ก็ไม่ต้องอัพเดท group_id
      await query(updteTeamInviteSQL);
      result = success(createSuccessBody({ message: 'already_have_team' }));
    } else { // ถ้าไม่มี ต้องอัพเดท group_id
      await query(updteGroupIDSQL);
      await query(updteTeamInviteSQL);
      result = success(createSuccessBody({ message: 'success' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function acceptFriend(event) {
  const {
    user_id,
    sender_id,
    log_id
  } = JSON.parse(event.body);

  const selectFriendListSQL = `
                                select friend_list, max_friends from member
                                where user_id = '${user_id}'
                                `;

  const selectFriendListSenderSQL = `
                                select friend_list from member
                                where user_id = '${sender_id}'
                                `;

  const updteFriendRequestSQL = `
                                update friend_request 
                                set status = 'accept'
                                where log_id = ${log_id}
                              `;

  try {
    let result;
    const selectFriendListResult = await queryRaw(selectFriendListSQL);
    const max_friends = selectFriendListResult[0].max_friends;
    var checkMaxNumbFriends = false;
    let new_friend_list = [];
    if (selectFriendListResult[0].friend_list) { //เช็คว่ามีเพื่อนไหม (ถ้ามีเพื่อน เพิ่ม id คนใหม่ต่อจากคนเก่า)
      const old_friend_list = JSON.parse(selectFriendListResult[0].friend_list);
      if (old_friend_list.includes(sender_id)) { //เช็คว่าถ้ามีคนนี้เป็นเพื่อนอยู่แล้ว ไม่ต้องเพิ่มเข้า friend_list
        result = success(createSuccessBody({ message: 'friend_list_exist' }));
      } else { //ถ้ายังไม่มีคนนี้เป็นเพื่อน 
        if (old_friend_list.length < max_friends) { //เช็คว่าถ้าเพื่อนยังไม่เต็ม ให้เพิ่มเข้า friend_list
          old_friend_list.push(sender_id);
          result = success(createSuccessBody({ message: 'success' }));
        } else { //ถ้าเพื่อนเต็มไม่ต้องเพิ่่ม
          checkMaxNumbFriends = true;
          result = success(createSuccessBody({ message: 'friend_list_exist' }));
        }
      }
      new_friend_list = old_friend_list;
    } else { //(ถ้าไม่มีเพื่อนเลย สามารถ เพิ่ม id คนใหม่ไปเลย)
      new_friend_list.push(sender_id);
      result = success(createSuccessBody({ message: 'success' }));
    }
    console.log("new_friend_list :", new_friend_list);
    const updteFriendListSQL = `
                                update member 
                                set friend_list = '${JSON.stringify(new_friend_list)}'
                                where user_id = '${user_id}'
                              `;
    await query(updteFriendListSQL);
    await query(updteFriendRequestSQL);

    const selectFriendListSenderResult = await queryRaw(selectFriendListSenderSQL);
    let new_friend_list_sender = [];
    if (selectFriendListSenderResult[0].friend_list) { //เช็คว่ามีเพื่อนไหม (ถ้ามีเพื่อน เพิ่ม id คนใหม่ต่อจากคนเก่า)
      const old_friend_list_sender = JSON.parse(selectFriendListSenderResult[0].friend_list);
      if (old_friend_list_sender.includes(user_id)) { //เช็คว่าถ้ามีคนนี้เป็นเพื่อนอยู่แล้ว ไม่ต้องเพิ่มเข้า friend_list
      } else { //ถ้ายังไม่มีคนนี้เป็นเพื่อน ให้เพิ่มเข้า friend_list
        old_friend_list_sender.push(user_id);
      }
      new_friend_list_sender = old_friend_list_sender;
    } else { //(ถ้าไม่มีเพื่อนเลย สามารถ เพิ่ม id คนใหม่ไปเลย)
      new_friend_list_sender.push(user_id);
    }
    console.log("new_friend_list_sender :", new_friend_list_sender);
    const updteFriendListSenderSQL = `
    update member 
    set friend_list = '${JSON.stringify(new_friend_list_sender)}'
    where user_id = '${sender_id}'
  `;
    console.log("checkMaxNumbFriends :", checkMaxNumbFriends);
    if (!checkMaxNumbFriends) { //เช็คผู้ที่ได้รับคำขอเพื่อนถ้าเพื่อนยังไม่เต็มถึงจะอัพเดท
      await query(updteFriendListSenderSQL);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function rejectFriend(event) {
  const {
    log_id
  } = JSON.parse(event.body);

  const updteFriendRequestSQL = `
                                  update friend_request 
                                  set status = 'reject'
                                  where log_id = ${log_id}
                                `;
  try {
    let result;
    await query(updteFriendRequestSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function deleteFriend(event) {
  const {
    user_id,
    friend_email
  } = JSON.parse(event.body);

  const selectFriendListSQL = `
                              select friend_list from member
                              where user_id = '${user_id}'
                              `;

  const selectFriendIDSQL = `
                              select user_id from member
                              where email = '${friend_email}'
                              `;

  try {
    let result;
    const selectFriendListResult = await queryRaw(selectFriendListSQL);
    const selectFriendIDResult = await queryRaw(selectFriendIDSQL);
    const friend_id = selectFriendIDResult[0].user_id;
    let new_friend_list = [];
    if (selectFriendListResult[0].friend_list) { //เช็คว่ามีเพื่อนไหม 
      const old_friend_list = JSON.parse(selectFriendListResult[0].friend_list);
      console.log("old_friend_list1 :", old_friend_list);
      //ลบรายช่ือเพื่อนตามอีเมลที่นับมาออก
      new_friend_list = old_friend_list.filter((item) => { return item !== friend_id }) //กำหนดให้ new_friend_list = list อันใหม่ที่ลบเพื่อนคนที่ต้องการออกแล้ว
      const updteFriendListSQL = `
                                    update member 
                                    set friend_list = '${JSON.stringify(new_friend_list)}'
                                    where user_id = '${user_id}'
                                  `;
      await query(updteFriendListSQL);
      result = success(createSuccessBody({ message: 'success' }));
    } else {
      result = success(createSuccessBody({ message: 'friendless' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkUpdateMaxFriends(event) {
  const {
    user_id
  } = JSON.parse(event.body);

  const selectActivitiesSQL = `
                              select * from exercise_activity
                              where user_id = '${user_id}'
                              order by week_in_program desc limit 1;
                            `;

  const selectLogActiveInWeekSQL = `
                                      select * from member_event_log
                                      where user_id = '${user_id}' 
                                      and log = 'active in week' 
                                      and DATE(created_at) BETWEEN getMondayOfTheWeek(CURDATE()) AND getSundayOfTheWeek(CURDATE());
                                    `;

  const insertLogActiveInWeekSQL = `
                                    INSERT INTO member_event_log ( user_id, log, log_value, log_type, score)
                                    VALUES ( '${user_id}', 'active in week', '0', 'individual', 0.00);
                                    `;

  const selectMaxFriendsSQL = `
                                select max_friends from member
                                where user_id = '${user_id}'
                              `;

  try {
    let result;
    const selectActivitiesResult = await queryRaw(selectActivitiesSQL);
    const activities = JSON.parse(selectActivitiesResult[0].activities);
    const completeVideoPlayPercentage = 0.9; //ถ้าดูคลิปเกิน 90% ของ duration นับว่าดูจบ
    var numbOfCompleteDay = 0;
    //เช็คจำนวนวันที่ผู้ใช้ดูครบทุปคลิป
    for (var i = 0; i < activities.length; i++) { //วนลูปเข้าไปแต่ละวันของ activities
      var numbOfCompleteVideo = 0;
      for (var j = 0; j < activities[i].length; j++) { //วนลูปเข้าไปแต่ละคลิปของวันนั้น
        if (activities[i][j].play_time / activities[i][j].duration >= completeVideoPlayPercentage) {
          numbOfCompleteVideo += 1;
        }
      }
      if (numbOfCompleteVideo === activities[i].length) {
        numbOfCompleteDay += 1;
      }
    }
    console.log("numbOfCompleteDay :", numbOfCompleteDay);

    const selectLogActiveInWeekResult = await queryRaw(selectLogActiveInWeekSQL);
    const selectMaxFriendsResult = await queryRaw(selectMaxFriendsSQL);
    const numbLogActiveInWeek = selectLogActiveInWeekResult.length;
    const max_friends = selectMaxFriendsResult[0].max_friends;
    console.log("numbLogActiveInWeek :", numbLogActiveInWeek);
    if (numbOfCompleteDay > 0 && numbLogActiveInWeek === 0 && max_friends < 14) { // ถ้ามีวันที่ออกกำลังกายสำเร็จอย่างน้อย1วันในสัปดาห์ ให้ทำการ + จำนวนเพื่อน 2 
      await query(insertLogActiveInWeekSQL);
      const updateMaxFriendsSQL = `
                                    update member 
                                    set max_friends = ${max_friends + 2}
                                    where user_id = '${user_id}'
                                  `;
      await query(updateMaxFriendsSQL);
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function changeEmail(event) {
  const {
    email,
    new_email
  } = JSON.parse(event.body);

  const selectEmailSQL = `SELECT email FROM member
                          WHERE email = '${email}';`;

  const selectNewEmailSQL = `SELECT email FROM member
                          WHERE email = '${new_email}';`;

  const updateEmailSQL = `UPDATE member
                          SET email = '${new_email}'
                          WHERE email = '${email}';`;

  try {
    const selectEmailResult = await queryRaw(selectEmailSQL);
    const selectNewEmailResult = await queryRaw(selectNewEmailSQL);
    let result;
    if (selectEmailResult.length > 0) {
      if (selectNewEmailResult.length > 0) {
        // ส่ง message อีเมลมีในระบบอยู่แล้ว
        result = success(createSuccessBody({ message: 'email_exist' }));
      } else {
        // ทำการเปลี่ยนอีเมลให้
        await query(updateEmailSQL);
        result = success(createSuccessBody({ message: 'success' }));
      }
    } else {
      // ส่ง message อีเมลไม่ถูกต้อง
      result = success(createSuccessBody({ message: 'email_incorrect' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateStayFitProfile(event) {
  const {
    user_id,
    other_attributes,
    start_date,
    program_id,
    is_beginner = false,
    is_firsttime = true,
  } = JSON.parse(event.body);
  const queryString = `
            UPDATE member SET
              other_attributes='${JSON.stringify(other_attributes)}'
            WHERE user_id='${user_id}';
        `;

  try {


    let videosQuery = 'select * from vdo_detail;';

    if (is_beginner && is_firsttime) {
      videosQuery = `
                      SELECT * 
                      FROM vdo_detail
                      WHERE (tag LIKE '%beginner%')
                      OR (category NOT IN ('Main Circuit', 'Cardio', 'Sub circuit'));
                    `
    }
    const videos = await queryRaw(videosQuery);
    let delVideos = [];
    if (!is_firsttime) {
      delVideos = await getVideoTemplates(user_id);
    }
    const schedule = JSON.stringify(generateVideos(start_date, 0, other_attributes.weight, videos, delVideos));
    const queryString2 = `
    UPDATE register_log SET
    video_template = '${schedule}'
    WHERE user_id = '${user_id}' AND round = 1 AND program_id = '${program_id}'
    `

    const queryStrings = [queryString, queryString2];

    const result = await transaction(queryStrings);
    return result;
  } catch (error) {
    return error;
  }

}

export async function cancelFriendRequest(event) {
  const {
    sender_id,
    receiver_id
  } = JSON.parse(event.body);

  const deleteFriendRequestSQL = `
  DELETE FROM friend_request 
  WHERE sender_id = '${sender_id}' and receiver_id = '${receiver_id}' and status = 'default';
  `;

  try {
    let result;
    await query(deleteFriendRequestSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function cancelTeamInvite(event) {
  const {
    sender_id,
    receiver_id
  } = JSON.parse(event.body);

  const deleteTeamInviteSQL = `
  DELETE FROM team_invite 
  WHERE sender_id = '${sender_id}' and receiver_id = '${receiver_id}' and status = 'default';
  `;

  try {
    let result;
    await query(deleteTeamInviteSQL);
    result = success(createSuccessBody({ message: 'success' }));
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateDisplayName(event) {
  const { user_id, display_name } = JSON.parse(event.body);
  const selectDisplayNameSQL = `select * from member where display_name='${display_name}'`;
  const updateDisplayNameSQL = `
  update member
  set display_name = '${display_name}'
  where user_id = '${user_id}';
  `;
  try {
    let result;
    const selectDisplayNameResult = await queryRaw(selectDisplayNameSQL);
    if (selectDisplayNameResult.length <= 0) {
      result = success(createSuccessBody({ message: 'new' }));
      await query(updateDisplayNameSQL);
    } else {
      result = success(createSuccessBody({ message: 'exist' }));
    }
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateProfile(event) {
  const {
    email,
    other_attributes,
    displayName
  } = JSON.parse(event.body);

  const queryString = `
            UPDATE member SET
              other_attributes='${JSON.stringify(other_attributes)}' ,display_name=${displayName ? `'${displayName}'` : null}
            WHERE email='${email}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateBodyInfo(event) {
  const {
    user_id,
    start_date,
    expire_date,
    other_attributes
  } = JSON.parse(event.body);
  var curr = new Date().getTime();
  var expireDate = new Date(expire_date).getTime();
  var week;
  if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
    week = calculateWeekInProgram(start_date, expire_date);
  } else {
    week = calculateWeekInProgram(start_date); //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  }

  const queryString = `
            UPDATE exercise_activity SET
              body_info='${JSON.stringify(other_attributes)}'
            WHERE user_id='${user_id}' AND week_in_program='${week}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function trialPackage(event) {
  const {
    email
  } = JSON.parse(event.body);

  const period = 14;
  const expire_date = `${moment().add(period, 'days').format('YYYY/MM/DD')} 23:59:59`;
  const start_date = `${moment().add(0, 'days').format('YYYY/MM/DD')} 00:00:00`;

  const queryString = `
            UPDATE member SET 
                start_date='${start_date}', expire_date='${expire_date}'
                WHERE email = '${email}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}