import { 
    getDistinctGroupId,
    formatLogs,
    checkTeamWeightCompleteness,
    filterThisWeekIndWeightLogs,
    distributeTeamScore,
    addIndividualScore,
    isAVGWeightLessThanLastWeek,
    isExerciseCompleted,
    getBonusScoreFromRank,
    sumOldScore,
    calculateEndRank
} from "../util/challengeScore";
import moment from "moment";
import { 
    memberEventLogs as logs, 
    members 
} from "./challengeData";

function userSort (a, b) {
    const userId1 = a.user_id;
    const userId2 = b.user_id;
    if (userId1 < userId2){
        return -1;
    } else if (userId1 > userId2) {
        return 1;
    } else {
        return 0;
    }
}

describe('getDistinctGroupId Test', () => {
    it('จากข้อมูล log ตัวอย่าง หากจัดกลุ่มจะเหลือแค่สองกลุ่มเท่านั้น', () => {
        const expectResult = ["first", "second"];
        const actualResult = getDistinctGroupId(logs);
        expect(actualResult).toEqual(expectResult); 
    });
});

describe('formatLogs Test', () => {
    it('จากข้อมูล log ตัวอย่าง หลังจากจัดกลุ่มเสร็จแล้ว array ผลลัพธ์ต้องมีสมาชิกสองตัว (สองกลุ่ม)', () => {
        const actualResult = formatLogs(logs);
        expect(actualResult.length).toEqual(2); 
    });
    it('จากข้อมูล log ตัวอย่าง หลังจากจัดกลุ่มเสร็จแล้ว data attribute ของ object ทุกตัวใน array ผลลัพธ์ ต้องมีจำนวนสมาชิกมากกว่า 0', () => {
        const actualResult = formatLogs(logs);
        expect(actualResult[0].data.length).toBeGreaterThan(0); 
    });
    it('จากข้อมูล log ตัวอย่าง สมาชิกในแต่ละกลุ่มต้องไม่ซ้ำกัน', () => {
        const formatedLogs = formatLogs(logs);
        formatedLogs[0].data.sort(userSort)
        let loopUserId = "";
        let hasDuplicatedUserId = false;
        for (let index = 0; index < formatedLogs[0].data.length; index++) {
            const firstGroupLog = formatedLogs[0].data[index];
            if (firstGroupLog.user_id === loopUserId) {
                continue;
            } else {
                loopUserId = firstGroupLog.user_id;
                const found = formatedLogs[1].data.find(secondGroupLog => firstGroupLog.user_id === secondGroupLog.user_id );
                hasDuplicatedUserId = found !== undefined;
            }
        }
        expect(hasDuplicatedUserId).toBeFalsy(); 
    });
    it('user_id ที่อยู่ใน log ภายใน data attributes ต้องเป็นสมาชิกที่อยู่ใน members attribute เท่านั้น', () => {
        const formatedLogs = formatLogs(logs, members);
        formatedLogs[0].data.sort(userSort);
        formatedLogs[0].members.sort(userSort);
        let isAllLogUserIdStayInMembersAttribute = true;
        for (let index = 0; index < formatedLogs[0].data.length; index++) {
            const dataUserId = formatedLogs[0].data[index].user_id; 
            const groupMembers = formatedLogs[0].members;

            const found = groupMembers.find(member => dataUserId === member.user_id );
            if (!found) {
                isAllLogUserIdStayInMembersAttribute = false;
                break;
            }
        }
        expect(isAllLogUserIdStayInMembersAttribute).toBeTruthy();
    });
    it('array ผลลัพธ์ ต้องมี attribute ชื่อ group_id และ data', () => {
        const actualResult = formatLogs(logs);
        expect(actualResult[0]).toHaveProperty("group_id"); 
        expect(actualResult[0]).toHaveProperty("data"); 
        expect(actualResult[0]).toHaveProperty("members"); 
    });
});


describe('filterThisWeekIndWeightLogs Test', () => {
    it('สมาชิกทุกตัวต้องมีค่า log_type เป็น individual', () => {
        const formatedLogs = formatLogs(logs);
        const resultLogs = filterThisWeekIndWeightLogs(formatedLogs[0].data);
        let isAllIndividualLog = true
        for (let i = 0; i < resultLogs.length; i++) {
            const log = resultLogs[i];
            if (log.log_type !== "individual") {
                isAllIndividualLog = false;
                break;
            }
        }
        expect(isAllIndividualLog).toBeTruthy(); 
    });
    it('สมาชิกทุกตัวต้องมีค่า log เป็น weight', () => {
        const formatedLogs = formatLogs(logs);
        const resultLogs = filterThisWeekIndWeightLogs(formatedLogs[0].data);
        let isAllWeightLog = true
        for (let i = 0; i < resultLogs.length; i++) {
            const log = resultLogs[i];
            if (log.log !== "weight") {
                isAllWeightLog = false;
                break;
            }
        }
        expect(isAllWeightLog).toBeTruthy(); 
    });
    it('สมาชิกทุกตัวต้องมีค่า activity_date อยู่ในสัปดาห์ปัจจุบันของข้อมูลตัวอย่าง (2021-03-22 to 2021-03-28)', () => {
        const formatedLogs = formatLogs(logs);
        const resultLogs = filterThisWeekIndWeightLogs(formatedLogs[0].data, '2021-03-22');
        let isInCurrentWeekLog = true
        for (let i = 0; i < resultLogs.length; i++) {
            const log = resultLogs[i];
            if (!moment(log.activity_date).isBetween('2021-03-22', '2021-03-28', undefined, [])) {
                isInCurrentWeekLog = false;
                break;
            }
        }
        expect(isInCurrentWeekLog).toBeTruthy(); 
    });
});

//ถ้าไม่กำหนดระยะเวลา จะเทสไม่ผ่าน
describe('checkTeamWeightCompleteness Test', () => {
    it('จากข้อมูล log ตัวอย่าง กลุ่มแรกต้องผ่าน', () => {
        const formatedLogs = formatLogs(logs, members);
        const actualResult = checkTeamWeightCompleteness(formatedLogs[0], '2021-03-22');
        expect(actualResult).toBeTruthy();
    });
    it('จากข้อมูล log ตัวอย่าง กลุ่มสองต้องตก', () => {
        const formatedLogs = formatLogs(logs, members);
        const actualResult = checkTeamWeightCompleteness(formatedLogs[1], '2021-03-22');
        expect(actualResult).toBeFalsy(); 
    });
});

describe('distributeTeamScore Test', () => {
    it('สมาชิกทุกคนต้องได้คะแนน 10 คะแนนหากไม่มีการระบุ second params', () => {
        const membersData = {
            "members": [
                {user_id: "10011", group_id: "first"},
                {user_id: "10012", group_id: "first"}
            ]
        }
        const newMembersData = distributeTeamScore(membersData);

        let isAllMemberGetScore = false;

        for (let index = 0; index < newMembersData.length; index++) {
            const memberData = newMembersData[index];
            if(memberData.new_score && memberData.new_score === 10) {
                isAllMemberGetScore = true;
            }
        }

        expect(isAllMemberGetScore).toBeTruthy(); 
    });
    it('สมาชิกทุกคนต้องได้คะแนนเพิ่มตามที่ระบุไว้ใน second param', () => {
        const membersData = {
            "members": [
                {user_id: "10011", group_id: "first"},
                {user_id: "10012", group_id: "first"}
            ]
        }
        const newMembersData = distributeTeamScore(membersData, 5);

        let isAllMemberGetScore = false;

        for (let index = 0; index < newMembersData.length; index++) {
            const memberData = newMembersData[index];
            if(memberData.new_score && memberData.new_score === 5) {
                isAllMemberGetScore = true;
            }
        }

        expect(isAllMemberGetScore).toBeTruthy(); 
    });
    it('หากสมาชิกทุกคนมีคะแนนในช่อง new_score อยู่แล้ว จะต้องได้เพิ่ม 10 คะแนนหากไม่มีการระบุ second params', () => {
        const membersData = {
            "members": [
                {user_id: "10011", group_id: "first", new_score: 20},
                {user_id: "10012", group_id: "first", new_score: 20}
            ]
        }
        const newMembersData = distributeTeamScore(membersData);

        let isAllMemberGetAddedScore = false;

        for (let index = 0; index < newMembersData.length; index++) {
            const memberData = newMembersData[index];
            if(memberData.new_score && memberData.new_score === 30) {
                isAllMemberGetAddedScore = true;
            }
        }

        expect(isAllMemberGetAddedScore).toBeTruthy(); 
    });
    it('หากสมาชิกทุกคนมีคะแนนในช่อง new_score อยู่แล้ว จะต้องได้คะแนนเพิ่มตามที่ระบุไว้ใน second param', () => {
        const membersData = {
            "members": [
                {user_id: "10011", group_id: "first", new_score: 20},
                {user_id: "10012", group_id: "first", new_score: 20}
            ]
        }
        const newMembersData = distributeTeamScore(membersData, 5);

        let isAllMemberGetAddedScore = false;

        for (let index = 0; index < newMembersData.length; index++) {
            const memberData = newMembersData[index];
            if(memberData.new_score && memberData.new_score === 25) {
                isAllMemberGetAddedScore = true;
            }
        }

        expect(isAllMemberGetAddedScore).toBeTruthy(); 
    });
});

describe('addIndividualScore Test', () => {
    it('สมาชิกได้คะแนน 10 คะแนนหากไม่มีการระบุ second params', () => {
        const member = {user_id: "10011", group_id: "first"};
        const newMember = addIndividualScore(member);

        expect(newMember.new_score).toBeDefined(); 
        expect(newMember.new_score).toBe(10);
    });
    it('สมาชิกได้คะแนนตามที่ระบุใน second params', () => {
        const member = {user_id: "10011", group_id: "first"};
        const newMember = addIndividualScore(member, 5);

        expect(newMember.new_score).toBeDefined(); 
        expect(newMember.new_score).toBe(5);
    });
    it('หากสมาชิกมีคะแนนในช่อง new_score อยู่แล้ว จะต้องได้เพิ่ม 10 คะแนนหากไม่มีการระบุ second params', () => {
        const member = {user_id: "10011", group_id: "first", new_score: 10};
        const newMember = addIndividualScore(member);

        expect(newMember.new_score).toBeDefined(); 
        expect(newMember.new_score).toBe(20);
    });
    it('หากสมาชิกมีคะแนนในช่อง new_score อยู่แล้ว จะต้องได้เพิ่มคะแนนตามที่ระบุ second params', () => {
        const member = {user_id: "10011", group_id: "first", new_score: 10};
        const newMember = addIndividualScore(member, 5);

        expect(newMember.new_score).toBeDefined(); 
        expect(newMember.new_score).toBe(15);
    });
});

describe('isAVGWeightLessThanLastWeek Test', () => {
    const logData = {
        "data": [
            {"user_id": 10011, "log": "weight", "log_value": 73.6, "log_type": "individual", "activity_date": "2021-03-18"},
            {"user_id": 10011, "log": "weight", "log_value": 73.4, "log_type": "individual", "activity_date": "2021-03-19"},
            {"user_id": 10011, "log": "weight", "log_value": 72.6, "log_type": "individual", "activity_date": "2021-03-25"},
            {"user_id": 10011, "log": "weight", "log_value": 72.4, "log_type": "individual", "activity_date": "2021-03-26"},
            {"user_id": 10012, "log": "weight", "log_value": 73.6, "log_type": "individual", "activity_date": "2021-03-18"},
            {"user_id": 10012, "log": "weight", "log_value": 73.4, "log_type": "individual", "activity_date": "2021-03-19"},
            {"user_id": 10012, "log": "weight", "log_value": 73.6, "log_type": "individual", "activity_date": "2021-03-25"},
            {"user_id": 10012, "log": "weight", "log_value": 73.6, "log_type": "individual", "activity_date": "2021-03-26"}
        ]
    }
    it('ถ้าเป็นสัปดาห์แรก ต้อง return false', () => {
        const actualResult = isAVGWeightLessThanLastWeek(logData, "10011", "2021-03-18");
        expect(actualResult).toBeFalsy(); 
    });
    it('หากค่าเฉลี่ยน้ำหนักลดลง ต้อง return true', () => {
        const actualResult = isAVGWeightLessThanLastWeek(logData, "10011", "2021-03-25");
        expect(actualResult).toBeTruthy(); 
    });
    it('หากค่าเฉลี่ยน้ำหนักเพิ่มขึ้น ต้อง return false', () => {
        const actualResult = isAVGWeightLessThanLastWeek(logData, "10012", "2021-03-25");
        expect(actualResult).toBeFalsy(); 
    });
});

describe('isExerciseCompleted Test', () => {
    it('หากเป็นผู้ใช้ที่เล่นไม่ครบต้อง return false', () => {
        const actualResult = isExerciseCompleted(members[0].activites);
        expect(actualResult).toBeFalsy();
    });
    it('หากเป็นผู้ใช้ที่เล่นครบต้อง return true', () => {
        const actualResult = isExerciseCompleted(members[2].activites);
        expect(actualResult).toBeTruthy();
    });
});

describe('getBonusScoreFromRank test', () => {
    it('หาก rank เป็น gold จะได้ 5 แต้ม', () => {
        expect(getBonusScoreFromRank("gold")).toBe(5);
    });
    it('หาก rank เป็น platinum จะได้ 10 แต้ม', () => {
        expect(getBonusScoreFromRank("Platinum")).toBe(10);
    });
    it('หาก rank เป็น silver จะได้ 0 แต้ม', () => {
        expect(getBonusScoreFromRank("SiLver")).toBe(0);
    });
});

describe('sumOldScore test', () => {
    const oldScoreTeamLogs = {
        data: [
            { user_id: "10011", log: "weight", log_value: "73", log_type: "individual", score: 0, activity_date: "2021-03-15", group_id: "first" },
            { user_id: "10011", log: "weight bonus", log_value: "0", log_type: "team", score: 10, activity_date: "2021-03-15", group_id: "first" },
            { user_id: "10011", log: "weight bonus", log_value: "0", log_type: "team", score: 10, activity_date: "2021-03-16", group_id: "first" },
            { user_id: "10011", log: "weight", log_value: "72.9", log_type: "individual", score: 0, activity_date: "2021-03-22", group_id: "first" },
            { user_id: "10012", log: "weight", log_value: "72.9", log_type: "individual", score: 0, activity_date: "2021-03-22", group_id: "first" },
            { user_id: "10011", log: "weight bonus", log_value: "0", log_type: "team", score: 10, activity_date: "2021-03-22", group_id: "first" },
            { user_id: "10011", log: "weight bonus", log_value: "0", log_type: "team", score: 10, activity_date: "2021-03-23", group_id: "first" }
        ]
    };
    it('หากเป็น user 10011 จะได้ oldScore เป็น 20', () => {
        expect(sumOldScore(oldScoreTeamLogs, '10011', '2021-03-22')).toBe(20);
    });
});

describe('calculateEndRank test', () => {
    it('ถ้าคะแนนต้้งแต่ 40 ลงไปแล้ว start_rank เป็น platinum ผลลัพธ์จะต้องเป็น gold', () => {
        expect(calculateEndRank("platinum", 30)).toBe("gold");
    });
    it('ถ้าคะแนนเกิน 40 แล้ว start_rank เป็น rank สูงสุดผลลัพธ์จะต้องเป็นเป็น rank เดิม', () => {
        const start_rank = "platinum";
        expect(calculateEndRank(start_rank, 50)).toBe(start_rank);
    });
    it('ถ้าคะแนนตั้งแต่ 40 ลงไปแล้ว start_rank เป็น rank ต่ำสุดผลลัพธ์จะต้องเป็นเป็น rank เดิม', () => {
        const start_rank = "newbie";
        expect(calculateEndRank(start_rank, 30)).toBe(start_rank);
    });
    it('ถ้าคะแนนเกิน 40 และ rank ทั้งหมดมีจำนวนมากกว่า default ที่เคยกำหนดไว้ใน req. แล้ว start_rank เป็น rank สูงสุดผลลัพธ์จะต้องเป็นเป็น rank เดิม', () => {
        const newRankArray = [
            "newbie", 
            "bronze",
            "silver",
            "gold",
            "platinum",
            "diamond"
        ]
        const start_rank = "diamond";
        expect(calculateEndRank(start_rank, 50, newRankArray)).toBe(start_rank);
    });
})
