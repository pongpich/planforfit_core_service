import {
  scheduleGeneratorGen1Value,
  getWarmUp,
  getCoolDown,
  getCardioFourDay,
  getSubcurcitFourDay,
  getMainCircuitByType,
  groupSchedule,
  generateVideos,
  calculateWeekInProgram,
  processByCategory,
  generateToRemoveVideos
} from '../util/schedule';

import { vdoDetail as videos } from './vdoDetail';

describe("calculateWeekInProgram Test", () => {
  it("ระหว่าง 1/10/2020 ถึง 6/11/2020 ต้องเป็น 6สัปดาห์", () => {
    const result = calculateWeekInProgram("2020-10-01", "2020-11-06");
    expect(result).toBe(6);
  });
  it("ระหว่าง 2/11/2020 ถึง 6/11/2020 ต้องเป็น 1สัปดาห์", () => {
    const result = calculateWeekInProgram("2020-11-02", "2020-11-06");
    expect(result).toBe(1);
  });
  it("วันแรกเป็นวันอาทิตย์ วันต่อมาเป็นวันจันทร์ ต้องห่างกัน 2สัปดาห์", () => {
    const result = calculateWeekInProgram("2020-10-04", "2020-10-05");
    expect(result).toBe(2);
  });
  it("วันแรกเป็นวันจันทร์ วันสุดท้ายเป็นวันอาทิตย์ ในสัปดาห์เดียวกัน ต้องห่างกัน 1สัปดาห์", () => {
    const result = calculateWeekInProgram("2020-11-02", "2020-11-08");
    expect(result).toBe(1);
  });
});
describe("generateVideos Test", () => {
  it("วีดีโอแต่ละวัน order ต้องเรียงลำดับ", () => {
    const result = generateVideos("2020-09-30", 5, 45, videos, "2020-11-03");
    let isOrder = true;
    let prevOrder = -1;
    for (let index = 0; index < result[0].length; index++) {
      const video = result[0][index];
      if (video.order <= prevOrder) {
        isOrder = false;
        break;
      }
      prevOrder = video.order;
    }
    expect(isOrder).toBeTruthy();
  });
  it("วีดีโอแต่ละตัวต้องมี field play_time", () => {
    const result = generateVideos("2020-09-30", 5, 45, videos, "2020-11-03");
    expect(result[0][0].hasOwnProperty('play_time')).toBeTruthy();
  });
  it("วีดีโอแต่ละตัวต้องมี order", () => {
    const result = generateVideos("2020-09-30", 5, 45, videos, "2020-11-03");
    expect(result[0][0].hasOwnProperty('order')).toBeTruthy();
  });
  it("type แต่ละวันของ mainCircuit ตรงตามที่ต้องการ", () => {
    const result = generateVideos("2020-09-30", 5, 45, videos, "2020-11-03");
    const typeDay1 = result[0].filter(element => element.type.toLowerCase() === 'chest focus' && element.category.toLowerCase() === 'main circuit');
    const typeDay2 = result[1].filter(element => element.type.toLowerCase() === 'back focus' && element.category.toLowerCase() === 'main circuit');
    const typeDay3 = result[2].filter(element => element.type.toLowerCase() === 'leg focus' && element.category.toLowerCase() === 'main circuit');
    const typeDay4 = result[3].filter(element => element.type.toLowerCase() === 'arm focus' && element.category.toLowerCase() === 'main circuit');
    expect(typeDay1[0].type.toLowerCase()).toEqual('chest focus');
    expect(typeDay2[0].type.toLowerCase()).toEqual('back focus');
    expect(typeDay3[0].type.toLowerCase()).toEqual('leg focus');
    expect(typeDay4[0].type.toLowerCase()).toEqual('arm focus');
  });
  it("ภายใน 1สัปดาห์ cardio ห้ามซ้ำ", () => {
    const result = generateVideos("2020-09-30", 0, 82, videos, "2020-11-20");
    const cardioDay1 = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cardioDay2 = result[1].filter(element => element.category.toLowerCase() === 'cardio');
    const cardioDay3 = result[2].filter(element => element.category.toLowerCase() === 'cardio');
    const cardioDay4 = result[3].filter(element => element.category.toLowerCase() === 'cardio');

    let count12 = 0;
    for (let day1 = 0; day1 < cardioDay1.length; day1++) {
      for (let day2 = 0; day2 < cardioDay2.length; day2++) {
        if (cardioDay1[day1].video_id === cardioDay2[day2].video_id) {
          count12 += 1;
        }
      }
    }

    let count13 = 0;
    for (let day1 = 0; day1 < cardioDay1.length; day1++) {
      for (let day3 = 0; day3 < cardioDay3.length; day3++) {
        if (cardioDay1[day1].video_id === cardioDay3[day3].video_id) {
          count13 += 1;
        }
      }
    }

    let count14 = 0;
    for (let day1 = 0; day1 < cardioDay1.length; day1++) {
      for (let day4 = 0; day4 < cardioDay4.length; day4++) {
        if (cardioDay1[day1].video_id === cardioDay4[day4].video_id) {
          count14 += 1;
        }
      }
    }

    let count23 = 0;
    for (let day2 = 0; day2 < cardioDay2.length; day2++) {
      for (let day3 = 0; day3 < cardioDay3.length; day3++) {
        if (cardioDay2[day2].video_id === cardioDay3[day3].video_id) {
          count23 += 1;
        }
      }
    }

    let count24 = 0;
    for (let day2 = 0; day2 < cardioDay2.length; day2++) {
      for (let day4 = 0; day4 < cardioDay4.length; day4++) {
        if (cardioDay2[day2].video_id === cardioDay4[day4].video_id) {
          count24 += 1;
        }
      }
    }

    let count34 = 0;
    for (let day3 = 0; day3 < cardioDay3.length; day3++) {
      for (let day4 = 0; day4 < cardioDay4.length; day4++) {
        if (cardioDay3[day3].video_id === cardioDay4[day4].video_id) {
          count34 += 1;
        }
      }
    }

    expect(count12).toEqual(0);
    expect(count13).toEqual(0);
    expect(count14).toEqual(0);
    expect(count23).toEqual(0);
    expect(count24).toEqual(0);
    expect(count34).toEqual(0);
  });
  it("ภายใน 1สัปดาห์ sub circuit ห้ามซ้ำ", () => {
    const result = generateVideos("2020-09-30", 0, 82, videos, "2020-11-20");
    const subCircuitDay1 = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const subCircuitDay2 = result[1].filter(element => element.category.toLowerCase() === 'sub circuit');
    const subCircuitDay3 = result[2].filter(element => element.category.toLowerCase() === 'sub circuit');
    const subCircuitDay4 = result[3].filter(element => element.category.toLowerCase() === 'sub circuit');

    let count12 = 0;
    for (let day1 = 0; day1 < subCircuitDay1.length; day1++) {
      for (let day2 = 0; day2 < subCircuitDay2.length; day2++) {
        if (subCircuitDay1[day1].video_id === subCircuitDay2[day2].video_id) {
          count12 += 1;
        }
      }
    }

    let count13 = 0;
    for (let day1 = 0; day1 < subCircuitDay1.length; day1++) {
      for (let day3 = 0; day3 < subCircuitDay3.length; day3++) {
        if (subCircuitDay1[day1].video_id === subCircuitDay3[day3].video_id) {
          count13 += 1;
        }
      }
    }

    let count14 = 0;
    for (let day1 = 0; day1 < subCircuitDay1.length; day1++) {
      for (let day4 = 0; day4 < subCircuitDay4.length; day4++) {
        if (subCircuitDay1[day1].video_id === subCircuitDay4[day4].video_id) {
          count14 += 1;
        }
      }
    }

    let count23 = 0;
    for (let day2 = 0; day2 < subCircuitDay2.length; day2++) {
      for (let day3 = 0; day3 < subCircuitDay3.length; day3++) {
        if (subCircuitDay2[day2].video_id === subCircuitDay3[day3].video_id) {
          count23 += 1;
        }
      }
    }

    let count24 = 0;
    for (let day2 = 0; day2 < subCircuitDay2.length; day2++) {
      for (let day4 = 0; day4 < subCircuitDay4.length; day4++) {
        if (subCircuitDay2[day2].video_id === subCircuitDay4[day4].video_id) {
          count24 += 1;
        }
      }
    }

    let count34 = 0;
    for (let day3 = 0; day3 < subCircuitDay3.length; day3++) {
      for (let day4 = 0; day4 < subCircuitDay4.length; day4++) {
        if (subCircuitDay3[day3].video_id === subCircuitDay4[day4].video_id) {
          count34 += 1;
        }
      }
    }
    expect(count12).toEqual(0);
    expect(count13).toEqual(0);
    expect(count14).toEqual(0);
    expect(count23).toEqual(0);
    expect(count24).toEqual(0);
    expect(count34).toEqual(0);

  });
  it("ภายใน 1สัปดาห์ main circuit ห้ามซ้ำ", () => {
    const result = generateVideos("2020-09-30", 0, 82, videos, "2020-11-20");
    const mainCircuitDay1 = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    const mainCircuitDay2 = result[1].filter(element => element.category.toLowerCase() === 'main circuit');
    const mainCircuitDay3 = result[2].filter(element => element.category.toLowerCase() === 'main circuit');
    const mainCircuitDay4 = result[3].filter(element => element.category.toLowerCase() === 'main circuit');

    let count12 = 0;
    for (let day1 = 0; day1 < mainCircuitDay1.length; day1++) {
      for (let day2 = 0; day2 < mainCircuitDay2.length; day2++) {
        if (mainCircuitDay1[day1].video_id === mainCircuitDay2[day2].video_id) {
          count12 += 1;
        }
      }
    }

    let count13 = 0;
    for (let day1 = 0; day1 < mainCircuitDay1.length; day1++) {
      for (let day3 = 0; day3 < mainCircuitDay3.length; day3++) {
        if (mainCircuitDay1[day1].video_id === mainCircuitDay3[day3].video_id) {
          count13 += 1;
        }
      }
    }

    let count14 = 0;
    for (let day1 = 0; day1 < mainCircuitDay1.length; day1++) {
      for (let day4 = 0; day4 < mainCircuitDay4.length; day4++) {
        if (mainCircuitDay1[day1].video_id === mainCircuitDay4[day4].video_id) {
          count14 += 1;
        }
      }
    }

    let count23 = 0;
    for (let day2 = 0; day2 < mainCircuitDay2.length; day2++) {
      for (let day3 = 0; day3 < mainCircuitDay3.length; day3++) {
        if (mainCircuitDay2[day2].video_id === mainCircuitDay3[day3].video_id) {
          count23 += 1;
        }
      }
    }

    let count24 = 0;
    for (let day2 = 0; day2 < mainCircuitDay2.length; day2++) {
      for (let day4 = 0; day4 < mainCircuitDay4.length; day4++) {
        if (mainCircuitDay2[day2].video_id === mainCircuitDay4[day4].video_id) {
          count24 += 1;
        }
      }
    }

    let count34 = 0;
    for (let day3 = 0; day3 < mainCircuitDay3.length; day3++) {
      for (let day4 = 0; day4 < mainCircuitDay4.length; day4++) {
        if (mainCircuitDay3[day3].video_id === mainCircuitDay4[day4].video_id) {
          count34 += 1;
        }
      }
    }
    expect(count12).toEqual(0);
    expect(count13).toEqual(0);
    expect(count14).toEqual(0);
    expect(count23).toEqual(0);
    expect(count24).toEqual(0);
    expect(count34).toEqual(0);
  });
  it("ภายใน 1สัปดาห์ ต้องมีวันออกกำลังกาย 4วัน", () => {
    const result = generateVideos("2020-09-30", 5, 45, videos, "2020-11-03");
    expect(result.length).toEqual(4);
  });
  it("กรณี 1-30วัน ในทุกๆวัน มีคลิปตามกำหนดใน category อย่างน้อยอันละ 1คลิป *ยกเว้นน้ำหนักน้อยกว่า 50", () => {
    const result = generateVideos("2020-09-29", 0, 60, videos, "2020-09-30");
    const warmUp = result[0].filter(element => element.category.toLowerCase() === 'warm up');
    const mainCircuit = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    const subCircuit = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const cardio = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cooldown = result[0].filter(element => element.category.toLowerCase() === 'cool down');
    expect(warmUp.length >= 1).toEqual(true);
    expect(mainCircuit.length >= 1).toEqual(true);
    expect(subCircuit.length >= 1).toEqual(true);
    expect(cardio.length >= 1).toEqual(true);
    expect(cooldown.length >= 1).toEqual(true);
  });
  it("กรณี 31-60วัน ในทุกๆวัน มีคลิปตามกำหนดใน category อย่างน้อยอันละ 1คลิป *ยกเว้นน้ำหนักน้อยกว่า 50", () => {
    const result = generateVideos("2020-09-30", 0, 60, videos, "2020-11-02");
    const warmUp = result[0].filter(element => element.category.toLowerCase() === 'warm up');
    const mainCircuit = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    const subCircuit = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const cardio = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cooldown = result[0].filter(element => element.category.toLowerCase() === 'cool down');
    expect(warmUp.length >= 1).toEqual(true);
    expect(mainCircuit.length >= 1).toEqual(true);
    expect(subCircuit.length >= 1).toEqual(true);
    expect(cardio.length >= 1).toEqual(true);
    expect(cooldown.length >= 1).toEqual(true);
  });
  it("กรณี 61-120วัน ในทุกๆวัน มีคลิปตามกำหนดใน category อย่างน้อยอันละ 1คลิป *ยกเว้นน้ำหนักน้อยกว่า 50", () => {
    const result = generateVideos("2020-03-31", 0, 60, videos, "2020-06-02");
    const warmUp = result[0].filter(element => element.category.toLowerCase() === 'warm up');
    const mainCircuit = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    const subCircuit = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const cardio = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cooldown = result[0].filter(element => element.category.toLowerCase() === 'cool down');
    expect(warmUp.length >= 1).toEqual(true);
    expect(mainCircuit.length >= 1).toEqual(true);
    expect(subCircuit.length >= 1).toEqual(true);
    expect(cardio.length >= 1).toEqual(true);
    expect(cooldown.length >= 1).toEqual(true);
  });
  /* it("กรณี 121-180วัน ในทุกๆวัน มีคลิปตามกำหนดใน category อย่างน้อยอันละ 1คลิป *ยกเว้นน้ำหนักน้อยกว่า 50", () => {
    const result = generateVideos("2020-03-31", 0, 60, videos, "2020-07-31");
    const warmUp = result[0].filter(element => element.category.toLowerCase() === 'warm up');
    const mainCircuit = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    const chestChallenge = result[0].filter(element => element.category.toLowerCase() === 'chest challenge');
    const backChallenge = result[0].filter(element => element.category.toLowerCase() === 'back challenge');
    const legChallenge = result[0].filter(element => element.category.toLowerCase() === 'leg challenge');
    const armChallenge = result[0].filter(element => element.category.toLowerCase() === 'arm challenge');
    const subCircuit = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const cardio = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cooldown = result[0].filter(element => element.category.toLowerCase() === 'cool down');
    expect(warmUp.length >= 1).toEqual(true);
    expect(mainCircuit.length >= 1).toEqual(true);
    expect(chestChallenge.length >= 1).toEqual(true);
    expect(backChallenge.length >= 1).toEqual(true);
    expect(legChallenge.length >= 1).toEqual(true);
    expect(armChallenge.length >= 1).toEqual(true);
    expect(subCircuit.length >= 1).toEqual(true);
    expect(cardio.length >= 1).toEqual(true);
    expect(cooldown.length >= 1).toEqual(true);
  }); */
  it("กรณี 181-210วัน ในทุกๆวัน มีคลิปตามกำหนดใน category อย่างน้อยอันละ 1คลิป *ยกเว้นน้ำหนักน้อยกว่า 50", () => {
    const result = generateVideos("2020-03-31", 0, 60, videos, "2020-09-30");
    const warmUp = result[0].filter(element => element.category.toLowerCase() === 'warm up');
    //const mainCircuitAccerelation1 = result[0].filter(element => element.category.toLowerCase() === 'main circuit accerelation 1');
    const mainCircuit = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    //const subCircuitAccerelation1 = result[0].filter(element => element.category.toLowerCase() === 'sub circuit accerelation 1');
    const subCircuit = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const cardio = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cooldown = result[0].filter(element => element.category.toLowerCase() === 'cool down');
    expect(warmUp.length >= 1).toEqual(true);
    //expect(mainCircuitAccerelation1.length >= 1).toEqual(true);
    expect(mainCircuit.length >= 1).toEqual(true);
    //expect(subCircuitAccerelation1.length >= 1).toEqual(true);
    expect(subCircuit.length >= 1).toEqual(true);
    expect(cardio.length >= 1).toEqual(true);
    expect(cooldown.length >= 1).toEqual(true);
  });
  it("กรณี 211-240วัน ในทุกๆวัน มีคลิปตามกำหนดใน category อย่างน้อยอันละ 1คลิป *ยกเว้นน้ำหนักน้อยกว่า 50", () => {
    const result = generateVideos("2020-03-31", 0, 60, videos, "2020-10-31");
    const warmUp = result[0].filter(element => element.category.toLowerCase() === 'warm up');
    //const mainCircuitAccerelation2 = result[0].filter(element => element.category.toLowerCase() === 'main circuit accerelation 2');
    const mainCircuit = result[0].filter(element => element.category.toLowerCase() === 'main circuit');
    //const subCircuitAccerelation2 = result[0].filter(element => element.category.toLowerCase() === 'sub circuit accerelation 2');
    const subCircuit = result[0].filter(element => element.category.toLowerCase() === 'sub circuit');
    const cardio = result[0].filter(element => element.category.toLowerCase() === 'cardio');
    const cooldown = result[0].filter(element => element.category.toLowerCase() === 'cool down');
    expect(warmUp.length >= 1).toEqual(true);
    //expect(mainCircuitAccerelation2.length >= 1).toEqual(true);
    expect(mainCircuit.length >= 1).toEqual(true);
    //expect(subCircuitAccerelation2.length >= 1).toEqual(true);
    expect(subCircuit.length >= 1).toEqual(true);
    expect(cardio.length >= 1).toEqual(true);
    expect(cooldown.length >= 1).toEqual(true);
  });
});
describe("getWarmUp Test", () => {
  it("เอาVDO ที่อยู่ใน category 'warm up' ", () => {
    const result = getWarmUp(videos);
    expect(result[0].category.toLowerCase()).toBe("warm up");
  });
  it('วิดีโอทั้งหมดต้องเป็น warm up', () => {
    const warmups = getWarmUp(videos);
    const result = warmups.filter(cardio => cardio.category.toLowerCase() === 'warm up');
    expect(warmups.length).toBe(result.length);
  });
  it('วิดีโอทั้งหมดต้องเป็น warm up', () => {
    const warmups = getWarmUp(videos);
    const result = warmups.filter(cardio => cardio.category.toLowerCase() === 'warm up');
    expect(warmups.length).toBe(result.length);
  });
  it('วิดีโอ warm up ต้องมี 1 คลิปเท่านั้น', () => {
    const warmups = getWarmUp(videos);
    expect(warmups.length).toBe(1);
  });
});
describe("getCoolDown Test", () => {
  it("เอาVDO ที่อยู่ใน category 'cool down'", () => {
    const result = getCoolDown(videos);
    expect(result[0].category.toLowerCase()).toEqual("cool down");
  });
  it('วิดีโอทั้งหมดต้องเป็น cool down', () => {
    const cooldowns = getCoolDown(videos);
    const result = cooldowns.filter(cardio => cardio.category.toLowerCase() === 'cool down');
    expect(cooldowns.length).toBe(result.length);
  });
  it('วิดีโอ cooldown ต้องมี 1 คลิปเท่านั้น', () => {
    const cooldowns = getCoolDown(videos);
    expect(cooldowns.length).toBe(1);
  });
});
describe("getCardioFourDay Test", () => {
  it("กรณีใส่ amountCardio = 1  ผลลัพธืคือ Array ที่มีสมาชิก 4ตัว แต่ละตัวเป็นArray 1สมาชิก", () => {
    const result = getCardioFourDay(1, ['1'], videos);
    expect(result.length).toBe(4);
    expect(result[0].length).toBe(1);
  });
  it("กรณีใส่ amountCardio = 4  ผลลัพธืคือ Array ที่มีสมาชิก 4ตัว แต่ละตัวเป็นArray 4สมาชิก", () => {
    const result = getCardioFourDay(4, ['1'], videos);
    expect(result.length).toBe(4);
    expect(result[0].length).toBe(4);
  });
  it("กรณี genClip 2รุ่น และเล่นวันละ 3คลิป จะได้Array 4สมาชิก แต่ละตัวมี 3คลิป", () => {
    const result = getCardioFourDay(3, ['1', '2'], videos);
    expect(result.length).toBe(4);
    expect(result[3].length).toBe(3);
  });
  it("กรณี genClip 2รุ่น และเล่นวันละ 3คลิป จะได้ว่าในแต่ละวัน คลิปรุ่น2 มี 2คลิป และรุ่น1 มี 1คลิป", () => {
    const result = getCardioFourDay(3, ['1', '2'], videos);
    const gen1Result = result[0].filter(element => element.clip_gen === '1');
    const gen2Result = result[0].filter(element => element.clip_gen === '2');
    expect(gen1Result.length).toBe(1);
    expect(gen2Result.length).toBe(2);
  });
  it("กรณี genClip 3รุ่น และเล่นวันละ 3คลิป จะได้Array 4สมาชิก แต่ละตัวมี 3คลิป", () => {
    const result = getCardioFourDay(3, ['1', '2', '3'], videos);
    expect(result.length).toBe(4);
    expect(result[2].length).toBe(3);
  });
  it("กรณี genClip 3รุ่น และเล่นวันละ 3คลิป จะได้ว่าในแต่ละวัน คลิปรุ่น3 มี 2คลิป และสุ่มระหว่างรุ่น1หรือรุ่น2 มา 1คลิป", () => {
    const result = getCardioFourDay(3, ['1', '2', '3'], videos);
    const gen1_2Result = result[3].filter(element => element.clip_gen === '1' || element.clip_gen === '2');
    const gen3Result = result[3].filter(element => element.clip_gen === '3');
    expect(gen1_2Result.length).toBe(1);
    expect(gen3Result.length).toBe(2);
  });
  it("กรณี genClip 3รุ่น และเล่นวันละ 1คลิป จะได้ว่าในแต่ละวัน คลิปรุ่น3 มี 1คลิป", () => {
    const result = getCardioFourDay(1, ['1', '2', '3'], videos);
    const gen1_2Result = result[3].filter(element => element.clip_gen === '1' || element.clip_gen === '2');
    const gen3Result = result[3].filter(element => element.clip_gen === '3');
    expect(gen1_2Result.length).toBe(0);
    expect(gen3Result.length).toBe(1);
  });
  it('วิดีโอทั้งหมดต้องเป็น cardio', () => {
    const cardios = getCardioFourDay(3, ['1', '2'], videos);
    const result = cardios[3].filter(cardio => cardio.category.toLowerCase() === 'cardio');
    expect(cardios[3].length).toBe(result.length);
  });
});
describe("getSubcurcitFourDay Test", () => {
  it("กรณีใส่ amountsubCircutPerDay = 2 ผลลัพธ์Arrayแต่ละตัว จะต้องมีสมาชิก 1ตัว", () => {
    const result = getSubcurcitFourDay(2, ['1'], videos);
    expect(result[3].length).toEqual(1);
  });
  it("กรณี clipGenมี2รุ่น ผลลัพธ์Arrayแต่ละตัว จะต้องมีสมาชิก 2ตัว", () => {
    const result = getSubcurcitFourDay(2, ['1', '2'], videos);
    expect(result[3].length).toEqual(2);
  });
  it("กรณี clipGenมี3รุ่น subcircuit มีวันละ 1คลิป โดยมีgen3 2วัน, gen2 1วัน, gen1 1วัน ", () => {
    const result = getSubcurcitFourDay(2, ['1', '2', '3'], videos);
    const gen3Result = result.filter(element => element[0].clip_gen === '3');
    const gen2Result = result.filter(element => element[0].clip_gen === '2');
    const gen1Result = result.filter(element => element[0].clip_gen === '1');
    expect(gen3Result.length).toEqual(2);
    expect(gen2Result.length).toEqual(1);
    expect(gen1Result.length).toEqual(1);
  });
  it('วิดีโอทั้งหมดต้องเป็น subcircuit', () => {
    const subcircuits = getSubcurcitFourDay(2, ['1', '2', '3'], videos);
    const result = subcircuits[0].filter(cardio => cardio.category.toLowerCase() === 'sub circuit');
    expect(subcircuits[0].length).toBe(result.length);
  });
  it('video subcircuit ในแต่ละวันต้องมีค่า 1 เท่านั้น แม้ว่าจะกรอก amount เป็น 3', () => {
    const subcircuits = getSubcurcitFourDay(3, ['1', '2', '3'], videos);
    expect(subcircuits[0].length).toBe(1);
  });
  it('video subcircuit ในแต่ละวันต้องมีค่า 2 เท่านั้น เมื่อกรอก amount เป็น 1', () => {
    const subcircuits = getSubcurcitFourDay(1, ['1', '2'], videos);
    expect(subcircuits[0].length).toBe(2);
  });
});
describe("getMainCircuitByType Test", () => {
  it("เอาVDO ที่อยู่ใน category 'main circuit' และ type, clip_gen ตามที่กำหนด  ", () => {
    const result = getMainCircuitByType('leg focus', ['2'], videos);
    expect(result[0].category.toLowerCase()).toBe("main circuit");
    expect(result[0].type.toLowerCase()).toBe("leg focus");
    expect(result[0].clip_gen).toBe("2");
  });
  it("วิดีโอ main circuit ในแต่ละวันต้องเท่ากับ 1 คลิป", () => {
    const result = getMainCircuitByType('leg focus', ['2'], videos);
    expect(result.length).toBe(1);
  });
});
describe("groupSchedule Test", () => {
  it("เมื่อกรอก amount ให้ cardio เป็น 3 ผลลัพธ์คือ warm up:1, cool down: 1, main circuit: 1 and cardio: 3", () => {
    const warmUp_ = getWarmUp(videos);
    const coolDown_ = getCoolDown(videos);
    const cardio_ = getCardioFourDay(3, ['1', '2'], videos);
    const subCircuit_ = getSubcurcitFourDay(1, ['1', '2'], videos);
    const mainCircuit_ = getMainCircuitByType('leg focus', ['2'], videos);
    const allVDO = [warmUp_[0], mainCircuit_[0], subCircuit_[0], cardio_[0], coolDown_[0]];
    const result = groupSchedule(allVDO, 1);
    const warmUpCate = result.filter(elem => elem.category.toLowerCase() === 'warm up');
    const cooldownCate = result.filter(elem => elem.category.toLowerCase() === 'cool down');
    const mainCircuitCate = result.filter(elem => elem.category.toLowerCase() === 'main circuit');
    const cardioCate = result.filter(elem => elem.category.toLowerCase() === 'cardio');
    expect(warmUpCate.length).toBe(1);
    expect(cooldownCate.length).toBe(1);
    expect(mainCircuitCate.length).toBe(1);
    expect(cardioCate.length).toBe(3);
  });
  it("สมาชิกทุกตัวต้องเป็น object", () => {
    const warmUp_ = getWarmUp(videos);
    const coolDown_ = getCoolDown(videos);
    const cardio_ = getCardioFourDay(1, ['1', '2'], videos);
    const subCircuit_ = getSubcurcitFourDay(1, ['1'], videos);
    const mainCircuit_ = getMainCircuitByType('leg focus', ['1'], videos);
    const allVDO = [warmUp_[0], mainCircuit_[0], subCircuit_[0], cardio_[0], coolDown_[0]];
    const result = groupSchedule(allVDO, 1);
    const arrayCount = result.reduce((accu, curr) => accu += Array.isArray(curr) ? 1 : 0, 0)
    expect(arrayCount).toBe(0);
  });
});

describe("processByCategory test", () => {
  const vdoDetail =
    [
      {
        "video_id": "414643165",
        "name": "Oh My Muscle",
        "thumbnail": "",
        "rep": 1,
        "play_set": 1,
        "rest_time": 0,
        "duration": 15,
        "type": "Sub circuit",
        "category": "Sub Circuit",
        "clip_gen": "1"
      },
      {
        "video_id": "414643305",
        "name": "Run In Place",
        "thumbnail": "",
        "rep": 1,
        "play_set": 1,
        "rest_time": 0,
        "duration": 11.23,
        "type": "Sub circuit",
        "category": "Sub Circuit",
        "clip_gen": "1"
      },
      {
        "video_id": "414643433",
        "name": "Burn From Home",
        "thumbnail": "",
        "rep": 1,
        "play_set": 1,
        "rest_time": 0,
        "duration": 13.27,
        "type": "Sub circuit",
        "category": "Sub Circuit",
        "clip_gen": "1"
      }];
  it("หาก array ที่จะนำมาลบ เป็น array จำนวนสมาชิกในอาร์เรย์ต้นฉบับต้องเท่าเดิม", () => {
    const toRemove = [];
    const filtered = processByCategory(vdoDetail, toRemove, 'sub circuit');
    expect(filtered.length).toBe(3);
  });
  it("ต้องทำการกำจัดวิดีโอที่อยู่ใน array toRemove ออกจากข้อมูลหลัก", () => {
    const toRemove = [
      {
        "video_id": "414643433",
        "name": "Burn From Home",
        "thumbnail": "",
        "rep": 1,
        "play_set": 1,
        "rest_time": 0,
        "duration": 13.27,
        "type": "Sub circuit",
        "category": "Sub Circuit",
        "clip_gen": "1"
      }
    ];
    const filtered = processByCategory(vdoDetail, toRemove, 'sub circuit');
    expect(filtered.length).toBe(2);
    const isContained = filtered.some(vdo => vdo.video_id === toRemove[0].video_id)
    expect(isContained).toBeFalsy();
  });
});

describe("generateToRemoveVideos test", () => {
  const videos =
    [
      {
        "video_id": "414643165",
        "category": "Sub Circuit",
        "order": 1,
        "play_time": 0
      },
      {
        "video_id": "414643165",
        "category": "Sub Circuit",
        "order": 2,
        "play_time": 0
      },
      {
        "video_id": "414643305",
        "category": "Warm Up",
        "order": 3,
        "play_time": 0
      },
      {
        "video_id": "414643433",
        "category": "Sub Circuit",
        "order": 4,
        "play_time": 0
      },
      {
        "video_id": "414643466",
        "category": "Cardio",
        "order": 5,
        "play_time": 0
      },
      {
        "video_id": "414643477",
        "category": "Cool Down",
        "order": 6,
        "play_time": 0
      }
    ];

    it("Result Array must not contains warm up, cool down, and challenge videos", () => {
      const toRemove = generateToRemoveVideos(videos);
      expect(toRemove.some(x => x.category.toLowerCase() === 'warm up')).toBeFalsy();
      expect(toRemove.some(x => x.category.toLowerCase() === 'cool down')).toBeFalsy();
      expect(toRemove.some(x => x.category.toLowerCase() === 'challenge')).toBeFalsy();
    });
    it("The Result Array must contain unique video object", () => {
      const toRemove = generateToRemoveVideos(videos);
      const duplicatedNumber = videos.filter(x => x.video_id === '414643165');
      const expectDuplicated = toRemove.filter(x => x.video_id === '414643165');
      expect(duplicatedNumber.length).toBe(2);
      expect(expectDuplicated.length).toBe(1);
    })
})