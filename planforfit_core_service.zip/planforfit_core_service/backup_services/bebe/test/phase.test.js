import {
  calculatePhase,
  getPhase
} from '../util/phase';

describe('calculatePhase Test', () => {
it('กรณีไม่เกิน30วัน น้ำหนัก45 cardio ต้องเป็น0', () => {
    const received = calculatePhase(30, 45);
    const cardio = received.filter(element => element.category.toLowerCase() === "cardio")[0];
    expect(cardio.amount).toEqual(0);
  });
  it('กรณีไม่เกิน60วัน น้ำหนัก45 cardio ต้องเป็น1', () => {
    const received = calculatePhase(60, 45);
    const cardio = received.filter(element => element.category.toLowerCase() === "cardio")[0];
    expect(cardio.amount).toEqual(1); 
  });
  it('กรณีไม่เกิน120วัน น้ำหนัก60 subCircuit ต้องเป็น2 cardio ต้องเป็น1', () => {
    const received = calculatePhase(120, 60);
    const subCircuit = received.filter(element => element.category.toLowerCase() === "sub circuit")[0];
    const cardio = received.filter(element => element.category.toLowerCase() === "cardio")[0];
    expect(subCircuit.amount).toEqual(2); 
    expect(cardio.amount).toEqual(1); 
  });
  it('กรณีไม่เกิน180วัน น้ำหนัก60 chest, back, leg, arm ต้องเป็นอย่างละ1', () => {
    const received = calculatePhase(180, 60);
    const chest = received.filter(element => element.category.toLowerCase() === "chest challenge")[0];
    const back = received.filter(element => element.category.toLowerCase() === "back challenge")[0];
    const leg = received.filter(element => element.category.toLowerCase() === "leg challenge")[0];
    const arm = received.filter(element => element.category.toLowerCase() === "arm challenge")[0];
    expect(chest.amount).toEqual(1); 
    expect(back.amount).toEqual(1);
    expect(leg.amount).toEqual(1); 
    expect(arm.amount).toEqual(1);
  });
  it('กรณีไม่เกิน210วัน น้ำหนัก60 mainAccerelation1, subAccerelation1 ต้องเป็นอย่างละ1', () => {
    const received = calculatePhase(210, 60);
    const mainAccerelation1 = received.filter(element => element.category.toLowerCase() === "main circuit accerelation 1")[0];
    const subAccerelation1 = received.filter(element => element.category.toLowerCase() === "sub circuit accerelation 1")[0];
    expect(mainAccerelation1.amount).toEqual(1); 
    expect(subAccerelation1.amount).toEqual(1);
  });
  it('กรณีไม่เกิน240วัน น้ำหนัก60 mainAccerelation2, subAccerelation2 ต้องเป็นอย่างละ1', () => {
    const received = calculatePhase(240, 60);
    const mainAccerelation2 = received.filter(element => element.category.toLowerCase() === "main circuit accerelation 2")[0];
    const subAccerelation2 = received.filter(element => element.category.toLowerCase() === "sub circuit accerelation 2")[0];
    expect(mainAccerelation2.amount).toEqual(1); 
    expect(subAccerelation2.amount).toEqual(1);
  });
});

describe('getPhase Test', () => {
  it('กรณีoffset 5วัน ระยะห่างระหว่างวันเริ่มต้นกับวันสุดท้าย คือ 34วัน จะได้ Phase "1-30" น้ำหนัก 45 ต้องได้ cardio = 0, subcircuit = 1  ', () => {
    const received = getPhase("2020-09-30", 5, 45, "2020-11-03");
    const cardio = received.filter(element => element.category.toLowerCase() === "cardio")[0];
    const subCircuit = received.filter(element => element.category.toLowerCase() === "sub circuit")[0];
    expect(cardio.amount).toEqual(0); 
    expect(subCircuit.amount).toEqual(1); 
  });
});