import moment from "moment";

export function formatLogs(logs, allMembers = []) {
  const groups = getDistinctGroupId(logs);
  const formatedLogs = [];
  for (var i = 0; i < groups.length; i++) {
    const group_id = groups[i];
    const groupMemberData = logs.filter(log => log.group_id === group_id);
    const data = [];

    for (let j = 0; j < groupMemberData.length; j++) {
      const element = groupMemberData[j];
      data.push(element);
    }

    const members = allMembers.filter(member => member.group_id === group_id)

    const groupObject = {
      group_id,
      data,
      members
    };
    formatedLogs.push(groupObject);
  }
  return formatedLogs;
}

/* export function getDistinctGroupId(logs) {
  const distinctGroups = [];
  let group_id = "";
  for (let index = 0; index < logs.length; index++) {
    const log = logs[index];
    if (distinctGroups.find(group => group === log.group_id)) {
      continue;
    } else {
      group_id = log.group_id;
      distinctGroups.push(log.group_id);
    }
  }

  return distinctGroups;
} */
export function getDistinctGroupId(logs) {
  const distinctGroups = [];
  let group_id = "";
  for (let index = 0; index < logs.length; index++) {
    const log = logs[index];
    if (distinctGroups.find(group => group === log.group_id)) {
      continue;
    } else {
      group_id = log.group_id;
      const checkNullGroup = distinctGroups.includes(null);
      //เพิ่มการเช็ค เพื่อให้ผู้ที่ไม่มีกลุ่มก็ได้รับคะแนนด้วย
      if (!group_id && checkNullGroup) {
        continue;
      }
      distinctGroups.push(log.group_id);
    }
  }
  return distinctGroups;
}

export function filterWantedWeekLogs(teamLogsData, focusDate) {
  const thisMonday = (focusDate ? moment(focusDate) : moment()).startOf('isoWeek');
  const thisSunday = (focusDate ? moment(focusDate) : moment()).endOf('isoWeek');
  const wantedWeekLogs = teamLogsData.filter(indWeightLog =>
    moment(indWeightLog.activity_date).isBetween(thisMonday, thisSunday, undefined, [])
  );
  return wantedWeekLogs;
}

export function filterThisWeekIndWeightLogs(teamLogsData, focusDate) {
  const wantedWeekLogs = filterWantedWeekLogs(teamLogsData, focusDate);
  const thisWeekIndWeightLogs = wantedWeekLogs
    .filter(teamLog => teamLog.log_type === "individual")
    .filter(individualLog => individualLog.log === "weight");
  return thisWeekIndWeightLogs;
}

export function checkTeamWeightCompleteness(teamLogs, focusDate) {
  const { members } = teamLogs;
  const thisWeekIndWeightLogs = filterThisWeekIndWeightLogs(teamLogs.data, focusDate);
  let allMemberWeigh = true;
  //เช็คว่าสมาชิกทุกคนมีนข้อมูลใน data attribute
  for (let index = 0; index < members.length; index++) {
    const member = members[index];
    const foundMemberInLog = thisWeekIndWeightLogs.find(log => log.user_id === member.user_id);

    if (!foundMemberInLog) {
      allMemberWeigh = false;
      break;
    }
  }
  //เช็คว่าสมาชิกแต่ละคนใน data attribute ชั่งน้ำหนักสองรอบ
  let allMemberWeighComplete = true;
  for (let index = 0; index < members.length; index++) {
    const member = members[index];
    const idealAmount = 2;
    const actualAmount = thisWeekIndWeightLogs.filter(log => log.user_id === member.user_id).length;

    if (actualAmount < idealAmount) {
      allMemberWeighComplete = false;
      break;
    }
  }
  const isComplete = allMemberWeigh && allMemberWeighComplete;
  return isComplete;
}

export function distributeTeamScore(teamLogs, score = 10) {
  const { members } = teamLogs;
  const newMembers = [];
  for (let index = 0; index < members.length; index++) {
    const member = members[index];
    const newMember = { ...member, new_score: (member.new_score ? member.new_score : 0) + score }
    newMembers.push(newMember)
  }
  return newMembers;
}

export function addIndividualScore(member, score = 10) {
  return { ...member, new_score: (member.new_score ? member.new_score : 0) + score };
}

export function isAVGWeightLessThanLastWeek(teamLogs, pUserId, focusDate) {
  const { data } = teamLogs;
  const currentDate = focusDate ? moment(focusDate) : moment();
  const lastWeekDate = (focusDate ? moment(focusDate) : moment()).subtract(7, 'days');

  const thisWeekLogs = filterThisWeekIndWeightLogs(data, currentDate.format("YYYY-MM-DD"))
    .filter(data => data.user_id.toString() === pUserId.toString());
  const prevWeekLogs = filterThisWeekIndWeightLogs(data, lastWeekDate.format("YYYY-MM-DD"))
    .filter(data => data.user_id.toString() === pUserId.toString());

  const weightReducer = (accumulator, currentLog) => accumulator + parseFloat(currentLog.log_value);

  const thisWeekAVGWeight = thisWeekLogs.reduce(weightReducer, 0) / (thisWeekLogs.length || 1);
  const prevWeekAVGWeight = prevWeekLogs.reduce(weightReducer, 0) / (prevWeekLogs.length || 1);
  return thisWeekAVGWeight < prevWeekAVGWeight;
}

export function isExerciseCompleted(activites) {
  let isCompleted = true;
  if (!activites) return false;
  if (activites.length <= 0) return false;

  for (let dayIndex = 0; dayIndex < activites.length; dayIndex++) {
    const dailyExercises = activites[dayIndex];
    for (let exIndex = 0; exIndex < dailyExercises.length; exIndex++) {
      const exercise = dailyExercises[exIndex];
      if (parseFloat(exercise.play_time) / parseFloat(exercise.duration) < 0.9) {
        isCompleted = false;
        break;
      }
    }
  }
  return isCompleted;
}

export function getBonusScoreFromRank(rank) {
  switch (rank.toLowerCase()) {
    case "gold":
      return 5;
    case "platinum":
      return 10;
    default:
      return 0;
  }
}

export function sumOldScore(teamLogs, pUserID, focusDate) {
  const { data } = teamLogs;
  const wantedWeekLogs = filterWantedWeekLogs(data, focusDate);
  const thisUserLogs = wantedWeekLogs.filter(log => log.user_id === pUserID);

  const sumOldScore = thisUserLogs.reduce((accumulator, currentLog) => accumulator + currentLog.score, 0);
  return sumOldScore;
}

export function calculateEndRank(startRank, totalScore, rankArray = [
  "newbie",
  "bronze",
  "silver",
  "gold",
  "platinum"
]) {

  const startRankIndex = rankArray.findIndex(rank => rank === startRank);
  let endRankIndex = totalScore > 40 ? startRankIndex + 1 : startRankIndex - 1;
  endRankIndex = endRankIndex >= rankArray.length ? (endRankIndex - 1) : endRankIndex;
  endRankIndex = endRankIndex < 0 ? 0 : endRankIndex;

  return rankArray[endRankIndex];
}
