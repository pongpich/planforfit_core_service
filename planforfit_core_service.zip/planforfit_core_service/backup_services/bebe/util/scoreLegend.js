export const legend = [
    {
        log: "weight",
        log_type: "individual",
        description: "ชั่งน้ำหนักรายวันของแต่ละบุคคล"
    },
    {
        log: "weight bonus",
        log_type: "team",
        description: "คะแนนทีมที่เกิดจากการชั่งน้ำหนักของสมาชิกในทีมในแต่ละวัน"
    },
    {
        log: "weight team complete",
        log_type: "team",
        description: "ชั่สำหรับทีมที่มีสมาชิกในทีมชั่งและบันทึกน้ำหนักมาครบทั้งสัปดาห์จะได้คะแนนทีม 10 คะแนน"
    },
    {
        log: "reduced weight",
        log_type: "individual",
        description: "ถ้าค่าเฉลี่ยน้ำหนักลดลง (Wkn  < Wkn-1) จะได้คะแนน 10 คะแนน"
    },
    {
        log: "exercise complete",
        log_type: "individual",
        description: "หาก member คนนี้เล่นวิดีโอครบทุกคลิป จะได้บวกเพิ่มอีก 10 คะแนน"
    },
    {
        log: "rank bonus",
        log_type: "individual",
        description: "หาก rank เป็น gold จะได้ 5 แต้ม หากเป็น platinum จะได้ 10 แต้ม"
    },
]