import { query, queryRaw } from "../local_lib/dbhelper";

var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

export const calculateWeekInProgram = (startDate, endDate) => {
  let startDateMoment = moment(startDate).startOf('isoWeek');
  let endDateMoment = endDate ? moment(endDate) : moment();
  return endDateMoment.diff(startDateMoment, 'week') + 1
}