import { queryRaw } from "./local_lib/dbhelper";
import { success, createSuccessBody } from "./local_lib/response-lib";
import * as dynamoDbLib from "./local_lib/dynamodb-lib";
import { calculateWeekInProgram } from './util/schedule';
import { formatThaiDate } from './util/dateStuff';
import hmacSHA256 from 'crypto-js/hmac-sha256';
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

const defaultCardioType = "running";

async function getPrevExerciseProgram(user_id, week_in_program) {
  const queryString = `
                        SELECT exercise_program
                        FROM exercise_activity
                        WHERE user_id = '${user_id}'
                        AND week_in_program < ${week_in_program}
                        ORDER BY week_in_program DESC
                        LIMIT 1;
                      `;
  try {
    const queryResult = await queryRaw(queryString);
    if (queryResult.length > 0 && queryResult[0].exercise_program) {
      return JSON.parse(queryResult[0].exercise_program);
    } else {
      return [];
    }
  } catch (error) {
    console.log("Error in getPrevExerciseProgram:", Error);
    return [];
  }
}

async function retrieveExerciseProgram(user_id, start_date) {
  const week = calculateWeekInProgram(start_date);
  const query = `
      select prog.day, tset.order, ${week} week_number,
        main_form.form_code main_code, main_form.name main_name, 
        main_form.main_muscle main_main_muscle, main_form.other_muscle main_other_muscle, 
        main_form.equipment main_equipment, main_form.mechanic main_mechanic, 
        main_form.description main_description, main_form.attributes main_images,
        alt_form.form_code alt_code, alt_form.name alt_name, 
        alt_form.main_muscle alt_main_muscle, alt_form.other_muscle alt_other_muscle, 
        alt_form.equipment alt_equipment, alt_form.mechanic alt_mechanic, 
        alt_form.description alt_description, alt_form.attributes alt_images,
        tset.rep, tset.set, tset.rest
      from training_suite suite JOIN suite_for_user sfu
        ON suite.suite_code = sfu.suite_code JOIN training_program prog
        ON suite.program_code = prog.program_code JOIN training_set tset
        ON prog.set_code = tset.set_code LEFT OUTER JOIN training_form main_form
        ON tset.main_form = main_form.form_code LEFT OUTER JOIN training_form alt_form
        ON tset.alt_form = alt_form.form_code
      where sfu.user_id = '${user_id}'
        AND suite.week = ${week}
      order by prog.day, tset.order;`;

  const queryResult = await queryRaw(query);
  let prevExerciseProgram = [];
  if (week > 1) {
    prevExerciseProgram = await getPrevExerciseProgram(user_id, week);
  }
  const data = queryResult;
  let entireProgramForUpsert = [];
  let entireProgramForClient = [];
  const maxDay = data.reduce((prev, current) => (prev.day > current.day) ? prev.day : current.day, 1);
  for (let i = 1; i <= maxDay; i++) {
    const currentProgram = data.filter(elem => elem.day === i);
    let currentProgramForUpsertAdj = {
      day: i,
      workout: []
    }
    let currentProgramForClientAdj = {
      day: i,
      workout: []
    }
    for (let j = 0; j < currentProgram.length; j++) {
      const {
        order,
        rep,
        set,
        rest,
        main_code,
        main_name,
        main_main_muscle,
        main_other_muscle,
        main_equipment,
        main_mechanic,
        main_description,
        main_images,
        alt_code,
        alt_name,
        alt_main_muscle,
        alt_other_muscle,
        alt_equipment,
        alt_mechanic,
        alt_description,
        alt_images,
      } = currentProgram[j];
      let main_weight = "";
      let alt_weight = "";
      const outIndex = i - 1;
      if (prevExerciseProgram.length > 0 && prevExerciseProgram[outIndex]) {
        const prevWorkout = prevExerciseProgram[outIndex].workout;
        main_weight = prevExerciseProgram.length > 0 && prevWorkout[j]
          ? prevWorkout[j].workouts.workout_form[0].weight
          : "";
        alt_weight = prevExerciseProgram.length > 0 && prevWorkout[j]
          ? prevWorkout[j].workouts.workout_form[1].weight
          : "";
      }

      const upsertObject = {
        order: order,
        status: "non_exercise",
        workouts: {
          rep: rep,
          set: set,
          rest: rest,
          workout_form: [
            {
              type: "main",
              id: main_code,
              name: main_name,
              main_muscle: main_main_muscle,
              other_muscle: main_other_muscle,
              equipment: main_equipment,
              mechanic: main_mechanic,
              description: encodeURIComponent(main_description),
              images: JSON.parse(main_images),
              weight: main_weight
            },
            {
              type: "alt",
              id: alt_code,
              name: alt_name,
              main_muscle: alt_main_muscle,
              other_muscle: alt_other_muscle,
              equipment: alt_equipment,
              mechanic: alt_mechanic,
              description: encodeURIComponent(alt_description),
              images: JSON.parse(alt_images),
              weight: alt_weight
            }
          ]
        }
      };
      const clientObject = {
        order: order,
        status: "non_exercise",
        workouts: {
          rep: rep,
          set: set,
          rest: rest,
          workout_form: [
            {
              type: "main",
              id: main_code,
              name: main_name,
              main_muscle: main_main_muscle,
              other_muscle: main_other_muscle,
              equipment: main_equipment,
              mechanic: main_mechanic,
              description: main_description,
              images: JSON.parse(main_images),
              weight: main_weight
            },
            {
              type: "alt",
              id: alt_code,
              name: alt_name,
              main_muscle: alt_main_muscle,
              other_muscle: alt_other_muscle,
              equipment: alt_equipment,
              mechanic: alt_mechanic,
              description: alt_description,
              images: JSON.parse(alt_images),
              weight: alt_weight
            }
          ]
        }
      };
      currentProgramForUpsertAdj.workout.push(upsertObject);
      currentProgramForClientAdj.workout.push(clientObject);
    }// END OF Inner Loop
    entireProgramForUpsert.push(currentProgramForUpsertAdj);
    entireProgramForClient.push(currentProgramForClientAdj);
  }// END of Outer Loop

  const resultObj = {
    entireProgramForUpSert: entireProgramForUpsert,
    entireProgramForClient: entireProgramForClient
  };

  return resultObj;
}

export async function getCoachComment(event) {
  const { user_id, start_date } = event.queryStringParameters;
  //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  const week = calculateWeekInProgram(start_date);
  const lastweek = week - 1;

  const queryCoachComment = `
                                SELECT exercise_activity.exercise_comment, exercise_activity.nutrition_comment, exercise_activity.exercise_program, member.first_name, member.last_name, member.exercise_type  
                                FROM exercise_activity 
                                JOIN member ON exercise_activity.user_id = member.user_id
                                WHERE exercise_activity.user_id = '${user_id}' 
                                AND exercise_activity.week_in_program = ${lastweek} `;

  try {
    const queryCoachCommentResult = await queryRaw(queryCoachComment);
    let result;
    if (queryCoachCommentResult.length <= 0) { //ถ้าไม่มีข้อมูลใน exercise_activity ให้กำหนดเป็น string เปล่าๆ ตาม format นี้
      result = success(createSuccessBody({ exercise_comment: "", nutrition_comment: `{ "day_off": "", "workday1": "", "workday2": "" }` }));
    } else {
      let exerciseComment = queryCoachCommentResult[0].exercise_comment;
      let nutritionComment = queryCoachCommentResult[0].nutrition_comment;
      const first_name = queryCoachCommentResult[0].first_name;
      const last_name = queryCoachCommentResult[0].last_name;
      const exercise_type = queryCoachCommentResult[0].exercise_type;
      if (!exerciseComment) { exerciseComment = "" };

      //--------------------------- เช็คจำนวน Status ----------------------------
      const exercise_program = JSON.parse(queryCoachCommentResult[0].exercise_program);
      var numberOfNonExercisePosture = 0;
      var numberOfCompletePosture = 0;
      var numberOfFailPosture = 0;
      if (exercise_program) {
        for (var dayIndex = 0; dayIndex < exercise_program.length; dayIndex++) {
          for (var postureIndex = 0; postureIndex < exercise_program[dayIndex].workout.length; postureIndex++) {
            if (exercise_program[dayIndex].workout[postureIndex].status === "non_exercise") {
              numberOfNonExercisePosture += 1;
            }
            if (exercise_program[dayIndex].workout[postureIndex].status === "complete") {
              numberOfCompletePosture += 1;
            }
            if (exercise_program[dayIndex].workout[postureIndex].status === "fail") {
              numberOfFailPosture += 1;
            }
          }
        }
      }
      //------------------------------------------------------------------------

      //---------------------------- ข้อความกรณีต่างๆ -----------------------------
      //------module1------
      //กรณีที่ไม่มีท่าฝึกเป็น non_exercise เลย
      const module1_case1 = `สัปดาห์ที่ผ่านมาคุณบันทึกท่าฝึกได้ครบทุกท่า ซึ่งมันดีต่อการพัฒนามากๆเลย`;
      //กรณีที่ท่าฝึกทุกท่าเป็น non_exercise
      const module1_case2 = `สัปดาห์ที่ผ่านมาคุณ${first_name} ${last_name} ไม่ได้บันทึกข้อมูลของการฝึก หรือมีการข้ามท่าฝึกไป คุณติดปัญหาอะไรหรือไม่ คุณสามารถแจ้งปัญหาได้ที่ข้อความประจำกลุ่มของคุณเพื่อขอความช่วยเหลือ`;
      //กรณีที่มีบางท่าฝึกเป็น non_exercise
      const module1_case3 = `สัปดาห์ที่ผ่านมา มีบางท่่าฝึกที่ไม่ได้ถูกบันทึก หรือ คุณได้ข้ามท่าฝึกนั้นๆไปบ้าง`;
      //------module2------
      //กรณีที่มีท่าฝึกเป็น complete >= 70%
      const module2_case1 = `และ ขอแสดงความยินดี คุณ${first_name} ${last_name} มีพัฒนาการของการฝึกได้ดีมาก เยี่ยมไปเลย`;
      //กรณีที่มีท่าฝึกเป็น complete >= 50% และ < 70%
      const module2_case2 = `และ คุณ${first_name} ${last_name} มีพัฒนาการที่ดี ยังมีบางท่าฝึกที่ยังสามารถพัฒนาขึ้นได้อีก`;
      //กรณีที่มีท่าฝึกเป็น complete < 50%
      const module2_case3 = `และ คุณ${first_name} ${last_name} อยู่ในช่วงเริ่มพัฒนาการ ท่าฝึกส่วนใหญ่ยังสร้างความท้าทายคุณอยู่`;
      //------module3------
      //กรณี exercise_type !== body_weight และ ท่าฝึกเป็น complete >= 70%
      const module3_case1 = `เป้าหมายของสัปดาห์นี้ให้คุณ${first_name} ${last_name} เพิ่มน้ำหนักของการฝึกอีก และพยายามฝึกตามให้ได้เพื่อกระตุ้นให้เกิดพัฒนาการเพิ่ม`;
      //กรณี exercise_type !== body_weight และ ท่าฝึกเป็น complete >= 50% และ < 70%
      const module3_case2 = `เป้าหมายสัปดาห์นี้ให้เพิ่มน้ำหนักของการฝึกในท่าที่คุณฝึกได้ตามเป้าแล้ว และ พยายามฝึกให้ได้จำนวนครั้งที่กำหนดในท่าฝึกที่คุณยังฝึกได้ไม่ครบในสัปดาห์ที่แล้ว`;
      //กรณี exercise_type !== body_weight และ ท่าฝึกเป็น complete < 50%
      const module3_case3 = `เป้าหมายในสัปดาห์นี้ให้คุณ${first_name} ${last_name} ยกที่ความหนักเท่าเดิม และพยายามฝึกให้ครบตามจำนวนที่กำหนดให้ได้ทุกท่า เพื่อข้ามไปสู่การพัฒนาอีกระดับหนึ่ง`;

      //กรณี exercise_type === body_weight และ ท่าฝึกเป็น complete >= 70%
      const module3_case4 = `เป้าหมายของสัปดาห์นี้ให้คุณ${first_name} ${last_name} ฝึกให้ได้จำนวนครั้งที่มากกว่าเดิมอีก เพื่อกระตุ้นให้เกิดพัฒนาการเพิ่ม`;
      //กรณี exercise_type === body_weight และ ท่าฝึกเป็น complete >= 50% และ < 70%
      const module3_case5 = `เป้าหมายสัปดาห์นี้ให้เพิ่มจำนวนครั้งขึ้นอีก ในท่าฝึกที่คุณทำได้ตามเป้าหมายแล้ว และ พยายามฝึกให้ได้จำนวนครั้งที่มากขึ้นอีกในท่าฝึกที่คุณยังฝึกได้ไม่ครบในสัปดาห์ที่แล้ว`;
      //กรณี exercise_type === body_weight และ ท่าฝึกเป็น complete < 50%
      const module3_case6 = `เป้าหมายในสัปดาห์นี้ให้คุณ${first_name} ${last_name} พยายามเอาชนะขึดจำกัดเดิม ฝึกให้ได้จำนวนครั้งที่มากกว่าครั้งที่แล้ว`;
      //------------------------------------------------------------------------

      const numberOfAllPosture = numberOfNonExercisePosture + numberOfCompletePosture + numberOfFailPosture;
      var module1 = "";
      var module2 = "";
      var module3 = "";

      if (numberOfNonExercisePosture === 0) {
        module1 = module1_case1;
      } else if (numberOfNonExercisePosture === numberOfAllPosture) {
        module1 = module1_case2;
      } else {
        module1 = module1_case3;
      }

      if (numberOfCompletePosture / numberOfAllPosture >= 0.7) {
        module2 = module2_case1;
      } else if (numberOfCompletePosture / numberOfAllPosture >= 0.5) {
        module2 = module2_case2;
      } else {
        module2 = module2_case3;
      }

      if (exercise_type !== "body_weight") {
        if (numberOfCompletePosture / numberOfAllPosture >= 0.7) {
          module3 = module3_case1;
        } else if (numberOfCompletePosture / numberOfAllPosture >= 0.5) {
          module3 = module3_case2;
        } else {
          module3 = module3_case3;
        }
      } else {
        if (numberOfCompletePosture / numberOfAllPosture >= 0.7) {
          module3 = module3_case4;
        } else if (numberOfCompletePosture / numberOfAllPosture >= 0.5) {
          module3 = module3_case5;
        } else {
          module3 = module3_case6;
        }
      }

      exerciseComment = `${module1} ${module2} ${module3}`;

      if (!nutritionComment) { nutritionComment = `{ "day_off": "", "workday1": "", "workday2": "" }` };
      result = success(createSuccessBody({ exercise_comment: exerciseComment, nutrition_comment: nutritionComment }));
      console.log("exerciseComment :", exerciseComment);
    }
    return result
  } catch (error) {
    return error;
  }
}

export async function getExerciseProgram(event) {
  const { user_id, start_date } = event.queryStringParameters;
  //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  const week = calculateWeekInProgram(start_date);

  const queryExerciseProgram = `
                                SELECT exercise_program FROM exercise_activity
                                WHERE user_id = '${user_id}'
                                AND week_in_program = ${week} `;

  const queryExpireDate = ` SELECT expire_date FROM member
                            WHERE member.user_id = '${user_id}';`;

  try {
    const queryExerciseProgramResult = await queryRaw(queryExerciseProgram);
    const resultExpireDate = await queryRaw(queryExpireDate);

    var expire_date = resultExpireDate[0].expire_date;
    var expireDate = new Date(expire_date).getTime();
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();

    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      // ถ้าหมดอายุจะไม่ gen program ให้
    } else {
      // เช็คว่าต้องยังไม่หมดอายุ ถึงจะ gen program ให้

      let shouldUpsert = false;
      if (queryExerciseProgramResult.length <= 0) {
        // case#1 กรณีไม่เจอข้อมูลใน table exercise_activity
        // สิ่งที่ต้องทำก็คือ insert เข้าไป แล้วดึงข้อมูลที่เพิ่ง insert คืน client ไป
        shouldUpsert = true;
      } else if (!queryExerciseProgramResult[0].exercise_program) {
        // case#2 กรณีเจอ record ใน table exercise_activity แต่ field exercise_program มีค่า NULL
        // สิ่งที่ต้องทำก็คือ update ค่า program ของสัปดาห์นั้นๆ เข้าไปใน field ดังกล่าว
        shouldUpsert = true;
      }

      let entireProgram = [];
      if (shouldUpsert) {
        //For Case#1 and Case#2
        const {
          entireProgramForUpSert,
          entireProgramForClient
        } = await retrieveExerciseProgram(user_id, start_date);
        entireProgram = entireProgramForClient;
        const exerciseProgramJSON = JSON.stringify(entireProgramForUpSert);

        const insertExerciseProgram = `
                                    INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = ${week}, exercise_program = '${exerciseProgramJSON}'
                                    ON DUPLICATE KEY UPDATE
                                    exercise_program = '${exerciseProgramJSON}';`;
        await queryRaw(insertExerciseProgram);
      } else {
        //Case#3 มีข้อมูลอยู่ใน exercise_activity อยู่แล้ว ระบบก็จะดึงข้อมูลออกมาตรงๆ
        entireProgram = JSON.parse(queryExerciseProgramResult[0].exercise_program);
      }

      let result;
      if (entireProgram.length <= 0) {
        result = success(createSuccessBody({ message: 'no_data' }));
      } else {
        result = success(createSuccessBody({ data: entireProgram }));
      }
      return result
    }
  } catch (error) {
    return error;
  }
}

export async function getExerciseProgramLastweek(event) {
  const { user_id, start_date } = event.queryStringParameters;
  //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  const week = calculateWeekInProgram(start_date);
  const lastweek = week - 1;

  const queryExerciseProgram = `
                                SELECT exercise_program FROM exercise_activity
                                WHERE user_id = '${user_id}'
                                AND week_in_program = ${lastweek} `;

  const queryExpireDate = ` SELECT expire_date FROM member
                            WHERE member.user_id = '${user_id}';`;

  try {
    const queryExerciseProgramResult = await queryRaw(queryExerciseProgram);
    const resultExpireDate = await queryRaw(queryExpireDate);

    var expire_date = resultExpireDate[0].expire_date;
    var expireDate = new Date(expire_date).getTime();
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();

    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      // ถ้าหมดอายุจะไม่ gen program ให้
    } else {
      // เช็คว่าต้องยังไม่หมดอายุ ถึงจะ gen program ให้

      let shouldUpsert = false;
      if (queryExerciseProgramResult.length <= 0) {
        // case#1 กรณีไม่เจอข้อมูลใน table exercise_activity
        // สิ่งที่ต้องทำก็คือ insert เข้าไป แล้วดึงข้อมูลที่เพิ่ง insert คืน client ไป
        if (week > 1) { //ถ้า week 1 ไม่ต้อง insert
          shouldUpsert = true;
        }
      } else if (!queryExerciseProgramResult[0].exercise_program) {
        // case#2 กรณีเจอ record ใน table exercise_activity แต่ field exercise_program มีค่า NULL
        // สิ่งที่ต้องทำก็คือ update ค่า program ของสัปดาห์นั้นๆ เข้าไปใน field ดังกล่าว
        shouldUpsert = true;
      }

      let entireProgram = [];
      if (shouldUpsert) {
        //For Case#1 and Case#2
        const {
          entireProgramForUpSert,
          entireProgramForClient
        } = await retrieveExerciseProgram(user_id, start_date);
        entireProgram = entireProgramForClient;
        const exerciseProgramJSON = JSON.stringify(entireProgramForUpSert);

        const insertExerciseProgram = `
                                    INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = ${lastweek}, exercise_program = '${exerciseProgramJSON}'
                                    ON DUPLICATE KEY UPDATE
                                    exercise_program = '${exerciseProgramJSON}';`;
        await queryRaw(insertExerciseProgram);
      } else {
        //Case#3 มีข้อมูลอยู่ใน exercise_activity อยู่แล้ว ระบบก็จะดึงข้อมูลออกมาตรงๆ
        entireProgram = JSON.parse(queryExerciseProgramResult[0].exercise_program);
      }

      let result;
      if (entireProgram.length <= 0) {
        result = success(createSuccessBody({ message: 'no_data' }));
      } else {
        result = success(createSuccessBody({ data: entireProgram }));
      }
      return result
    }
  } catch (error) {
    return error;
  }
}

async function getCardioType(user_id) {
  const queryString = `
                        SELECT cardio_type
                        FROM member
                        where user_id='${user_id}';
                      `;
  try {
    const queryResult = await queryRaw(queryString);
    if (queryResult.length > 0 && queryResult[0].cardio_type) {
      return queryResult[0].cardio_type;
    }
  } catch (error) {
    console.log("Error inside getCardioType:", error);
    return defaultCardioType;
  } finally {
    return defaultCardioType;
  }
}

async function getPrevAvgCardio(user_id, week_in_program) {
  const queryString = `
                        SELECT cardio_record
                        FROM exercise_activity
                        WHERE user_id = '${user_id}'
                        AND week_in_program < ${week_in_program}
                        ORDER BY week_in_program DESC
                        LIMIT 1;
                      `;
  let cardio_goal = 0;
  let cardio_type = defaultCardioType;
  try {
    const queryCardioRecordResult = await queryRaw(queryString);
    if (queryCardioRecordResult.length > 0 && queryCardioRecordResult[0].cardio_record) {
      const cardio_record = JSON.parse(queryCardioRecordResult[0].cardio_record);
      let day_count = 0;
      let total_cardio = 0;

      for (const key in cardio_record) {
        if (key.includes('day') && cardio_record[key] > 0) {
          day_count += 1;
          total_cardio += cardio_record[key];
        }
      }
      cardio_goal = day_count > 0 ? total_cardio / day_count : 0;
      cardio_type = cardio_record.cardio_type ? cardio_record.cardio_type : defaultCardioType;
    }
    return { cardio_goal, cardio_type };
  } catch (error) {
    console.log("Error inside getPrevAvgCardio:", error)
    return { cardio_goal, cardio_type };
  }
}

export async function getCardioRecord(event) {
  const { user_id, start_date } = event.queryStringParameters;
  //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  const week = calculateWeekInProgram(start_date);
  let cardio_record = {
    friday: 0,
    monday: 0,
    sunday: 0,
    tuesday: 0,
    saturday: 0,
    thursday: 0,
    wednesday: 0,
    cardio_type: "",
    cardio_goal: 0
  }


  const queryCardioRecordSQL = `
  SELECT cardio_record FROM exercise_activity
  WHERE user_id = '${user_id}'
  AND week_in_program = ${week} `;

  const queryExpireDate = ` SELECT expire_date FROM member
                            WHERE member.user_id = '${user_id}';`;

  try {
    const queryCardioRecordResult = await queryRaw(queryCardioRecordSQL);
    const resultExpireDate = await queryRaw(queryExpireDate);

    var expire_date = resultExpireDate[0].expire_date;
    var expireDate = new Date(expire_date).getTime();
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();

    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      // ถ้าหมดอายุจะไม่สร้าง record ให้
    } else {
      // เช็คว่าต้องยังไม่หมดอายุ ถึงจะสร้าง record ให้


      //ถ้า week นั้น table exercise_activity ยังไม่ถูกสร้าง หรือ cardio_record = null ให้ทำการ update 
      if (queryCardioRecordResult.length <= 0 || !queryCardioRecordResult[0].cardio_record) {
        let cardio_goal = 0;
        let cardio_type = defaultCardioType;
        if (week <= 1) {
          cardio_type = await getCardioType(user_id);
        } else {
          const prevCardio = await getPrevAvgCardio(user_id, week);
          cardio_type = prevCardio.cardio_type || defaultCardioType;
          cardio_goal = prevCardio.cardio_goal ? parseInt(prevCardio.cardio_goal * 1.1) : 0;
        }
        cardio_record.cardio_type = cardio_type;
        cardio_record.cardio_goal = cardio_goal;
        const updateCardioRecordSQL = `
                                      INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = '${week}', cardio_record = '${JSON.stringify(cardio_record)}'
                                      ON DUPLICATE KEY UPDATE
                                      cardio_record = '${JSON.stringify(cardio_record)}';
                                    `;

        await queryRaw(updateCardioRecordSQL);
      } else {
        cardio_record = JSON.parse(queryCardioRecordResult[0].cardio_record);
      }

      let result;
      if (cardio_record) {
        result = success(createSuccessBody({ cardio_record: cardio_record }));
      }
      return result;
    }
  } catch (error) {
    return error;
  }
}

export async function getGBHash(event) {
  const { message } = event.queryStringParameters;
  const hash = hmacSHA256(message, process.env.GB_SECRET_KEY);
  return success(createSuccessBody(hash.toString()));
}
export async function getUrlFoodImage(event) {
  const { user_id, start_date } = event.queryStringParameters;
  //calculateWeekInProgram ถ้าไม่ส่ง expire_date จะคำนวน week จากวันปัจจุบัน
  const week = calculateWeekInProgram(start_date);
  var url_food_image = {
    workday1: { image1: "", image2: "", image3: "", image4: "", image5: "" },
    workday2: { image1: "", image2: "", image3: "", image4: "", image5: "" },
    day_off: { image1: "", image2: "", image3: "", image4: "", image5: "" }
  }

  const queryExpireDate = ` SELECT expire_date FROM member
  WHERE member.user_id = '${user_id}';`;

  const queryUrlFoodImageSQL = `
  SELECT url_food_image FROM exercise_activity
  WHERE user_id = '${user_id}'
  AND week_in_program = ${week} `;

  const updateUrlFoodImageSQL = `
                                  INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = '${week}', url_food_image = '${JSON.stringify(url_food_image)}'
                                  ON DUPLICATE KEY UPDATE
                                  url_food_image = '${JSON.stringify(url_food_image)}';
                                `

  try {
    const queryUrlFoodImageResult = await queryRaw(queryUrlFoodImageSQL);
    const resultExpireDate = await queryRaw(queryExpireDate);

    var expire_date = resultExpireDate[0].expire_date;
    var expireDate = new Date(expire_date).getTime();
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();

    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      // ถ้าหมดอายุจะไม่สร้าง record ให้
    } else {
      // เช็คว่าต้องยังไม่หมดอายุ ถึงจะสร้าง record ให้


      //ถ้า week นั้น table exercise_activity ยังไม่ถูกสร้าง หรือ url_food_image = null ให้ทำการ update 
      if (queryUrlFoodImageResult.length <= 0 || !queryUrlFoodImageResult[0].url_food_image) {
        await queryRaw(updateUrlFoodImageSQL);
      } else {
        url_food_image = JSON.parse(queryUrlFoodImageResult[0].url_food_image);
      }

      let result;
      if (url_food_image) {
        result = success(createSuccessBody({ url_food_image: url_food_image }));
      }
      return result;
    }
  } catch (error) {
    return error;
  }
}

export async function getPrice(event) {
  const { program_id } = event.queryStringParameters;

  const queryString = `
      SELECT price
      FROM program
      WHERE program_id = '${program_id}';
    `;

  try {
    const result = await queryRaw(queryString);
    const returnBody = result && result.length > 0 ? result[0].price : 0;
    return success(returnBody);
  } catch (error) {
    return error;
  }
}

export async function getExerciseHistory(event) {
  const { user_id } = event.queryStringParameters;

  const queryString = `
      SELECT * FROM exercise_activity
      WHERE user_id = '${user_id}'
      ORDER BY week_in_program DESC;
    `;

  try {
    const result = await queryRaw(queryString);
    return success(result);
  } catch (error) {
    return error;
  }
}

export async function getExerciseHistoryOverview(event) {
  const { user_id } = event.queryStringParameters;

  const queryString = `
        SELECT * FROM exercise_activity
        WHERE user_id = '${user_id}'
        ORDER BY week_in_program ASC;
    `;

  try {
    const result = await queryRaw(queryString);
    return success(result);
  } catch (error) {
    return error;
  }
}

export async function getAllMembers() {
  const queryString = `SELECT * FROM member;`;

  try {
    const results = await queryRaw(queryString);
    return success(results);
  } catch (error) {
    return error;
  }
}

export async function getExerciseHomework() {

  const queryString = `
  SELECT  m.user_id, m.email, m.exercise_type, m.number_of_exercise_days, m.cardio_type,
        m.first_name, m.last_name, m.facebook, m.birthday, m.weight, m.start_date, m.expire_date,
        act.week_in_program, act.cardio_record, act.exercise_comment,
        act.exercise_coach_id as coach_id, concat(COALESCE(coach.first_name, ''), ' ', coalesce(coach.last_name, '')) as coach_name
  FROM member m JOIN exercise_activity act
      ON m.user_id = act.user_id LEFT JOIN member coach
      ON act.exercise_coach_id = coach.user_id
  WHERE act.week_in_program = CalcWeekInProgram(m.start_date) - 1;
`;

  try {
    const results = await queryRaw(queryString);
    if (results.length <= 0) throw failure(createFailureBody("Not_Found", "Found no data"));

    const wpParams = {
      TableName: process.env.p4fCoachtasksTableName,
      ProjectionExpression: "coachId, coachName, userId"
    };
    console.log("dynamoDbLib:", wpParams.TableName)
    const coachTasksData = await dynamoDbLib.call("scan", wpParams);
    const homeworks = [];
    for (const result of results) {
      let status = result.exercise_comment ? "done" : "ready";
      let coach_id = "";
      let coach_name = "";

      const coachData = coachTasksData.Items.find(
        task => task.userId === result.user_id
      );
      if (coachData) {
        status = "adjusting";
        coach_id = coachData.coachId;
        coach_name = coachData.coachName;
      } else {
        coach_id = result.coach_id;
        coach_name = result.coach_name;
      }

      const subData = {
        ...result,
        status,
        coach_id,
        coach_name
      }

      homeworks.push(subData);
    }
    return success(homeworks);
  } catch (error) {
    return error;
  }
}

export async function getNutritionHomework() {

  const queryString = `
  SELECT  m.user_id, m.email, m.exercise_type, m.number_of_exercise_days, m.cardio_type,
        m.first_name, m.last_name, m.facebook, m.birthday, m.weight, m.start_date, m.expire_date,
        act.week_in_program, act.url_food_image, act.nutrition_comment,
        act.nutrition_coach_id as coach_id, concat(COALESCE(coach.first_name, ''), ' ', coalesce(coach.last_name, '')) as coach_name
FROM member m JOIN exercise_activity act
        ON m.user_id = act.user_id LEFT JOIN member coach
        ON act.nutrition_coach_id = coach.user_id
WHERE act.week_in_program = CalcWeekInProgram(m.start_date) - 1 AND  week_in_program  < 3;
`;

  try {
    const results = await queryRaw(queryString);
    if (results.length <= 0) throw failure(createFailureBody("Not_Found", "Found no data"));

    const wpParams = {
      TableName: process.env.p4fCoachNutritionTasksTableName,
      ProjectionExpression: "coachId, coachName, userId"
    };
    console.log("dynamoDbLib:", wpParams.TableName)
    const coachTasksData = await dynamoDbLib.call("scan", wpParams);
    const homeworks = [];
    for (const result of results) {
      let status = result.nutrition_comment ? "done" : "ready";
      let coach_id = "";
      let coach_name = "";

      const coachData = coachTasksData.Items.find(
        task => task.userId === result.user_id
      );
      if (coachData) {
        status = "adjusting";
        coach_id = coachData.coachId;
        coach_name = coachData.coachName;
      } else {
        coach_id = result.coach_id;
        coach_name = result.coach_name;
      }

      const subData = {
        ...result,
        status,
        coach_id,
        coach_name
      }

      homeworks.push(subData);
    }
    return success(homeworks);
  } catch (error) {
    return error;
  }
}

function getResultCode(body) {
  if (!body) return '01';

  const bodyParsed = body.split('&');
  const resultArray = bodyParsed.filter(elem => elem.toLowerCase().includes('resultcode'));

  if (resultArray.length > 0) {
    const resultCode = resultArray[0].split('=')[1];
    return resultCode;
  } else {
    return '01';
  }
}

export async function thankyouRoute(event, context, callback) {
  console.log("inside thankyouRoute:", event);
  const resultCode = getResultCode(event.body);
  if (resultCode !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));

  const queryString = `
      SELECT description, price, program_start_date
      FROM program
      WHERE program_expire_date > CURRENT_DATE()
      ORDER BY program_start_date DESC
      LIMIT 1;
    `;

  let description = "PlanforFIT Online Training";
  let price = "1";
  let start_date = formatThaiDate(new Date());

  try {
    const result = await queryRaw(queryString);
    if (result && result.length > 0) {
      description = result[0].description || "PlanforFIT Online Training";
      price = result[0].price || 1;
      start_date = formatThaiDate(new Date(result[0].program_start_date));
    }
  } catch (error) {
    return error;
  }
  const response = {
    statusCode: 200,
    headers: {
      "content-type": "text/html; charset=UTF-8"
    },
    body: `<!DOCTYPE html>
    <html lang="en">
    
    <head>
      <title>PlanforFIT Online Training</title>
      <meta property="og:title" content="PlanforFIT Online Training" />
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="icon" type="image/png" href="https://pot.planforfit.com/img/favicon.png" />
      <link rel="stylesheet" href="https://pot.planforfit.com/css/thankyou.css">
    </head>
    
    <body>
      <div class="thankyou_header">
        <img src="https://pot.planforfit.com/img/main_logo.svg" alt="" class="main_logo">
      </div>
      <div class="w100">
        <img src="https://pot.planforfit.com/img/thank_you_main.jpg" alt="">
      </div>
      <p class="title">
        THANK YOU!
      </p>
      <div class="message_wrapper">
        <p class="message">ขอบคุณสำหรับความสนใจ<br class="mobile_break">โปรแกรมออกกำลังกายจาก <span class="planforfit">Planfor<span class="planforfit-sub">FIT</span></span> <br>
          ทีมงานได้รับคำสั่งซื้อและกำลังดำเนินการตรวจสอบ<br class="mobile_break">รายการคำสั่งซื้อของท่าน <br class="desktop_break">
          หากเรียบร้อยแล้ว<br class="mobile_break"> ท่านจะได้รับข้อมูลอัปเดตผ่านทางอีเมลโดยทันที<br>
        </p>
      </div>
      <div class="course_detail">
        <div class="left">
          <img src="https://pot.planforfit.com/img/course_img.svg" alt="" class="course_img">
          <span>&nbsp;&nbsp;&nbsp;&nbsp;${description}</span>
        </div>
        <div class="right">
          <span>฿${new Intl.NumberFormat().format(price)}</span>
        </div>
      </div>
      <div class="download_wrapper">
        <p class="download_message">
          กรุณาดาวน์โหลดแอปพลิเคชั่นเพื่อเตรียมตัว <br>
          โดยโปรแกรมของคุณจะเริ่มในวันที่ ${start_date}
        </p>
        <div class="download">
          <div>
            <a href="https://apps.apple.com/us/app/planforfit-training/id1595762920" target="_blank">
              <img src="https://pot.planforfit.com/img/appstore_badge.svg" class="download-img" alt="">
            </a>
          </div>
          <div class="space"></div>
          <div>
            <a href="https://play.google.com/store/apps/details?id=com.planforfit.planforfit_training" target="_blank">
              <img src="https://pot.planforfit.com/img/playstore_badge.svg" class="download-img" alt="">
            </a>
          </div>
        </div>
      </div>
      <div class="button_wrapper">
        <a href="https://pot.planforfit.com" class="btn">กลับไปหน้าแรก</a>
      </div>
    
    </body>
    
    </html>`
  };
  callback(null, response);
}

export async function getC2C(event) {
  const { user_id } = event.queryStringParameters;

  const queryString = `
      SELECT c_to_c FROM coach_to_coach
      WHERE user_id = '${user_id}';
    `;

  try {
    const result = await queryRaw(queryString);
    return success(result);
  } catch (error) {
    return error;
  }
}

