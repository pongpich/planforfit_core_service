import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import { uuidv4 } from "./local_lib/Utils";
import { htmlSuccess, success, createSuccessBody } from "./local_lib/response-lib";
import moment from 'moment';
import { calculateWeekInProgram } from './util/schedule';

export async function leaveTeam(event) {
  const {
    user_id
  } = JSON.parse(event.body);

  const updateGroupIDSQL = `  UPDATE member
                              SET group_id = NULL
                              WHERE user_id = '${user_id}'`;

  try {
    await queryRaw(updateGroupIDSQL);
  } catch (error) {
    return error;
  }
}

export async function saveExerciseComment(event) {
  const {
    user_id,
    week_in_program,
    exercise_comment,
    coach_id,
  } = JSON.parse(event.body);

  var exercise_comment_split;
  // ตัดเครื่องหมายเหล่านี้ออกเพราะทำให้บัค ', "
  exercise_comment_split = exercise_comment.split("'").join(' ').split('"').join(' ');
  const saveExerciseCommentSQL = `
                                    UPDATE exercise_activity
                                    SET exercise_comment = '${exercise_comment_split}', exercise_coach_id = '${coach_id}'
                                    WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};
                                  `;

  try {
    await queryRaw(saveExerciseCommentSQL);
  } catch (error) {
    return error;
  }
}

export async function saveNutritionComment(event) {
  const {
    user_id,
    week_in_program,
    nutrition_comment,
    day,
    coach_id,
  } = JSON.parse(event.body);

  const selectNutritionCommentSQL = `
                                      SELECT nutrition_comment FROM exercise_activity
                                      WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};
                                    `

  try {
    var nutrition_comment_split;
    // ตัดเครื่องหมายเหล่านี้ออกเพราะทำให้บัค ', ", \n  
    nutrition_comment_split = nutrition_comment.split("'").join(' ').split('"').join(' ').split('\n').join(' ');
    const selectNutritionCommentResult = await queryRaw(selectNutritionCommentSQL);
    var nutrition_comment_old = JSON.parse(selectNutritionCommentResult[0].nutrition_comment);
    if (nutrition_comment_old) { //เช็ึคว่า nutrition_comment_old มีค่า (ไม่ใช่ null)
      if (day === "workday1") {
        nutrition_comment_old.workday1 = nutrition_comment_split
      }
      if (day === "workday2") {
        nutrition_comment_old.workday2 = nutrition_comment_split
      }
      if (day === "day_off") {
        nutrition_comment_old.day_off = nutrition_comment_split
      }
    } else {
      nutrition_comment_old = { "day_off": "", "workday1": "", "workday2": "" };
      if (day === "workday1") {
        nutrition_comment_old.workday1 = nutrition_comment_split
      }
      if (day === "workday2") {
        nutrition_comment_old.workday2 = nutrition_comment_split
      }
      if (day === "day_off") {
        nutrition_comment_old.day_off = nutrition_comment_split
      }
    }
    const saveNutritionCommentSQL = `
                                      UPDATE exercise_activity
                                      SET nutrition_comment = '${JSON.stringify(nutrition_comment_old)}', nutrition_coach_id = '${coach_id}'
                                      WHERE user_id = '${user_id}' AND week_in_program = ${week_in_program};
                                    `;
    await queryRaw(saveNutritionCommentSQL);
  } catch (error) {
    return error;
  }
}

export async function saveNumberOfSteps(event) {
  const {
    user_id,
    start_date,
    number_of_steps
  } = JSON.parse(event.body);

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน

  const saveNumberOfStepsSQL = `
                                  INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = '${week}', cardio_record = '${JSON.stringify(number_of_steps)}'
                                  ON DUPLICATE KEY UPDATE
                                  cardio_record = '${JSON.stringify(number_of_steps)}';
                                `
  try {
    await queryRaw(saveNumberOfStepsSQL);
  } catch (error) {
    return error;
  }
}

export async function saveWorkoutStatus(event) {
  const {
    user_id,
    start_date,
    exercise_program
  } = JSON.parse(event.body);

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน

  const exerciseProgramSQL = `
                                  INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = '${week}', exercise_program = '${JSON.stringify(exercise_program)}'
                                  ON DUPLICATE KEY UPDATE
                                  exercise_program = '${JSON.stringify(exercise_program)}';
                                `
  try {
    await queryRaw(exerciseProgramSQL);
  } catch (error) {
    return error;
  }
}

export async function saveFoodImage(event) {
  const {
    user_id,
    start_date,
    urlFoodImage, //urlFoodImage Ex. {image1: "xxxxx", image2: "xxxxx", image3: "xxxxx",....... }
    day //day Ex. workday1
  } = JSON.parse(event.body);

  const week = calculateWeekInProgram(start_date); //calculateWeekInProgram คำนวน week จากวันปัจจุบัน

  const selectUrlFoodImageSQL = `
                                select url_food_image from exercise_activity
                                where user_id = '${user_id}'
                                and week_in_program = ${week};
                              `

  const selectUrlFoodImageResult = await queryRaw(selectUrlFoodImageSQL);

  let url_food_image = JSON.parse(selectUrlFoodImageResult[0].url_food_image);
  if (day === "workday1") {
    url_food_image.workday1.image1 = JSON.parse(urlFoodImage).image1;
    url_food_image.workday1.image2 = JSON.parse(urlFoodImage).image2;
    url_food_image.workday1.image3 = JSON.parse(urlFoodImage).image3;
    url_food_image.workday1.image4 = JSON.parse(urlFoodImage).image4;
    url_food_image.workday1.image5 = JSON.parse(urlFoodImage).image5;
  }
  if (day === "workday2") {
    url_food_image.workday2.image1 = JSON.parse(urlFoodImage).image1;
    url_food_image.workday2.image2 = JSON.parse(urlFoodImage).image2;
    url_food_image.workday2.image3 = JSON.parse(urlFoodImage).image3;
    url_food_image.workday2.image4 = JSON.parse(urlFoodImage).image4;
    url_food_image.workday2.image5 = JSON.parse(urlFoodImage).image5;
  }
  if (day === "day_off") {
    url_food_image.day_off.image1 = JSON.parse(urlFoodImage).image1;
    url_food_image.day_off.image2 = JSON.parse(urlFoodImage).image2;
    url_food_image.day_off.image3 = JSON.parse(urlFoodImage).image3;
    url_food_image.day_off.image4 = JSON.parse(urlFoodImage).image4;
    url_food_image.day_off.image5 = JSON.parse(urlFoodImage).image5;
  }

  const saveFoodImageSQL = `
                                  INSERT INTO exercise_activity SET user_id = '${user_id}', week_in_program = '${week}', url_food_image = '${JSON.stringify(url_food_image)}'
                                  ON DUPLICATE KEY UPDATE
                                  url_food_image = '${JSON.stringify(url_food_image)}';
                                `
  try {
    await queryRaw(saveFoodImageSQL);
  } catch (error) {
    return error;
  }
}

export async function createC2CMessage(event) {
  const {
    user_id,
    date,
    coach_id,
    coach_name,
    message
  } = JSON.parse(event.body);

  const messageObjString = `{"date": "${date}", "coach_id": "${coach_id}", "coach_name": "${coach_name}", "message": "${message}"}`;

  const c2cQuery = `
    INSERT INTO coach_to_coach ( user_id, c_to_c )
    VALUES ('${user_id}', '[${messageObjString}]')
    ON DUPLICATE KEY UPDATE
      c_to_c = JSON_ARRAY_APPEND(c_to_c, "$", CAST('${messageObjString}' as JSON));
  `;

  try {
    const result = await query(c2cQuery);
    return result;
  } catch (error) {
    return error;
  }
}