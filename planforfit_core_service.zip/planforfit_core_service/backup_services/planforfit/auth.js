import { query, queryRaw, transaction } from "./local_lib/dbhelper";
import { success, createSuccessBody } from "./local_lib/response-lib";
import { sendHtmlMail } from "./local_lib/mail-helper";
import md5 from 'md5';
import { uuidv4 } from "./local_lib/Utils";
var moment = require('moment-timezone');
moment.tz.setDefault("Asia/Bangkok");

export async function login(event) {
  const { email, password } = event.queryStringParameters;
  const query = `select * from member where email='${email}'`;

  const userPeriodSQL = ` SELECT start_date, expire_date FROM member 
                          WHERE email = '${email}';`;
  try {
    const queryResult = await queryRaw(query);
    const userPeriodResult = await queryRaw(userPeriodSQL);
    var curr = new Date().getTime();
    var startDate = new Date(userPeriodResult[0].start_date).getTime();
    var expireDate = new Date(userPeriodResult[0].expire_date).getTime();

    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      const user = queryResult[0];
      const hash = md5(password);
      const isMatch = (hash === user.password);
      result = isMatch ?
        ((startDate) && (expireDate) && (curr >= startDate) && (curr <= expireDate)) ? //เช็คว่า startDate กับ expireDate มีค่า และ curr อยู่ในระยะเวลาของ startDate กับ expireDate
          success(createSuccessBody({ message: 'success', user }))
          :
          (curr < startDate) ?
            success(createSuccessBody({ message: 'invalidPeriod', user, start_date: user.start_date }))
            :
            success(createSuccessBody({ message: 'expired', user }))
        :
        success(createSuccessBody({ message: 'notMatch' }));
    }

    return result
  } catch (error) {
    return error;
  }
}

export async function loginNoPassword(event) {
  const { codedEM } = event.queryStringParameters;

  const email = Buffer.from(codedEM, 'base64').toString('binary');

  const query = `select * from member where email='${email}'`;
  try {
    const queryResult = await queryRaw(query);
    let result;
    if (queryResult.length <= 0) {
      result = success(createSuccessBody({ message: 'no_user' }));
    } else {
      const user = queryResult[0];
      result = success(createSuccessBody({ message: 'success', user }))
    }

    return result
  } catch (error) {
    return error;
  }
}

export async function signup(event) {
  const {
    email,
    password,
    first_name,
    last_name,
    exercise_type,
    cardio_type,
    no_exercise_days,
    birthday,
    weight
  } = JSON.parse(event.body);

  const hash = md5(password);

  const suite_code = `${exercise_type}_${no_exercise_days}d_suite`;
  const user_id = uuidv4();

  const queryString = `
              INSERT INTO member SET 
                  user_id='${user_id}', password='${hash}', 
                  email='${email}', first_name='${first_name}', 
                  last_name='${last_name}', exercise_type='${exercise_type}', 
                  cardio_type='${cardio_type}', number_of_exercise_days='${no_exercise_days}', 
                  birthday='${birthday}', weight=${weight};
          `;

  const suiteForUserQuery = `
              INSERT INTO suite_for_user SET
                  user_id='${user_id}', suite_code='${suite_code}';
  
          `;

  try {
    const result = await transaction([queryString, suiteForUserQuery]);
    return result;
  } catch (error) {
    return error;
  }
}

export async function updateUser(event) {
  const {
    email,
    phone,
    address
  } = JSON.parse(event.body);

  const queryString = `
            UPDATE member SET 
                address='${JSON.stringify(address)}', 
                phone='${phone}'
            WHERE email='${email}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

export async function checkUser(event) {
  const { email } = event.queryStringParameters;

  const queryString = `
      SELECT * 
      FROM member
      WHERE email = '${email}';
    `;

  try {
    const result = await queryRaw(queryString);
    const returnBody = result && result.length > 0 ? "existed" : "new";
    return success(createSuccessBody(returnBody));
  } catch (error) {
    return error;
  }
}

export async function GBQRResponse(event) {
  const {
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    merchantDefined1: program_id
  } = JSON.parse(event.body);
  console.log("inside gbqr:",
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    program_id
  );

  if (resultCode.toString() !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));

  const queryString = `
    UPDATE member INNER JOIN program
      ON program.program_id = '${program_id}'
    SET member.start_date = program.program_start_date,
          member.expire_date = program.program_expire_date
    WHERE member.email = '${customerEmail}';
    `;

  const queryUserId = ` SELECT user_id FROM member
  WHERE member.email = '${customerEmail}';`;

  try {
    const resultUserId = await queryRaw(queryUserId);
    var user_id = resultUserId[0].user_id;
    const result = await query(queryString);

    const queryString2 = `
    INSERT INTO register_log SET
    user_id = '${user_id}', program_id = '${program_id}', amount = '${amount}', referenceNo = '${referenceNo}', gbpReferenceNo = '${gbpReferenceNo}';
  `;
    await query(queryString2);

    const to = customerEmail;
    const from = 'contact@planforfit.com';
    const subject = "การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว!";

    await sendHtmlMail(to, from, subject, customerName, "register");
    return result;
  } catch (error) {
    return error;
  }
}

export async function GBQRResponseSubscription(event) {
  const {
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    merchantDefined1: program_id
  } = JSON.parse(event.body);
  console.log("inside gbqr:",
    amount,
    referenceNo,
    gbpReferenceNo,
    resultCode,
    date,
    detail,
    customerName,
    customerEmail,
    customerTelephone,
    customerAddress,
    program_id
  );

  if (resultCode.toString() !== '00') return success(createSuccessBody({ message: "unsuccess payment" }));

  const queryExpireDate = ` SELECT expire_date FROM member
                            WHERE member.email = '${customerEmail}';`;

  const queryUserId = ` SELECT user_id FROM member
                            WHERE member.email = '${customerEmail}';`;

  const queryPeriodProgram = ` SELECT period FROM program
                              WHERE program_id = '${program_id}';`;

  try {
    const resultUserId = await queryRaw(queryUserId);
    const resultExpireDate = await queryRaw(queryExpireDate);
    const resultPeriodProgram = await queryRaw(queryPeriodProgram);
    var user_id = resultUserId[0].user_id;
    var expire_date = resultExpireDate[0].expire_date;
    var period = resultPeriodProgram[0].period;
    var currTimeZone = new Date(moment(new Date()).format('YYYY-MM-DD')) //มีไว้เพื่อให้ curr ใช้ timezome "Asia/Bangkok"
    var curr = currTimeZone.getTime();
    var expireDate = new Date(expire_date).getTime();
    var new_expire_date;
    if (curr > expireDate) { //curr > expire_date คือ หมดอายุ
      //ต่ออายุจากวันปัจจุบัน
      new_expire_date = new Date(currTimeZone);
      new_expire_date.setDate(new_expire_date.getDate() + period);
    } else {
      //ต่ออายุจาก expire_date เดิม
      new_expire_date = new Date(expire_date);
      new_expire_date.setDate(new_expire_date.getDate() + period);
    }

    const queryString = `
                          UPDATE member INNER JOIN program
                            ON program.program_id = '${program_id}'
                          SET member.expire_date = '${moment(new_expire_date).format('YYYY-MM-DD')} 23:59:59'
                          WHERE member.email = '${customerEmail}';
                        `;
    const result = await query(queryString);

    const queryString2 = `
                          INSERT INTO subscription_log SET
                          user_id = '${user_id}', program_id = '${program_id}', amount = '${amount}', referenceNo = '${referenceNo}', gbpReferenceNo = '${gbpReferenceNo}';
                        `;
    await query(queryString2);

    const to = customerEmail;
    const from = 'contact@planforfit.com';
    const subject = "การลงทะเบียนและชำระเงินของคุณสำเร็จแล้ว!";

    await sendHtmlMail(to, from, subject, customerName, "register");
    return result;
  } catch (error) {
    return error;
  }
}

export async function resetPassword(event) {
  const {
    codedEM,
    codedPW
  } = JSON.parse(event.body);

  const email = Buffer.from(codedEM, 'base64').toString('binary');
  const password = Buffer.from(codedPW, 'base64').toString('binary');

  const hash = md5(password);

  const queryString = `
            UPDATE member SET 
                password='${hash}'
            WHERE email='${email}';
        `;

  try {
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}


export async function sendResetPasswordMail(event) {
  const {
    codedEM
  } = JSON.parse(event.body);

  try {
    const email = Buffer.from(codedEM, 'base64').toString('binary');

    const to = email;
    const from = 'contact@planforfit.com';
    const subject = "ตั้งรหัสผ่านใหม่ PlanforFIT Online Training";

    await sendHtmlMail(to, from, subject, codedEM, "forgetPW");
    return success(createSuccessBody("Success!!"));
  } catch (error) {
    return error;
  }
}

export async function sendPaymentResumeMail(event) {
  const {
    email
  } = JSON.parse(event.body);
  try {
    const to = email;
    const from = 'contact@planforfit.com';
    const subject = "อีกนิดเดียวการลงทะเบียนเข้าร่วม PlanforFIT Online Training จะสำเร็จ!";
    await sendHtmlMail(to, from, subject, undefined, "paymentResume");
    return success(createSuccessBody("Success!!"));
  } catch (error) {
    return error;
  }
}
