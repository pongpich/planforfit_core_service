import AWS from "aws-sdk";
import {
  success,
  failure,
  createSuccessBody,
  createFailureBody
} from "../../lib/response-lib";
import { query, queryRaw } from "../../lib/dbhelper";
import * as dynamoDbLib from "../../lib/dynamodb-lib";
import { genGetMooveHomeworks, genPageMooveHomeworks, genGetCCRHomeworks, genExerciseScoreCalculation } from "../../lib/someSQLs";
import { strPadLeft } from "../../lib/Utils";

export async function checkUser(event) {
  try {
    const { username } = event.queryStringParameters;
    const cognitoUser = await checkCognitoUser(username);
    return cognitoUser;
  } catch (error) {
    return error;
  }
}

export async function getInvoices(event) {
  try {
    const { user_id } = event.queryStringParameters;
    const queryString = `
        SELECT i.invoice_id, i.transaction_date, i.total, i.vat_rate, 
            d.detail_order, d.item_name, d.quantity, d.price
        FROM invoice_detail d JOIN invoice i 
            ON d.invoice_id = i.invoice_id 
        WHERE i.user_id = '${user_id}'
        ORDER BY i.invoice_id DESC;
        `;
    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const invoices = [];
    const map = new Map();
    for (const result of results) {
      if (!map.has(result.invoice_id)) {
        map.set(result.invoice_id, true);
        const master = {
          invoice_id: result.invoice_id,
          transaction_date: result.transaction_date,
          total: result.total,
          vat_rate: result.vat_rate
        };
        const details = results.reduce((acc, curr) => {
          if (curr.invoice_id === result.invoice_id) {
            acc.push({
              detail_order: curr.detail_order,
              item_name: curr.item_name,
              quantity: curr.quantity,
              price: curr.price
            });
          }
          return acc;
        }, []);
        invoices.push({ master, details });
      }
    }
    return success(createSuccessBody(invoices));
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function getWeightsAndImages(event) {
  try {
    const { user_id, product_id } = event.queryStringParameters;
    const queryString = `
    SELECT
      CONCAT(
            '[ ',
            GROUP_CONCAT(
              JSON_OBJECT(
                'week_in_program', da.week_in_program, 
                'daily_activities', CAST(da.activities->>'$.daily_activities' as JSON),
                'images', CAST(da.activities->>'$.weekly_progress.images' as JSON)
              )
            ),
            ' ]'
          ) as deep_profile
    FROM daily_activity da JOIN program pg ON da.program_id = pg.program_id
    WHERE da.user_id = '${user_id}'
      AND pg.product_id = '${product_id}';
        `;
    const result = await queryRaw(queryString);
    if (result.length <= 0 && !result[0].deep_profile)
      throw failure(createFailureBody("Not_Found", "Found no data"));
    
    const rawDeepProfile = JSON.parse(result[0].deep_profile);
    let weightLabel = [];
    let weightValue = [];
    let firstImage;
    let latestImage;
    rawDeepProfile.forEach(elem => {
      const weightObj = elem.daily_activities.reduce((accumulator, currentValue) => {
        accumulator.weight_sum += currentValue.weight || 0;
        accumulator.count += currentValue.weight ? 1 :0;
        return accumulator;
      }, {weight_sum: 0, count: 0 });
      const {week_in_program, images} = elem;
      if (!isImageEmpty(images)) {
        if (!firstImage) {
          firstImage = {week_in_program, images};
        } else {
          latestImage = {week_in_program, images};
        }
      }
      const avg_weight = weightObj.count == 0 ? 0 : parseInt(weightObj.weight_sum/weightObj.count);
      weightLabel.push(`wk${strPadLeft(week_in_program, '0', 3)}`);
      weightValue.push(avg_weight);
      return {
        week_in_program: week_in_program,
        images: images,
        avg_weight
      }
    });

    const emptyImageObj = {
      week_in_program: 0,
        images: {
            side: {
                public_id: ""
            },
            front: {
                public_id: ""
            }
        }
    }

    if (!firstImage) {
      firstImage = emptyImageObj;
    }

    if (!latestImage) {
      latestImage = emptyImageObj;
    }
  
    return success(createSuccessBody({
      firstImage,
      latestImage,
      weightLabel,
      weightValue
    }));
  } catch (error) {
    console.log(error);
    return error;
  }
}

function isImageEmpty(images) {
  if(!images) return true;
  let isEmpty = true;

  const { side, front } = images;
  const sidePublicId = (side || {public_id: ""}).public_id;
  const frontPublicId = (front || {public_id: ""}).public_id;
  if (sidePublicId || frontPublicId) {
    isEmpty = false;
  }

  return isEmpty;
}

export async function getAllUnsubscriptions(event) {
  try {
    const queryString = `
      SELECT user_id, email, CONCAT(COALESCE(first_name, ''), ' ', COALESCE(last_name,'')) as name , phone,
            fb_link as facebookLink, address, created_at as register_date
      FROM member 
      WHERE NOT EXISTS (	SELECT * FROM subscription 
            WHERE subscription.user_id = member.user_id);
    `;
    const results = await queryRaw(queryString);if (results.length <= 0)
    throw failure(createFailureBody("Not_Found", "Found no data"));

    const subscriptions = [];
    for (const result of results) {
      const {
        address_line1 = "",
        address_line2 = "",
        tambol = "",
        city = "",
        state = "",
        zip = ""
      } = JSON.parse(result.address) || {};
      const address = [
        `${address_line1}`,
        `${address_line2}`,
        `${tambol} ${city}`,
        `${state} ${zip}`
      ];

      const subData = {
        ...result,
        facebookLink: unescape(result.facebookLink),
        address
      };

      subscriptions.push(subData);
    }
    return success(createSuccessBody(subscriptions));
  } catch (error) {
    return error;
  }
}

export async function getAllSubscriptions(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const queryString = `
        SELECT CONCAT(sub.user_id, '||', sub.program_id) as sub_id, sub.user_id, sub.program_id,
          sub.payment_type, sub.amount, sub.payment_date, sub.payment_status, pg.batch_no,
          m.email, CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, 
          m.phone, m.fb_link as facebookLink, m.address
        FROM subscription sub JOIN program pg 
          ON sub.program_id = pg.program_id JOIN member m
          ON sub.user_id = m.user_id
        WHERE pg.product_id = '${product_id}';
        `;

    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const approves = [];
    const pendings = [];
    const rejects = [];
    for (const result of results) {
      const {
        address_line1 = "",
        address_line2 = "",
        tambol = "",
        city = "",
        state = "",
        zip = ""
      } = JSON.parse(result.address) || {};
      const address = [
        `${address_line1}`,
        `${address_line2}`,
        `${tambol} ${city}`,
        `${state} ${zip}`
      ];

      const subData = {
        ...result,
        facebookLink: unescape(result.facebookLink),
        address
      };

      if (result.payment_status === "pending") {
        pendings.push(subData);
      } else if (result.payment_status === "rejected") {
        rejects.push(subData);
      } else {
        approves.push(subData);
      }
    }
    const subscriptions = { pendings, approves, rejects };
    return success(createSuccessBody(subscriptions));
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function getAllProgram(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const queryString = `
        SELECT *
        FROM program
        WHERE product_id = '${product_id}';
        `;

    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    const batches = [];
    const subscriptions = [];
    for (const result of results) {
      if (result.period) {
        subscriptions.push(result);
      } else {
        batches.push(result);
      }
    }
    const result = { batches, subscriptions };
    return success(createSuccessBody(result));
  } catch (error) {
    console.log(error);
    return error;
  }
}

export async function getAllMembers(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const queryString = `
          SELECT m.user_id, m.email, CONCAT(COALESCE(m.first_name, ''), ' ', COALESCE(m.last_name,'')) as name, m.phone, m.fb_link, h.start_date, h.expire_date
          FROM member m LEFT OUTER JOIN health_profile h ON m.user_id = h.user_id
          WHERE h.product_id = '${product_id}';
        `;

    const results = await queryRaw(queryString);
    if (results.length <= 0)
      throw failure(createFailureBody("Not_Found", "Found no data"));

    return success(createSuccessBody(results));
  } catch (error) {
    console.log(error);
    return error;
  }
}

const checkCognitoUser = Username => {
  const params = {
    UserPoolId: process.env.USER_POOL_ID,
    Username
  };
  return new Promise((resolve, reject) => {
    AWS.config.update({
      region: "ap-southeast-1",
      accessKeyId: process.env.ACCESS_KEY_ID,
      secretAccessKey: process.env.SECRET_KEY
    });
    const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();
    cognitoServiceProvider.adminGetUser(params, function(error, data) {
      if (error) {
        const errorReturn = failure(
          createFailureBody(error.code, error.message)
        );
        reject(errorReturn);
      } else {
        const dataReturn = success(createSuccessBody(data));
        resolve(dataReturn);
      }
    });
  });
};

export async function getLeaderboard(event) {
  try {
    const { product_id } = event.queryStringParameters;
    const result = await query(genExerciseScoreCalculation(product_id));
    return result;
  } catch (error) {
    return error;
  }
}

export async function getHomeworks(event) {
  try {
    const { product_id, limit, page } = event.queryStringParameters;
    let subscriptions;
    switch (product_id) {
      case "bemoove":
        subscriptions = await createMooveHomeworksResponse(product_id);
        break;
      case "tbpa":
        subscriptions = await createPageMooveHomeworksResponse(product_id, limit, page);
        break;
      case "ccr":
        subscriptions = await createCCRHomeworksResponse(product_id);
        break;
      default:
        subscriptions = await createMooveHomeworksResponse(product_id);
        break;
    }
    return success(createSuccessBody(subscriptions));
  } catch (error) {
    console.log("error reason for getHomeworks:", error);
    return error;
  }
}

async function createMooveHomeworksResponse(product_id) {
  return new Promise(async (resolve, reject) => {
    try {
      const queryString = genGetMooveHomeworks(product_id);
    
      const results = await queryRaw(queryString);
      if (results[1].length <= 0)
        throw failure(createFailureBody("Not_Found", "Found no data"));
      const wpParams = {
        TableName: process.env.weekPlanTableName,
        ProjectionExpression: "coachId, coachName, userId"
      };
      const coachTasksData = await dynamoDbLib.call("scan", wpParams);
      const complete = [];
      const checking = [];
      const init = [];
      for (const result of results[1]) {
        const {daily_activities: activities, weekly_plan} = JSON.parse(result.activities);
        const sent_number = activities.reduce((accumulator, activity) => {
          return accumulator + checkMeal(activity.meal);
        }, 0);
        const coachData = coachTasksData.Items.find(
          coachData => coachData.userId === result.user_id
        );
        let coach_id = "";
        let coach_name = "";
        let newActivities = null;
        if (coachData) {
          coach_id = coachData.coachId;
          coach_name = coachData.coachName;
        } else if (result.status === "complete") {
          coach_id = weekly_plan.next_week_coach_id || "";
          coach_name = weekly_plan.next_week_coach_name || "";
          const newWeeklyPlan = {
            ...weekly_plan,
            exercise_note: weekly_plan.next_week_exercise_note ? weekly_plan.next_week_exercise_note : weekly_plan.exercise_note,
            nutrition_note: weekly_plan.next_week_nutrition_note ? weekly_plan.next_week_nutrition_note : weekly_plan.nutrition_note,
            exercise_plan: {
              ...weekly_plan.exercise_plan,
              weekly_exercise_score: weekly_plan.exercise_plan.next_week_exercise_score ? weekly_plan.exercise_plan.next_week_exercise_score : weekly_plan.exercise_plan.weekly_exercise_score
            }
          }
          newActivities = JSON.stringify({
            weekly_plan: newWeeklyPlan,
            daily_activities: activities
          });
        }
    
        const status =
          coach_id !== "" && coach_name !== "" && result.status === "init"
            ? "checking"
            : result.status;
        const subData = {
          ...result,
          activities: newActivities ? newActivities : result.activities,
          fb: unescape(result.fb_link),
          coach_id,
          coach_name,
          sent_number,
          status
        };
    
        if (result.status === "complete") {
          complete.push(subData);
        } else if (coach_id !== "" && coach_name !== "") {
          checking.push(subData);
        } else {
          init.push(subData);
        }
      }
      resolve({ init, checking, complete });
    } catch (error) {
      console.log("error reason for createMooveHomeworksResponse:", error);
      reject(error);
    }
  });
  
}

async function createPageMooveHomeworksResponse(product_id, limit, page) {
  return new Promise(async (resolve, reject) => {
    try {
      const offset = (page - 1) * limit;
      const queryString = genPageMooveHomeworks(product_id, limit, offset);
    
      const results = await queryRaw(queryString);
      if (results[1].length <= 0)
        throw failure(createFailureBody("Not_Found", "Found no data"));
      const wpParams = {
        TableName: process.env.weekPlanTableName,
        ProjectionExpression: "coachId, coachName, userId"
      };
      const coachTasksData = await dynamoDbLib.call("scan", wpParams);
      const complete = [];
      const checking = [];
      const init = [];
      for (const result of results[1]) {
        const {daily_activities: activities, weekly_plan} = JSON.parse(result.activities);
        const sent_number = activities.reduce((accumulator, activity) => {
          return accumulator + checkMeal(activity.meal);
        }, 0);
        const coachData = coachTasksData.Items.find(
          coachData => coachData.userId === result.user_id
        );
        let coach_id = "";
        let coach_name = "";
        let newActivities = null;
        if (coachData) {
          coach_id = coachData.coachId;
          coach_name = coachData.coachName;
        } else if (result.status === "complete") {
          coach_id = weekly_plan.next_week_coach_id || "";
          coach_name = weekly_plan.next_week_coach_name || "";
          const newWeeklyPlan = {
            ...weekly_plan,
            exercise_note: weekly_plan.next_week_exercise_note ? weekly_plan.next_week_exercise_note : weekly_plan.exercise_note,
            nutrition_note: weekly_plan.next_week_nutrition_note ? weekly_plan.next_week_nutrition_note : weekly_plan.nutrition_note,
            exercise_plan: {
              ...weekly_plan.exercise_plan,
              weekly_exercise_score: weekly_plan.exercise_plan.next_week_exercise_score ? weekly_plan.exercise_plan.next_week_exercise_score : weekly_plan.exercise_plan.weekly_exercise_score
            }
          }
          newActivities = JSON.stringify({
            weekly_plan: newWeeklyPlan,
            daily_activities: activities
          });
        }
    
        const status =
          coach_id !== "" && coach_name !== "" && result.status === "init"
            ? "checking"
            : result.status;
        const subData = {
          ...result,
          activities: newActivities ? newActivities : result.activities,
          fb: unescape(result.fb_link),
          coach_id,
          coach_name,
          sent_number,
          status
        };
    
        if (result.status === "complete") {
          complete.push(subData);
        } else if (coach_id !== "" && coach_name !== "") {
          checking.push(subData);
        } else {
          init.push(subData);
        }
      }
      resolve({ init, checking, complete });
    } catch (error) {
      console.log("error reason for createMooveHomeworksResponse:", error);
      reject(error);
    }
  });
  
}

async function createCCRHomeworksResponse(product_id) {
  return new Promise(async (resolve, reject) => {
    try {
      const queryString = genGetCCRHomeworks(product_id);
    
      const results = await queryRaw(queryString);
      if (results[1].length <= 0)
        throw failure(createFailureBody("Not_Found", "Found no data"));
      const masterTDEEQueryString = `
        select JSON_ARRAYAGG(JSON_OBJECT("week", \`week\`, "tdee", tdee_percentage, "cardio", cardio)) as master_tdee
        from master_tdee_week
        order by \`week\`;
      `
      const masterTDEE = await queryRaw(masterTDEEQueryString);

      const wpParams = {
        TableName: process.env.weekPlanTableName,
        ProjectionExpression: "coachId, coachName, userId"
      };
      const coachTasksData = await dynamoDbLib.call("scan", wpParams);
      const complete = [];
      const checking = [];
      const init = [];
      for (const result of results[1]) {
        const {daily_activities, weekly_plan, weekly_progress} = JSON.parse(result.activities);
        // find user's homework that checking by any coach
        // coachTasksData retrieve data from dynamoDB
        // the table contain {coachId, coachName, usereId}
        const coachData = coachTasksData.Items.find(
          coachData => coachData.userId === result.user_id
        );
        let coach_id = "";
        let coach_name = "";
        let newActivities = null;
        if (coachData) {
          coach_id = coachData.coachId;
          coach_name = coachData.coachName;
        } else if (result.status === "complete") {
          coach_id = weekly_plan.next_week_coach_id || "";
          coach_name = weekly_plan.next_week_coach_name || "";
          const newWeeklyPlan = {
            ...weekly_plan,
            note: weekly_plan.next_week_note ? weekly_plan.next_week_note : weekly_plan.note
          }
          newActivities = JSON.stringify({
            weekly_plan: newWeeklyPlan,
            weekly_progress,
            daily_activities
          });
        }
    
        const status =
          coach_id !== "" && coach_name !== "" && result.status === "init"
            ? "checking"
            : result.status;
        const subData = {
          ...result,
          activities: newActivities ? newActivities : result.activities,
          fb: unescape(result.fb_link),
          coach_id,
          coach_name,
          sent_number: 0,
          status,
          master_tdee: masterTDEE[0].master_tdee || []
        };
    
        if (result.status === "complete") {
          complete.push(subData);
        } else if (coach_id !== "" && coach_name !== "") {
          checking.push(subData);
        } else {
          init.push(subData);
        }
      }
      resolve({ init, checking, complete });
    } catch (error) {
      reject(error);
    }
  });
  
}

function checkMeal(meals) {
  for (const meal in meals) {
    if (
      (meal === "lunch" ||
        //meal === "snack" ||
        meal === "supper" ||
        meal === "breakfast") &&
      meals[meal] === null
    ) {
      return 0;
    }
  }
  return 1;
}
