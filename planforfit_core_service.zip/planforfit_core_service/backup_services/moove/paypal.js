import paypal from "paypal-rest-sdk";
import { success, failure, createSuccessBody, createFailureBody } from "../../lib/response-lib";

export async function payment(event) {
    const { base_url, items, description} = JSON.parse(event.body);
    const totalAmount = items.reduce((acc, elem) => {
        return parseFloat(acc.price) + parseFloat(elem.price)
    }, {price: "0"});

    paypal.configure({
        'mode': process.env.PAYPAL_MODE,
        'client_id': process.env.PAYPAL_ID,
        'client_secret': process.env.PAYPAL_SECRET,
    });

    const create_payment_json = {
        "intent": "sale",
        "payer": {
            "payment_method": "paypal"
        },
        "redirect_urls": {
            "return_url": `${base_url}/digital_paid`,
            "cancel_url": `${base_url}/checkout`
        },
        "transactions": [{
            "item_list": {
                "items": items
            },
            "amount": {
                "currency": "THB",
                "total": `${totalAmount}`
            },
            "description": description
        }]
    };

    try {
        const payment = await createPayment(create_payment_json);
        return payment;
    } catch (error) {
        return error;
    }
    
}

const createPayment = (create_payment_json) => new Promise((resolve, reject) => {
    paypal.payment.create(create_payment_json, (error, payment) => {
        if (error) {
            console.log("in createPayment#1:", error);
            reject(failure(createFailureBody(error.error , error.error_description)));
        } else {
            resolve(success(createSuccessBody(payment)));
        }
    });
});

export async function execute(event) {
  paypal.configure({
      'mode': process.env.PAYPAL_MODE,
      'client_id': process.env.PAYPAL_ID,
      'client_secret': process.env.PAYPAL_SECRET,
  });

  const { paymentId, execute_json } = JSON.parse(event.body);
  try {
    const paymentResult = await executePayment(paymentId, execute_json);
    return paymentResult;
  } catch (error) {
    return error;
  }
}

const executePayment = (paymentId, execute_json) => new Promise((resolve, reject) => {
  paypal.payment.execute(paymentId, execute_json, (error, payment) => {
    if (error) {
      console.log("inside executePayment:", error);
      reject(failure(createFailureBody(error.error, error.error_description)));
    } else {
      resolve(success(createSuccessBody(payment)));
    }
  })
})