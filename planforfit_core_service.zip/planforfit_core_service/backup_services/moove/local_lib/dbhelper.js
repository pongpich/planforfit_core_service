import db_pool from "../../../lib/connection-lib";
import { success, failure, createSuccessBody, createFailureBody } from "../../../lib/response-lib";

export const query = (queryText, data) => new Promise((resolve, reject) => {
    db_pool.getConnection((err, conn) => {
        conn.query(queryText, function (error, results, fields) {
            conn.destroy();
            let return_error;
            if (error) {
                switch(error.code) {
                    case "ER_DUP_ENTRY":
                        return_error = failure(createFailureBody(error.code , error.sqlMessage, data));
                        break;
                    default:
                        return_error = failure(createFailureBody(error.code, error.sqlMessage, data ));
                }
                resolve(return_error);
            }
            
            resolve(success(createSuccessBody(results, data )));
        });
    });
});

export const transaction = (queryArray, data) => new Promise((resolve, reject) => {
    db_pool.getConnection((err, conn) => {
        conn.beginTransaction(function(tran_err) {
            if (tran_err) { throw tran_err; }

            queryArray.forEach((item, index) => conn.query(item, function(error, results) {
                    if (error) {
                        return conn.rollback(function() {
                            resolve(failure(createFailureBody(error.code, error.sqlMessage)));
                        });
                    }

                    if(index == queryArray.length - 1) {
                        conn.commit(function(commit_error) {
                            if (commit_error) {
                                return conn.rollback(function() {
                                    resolve(failure(createFailureBody(commit_error.code, commit_error.sqlMessage)));
                                })
                            }
                            conn.destroy();
                            resolve(success(createSuccessBody(results, data)));
                        });
                    }
                })
            );


        });
    });
});
