import { query } from "../../lib/dbhelper";
import { getUsers } from "../../lib/cognito-lib";

export async function getSubscriptions(event) {
    const { user_id, product_id } = event.queryStringParameters;
    
    const queryString = `
            SELECT sub.user_id, pg.product_id, sub.program_id, sub.payment_type, sub.amount,
                sub.payment_date, sub.payment_status, pg.batch_no, pg.description, pg.price, pg.registration_start_date,
                pg.registration_expire_date, pg.program_start_date, pg.program_expire_date
            FROM subscription sub JOIN program pg
                ON sub.program_id = pg.program_id
            WHERE sub.user_id = '${user_id}'
                AND product_id = '${product_id}'
            ORDER BY pg.batch_no;
        `;
    
    try {
        const result = await query(queryString);
        return result;
    } catch (error) {
        return error;
    }
}

export async function addMember(event) {
  const { 
    user_id,
    email,
    first_name,
    last_name,
    phone,
    fb_link,
    address
  } = JSON.parse(event.body);

  const queryString = `
            INSERT INTO member SET 
                user_id='${user_id}', email='${email}', first_name='${first_name}', 
                last_name='${last_name}'
            ON DUPLICATE KEY UPDATE
              phone='${phone}', fb_link='${fb_link}', address='${address}';
        `;

  try {
      const result = await query(queryString);
      return result;
  } catch (error) {
      return error;
  }
}
/* 
export async function syncMember(event) {
  try {
    const cognitoUsers = await getUsers();
    const batchQuery = cognitoUsers.Users.map(user => {
      const user_id = user.Username;
      const email = (
        user.Attributes.find(
          attribute => attribute.Name === "email"
        ) || { Value: "" }
      ).Value;
      const first_name = (
        user.Attributes.find(
          attribute => attribute.Name === "given_name"
        ) || { Value: "" }
      ).Value;
      const last_name = (
        user.Attributes.find(
          attribute => attribute.Name === "family_name"
        ) || { Value: "" }
      ).Value;
      const phone = (
        user.Attributes.find(
          attribute => attribute.Name === "custom:phone"
        ) || { Value: "" }
      ).Value;
      const fb_link = (
        user.Attributes.find(
          attribute => attribute.Name === "custom:user_link"
        ) || { Value: "" }
      ).Value;
      const addressRawAttribute = (
        user.Attributes.find(
          attribute => attribute.Name === "address"
        ) || { Value: "{}" }
      ).Value;
      let address = JSON.parse(addressRawAttribute);
      address = JSON.stringify(address);
      let unitQuery = "INSERT INTO member SET user_id='"+user_id+"', email='"+email+"', first_name='"+first_name+"',"; 
      unitQuery += "last_name='"+last_name+"', phone='"+phone+"', fb_link='"+fb_link+"', address='"+address+"'";
      unitQuery += "ON DUPLICATE KEY UPDATE email='"+email+"', first_name='"+first_name+"',"; 
      unitQuery += "last_name='"+last_name+"', phone='"+phone+"', fb_link='"+fb_link+"', address='"+address+"';";
      console.log(unitQuery);
      return unitQuery;
    });
    //console.log("batchQuery", batchQuery);
    //const result = await transaction(batchQuery);
    return null;
  } catch (error) {
    return error;
  }
}
 */
export async function getHealthProfile(event) {
    const { user_id, product_id } = event.queryStringParameters;
    
    const queryString = `
          SELECT m.*, hp.base_info, hp.main_info, hp.start_date, hp.expire_date, hp.program_id,
            CalcWeekInProgram(hp.start_date) current_week, 
            CalcEntireWeekInProgram(hp.start_date, hp.expire_date) last_week
          FROM member m JOIN health_profile hp 
            ON m.user_id = hp.user_id
          WHERE m.user_id = '${user_id}'
            AND hp.product_id = '${product_id}'
          LIMIT 1;
        `;
    
    try {
        const result = await query(queryString);
        return result;
    } catch (error) {
        return error;
    }
}

export async function getCurrentProgram(event) {
    const { product_id, product_type } = event.queryStringParameters;
    let queryString = `
      select *
      FROM program
      WHERE period IS NOT NULL
        AND period > 0
        AND product_id='${product_id}'
      ORDER BY period;
    `;

    if (product_type === "batch") {
      queryString = `
          select *
          FROM program
          WHERE DATEDIFF(registration_expire_date, NOW()) >= 0 
            AND DATEDIFF(NOW(), registration_start_date) >= 0
            AND product_id='${product_id}'
          ORDER BY batch_no DESC;
      `;
    }
    
    try {
        const result = await query(queryString);
        return result;
    } catch (error) {
        return error;
    }
}
