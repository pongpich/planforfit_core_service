import { queryRaw, query, transaction as batchQuery } from "../../lib/dbhelper";
import { genActivitiesInsertState, calculateProgramFixPeriod } from "../../lib/someSQLs";
import { getUser } from "../../lib/cognito-lib";
import { sendHtmlMail, sendFreeHtmlMail } from "../../lib/mail-helper";

export async function batchPendingSubscription(event) {
  const { 
    user_ids, 
    program_id, 
    payment_type, 
    amount, 
    payment_date, 
    payment_status,
    transaction,
    create_time 
  } = JSON.parse(event.body);
  try {
    let queries = [];
    user_ids.forEach((user_id) => {
      const query = `
          INSERT INTO subscription SET 
            user_id='${user_id}', program_id='${program_id}', payment_type='${payment_type}', 
            amount=${amount}, payment_date='${payment_date}', payment_status='${payment_status}',
            start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}'
          ON DUPLICATE KEY UPDATE
            payment_type='${payment_type}', amount=${amount}, payment_date='${payment_date}', 
            payment_status='${payment_status}',
            start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}';
          ${getTempInvoiceStatement(user_id, program_id, create_time, transaction )}
        `;
      queries.push(query);
    });
    let queryResult;
    console.log(queries);
    if(queries.length > 0) {
      queryResult = await batchQuery(queries);
    }
    return queryResult;
  } catch (error) {
    return error;
  }
}

export async function freeSubscription(event) {
    const { 
        user_id, 
        program_id, 
        payment_type, 
        amount, 
        payment_date, 
        payment_status,
        product_id,
        transaction,
        create_time,
        phone,
        fb_link,
        address,
        sex,
        birthday,
        other_attributes
    } = JSON.parse(event.body);

    const memberUpdateQry = `
              UPDATE member SET
                phone='${phone}', fb_link='${fb_link}', address='${JSON.stringify(address)}', 
                sex='${sex}', birthday='${birthday}', other_attributes='${JSON.stringify(other_attributes)}'
              WHERE user_id='${user_id}';
            `;
    
    const queryString = `
              INSERT INTO subscription SET 
                  user_id='${user_id}', program_id='${program_id}', payment_type='${payment_type}', 
                  amount=${amount}, payment_date='${payment_date}', payment_status='${payment_status}',
                  start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}'
              ON DUPLICATE KEY UPDATE
                  payment_type='${payment_type}', amount=${amount}, payment_date='${payment_date}', 
                  payment_status='${payment_status}',
                  start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}';
            `;
    
    const healthProfileInsertStr = calculateProgramFixPeriod(user_id, program_id, product_id,);
    const invoiceQuery = getInvoiceStatement(user_id, create_time, transaction);
    const createFirstActivityQuery = genActivitiesInsertState(user_id, product_id);
    const getEmail = `SELECT email FROM member WHERE user_id='${user_id}'`;
    try {
        let result = null;
        let urlPart = product_id === 'bemoove' 
                      ? 'bemoove.co'
                      : product_id === 'tbpa'
                        ? 'tbpa.asia'
                        : 'ccrdiet.co';

        result = await batchQuery([memberUpdateQry, queryString, healthProfileInsertStr, invoiceQuery, createFirstActivityQuery]);

        const user = await queryRaw(getEmail);
        
        if(user.length > 0 && user[0].email) {
          sendFreeEMail(user[0].email, urlPart, product_id);
        }

        return result;
    } catch (error) {
        return error;
    }
}

export async function subscription(event) {
    const { 
        user_id, 
        program_id, 
        payment_type, 
        amount, 
        payment_date, 
        payment_status,
        product_id,
        transaction,
        create_time,
        start_date,
        expire_date,
    } = JSON.parse(event.body);
    
    const queryString = `
            INSERT INTO subscription SET 
                user_id='${user_id}', program_id='${program_id}', payment_type='${payment_type}', 
                amount=${amount}, payment_date='${payment_date}', payment_status='${payment_status}',
                start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}'
            ON DUPLICATE KEY UPDATE
                payment_type='${payment_type}', amount=${amount}, payment_date='${payment_date}', 
                payment_status='${payment_status}',
                start_date=concat(current_date(), ' 00:00:00'), expire_date='${expire_date}';
        `;
    
    try {
        let result = null;
        if (payment_status === "approved") {
            const healthProfileInsertStr = `
                  INSERT INTO health_profile SET 
                      user_id='${user_id}', product_id='${product_id}', base_info='{}', main_info='[]',
                      program_id='${program_id}', start_date='${start_date}', expire_date='${expire_date}'
                  ON DUPLICATE KEY UPDATE
                      expire_date='${expire_date}';
                `;
          
            const invoiceQuery = getInvoiceStatement(user_id, create_time, transaction);
            let urlPart = product_id === 'bemoove' 
                          ? 'bemoove.co'
                          : product_id === 'tbpa'
                            ? 'tbpa.asia'
                            : 'ccrdiet.co';
            if(product_id === 'bemoove' || product_id === 'tbpa'){
              const createFirstActivityQuery = genActivitiesInsertState(user_id, product_id);
              result = await batchQuery([queryString, healthProfileInsertStr, invoiceQuery, createFirstActivityQuery]);
            } else {
              result = await batchQuery([queryString, healthProfileInsertStr, invoiceQuery]);
            }
            const cognitoUser = await getUser(user_id);
            sendMail(cognitoUser, urlPart);
        } else {
            const tempInvoiceQuery = getTempInvoiceStatement(user_id, program_id, create_time, transaction );
            result = await batchQuery([queryString, tempInvoiceQuery]);
        }

        return result;
    } catch (error) {
        return error;
    }
}

export async function program(event) {
  const{
    program_id,
    product_id,
    batch_no,
    description,
    price,
    period,
    registration_start_date,
    registration_expire_date,
    program_start_date,
    program_expire_date
  } = JSON.parse(event.body);

  try {
    const periodValue = period ? period : 'NULL';
    const strRegisStart = registration_start_date ? `'${registration_start_date}'` : 'NULL';
    const strRegisExpire = registration_expire_date ? `'${registration_expire_date}'` : 'NULL';
    const strProgStart = program_start_date ? `'${program_start_date}'` : 'NULL';
    const strProgExpire = program_expire_date ? `'${program_expire_date}'` : 'NULL';

    const queryString = `
      INSERT INTO program SET program_id='${program_id}', product_id='${product_id}',
        batch_no=${batch_no}, description='${description}', price=${price}, period=${periodValue}, 
        registration_start_date=${strRegisStart}, registration_expire_date=${strRegisExpire},
        program_start_date=${strProgStart},program_expire_date=${strProgExpire}
      ON DUPLICATE KEY UPDATE
        batch_no=${batch_no}, description='${description}', price=${price}, period=${periodValue}, 
        registration_start_date=${strRegisStart}, registration_expire_date=${strRegisExpire},
        program_start_date=${strProgStart},program_expire_date=${strProgExpire}
    `
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}

const sendMail = async (cognitoUser, urlPart) => {
    const baseUrl = process.env.STAGE === "prod" 
                        ? `https://${urlPart}` 
                        : process.env.STAGE === "dev"
                            ? `https://staging.${urlPart}`
                            : "http://localhost:3000";
    const to =   (
                        cognitoUser.UserAttributes.find
                            (attribute => attribute.Name === "email") || ""
                    )
                    .Value || "";
    const from = "contact@planforfit.com";
    const subject = "การลงทะเบียน และชำระเงินสำเร็จแล้ว!"
    const content = `การสั่งซื้อของคุณได้รับการดำเนินการโดยสมบูรณ์เรียบร้อยแล้ว หากคุณต้องการตรวจรับใบเสร็จ สามารถเข้าไปดูได้ที่ 
                     <a href="${baseUrl}/app/invoice" target="_blank" >ใบเสร็จรับเงิน</a><br/>
                     และคุณสามารถเข้าไปใช้งานระบบได้โดยคลิกปุ่มต่อไปนี้
                    `
    const mainLink = `${baseUrl}/app/main`;
    const mainButtonLabel = "Moove";
    
    sendHtmlMail(to, from, subject, content, mainLink, mainButtonLabel);
        
}

const sendFreeEMail = async (email, urlPart, product_id) => {
    const baseUrl = process.env.STAGE === "prod" 
                        ? `https://${urlPart}` 
                        : process.env.STAGE === "dev"
                            ? `https://staging.${urlPart}`
                            : "http://localhost:3000";
    const to =   email;
    const from = product_id === "tbpa" ? "contact@planforfit.com" : "contact@planforfit.com";
    const subject = product_id === "tbpa" ? "การลงทะเบียน THAI FIT Apps สำเร็จแล้ว" : "การลงทะเบียนสำเร็จแล้ว!"
    const content = product_id === "tbpa" 
                    ? ` ยินดีต้อนรับเข้าสู่ THAIFIT <br/>
                        Mobile Application ที่จะช่วยให้หุ่นและสุขภาพของคุณดีขึ้นเพียงทานอาหารและออกกำลังกาย 
                        อย่างเหมาะสมตามที่กำหนดให้ โดยสมาคมกีฬาเพาะกายและฟิตเนสแห่งประเทศไทย
                        <br/><br/>
                        โดยสามารถเข้าไปศึกษาวิธีการทานอาหารและการออกกำลังกายทั้งหมดผ่านแอปได้ทันทีและสามารถกดร่วมกลุ่มเฟสบุ๊คนี้เพื่อติดตามข้อมูลกิจกรรม 
                        สอบถามข้อสงสัยการดูแลสุขภาพและพูดคุยกับนักกีฬาทีมชาติไทยได้
                      `
                    : ` การลงทะเบียนของคุณได้รับการดำเนินการโดยสมบูรณ์เรียบร้อยแล้ว หากคุณดูรายละเอียดเพิ่มเติม สามารถเข้าไปดูได้ที่ 
                        <a href="${baseUrl}/app/invoice" target="_blank" >รายละเอียด</a><br/>
                      `;
    const mainLink = product_id === "tbpa" ? `https://facebook.com/groups/onlineforTHAIFIT` : `${baseUrl}/app/main`;
    const mainButtonLabel = product_id ? "คลิกที่นี่" : "เข้าใช้ระบบ";

                      

    sendHtmlMail(to, from, subject, content, mainLink, mainButtonLabel);
        
}

const getInvoiceStatement = (user_id, create_time, transaction) => {
    const { amount: {total}, item_list: {items} } = transaction;
    const vat_rate = 7;
    const invoiceDetailStatement = getInvoiceDetailState(items);
    return (`
        select @newInvoiceNumber := CONCAT(
            YEAR(NOW()),  
            IF(STRCMP(SUBSTRING(param_value, 1, 4), YEAR(NOW())) = 0,
                LPAD(CAST(SUBSTRING(param_value, 5, 6) as UNSIGNED) + 1, 6, '0'),
                LPAD('1', 6, '0')
            )
        ) as new_invoice_number
        from system_param 
        where param_name = 'current_invoice';
        
        INSERT INTO invoice SET 
        invoice_id = @newInvoiceNumber,
        transaction_date = '${create_time}',
        user_id = '${user_id}',
        total = ${total},
        vat_rate = ${vat_rate};
        
        ${invoiceDetailStatement}
        
        UPDATE system_param SET param_value = @newInvoiceNumber WHERE param_name = 'current_invoice';
    `
    );
}

const getTempInvoiceStatement = (user_id, program_id, create_time, transaction) => {
    const { amount: {total}, item_list: {items} } = transaction;
    const vat_rate = 7;
    const invoiceDetailStatement = getInvoiceDetailState(items, true);
    return (`
        select @newInvoiceNumber := UUID();
        
        INSERT INTO invoice_temp SET 
        invoice_id = @newInvoiceNumber,
        transaction_date = '${create_time}',
        user_id = '${user_id}',
        program_id = '${program_id}',
        total = ${total},
        vat_rate = ${vat_rate};
        
        ${invoiceDetailStatement};
    `
    );
}

const getInvoiceDetailState = (items, isTemp = false) => {
    return items.reduce((acc, item, index) => (
        `
            ${acc}
            INSERT INTO invoice_detail${isTemp ? '_temp': ''} SET
            detail_order = ${index + 1},
            invoice_id = @newInvoiceNumber,
            item_name = '${item.name}',
            quantity = ${item.quantity},
            price = ${item.price};
        `
    ), "");
}
