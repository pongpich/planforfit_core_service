import * as dynamoDbLib from "../../lib/dynamodb-lib";
import { success, failure } from "../../lib/response-lib";
import AWS from "aws-sdk";

export async function onConnect(event) {
  const { connectionId } = event.requestContext;
  const params = {
    TableName: process.env.tableName,
    Item: {
      connectionId
    }
  };

  try {
    console.log("before execute:", params);
    const result = await dynamoDbLib.call("put", params);
    console.log("after execute:", result);
    return success({ results: "connected" });
  } catch (error) {
    console.log("after error:", error);
    return failure({ error: `Failed to connect: ${JSON.stringify(error)}` });
  }
}

export async function onDisconnect(event) {
  const params = {
    TableName: process.env.tableName,
    Key: {
      connectionId: event.requestContext.connectionId
    }
  };

  try {
    await dynamoDbLib.call("delete", params);
    return success({ results: "Disconnected" });
  } catch (error) {
    return failure({ error: `Failed to disconnect: ${JSON.stringify(error)}` });
  }
}

export async function sendStatus(event) {
  let connectionData;
  const TABLE_NAME = process.env.tableName;

  try {
    const params = {
      TableName: TABLE_NAME,
      ProjectionExpression: "connectionId"
    };
    connectionData = await dynamoDbLib.call("scan", params);
  } catch (error) {
    return failure(error);
  }

  const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: event.requestContext.domainName + "/" + event.requestContext.stage
  });

  const postData = JSON.parse(event.body).data;

  const postCalls = connectionData.Items.map(async ({ connectionId }) => {
    try {
      await apigwManagementApi
        .postToConnection({ ConnectionId: connectionId, Data: postData })
        .promise();
    } catch (e) {
      if (e.statusCode === 410) {
        console.log(`Found stale connection, deleting ${connectionId}`);
        const delParams = { TableName: TABLE_NAME, Key: { connectionId } };
        await dynamoDbLib.call("delete", delParams);
      } else {
        throw e;
      }
    }
  });

  try {
    await Promise.all(postCalls);
  } catch (e) {
    return failure(e);
  }

  return success("Data Sent");
}


export async function sendTasks(event) {
  let coachTasksData;
  let connectionData;
  const TABLE_NAME = process.env.tableName;
  const WP_TABLE_NAME = process.env.weekPlanTableName;
  const { action, data:{coachId, coachName, userId} } = JSON.parse(event.body);
  const { domainName, stage } = event.requestContext;

  try {
    const updateParams = {
      TableName: WP_TABLE_NAME,
      Key:{
        coachId
      },
      UpdateExpression: "set coachName = :cn, userId = :u",
      ExpressionAttributeValues:{
        ":cn":coachName,
        ":u":userId
      },
      ReturnValues:"UPDATED_NEW"
    };
    await dynamoDbLib.call("update", updateParams);
    const wpParams = {
      TableName: WP_TABLE_NAME,
      ProjectionExpression: "coachId, coachName, userId"
    };
    coachTasksData = await dynamoDbLib.call("scan", wpParams);
    const params = {
      TableName: TABLE_NAME,
      ProjectionExpression: "connectionId"
    };
    connectionData = await dynamoDbLib.call("scan", params);
  } catch (error) {
    console.log("catch of update and scan:", error);
    return failure(error);
  }

  const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: domainName + "/" + stage
  });

  const postCalls = connectionData.Items.map(async ({ connectionId }) => {
    try {
      await apigwManagementApi
        .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify({
          action, 
          Items:coachTasksData.Items
        }) })
        .promise();
    } catch (e) {
      if (e.statusCode === 410) {
        console.log(`Found stale connection, deleting ${connectionId}`);
        const delParams = { TableName: TABLE_NAME, Key: { connectionId } };
        await dynamoDbLib.call("delete", delParams);
      } else {
        console.log("in semi-final catch:", e);
        throw e;
      }
    }
  });

  try {
    console.log("before send all message:", postCalls);
    await Promise.all(postCalls);
  } catch (e) {
    console.log("in final catch:", e);
    return failure(e);
  }

  return success("Data Sent");
}

export async function removeTask(event) {
  let coachTasksData;
  let connectionData;
  const TABLE_NAME = process.env.tableName;
  const WP_TABLE_NAME = process.env.weekPlanTableName;
  const { action, data: {coachId} } = JSON.parse(event.body);
  const { domainName, stage } = event.requestContext;

  try {
    const updateParams = {
      TableName: WP_TABLE_NAME,
      Key:{
        coachId
      }
    };
    await dynamoDbLib.call("delete", updateParams);
    const wpParams = {
      TableName: WP_TABLE_NAME,
      ProjectionExpression: "coachId, coachName, userId"
    };
    coachTasksData = await dynamoDbLib.call("scan", wpParams);
    const params = {
      TableName: TABLE_NAME,
      ProjectionExpression: "connectionId"
    };
    connectionData = await dynamoDbLib.call("scan", params);
  } catch (error) {
    console.log("catch of update and scan:", error);
    return failure(error);
  }

  const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: domainName + "/" + stage
  });

  const postCalls = connectionData.Items.map(async ({ connectionId }) => {
    try {
      await apigwManagementApi
        .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify({
          action, 
          Items:coachTasksData.Items
        }) })
        .promise();
    } catch (e) {
      if (e.statusCode === 410) {
        console.log(`Found stale connection, deleting ${connectionId}`);
        const delParams = { TableName: TABLE_NAME, Key: { connectionId } };
        await dynamoDbLib.call("delete", delParams);
      } else {
        console.log("in semi-final catch:", e);
        throw e;
      }
    }
  });

  try {
    console.log("before send all message:", postCalls);
    await Promise.all(postCalls);
  } catch (e) {
    console.log("in final catch:", e);
    return failure(e);
  }

  return success("Data Sent");
}
