import { query, transaction as batchQuery } from "../../lib/dbhelper";
import { genActivitiesInsertState } from "../../lib/someSQLs";
import { getUser } from "../../lib/cognito-lib";
import { sendHtmlMail, simpleTemplate, registerTemplate } from "../../lib/mail-helper";
import { getUrlPart } from "../../lib/Utils";
import { success, failure } from "../../lib/response-lib";
import sgMail from '@sendgrid/mail';

sgMail.setApiKey(process.env.SENDGRID_API_KEY);
/* 
export async function batchSubscription(event) {
  try {
    const { users } = JSON.parse(event.body);
    let queries = [];
    let mailList = [];
    users.forEach(({ user_id, program_id, product_id, payment_status, email }) => {
      const query = `
          UPDATE subscription SET payment_status = '${payment_status}' 
          WHERE user_id= '${user_id}' AND program_id = '${program_id}';
          ${calculateProgramPeriod(user_id, program_id, product_id)}
          ${getAddInvoiceFromTempStatement(user_id, program_id)}
          ${genActivitiesInsertState(user_id, product_id)}
        `;
      queries.push(query);
      mailList.push({
        email
      });
    });
    let queryResult;
    if (queries.length > 0) {
      queryResult = await batchQuery(queries);
    }

    if (mailList.length > 0) {
      const sendgridCalls = mailList.map( async (elem) => 
        {
          try {
            await sendRegisterMail(elem.email);
          } catch (error) {
            throw error;
          }
        }
      );

      try {
        await Promise.all(sendgridCalls);
      } catch (error) {
        return failure(error)
      }
    }

    return queryResult;
  } catch (error) {
    return error;
  }

}
 */
export async function subscription(event) {
    const { user_id, program_id, product_id, payment_status } = JSON.parse(event.body);
    
    const queryString = `
            UPDATE subscription SET payment_status = '${payment_status}' 
            WHERE user_id= '${user_id}' AND program_id = '${program_id}';
        `;

    try {
        let result = null;
        if (payment_status === "approved") {
            const invoiceQuery = getAddInvoiceFromTempStatement(user_id, program_id);
            const programPeriodQuery = product_id === 'ccr' 
                                        ? calculateMondayStartProgramPeriod(user_id, program_id, product_id)
                                        : calculateProgramPeriod(user_id, program_id, product_id);
            let urlPart = product_id === 'bemoove' 
                          ? 'bemoove.co'
                          : product_id === 'tbpa'
                            ? 'tbpa.asia'
                            : 'ccrdiet.co';
            if (product_id === 'bemoove' || product_id === 'tbpa') {
              const createFirstActivityQuery = genActivitiesInsertState(user_id, product_id);
              result = await batchQuery([queryString, programPeriodQuery, invoiceQuery, createFirstActivityQuery]);
            } else {
              result = await batchQuery([queryString, programPeriodQuery, invoiceQuery]);
            }
            const cognitoUser = await getUser(user_id);
            sendMail(cognitoUser, urlPart);
        } else {
            result = await query(queryString);
        }

        return result;
    } catch (error) {
        return error;
    }
}

export async function updateHomework(event) {
  const { 
    act_id, 
    weekly_plan: {
      coach_id, 
      coach_name,
      weekly_exercise_score,
      nutrition_note,
      exercise_note
    } 
  } = JSON.parse(event.body);

  const oldActivitiesStatement = ` 
		'$.weekly_plan.status', 'complete',
		'$.weekly_plan.next_week_coach_id', '${coach_id}',
		'$.weekly_plan.next_week_coach_name', '${coach_name}',
		'$.weekly_plan.exercise_plan.next_week_exercise_score', ${weekly_exercise_score},
		'$.weekly_plan.next_week_nutrition_note', '${nutrition_note}',
		'$.weekly_plan.next_week_exercise_note', '${exercise_note}'`

  const updateOldHWQuery = `
    UPDATE daily_activity SET activities = JSON_SET(activities, 
      ${oldActivitiesStatement}
    )
    where act_id = ${act_id};
  `;

  const newActivitiesStatement = ` 
		'$.weekly_plan.status', 'init',
		'$.weekly_plan.coach_id', '${coach_id}',
		'$.weekly_plan.coach_name', '${coach_name}',
		'$.weekly_plan.exercise_plan.weekly_exercise_score', ${weekly_exercise_score},
		'$.weekly_plan.nutrition_note', '${nutrition_note}',
		'$.weekly_plan.exercise_note', '${exercise_note}',
    '$.daily_activities[0].date', SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY),
    '$.daily_activities[1].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 1 DAY),
    '$.daily_activities[2].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 2 DAY),
    '$.daily_activities[3].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 3 DAY),
    '$.daily_activities[4].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 4 DAY),
    '$.daily_activities[5].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 5 DAY),
    '$.daily_activities[6].date', ADDDATE(SUBDATE(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 6 DAY)`
  const updateNewHWQuery = `
    SELECT @user_id := user_id, @program_id := program_id, @new_week := week_in_program+1
    FROM daily_activity
    WHERE act_id = ${act_id};
    
    UPDATE daily_activity 
    SET activities = JSON_SET(activities, 
        ${newActivitiesStatement}
      )
    WHERE user_id=@user_id AND program_id=@program_id AND week_in_program=@new_week;

    INSERT INTO daily_activity (user_id, program_id, week_in_program, activities )
    SELECT da.user_id, da.program_id, da.week_in_program + 1, 
      JSON_SET(tem.template,
        ${newActivitiesStatement}
      )
    FROM daily_activity da JOIN program pg 
      ON da.program_id = pg.program_id JOIN activity_template tem
      ON pg.product_id = tem.product_id
    where act_id = ${act_id} AND ROW_COUNT() = 0;
  `;
  
  try {
    const result = await batchQuery([updateOldHWQuery, updateNewHWQuery]);

    return result;
  } catch (error) {
      return error;
  }
}

export async function updateCCRHomework(event) {
  const { 
    act_id, 
    weekly_plan: {
      note,
      coach_id, 
      coach_name,
      plan: {
        food: {
          fat,
          protein,
          carbohydrate
        },
        cardio,
        nutrients_week,
        auto_plans
      }
    },
    change_mode = false,
    goal
  } = JSON.parse(event.body);

  const oldActivitiesStatement = ` 
		'$.weekly_plan.status', 'complete',
		'$.weekly_plan.next_week_coach_id', '${coach_id}',
		'$.weekly_plan.next_week_coach_name', '${coach_name}',
		'$.weekly_plan.next_week_note', '${note}'`

  const updateOldHWQuery = `
    UPDATE daily_activity SET activities = JSON_SET(activities, 
      ${oldActivitiesStatement}
    )
    where act_id = ${act_id};
  `;

  const auto_plans_string = JSON.stringify(auto_plans);

  const newActivitiesStatement = ` 
		'$.weekly_plan.status', 'init',
		'$.weekly_plan.coach_id', '${coach_id}',
		'$.weekly_plan.coach_name', '${coach_name}',
    '$.weekly_plan.note', '${note}',
    '$.weekly_plan.plan.food.fat', ${fat},
    '$.weekly_plan.plan.food.protein', ${protein},
    '$.weekly_plan.plan.food.carbohydrate', ${carbohydrate},
    '$.weekly_plan.plan.cardio', ${cardio},
    '$.weekly_plan.plan.nutrients_week', ${nutrients_week},
    '$.weekly_plan.plan.auto_plans', CAST(@auto_plans AS JSON)
  `; 
  let updateNewHWQuery = `
    SELECT @user_id := user_id, @program_id := program_id, @new_week := week_in_program+1
    FROM daily_activity
    WHERE act_id = ${act_id};
    
    SET @auto_plans = '${auto_plans_string}';
    UPDATE daily_activity 
    SET activities = JSON_SET(activities, 
        ${newActivitiesStatement}
      )
    WHERE user_id=@user_id AND program_id=@program_id AND week_in_program=@new_week;
  `;

  if (change_mode) {
    updateNewHWQuery += "CALL ccrChangeMode(@user_id, @new_week);"
  }

  if (goal !== "same") {
    updateNewHWQuery += ` UPDATE health_profile
                          SET base_info = JSON_SET(base_info,
                                '$.goal', '${goal}'
                              )
                          WHERE user_id = @user_id
                            AND product_id = 'ccr';
                        `
  }
  
  try {
    const result = await batchQuery([updateOldHWQuery, updateNewHWQuery]);

    return result;
  } catch (error) {
    console.log("when update ccr homework, the reason of error:", error);
    return error;
  }
}

const sendRegisterMail = (email) => {
  return new Promise(async (resolve, reject) => {
    const to = email;
    const from = "contact@tbpa.asia";
    const subject = "การลงทะเบียน และชำระเงินสำเร็จแล้ว!";
    const html = registerTemplate();    
    const msg = {
        to,
        from,
        subject,
        html,
      };
    try {
      const sendResult = await sgMail.send(msg);
      resolve(sendResult);
    } catch (error) {
      reject(error);
    }
  })
}

const sendMail = async (cognitoUser, urlPart) => {
  const baseUrl = process.env.STAGE === "prod" 
                      ? `https://${urlPart}` 
                      : process.env.STAGE === "dev"
                          ? `https://staging.${urlPart}`
                          : "http://localhost:3000";
    const to =   (
                        cognitoUser.UserAttributes.find
                            (attribute => attribute.Name === "email") || ""
                    )
                    .Value || "";
    const from = "contact@planforfit.com";
    const subject = "การลงทะเบียน และชำระเงินสำเร็จแล้ว!"
    const content = `การสั่งซื้อของคุณได้รับการดำเนินการโดยสมบูรณ์เรียบร้อยแล้ว หากคุณต้องการตรวจรับใบเสร็จ สามารถเข้าไปดูได้ที่ 
                     <a href="${baseUrl}/app/invoice" target="_blank" >ใบเสร็จรับเงิน</a><br/>
                     และคุณสามารถเข้าไปใช้งานระบบได้โดยคลิกปุ่มต่อไปนี้
                    `
    const mainLink = `${baseUrl}/app/main`;
    const mainButtonLabel = "Moove";
    
    sendHtmlMail(to, from, subject, content, mainLink, mainButtonLabel);
        
}

const getAddInvoiceFromTempStatement = (user_id, program_id) => {
    return `
        select @newInvoiceNumber := CONCAT(
            YEAR(NOW()),  
            IF(STRCMP(SUBSTRING(param_value, 1, 4), YEAR(NOW())) = 0,
                LPAD(CAST(SUBSTRING(param_value, 5, 6) as UNSIGNED) + 1, 6, '0'),
                LPAD('1', 6, '0')
            )
        ) as new_invoice_number
        from system_param 
        where param_name = 'current_invoice';

        INSERT INTO invoice (invoice_id, transaction_date, user_id, total, vat_rate) 
        SELECT @newInvoiceNumber, transaction_date, user_id, total, vat_rate
        FROM invoice_temp
        WHERE user_id = '${user_id}' AND program_id = '${program_id}'
        ORDER BY created_at desc 
        LIMIT 0, 1;

        INSERT INTO invoice_detail (detail_order, invoice_id, item_name, quantity, price)
        SELECT detail_order, @newInvoiceNumber, det.item_name, det.quantity, det.price
        FROM invoice_detail_temp det JOIN (
        	SELECT * 
        	FROM invoice_temp 
        	WHERE user_id = '${user_id}' 
        		AND program_id = '${program_id}'
        	ORDER BY created_at desc
        	LIMIT 0, 1
        ) AS tmp
        ON det.invoice_id = tmp.invoice_id;

        UPDATE system_param SET param_value = @newInvoiceNumber WHERE param_name = 'current_invoice';
    `;
}

const calculateProgramPeriod = (user_id, program_id, product_id) => (
  `
  INSERT INTO health_profile 
    (user_id, product_id, base_info, main_info, program_id, start_date, expire_date)
  SELECT '${user_id}', '${product_id}', '{}', '[]', '${program_id}', pp.start_date, pp.expire_date
  FROM (
    SELECT 
    CASE 
      WHEN hp.start_date IS NOT NULL THEN hp.start_date
      WHEN pg.period IS NOT NULL AND period > 0 THEN NOW()
      WHEN pg.program_start_date IS NOT NULL THEN pg.program_start_date
      ELSE NOW()
    END AS start_date,
    CASE
      WHEN hp.expire_date IS NOT NULL AND hp.expire_date >= NOW() THEN 
        CASE
          WHEN pg.period IS NOT NULL AND period > 0 THEN DATE_ADD(hp.expire_date, INTERVAL pg.period DAY)
          ELSE DATE_ADD(hp.expire_date, INTERVAL 60 DAY)
        END
      WHEN pg.period IS NOT NULL AND period > 0 THEN DATE_ADD(NOW(), INTERVAL pg.period DAY)
      WHEN pg.program_expire_date IS NOT NULL AND pg.program_expire_date >= NOW() THEN pg.program_expire_date
      ELSE DATE_ADD(NOW(), INTERVAL 60 DAY)
    END AS expire_date
    FROM program pg LEFT JOIN health_profile hp
      ON hp.program_id = pg.program_id
      AND hp.user_id = '${user_id}' 
    WHERE pg.program_id = '${program_id}'
  ) AS pp
  ON DUPLICATE KEY UPDATE expire_date = pp.expire_date;
  `
)


const calculateMondayStartProgramPeriod = (user_id, program_id, product_id) => (
  `
  INSERT INTO health_profile 
    (user_id, product_id, base_info, main_info, program_id, start_date, expire_date)
  SELECT '${user_id}', '${product_id}', '{}', '[]', '${program_id}', pp.start_date, pp.expire_date
  FROM (
    SELECT 
    CASE 
      WHEN hp.start_date IS NOT NULL THEN hp.start_date
      WHEN pg.period IS NOT NULL AND period > 0 THEN getMondayStartDate(CURDATE())
      WHEN pg.program_start_date IS NOT NULL THEN pg.program_start_date
      ELSE getMondayStartDate(CURDATE())
    END AS start_date,
    CASE
      WHEN hp.expire_date IS NOT NULL AND hp.expire_date >= NOW() THEN 
        CASE
          WHEN pg.period IS NOT NULL AND period > 0 THEN DATE_ADD(hp.expire_date, INTERVAL pg.period DAY)
          ELSE DATE_ADD(hp.expire_date, INTERVAL 60 DAY)
        END
      WHEN pg.period IS NOT NULL AND period > 0 THEN DATE_ADD(getMondayStartDate(CURDATE()), INTERVAL pg.period DAY)
      WHEN pg.program_expire_date IS NOT NULL AND pg.program_expire_date >= NOW() THEN pg.program_expire_date
      ELSE DATE_ADD(getMondayStartDate(CURDATE()), INTERVAL 60 DAY)
    END AS expire_date
    FROM program pg LEFT JOIN health_profile hp
      ON hp.program_id = pg.program_id
      AND hp.user_id = '${user_id}' 
    WHERE pg.program_id = '${program_id}'
  ) AS pp
  ON DUPLICATE KEY UPDATE expire_date = pp.expire_date;
  `
)

