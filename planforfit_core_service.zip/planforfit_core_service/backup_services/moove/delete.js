import { query } from "../../lib/dbhelper";

export async function program(event) {
  const{
    program_id
  } = JSON.parse(event.body);

  try {
    const queryString = `
      DELETE FROM program WHERE program_id='${program_id}';
    `
    const result = await query(queryString);
    return result;
  } catch (error) {
    return error;
  }
}
