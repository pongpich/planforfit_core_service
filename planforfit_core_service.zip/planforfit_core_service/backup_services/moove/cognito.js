export function preSignUp(event, context, callback) {

    // Confirm the user
    event.response.autoConfirmUser = true;

    // Set the email as verified if it is in the request
    if (event.request.userAttributes.hasOwnProperty("email")) {
        event.response.autoVerifyEmail = true;
    }

    // Set the phone number as verified if it is in the request
    if (event.request.userAttributes.hasOwnProperty("phone_number")) {
        event.response.autoVerifyPhone = true;
    }

    // Return to Amazon Cognito
    callback(null, event);
}

export function customMessage(event, context, callback) {
    const { triggerSource, callerContext } = event;
    if (triggerSource === "CustomMessage_ForgotPassword") {
        const linkSuffix = `forgot-password?state=code_sent&email=${encodeURIComponent(event.request.userAttributes.email)}&confirm_code=${event.request.codeParameter}`;
        let link;
        let mailSubject;
        let mailContent;
        switch (callerContext.clientId) {
            case "5228tmjdo4o5e0rkgaq8i0nk69":
                //moove-dev
                link = `https://staging.bemoove.co/${linkSuffix}`;
                mailSubject = "Resetting Your Moove Password";
                mailContent = mooveMailContent(link);
                break;
            case "7u7ja96josunv3oikcflcuhk1h":
                //moove-prod
                link = `https://bemoove.co/${linkSuffix}`;
                mailSubject = "Resetting Your Moove Password";
                mailContent = mooveMailContent(link);
                break;
            case "5vm6nnt6fj2raivp1fovlhdd63":
                //ccr-dev
                link = `https://staging.ccrdiet.co/${linkSuffix}`;
                mailSubject = "Resetting Your CCR Password";
                mailContent = ccrMailContent(link);
                break;
            case "2i1b1e5sag1hvc2sr008v6hpf":
                //ccr-prod
                link = `https://ccrdiet.co/${linkSuffix}`;
                mailSubject = "Resetting Your CCR Password";
                mailContent = ccrMailContent(link);
                break;
            case "5k53c50e34e1r2cbjfmo566nts":
                //tbpa-dev
                link = `https://staging.tbpa.asia/${linkSuffix}`;
                mailSubject = "Resetting Your THAI FIT Password";
                mailContent = tbpaMailContent(link,event.request.codeParameter);
                break;
            case "7cj07f48ehe6qa38fjiptffp2u":
                //tbpa-prod
                link = `https://tbpa.asia/${linkSuffix}`;
                mailSubject = "Resetting Your THAI FIT Password";
                mailContent = tbpaMailContent(link,event.request.codeParameter);
                break;
            default:
                // default is moove-dev
                link = `https://staging.bemoove.co/${linkSuffix}`;
                mailSubject = "Resetting Your Moove Password";
                mailContent = mooveMailContent(link);
                break;
        }

        event.response.emailSubject = mailSubject;
        event.response.emailMessage = mailContent;
        // Create custom message for other events
    }

    // Return to Amazon Cognito
    callback(null, event);
}

const mooveMailContent = (link) => (
    `
        <div leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:auto !important;width:100% !important; font-family: Helvetica,Arial,sans-serif !important; margin-bottom: 40px;">
            <center>
                <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" style="max-width:600px; background-color:#ffffff;border:1px solid #e4e2e2;border-collapse:separate !important; border-radius:4px;border-spacing:0;color:#242128; margin:0;padding:40px;"
                    heigth="auto">
                    <tbody>
                        <tr>
                            <td colSpan="2" style="padding-top:10px;">
                                <h3 style="color:#303030; font-size:18px; line-height: 1.6; font-weight:500;">แก้ไขรหัสผ่าน</h3>
                                <p style="color:#8f8f8f; font-size: 14px; padding-bottom: 20px; line-height: 1.4;">
                                    ขอให้คุณทำการคลิกที่ปุ่มข้างล่างนี้เพื่อเข้าไปทำการเปลี่ยนแปลงรหัสผ่านสำหรับเข้าใช้ระบบของคุณได้เลย
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan="2">
                                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse;">
                                    <tbody>
                                        <tr>
                                            <td style="padding:15px 0px;" valign="top" align="center">
                                                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate !important;">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center" valign="middle" style="padding:13px;">
                                                                <a 
                                                                    href="${link}" 
                                                                    title="แก้ไขรหัสผ่าน" 
                                                                    target="_blank" 
                                                                    style="font-size: 14px; line-height: 1.5; font-weight: 700; letter-spacing: 1px; padding: 15px 40px; text-align:center; text-decoration:none; color:#FFFFFF; border-radius: 50px; background-color:#922c88;"
                                                                >
                                                                    แก้ไขรหัสผ่าน
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="margin-top:30px; padding-bottom:20px;; margin-bottom: 40px;">
                    <tbody>
                        <tr>
                            <td align="center" valign="center">
                                <p style="font-size: 12px; text-decoration: none;line-height: 1; color:#909090; margin-top:0px; margin-bottom:5px; ">
                                    บริษัท ฟิต ทูเกทเธอร์ จำกัด (สำนักงานใหญ่) 11/17 ซอยร่วมฤดี แขวงลุมพินี เขตปทุมวัน กรุงเทพฯ 10330
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </center>
        </div>
    `
)

const tbpaMailContent = (link,codeParameter) => (
    `
        <div leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:auto !important;width:100% !important; font-family: Helvetica,Arial,sans-serif !important; margin-bottom: 40px;">
            <center>
                <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" style="max-width:600px; background-color:#ffffff;border:1px solid #e4e2e2;border-collapse:separate !important; border-radius:4px;border-spacing:0;color:#242128; margin:0;padding:40px;"
                    heigth="auto">
                    <tbody>
                        <tr>
                            <td colSpan="2" style="padding-top:10px;">
                                <h3 style="color:#303030; font-size:18px; line-height: 1.6; font-weight:500;"> ลืมรหัสผ่าน </h3>
                                <p style="color:#8f8f8f; font-size: 14px; padding-bottom: 20px; line-height: 1.4;">
                                  ขอให้คุณทำการคลิกที่ปุ่มข้างล่างนี้เพื่อเข้าไปทำการเปลี่ยนแปลงรหัสผ่านสำหรับเข้าใช้ระบบของคุณได้เลย
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan="2">
                                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse;">
                                    <tbody>
                                        <tr>
                                            <td style="padding:15px 0px;" valign="top" align="center">
                                                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate !important;">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center" valign="middle" style="padding:13px;">
                                                                <a 
                                                                    href="${link}" 
                                                                    title="แก้ไขรหัสผ่าน" 
                                                                    target="_blank" 
                                                                    style="font-size: 14px; line-height: 1.5; font-weight: 700; letter-spacing: 1px; padding: 15px 40px; text-align:center; text-decoration:none; color:#FFFFFF; border-radius: 50px; background-color:#922c88;"
                                                                >
                                                                    แก้ไขรหัสผ่าน
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="margin-top:10px; padding-bottom:10px;">
                    <tbody>
                        <tr>
                            <td align="center" valign="center"  >
                                <a 
                                    href="${link}" 
                                    title="แก้ไขรหัสผ่าน" 
                                    target="_blank" 
                                    style="font-size: 12px; text-decoration: none;line-height: 1; color:#909090; margin-top:0px; margin-bottom:5px; "
                                >
                                    สำหรับท่านที่พบปัญหา (ดำเนินการผ่านทางเว็บไซต์ คลิก)
                                </a>
                            </td> 
                        </tr>
                    </tbody>
                </table>
                <table style="margin-top:30px; padding-bottom:20px;; margin-bottom: 40px;">
                    <tbody>
                        <tr>
                            <td align="center" valign="center">
                                <p style="font-size: 12px; text-decoration: none;line-height: 1; color:#909090; margin-top:0px; margin-bottom:5px; ">
                                    บริษัท ฟิต ทูเกทเธอร์ จำกัด (สำนักงานใหญ่) 11/17 ซอยร่วมฤดี แขวงลุมพินี เขตปทุมวัน กรุงเทพฯ 10330
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </center>
        </div>
    `
)

const ccrMailContent = (link) => (
    `
      <div leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:auto !important;width:100% !important; font-family: Helvetica,Arial,sans-serif !important; margin-bottom: 40px;">
          <center>
              <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" style="max-width:600px; background-color:#ffffff;border:1px solid #e4e2e2;border-collapse:separate !important; border-radius:4px;border-spacing:0;color:#242128; margin:0;padding:40px;"
                  heigth="auto">
                  <tbody>
                      <tr>
                          <td colSpan="2" style="padding-top:10px;">
                              <h3 style="color:#303030; font-size:18px; line-height: 1.6; font-weight:500;">แก้ไขรหัสผ่าน</h3>
                              <p style="color:#8f8f8f; font-size: 14px; padding-bottom: 20px; line-height: 1.4;">
                                  ขอให้คุณทำการคลิกที่ปุ่มข้างล่างนี้เพื่อเข้าไปทำการเปลี่ยนแปลงรหัสผ่านสำหรับเข้าใช้ระบบของคุณได้เลย
                              </p>
                          </td>
                      </tr>
                      <tr>
                          <td colSpan="2">
                              <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse;">
                                  <tbody>
                                      <tr>
                                          <td style="padding:15px 0px;" valign="top" align="center">
                                              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate !important;">
                                                  <tbody>
                                                      <tr>
                                                          <td align="center" valign="middle" style="padding:13px;">
                                                              <a 
                                                                  href="${link}" 
                                                                  title="แก้ไขรหัสผ่าน" 
                                                                  target="_blank" 
                                                                  style="font-size: 14px; line-height: 1.5; font-weight: 700; letter-spacing: 1px; padding: 15px 40px; text-align:center; text-decoration:none; color:#FFFFFF; border-radius: 50px; background-color:#b50000;"
                                                              >
                                                                  แก้ไขรหัสผ่าน
                                                              </a>
                                                          </td>
                                                      </tr>
                                                  </tbody>
                                              </table>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                          </td>
                      </tr>
                  </tbody>
              </table>
              <table style="margin-top:30px; padding-bottom:20px;; margin-bottom: 40px;">
                  <tbody>
                      <tr>
                          <td align="center" valign="center">
                              <p style="font-size: 12px; text-decoration: none;line-height: 1; color:#909090; margin-top:0px; margin-bottom:5px; ">
                                  บริษัท ฟิต ทูเกทเธอร์ จำกัด (สำนักงานใหญ่) 11/17 ซอยร่วมฤดี แขวงลุมพินี เขตปทุมวัน กรุงเทพฯ 10330
                              </p>
                          </td>
                      </tr>
                  </tbody>
              </table>
          </center>
      </div>
  `
)
